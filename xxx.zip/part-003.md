# 新的开始

- 来源: https://chatgpt.com/g/g-p-6a5f4d3570688191a63c36d8624e43cc/c/6a5f4d4f-70a4-83ee-bd47-94f6ea917670
- 导出时间: 2026-07-25T16:41:44+09:00
- 分片: 3/3
- 总消息数: 404
- 总轮数: 143

## 第 101 轮

### 你

如果数据很多很长呢 或者每个月都不一样 每天都不一样 怎么写它的判定guiz

### ChatGPT

数据很多、很长、每天或每月变化时，不能把全部内容写成固定期待值；要把期待拆成“结构、范围、关系、汇总、时间和动态来源”几类规则。

### ChatGPT

对。**数据很多、内容很长、每天或每月都变化时，不应该逐条写固定期待值。**

正确做法是：

```text
不是规定“每条数据必须等于什么”
而是规定“这些数据必须满足什么条件”
```

也就是把Expected扩展成：

```text
Expected Condition / 期待条件
```

它既可以是固定值，也可以是结构、长度、范围、公式、时间条件、前后关系、汇总关系或动态取得的参考值。

---

# 一、三种主要判定方式

## 1. 固定值判定

适合不会变化的字段：

```yaml
selector: "$.status"
ruleType: "EXACT"
expectedValue: "SUCCESS"
```

判定：

```text
Current == SUCCESS
```

---

## 2. 条件判定

适合每天、每月变化的字段：

```yaml
selector: "$.transactionId"
ruleType: "PATTERN"
pattern: "^[0-9]{12}$"
```

不关心具体值，只关心：

```text
是否为12位数字
```

---

## 3. 动态期待值判定

期待值在执行时根据其他信息生成：

```yaml
selector: "$.businessDate"
ruleType: "EXPRESSION"
expectedExpression: "${runContext.businessDate}"
```

或者：

```yaml
selector: "$.customerId"
ruleType: "REFERENCE"
expectedReference: "${API1.response.customerId}"
```

这时Expected不是事先写死，而是在运行过程中解析出来。

---

# 二、数据很多时需要的规则分类

建议把判定规则分成以下九类。

## 1. Structure Rule：结构规则

验证整个数据结构是否正确：

```yaml
ruleType: "STRUCTURE"
rules:
  rootType: "OBJECT"
  requiredFields:
    - header
    - items
    - result
```

例如：

```text
header必须存在
items必须是数组
result必须是对象
```

---

## 2. Item Rule：明细统一规则

数组有十万条时，不需要写十万份规则。

写一份通用规则，应用到全部明细：

```yaml
target: "$.items[*]"

rules:
  - selector: "$.id"
    ruleType: "REQUIRED"

  - selector: "$.id"
    ruleType: "LENGTH"
    length: 12

  - selector: "$.amount"
    ruleType: "TYPE"
    expectedType: "DECIMAL"

  - selector: "$.amount"
    ruleType: "RANGE"
    minimum: 0
```

含义是：

> `items`中的每一条数据都必须满足同一组规则。

不是逐条写Expected。

---

## 3. Count Rule：件数规则

当具体数据不同，但件数有业务条件时：

```yaml
ruleType: "COUNT"
selector: "$.items"
minimum: 1
maximum: 100000
```

或者要求分页信息一致：

```yaml
ruleType: "EXPRESSION"
expression: "size($.items) == $.page.returnedCount"
```

---

## 4. Aggregate Rule：汇总规则

不要求知道每一条明细的固定值，但可以验证汇总关系。

例如：

```text
明细金额合计 = Header总金额
```

```yaml
ruleType: "AGGREGATE"
operator: "SUM_EQUALS"
sourceSelector: "$.items[*].amount"
expectedReference: "$.header.totalAmount"
```

也可以验证：

```text
成功件数 + 失败件数 = 总件数
```

```yaml
ruleType: "EXPRESSION"
expression: >
  $.summary.successCount
  + $.summary.failureCount
  == $.summary.totalCount
```

这类规则对大量动态数据非常重要。

---

## 5. Relationship Rule：数据关系规则

检查数据之间是否符合关系，而不是检查具体值。

例如ID不能重复：

```yaml
ruleType: "UNIQUE"
selector: "$.items[*].transactionId"
```

例如明细customerId必须与Header一致：

```yaml
ruleType: "ALL_EQUAL_REFERENCE"
selector: "$.items[*].customerId"
expectedReference: "$.header.customerId"
```

例如子记录必须能找到父记录：

```yaml
ruleType: "REFERENCE_INTEGRITY"
childSelector: "$.details[*].orderId"
parentSelector: "$.orders[*].orderId"
```

---

## 6. Temporal Rule：日期时间规则

每天、每月变化的数据，通常应该根据执行上下文判断。

### 必须是当天

```yaml
ruleType: "TEMPORAL"
selector: "$.processingDate"
operator: "EQUAL_BUSINESS_DATE"
expectedReference: "${runContext.businessDate}"
```

### 必须属于目标月份

```yaml
ruleType: "TEMPORAL"
selector: "$.items[*].targetDate"
operator: "IN_MONTH"
expectedReference: "${runContext.targetMonth}"
```

例如执行月份是：

```text
2026-07
```

允许：

```text
2026-07-01
2026-07-15
2026-07-31
```

不允许：

```text
2026-06-30
2026-08-01
```

### 必须在执行时间范围内

```yaml
ruleType: "TEMPORAL"
selector: "$.processedAt"
operator: "BETWEEN"
from: "${runContext.startedAt}"
to: "${runContext.finishedAt}"
```

---

## 7. Derived Rule：计算期待值

期待值可以由其他数据计算出来。

例如：

```text
税后金额 = 税前金额 + 税额
```

```yaml
ruleType: "EXPRESSION"
expression: >
  $.amountWithTax
  == $.amountWithoutTax + $.taxAmount
```

例如：

```text
结束余额 = 开始余额 + 入金 - 出金
```

```yaml
ruleType: "EXPRESSION"
expression: >
  $.closingBalance
  == $.openingBalance
  + $.depositAmount
  - $.withdrawalAmount
```

这时完全不需要写固定Expected Value。

---

## 8. Dynamic Reference Rule：动态参考值

Expected可以来自：

```text
前一个API
数据库
文件
其他字段
执行Context
计算式
其他系统API
```

例如第二个API的customerId必须与第一个API一致：

```yaml
ruleType: "REFERENCE"
selector: "$.customerId"
expectedReference: "${API1.response.customerId}"
```

例如API返回金额必须与DB一致：

```yaml
ruleType: "REFERENCE"
selector: "$.totalAmount"

expectedSource:
  type: "SQL"
  queryId: "SQL-EXPECTED-TOTAL-001"
  parameters:
    customerId: "${runContext.customerId}"
    businessDate: "${runContext.businessDate}"
```

运行时先取得Expected，再执行比较。

如果SQL本身执行失败：

```yaml
result: "BLOCKED"
reasonCode: "EXPECTED_SOURCE_UNAVAILABLE"
```

不能将其误判为API返回值错误。

---

## 9. Baseline Delta Rule：变化范围规则

每天或每月不同，但变化不能太异常时，可以与前日、前月比较变化率。

例如：

```text
本月件数与上月相比，变化不能超过30%
```

```yaml
ruleType: "BASELINE_DELTA"
selector: "$.summary.totalCount"

baselineReference: "${previousMonth.summary.totalCount}"

rule:
  deltaType: "PERCENTAGE"
  maximumIncreasePercent: 30
  maximumDecreasePercent: 30
```

但是要注意：

> Baseline Delta通常是异常检测，不一定代表业务正确性。

因此可以设为警告规则：

```yaml
required: false
severity: "MINOR"
```

结果可以是：

```yaml
verification:
  result: "PASS"

warnings:
  - reasonCode: "MONTHLY_COUNT_DELTA_EXCEEDED"
    severity: "MINOR"
```

仍然不使用`PASS_WITH_WARNING`这个新Result。

---

# 三、每个月都不一样的完整例子

假设API每月返回当月交易记录：

```json
{
  "targetMonth": "2026-07",
  "totalCount": 2,
  "totalAmount": 3000,
  "items": [
    {
      "transactionId": "202607000001",
      "transactionDate": "2026-07-05",
      "amount": 1000
    },
    {
      "transactionId": "202607000002",
      "transactionDate": "2026-07-20",
      "amount": 2000
    }
  ]
}
```

不应该写：

```text
第一条必须是1000
第二条必须是2000
```

应该写：

```yaml
verification:
  id: "VER-MONTHLY-TRANSACTION-001"
  targetMonth: "${runContext.targetMonth}"

  rules:
    - id: "RULE-001"
      ruleType: "REFERENCE"
      selector: "$.targetMonth"
      expectedReference: "${runContext.targetMonth}"
      required: true

    - id: "RULE-002"
      ruleType: "COUNT"
      selector: "$.items"
      minimum: 1
      required: true

    - id: "RULE-003"
      ruleType: "EXPRESSION"
      expression: "size($.items) == $.totalCount"
      required: true

    - id: "RULE-004"
      ruleType: "UNIQUE"
      selector: "$.items[*].transactionId"
      required: true

    - id: "RULE-005"
      ruleType: "PATTERN"
      selector: "$.items[*].transactionId"
      pattern: "^[0-9]{12}$"
      required: true

    - id: "RULE-006"
      ruleType: "TEMPORAL"
      selector: "$.items[*].transactionDate"
      operator: "IN_MONTH"
      expectedReference: "${runContext.targetMonth}"
      required: true

    - id: "RULE-007"
      ruleType: "RANGE"
      selector: "$.items[*].amount"
      minimum: 0
      required: true

    - id: "RULE-008"
      ruleType: "AGGREGATE"
      operator: "SUM_EQUALS"
      sourceSelector: "$.items[*].amount"
      expectedReference: "$.totalAmount"
      required: true
```

这样每个月具体数据不同也没有问题。

系统验证的是：

```text
月份正确
件数正确
ID格式正确
ID没有重复
日期属于目标月
金额合法
明细合计等于总金额
```

而不是固定比较每条内容。

---

# 四、数据特别长时怎么处理

例如数组有十万、百万条记录，设计上要区分：

```text
验证全部数据
报告有限数据
```

不能因为报告太长，就只验证前100条。

正确方式：

```text
全部记录执行规则
但报告只显示代表性错误
```

例如：

```yaml
executionPolicy:
  validationMode: "FULL_SCAN"
  stopMode: "COLLECT_ALL"

reportPolicy:
  maximumDetailedErrors: 100
  includeViolationCount: true
  includeFirstViolation: true
  includeLastViolation: true
  groupByRuleId: true
```

最终报告：

```text
检查记录数：1,000,000
失败记录数：12,350

RULE-005 ID长度错误：
  总件数：8,000
  详细表示：前100件

RULE-006 日期不属于目标月份：
  总件数：4,350
  详细表示：前100件
```

也就是说：

> **限制报告数量，不限制实际验证数量。**

只有业务明确允许抽样检查时，才能使用：

```yaml
validationMode: "SAMPLING"
```

而且必须标明：

```yaml
sampleSize: 1000
samplingMethod: "RANDOM"
```

抽样结果不能冒充全量验证结果。

---

# 五、超大固定内容可以使用Hash

如果内容虽然很大，但业务要求完全一致，可以：

```text
规范化
↓
生成Hash
↓
比较Hash
```

例如：

```yaml
ruleType: "CANONICAL_HASH"

normalization:
  ignorePaths:
    - "$.generatedAt"
    - "$.requestId"
  sortArraysBy:
    - "$.items[*].id"

hashAlgorithm: "SHA-256"

expectedHash: "..."
```

流程：

```text
Current
↓
去掉动态字段
↓
数组排序
↓
统一日期、数字格式
↓
生成Hash
↓
与Expected Hash比较
```

适合：

- 超大JSON。
- 大型配置。
- 大型Master数据。
- 顺序可能变化但内容应一致的数据。

不过Hash不容易直接说明哪里不同。

推荐采用两阶段：

```text
第一阶段：Hash快速比较

Hash不同
↓

第二阶段：详细Diff
```

---

# 六、第一个API成功，第二个API失败怎么判定

每个API必须独立保留：

```text
Execution Result
Verification Result
```

## API1正常

```yaml
apiStep:
  stepId: "STEP-001"

  execution:
    status: "SUCCEEDED"
    httpStatus: 200

  verification:
    result: "PASS"
```

## API2返回HTTP 500

如果API成功返回了Response，只是Status不符合期待：

```yaml
apiStep:
  stepId: "STEP-002"

  execution:
    status: "COMPLETED"
    httpStatus: 500

  verification:
    result: "FAIL"
    reasonCode: "EXPECTED_HTTP_STATUS_MISMATCH"
```

因为工具正常执行了API调用，并确认被测API返回错误结果。

---

## API2超时或连接失败

```yaml
apiStep:
  stepId: "STEP-002"

  execution:
    status: "FAILED"

  verification:
    result: "ERROR"
    reasonCode: "API_TIMEOUT"
```

这里没有取得可验证的正常Response，因此属于执行错误。

---

## API2因API1失败而没有执行

```yaml
apiStep:
  stepId: "STEP-002"

  execution:
    status: "NOT_EXECUTED"

  verification:
    result: "SKIPPED"
    reasonCode: "DEPENDENCY_UNMET"
```

---

# 七、Scenario整体结果怎么决定

例如：

|Step|情况|结果|
|---|---|---|
|API1|执行成功，返回值正确|PASS|
|API2|返回HTTP 500|FAIL|
|API3|依赖API2，没有执行|SKIPPED|

Scenario最终结果：

```yaml
scenario:
  result: "FAIL"
  reasonCode: "REQUIRED_STEP_FAILED"
```

如果API2是超时：

|Step|结果|
|---|---|
|API1|PASS|
|API2|ERROR|
|API3|SKIPPED|

Scenario最终：

```yaml
scenario:
  result: "ERROR"
  reasonCode: "REQUIRED_STEP_EXECUTION_ERROR"
```

不能因为API1成功，就让整个Scenario PASS。

---

# 八、什么时候不能判PASS

有一种情况特别重要：

```text
我不知道期待值，
也不知道类型、长度、范围、关系、时间条件，
也没有任何可验证的业务规则。
```

这时不能写：

```text
PASS
```

应该定义成观察模式：

```yaml
evaluationMode: "OBSERVATION_ONLY"

verification:
  result: "SKIPPED"
  reasonCode: "OBSERVATION_ONLY"
```

或者仅输出：

```text
已取得数据
但没有执行正确性验证
```

因为：

> “API成功返回了数据”不等于“数据正确”。

---

# 九、推荐的Canonical Rule Type

建议在Master中冻结以下规则类型：

```text
EXACT
REQUIRED
NULLABILITY
TYPE
LENGTH
PATTERN
ENUM
RANGE
STRUCTURE
COUNT
UNIQUE
TEMPORAL
REFERENCE
EXPRESSION
AGGREGATE
REFERENCE_INTEGRITY
BASELINE_DELTA
CANONICAL_HASH
CUSTOM
```

并且每条规则统一具有：

```yaml
rule:
  id: "RULE-001"
  ruleType: "TYPE"
  selector: "$.items[*].amount"

  required: true
  severity: "MAJOR"

  onMismatch:
    result: "FAIL"
    reasonCode: "EXPECTED_TYPE_MISMATCH"

  onEvaluationError:
    result: "ERROR"
    reasonCode: "RULE_EVALUATION_ERROR"
```

---

# 十、统一判定逻辑

|情况|最终结果|
|---|---|
|所有必须规则满足|PASS|
|必须规则正常执行但不满足|FAIL|
|规则执行引擎发生技术异常|ERROR|
|动态期待值或必要Reference无法取得|BLOCKED|
|依赖条件不满足，没有执行|SKIPPED|
|只有非必须警告规则不满足|PASS，并记录Warning|
|没有定义任何可验证规则|SKIPPED／OBSERVATION_ONLY|

---

# 对当前Master设计的结论

我们不需要把文件改名，但需要把原来的：

```text
Expected Value
```

扩展成：

```text
Expected Definition

├── Expected Value
├── Expected Constraint
├── Expected Reference
├── Expected Expression
├── Expected Aggregate
├── Expected Relationship
├── Expected Temporal Condition
└── Expected Execution Condition
```

因此原来的模型应该升级为：

```text
Current Observation
        +
Expected Definition
        ↓
Expectation Evaluation
        ↓
Rule Result
        ↓
Step Result
        ↓
Scenario Result
```

Baseline Compare继续保留，用于发现前回与今回变化；但大量动态数据的正确性，主要依靠这些**规则型Expected**判定。

---

# `system/02_master/` 当前完整结构与状态

按照已经确认的约束，`02_master`只保留Markdown文件，不放YAML、JSON Schema或运行时数据文件。

```text
system/
└── 02_master/
    ├── README.md
    │   └── 【需要重做】
    ├── Business_Master.md
    │   └── 【已给出内容】
    ├── Environment_Master.md
    │   └── 【已给出内容】
    ├── E6_API_Master.md
    │   └── 【待确认】
    ├── UseCase_Master.md
    │   └── 【已给出内容】
    ├── Scenario_Master.md
    │   └── 【需要重做】
    ├── API_UseCase_Scenario対応表.md
    │   └── 【需要重做】
    ├── Context_Master.md
    │   └── 【需要重做】
    ├── Verification_Master.md
    │   └── 【需要重做】
    ├── Verification_Policy_Master.md
    │   └── 【需要重做】
    ├── Compare_Policy_Master.md
    │   └── 【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md
    │   │   └── 【需要重做】
    │   ├── Business_Master設計書.md
    │   │   └── 【已给出内容】
    │   ├── Environment_Master設計書.md
    │   │   └── 【已给出内容】
    │   ├── API_Master設計書.md
    │   │   └── 【待确认】
    │   ├── UseCase_Master設計書.md
    │   │   └── 【已给出内容】
    │   ├── Scenario_Master設計書.md
    │   │   └── 【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md
    │   │   └── 【需要重做】
    │   ├── Context_Master設計書.md
    │   │   └── 【需要重做】
    │   ├── Verification_Master設計書.md
    │   │   └── 【需要重做】
    │   ├── Verification_Policy_Master設計書.md
    │   │   └── 【需要重做】
    │   └── Compare_Policy_Master設計書.md
    │       └── 【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md
    │   │   └── 【需要重做】
    │   └── Master_ID・Reference記述ガイド.md
    │       └── 【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md
    │   │   └── 【需要重做】
    │   └── Master整合性Checklist.md
    │       └── 【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md
        │   └── 【已给出内容】
        ├── Environment_Master_Example.md
        │   └── 【已给出内容】
        ├── E6_API_Master_Example.md
        │   └── 【待确认】
        ├── UseCase_Master_Example.md
        │   └── 【已给出内容】
        ├── Scenario_Master_Example.md
        │   └── 【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md
        │   └── 【需要重做】
        ├── Context_Master_Example.md
        │   └── 【需要重做】
        ├── Verification_Master_Example.md
        │   └── 【需要重做】
        ├── Verification_Policy_Master_Example.md
        │   └── 【需要重做】
        └── Compare_Policy_Master_Example.md
            └── 【需要重做】
```

## 本次新增的设计结论

```text
Expected不再只表示固定期待值。

Expected Definition必须支持：
固定值、条件、动态Reference、表达式、汇总关系、
时间规则、数据关系、变化范围及大数据Hash。
```

## 下一份计划文件

仍然优先补完：

```text
system/02_master/design/Master共通設計書.md
【下一份／追加Expected Definition与Rule Evaluation Model】
```

补完后再进入：

```text
system/02_master/design/Compare_Policy_Master設計書.md
```

## 第 102 轮

### 你

为什么不要yml json？

### ChatGPT

因为这里有两个层次，我上一条说得容易让人误解。

**不是说整个项目不要YAML和JSON。**
而是你之前已经明确冻结了：

```text
system/02_master/
只保存Markdown文件
```

所以YAML、JSON不应放进`02_master`，但在整个系统里它们仍然很重要，甚至是实现阶段必需的。

# Markdown、YAML、JSON各自负责什么

## Markdown：给人阅读和评审

例如：

```text
Verification_Master.md
Compare_Policy_Master.md
Master共通設計書.md
```

主要用于：

- 说明业务含义；
- 定义设计思想；
- 写判定规则；
- 使用Markdown表格；
- 使用Mermaid流程图；
- 让业务人员、设计人员、评审人员确认。

Markdown是**设计和管理层的正式资料**。

---

## YAML：给人维护，也给程序读取

例如：

```yaml
verificationId: VER-001
target: "$.items[*].transactionId"

expectations:
  - ruleType: REQUIRED
  - ruleType: LENGTH
    length: 12
  - ruleType: PATTERN
    pattern: "^[0-9]{12}$"
```

YAML适合：

- 定义实际Master数据；
- 配置Scenario；
- 配置API调用；
- 配置验证规则；
- 配置Expected Definition；
- 配置Compare Policy；
- 配置Environment；
- 配置Context Mapping。

它比Markdown更适合程序直接加载。

---

## JSON Schema：约束YAML或JSON是否写正确

例如Schema可以检查：

```text
ruleType是否属于允许范围
LENGTH规则是否填写length
PATTERN规则是否填写pattern
ID是否必填
是否出现未定义字段
枚举值是否正确
```

例如：

```json
{
  "type": "object",
  "required": ["verificationId", "expectations"],
  "properties": {
    "verificationId": {
      "type": "string"
    },
    "expectations": {
      "type": "array"
    }
  },
  "additionalProperties": false
}
```

JSON Schema是**机器校验层**，不是业务设计书。

---

# 正确的关系

应该是：

```text
Markdown设计书
        ↓
YAML Master Definition
        ↓
JSON Schema Validation
        ↓
Semantic Validation
        ↓
Runtime Load
        ↓
Verification Execution
```

所以不能只做Markdown。

如果只有Markdown：

```text
人能看懂
程序不能稳定执行
```

如果只有YAML：

```text
程序可以读取
但业务意义、责任边界和设计理由不完整
```

如果只有JSON Schema：

```text
只能检查格式
无法完整表达业务规则为什么这样设计
```

三者缺一不可。

# 为什么不放在02_master

这是**目录责任分离**，不是不要这些文件。

`02_master`负责：

```text
Master定义说明
Master设计书
Master模板
Master例子
评审指南
```

YAML和JSON应该进入后续的机器可执行层，例如：

```text
definitions/
schemas/
validation/
samples/
```

但是，这些目录具体放在`system/`下哪个番号目录，必须按照我们已经冻结的Repository Structure决定，不能现在随意新增。

也就是说，应当是：

```text
system/
├── 02_master/
│   └── 仅Markdown
│
├── 某个已冻结的Definition目录/
│   └── *.yml
│
├── 某个已冻结的Schema目录/
│   └── *.schema.json
│
└── 某个已冻结的Sample目录/
    ├── valid/
    └── invalid/
```

我上一条说：

> `02_master`只保留Markdown，不放YAML、JSON

这句话本身符合你此前的要求。

但如果被理解为：

> 整个项目都不要YAML和JSON

那就是错误的。**整个项目必须保留YAML和JSON，只是不放在02_master里面。**

# 最终建议

采用下面的三层结构：

|层|文件形式|用途|
|---|---|---|
|设计契约层|Markdown|业务评审、规则说明、设计冻结|
|可执行定义层|YAML|程序读取的Master和Policy|
|结构校验层|JSON Schema|检查YAML/JSON结构是否合法|

再增加第四层：

|层|文件形式|用途|
|---|---|---|
|语义校验层|YAML／代码|检查跨字段、跨Master和业务语义|

例如：

```text
Markdown规定：
LENGTH类型必须定义长度。

YAML实际写：
ruleType: LENGTH
length: 12

JSON Schema检查：
length字段存在且为正整数。

Semantic Validation检查：
length与API设计书中字段最大长度是否矛盾。
```

---

# 当前`system/02_master/`完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md
    │   └── 【需要重做】
    ├── Business_Master.md
    │   └── 【已给出内容】
    ├── Environment_Master.md
    │   └── 【已给出内容】
    ├── E6_API_Master.md
    │   └── 【待确认】
    ├── UseCase_Master.md
    │   └── 【已给出内容】
    ├── Scenario_Master.md
    │   └── 【需要重做】
    ├── API_UseCase_Scenario対応表.md
    │   └── 【需要重做】
    ├── Context_Master.md
    │   └── 【需要重做】
    ├── Verification_Master.md
    │   └── 【需要重做】
    ├── Verification_Policy_Master.md
    │   └── 【需要重做】
    ├── Compare_Policy_Master.md
    │   └── 【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md
    │   │   └── 【需要重做】
    │   ├── Business_Master設計書.md
    │   │   └── 【已给出内容】
    │   ├── Environment_Master設計書.md
    │   │   └── 【已给出内容】
    │   ├── API_Master設計書.md
    │   │   └── 【待确认】
    │   ├── UseCase_Master設計書.md
    │   │   └── 【已给出内容】
    │   ├── Scenario_Master設計書.md
    │   │   └── 【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md
    │   │   └── 【需要重做】
    │   ├── Context_Master設計書.md
    │   │   └── 【需要重做】
    │   ├── Verification_Master設計書.md
    │   │   └── 【需要重做】
    │   ├── Verification_Policy_Master設計書.md
    │   │   └── 【需要重做】
    │   └── Compare_Policy_Master設計書.md
    │       └── 【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md
    │   │   └── 【需要重做】
    │   └── Master_ID・Reference記述ガイド.md
    │       └── 【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md
    │   │   └── 【需要重做】
    │   └── Master整合性Checklist.md
    │       └── 【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md
        │   └── 【已给出内容】
        ├── Environment_Master_Example.md
        │   └── 【已给出内容】
        ├── E6_API_Master_Example.md
        │   └── 【待确认】
        ├── UseCase_Master_Example.md
        │   └── 【已给出内容】
        ├── Scenario_Master_Example.md
        │   └── 【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md
        │   └── 【需要重做】
        ├── Context_Master_Example.md
        │   └── 【需要重做】
        ├── Verification_Master_Example.md
        │   └── 【需要重做】
        ├── Verification_Policy_Master_Example.md
        │   └── 【需要重做】
        └── Compare_Policy_Master_Example.md
            └── 【需要重做】
```

## 本次新增或变更

```text
无文件内容变更。

重新明确：
02_master仅保存Markdown，
但整个项目必须保留YAML Definition、JSON Schema、
Semantic Validation及Valid／Invalid Sample。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【下一份／补充Expectation、Value Observation及Rule Evaluation统一模型】
```

## 第 103 轮

### 你

那为什么之前你都把schema和yaml文件都给出来了 那现在准备放哪

### ChatGPT

你说得对：前面把 `definitions/`、`schemas/`、`samples/` 放进 `02_master`，和后来冻结的“02_master仅MD”规则冲突。那些内容不应删除，而应迁移到机器可执行资产层。

### ChatGPT

你指出得对。**之前我把YAML、JSON Schema、Validation、Samples都列在了`02_master`下面，这与后来冻结的“`02_master`只放Markdown”规则冲突。**

这些文件不是不要，也不是重新发明，而是需要**从`02_master`迁移到现有的机器执行资产目录`06_verification_assets`**。

# 1. 现在准备放在哪里

最合适的位置是：

```text
system/
└── 06_verification_assets/
    └── master/
        ├── definitions/
        ├── schemas/
        ├── validation/
        └── samples/
```

完整建议结构：

```text
system/
└── 06_verification_assets/
    └── master/
        ├── definitions/
        │   ├── business-master.yml
        │   ├── environment-master.yml
        │   ├── api-master.yml
        │   ├── usecase-master.yml
        │   ├── scenario-master.yml
        │   ├── api-usecase-scenario-mapping.yml
        │   ├── context-master.yml
        │   ├── verification-master.yml
        │   ├── verification-policy-master.yml
        │   └── compare-policy-master.yml
        │
        ├── schemas/
        │   ├── business-master.schema.json
        │   ├── environment-master.schema.json
        │   ├── api-master.schema.json
        │   ├── usecase-master.schema.json
        │   ├── scenario-master.schema.json
        │   ├── api-usecase-scenario-mapping.schema.json
        │   ├── context-master.schema.json
        │   ├── verification-master.schema.json
        │   ├── verification-policy-master.schema.json
        │   └── compare-policy-master.schema.json
        │
        ├── validation/
        │   ├── master-reference-rules.yml
        │   ├── master-semantic-rules.yml
        │   └── master-validation-error-catalog.yml
        │
        └── samples/
            ├── valid/
            │   ├── business-master.valid.yml
            │   ├── environment-master.valid.yml
            │   ├── api-master.valid.yml
            │   ├── usecase-master.valid.yml
            │   ├── scenario-master.valid.yml
            │   ├── api-usecase-scenario-mapping.valid.yml
            │   ├── context-master.valid.yml
            │   ├── verification-master.valid.yml
            │   ├── verification-policy-master.valid.yml
            │   └── compare-policy-master.valid.yml
            │
            └── invalid/
                ├── business-master.invalid.yml
                ├── environment-master.invalid.yml
                ├── api-master.invalid.yml
                ├── usecase-master.invalid.yml
                ├── scenario-master.invalid.yml
                ├── api-usecase-scenario-mapping.invalid.yml
                ├── context-master.invalid.yml
                ├── verification-master.invalid.yml
                ├── verification-policy-master.invalid.yml
                └── compare-policy-master.invalid.yml
```

这里没有新增顶级番号目录，而是利用已经存在的：

```text
06_verification_assets
```

并在其下面增加Master机器资产分类。

# 2. 为什么放到`06_verification_assets`

仓库中的责任应当这样划分：

```text
02_master
    人阅读、设计、评审、冻结

06_verification_assets/master
    程序读取、结构校验、语义校验、测试样例
```

对应关系：

|内容|放置位置|
|---|---|
|Master含义、字段说明、业务规则|`02_master/*.md`|
|Master详细设计|`02_master/design/*.md`|
|填写模板|`02_master/templates/*.md`或冻结后的Markdown模板位置|
|人工阅读例子|`02_master/examples/*.md`|
|程序实际读取的Master|`06_verification_assets/master/definitions/*.yml`|
|YAML结构约束|`06_verification_assets/master/schemas/*.schema.json`|
|跨字段、跨Master语义检查|`06_verification_assets/master/validation/*.yml`|
|自动测试数据|`06_verification_assets/master/samples/`|

# 3. 原来给出的文件怎么处理

原来给出的YAML和JSON内容**不删除**，但不能原样全部搬过去。

因为后来核心模型已经发生变化：

```text
旧模型：
Previous ↔ Current

新模型：
Previous ↔ Current
Expectation ↔ Current Observation
```

而且新增了：

```text
Value Observation
Expectation Definition
Rule Evaluation
Execution Result
Dependency Result
Step Result
Scenario Result
```

所以文件分为三类。

## 可以迁移后复核

以下内容受新比较模型影响相对较小：

```text
business-master.yml
business-master.schema.json

environment-master.yml
environment-master.schema.json

usecase-master.yml
usecase-master.schema.json
```

它们的内容可以保留，但迁移时仍需要检查Reference和Canonical Enum。

## 待确认后迁移

```text
api-master.yml
api-master.schema.json
api-master.valid.yml
api-master.invalid.yml
```

因为目前`E6_API_Master`及API Master范围仍是待确认状态。

## 必须重做后再放入

以下内容不能直接搬迁：

```text
scenario-master.yml
api-usecase-scenario-mapping.yml
context-master.yml
verification-master.yml
verification-policy-master.yml
compare-policy-master.yml
```

以及对应的：

```text
*.schema.json
valid samples
invalid samples
semantic rules
reference rules
error catalog
```

因为这些都受到新模型直接影响。

# 4. 旧路径到新路径的迁移关系

|旧的错误位置|新的正确位置|
|---|---|
|`02_master/definitions/verification-master.yml`|`06_verification_assets/master/definitions/verification-master.yml`|
|`02_master/schemas/verification-master.schema.json`|`06_verification_assets/master/schemas/verification-master.schema.json`|
|`02_master/validation/master-semantic-rules.yml`|`06_verification_assets/master/validation/master-semantic-rules.yml`|
|`02_master/samples/valid/verification-master.valid.yml`|`06_verification_assets/master/samples/valid/verification-master.valid.yml`|
|`02_master/samples/invalid/verification-master.invalid.yml`|`06_verification_assets/master/samples/invalid/verification-master.invalid.yml`|

其他Master按照相同方式迁移。

# 5. Markdown和YAML谁是Source of Truth

不能简单地说只有一个文件是所有层面的Source of Truth，因为它们责任不同。

建议冻结为：

```text
Markdown：
设计契约与业务语义的Source of Truth

YAML：
运行时Master数据的Source of Truth

JSON Schema：
机器结构约束的Source of Truth

Semantic Validation：
跨字段、跨Master一致性规则的Source of Truth
```

但是它们必须通过相同ID和Version连接。

例如Markdown：

```text
Master ID: VERIFICATION_MASTER
Design Version: 2.0.0
```

YAML：

```yaml
metadata:
  masterId: VERIFICATION_MASTER
  version: 2.0.0
  designReference: "system/02_master/design/Verification_Master設計書.md"
```

Schema：

```json
{
  "$id": "verification-master.schema.json",
  "title": "VERIFICATION_MASTER 2.0.0"
}
```

这样不会出现：

```text
Markdown说一种规则
YAML写另一种规则
Schema又允许第三种规则
```

# 6. 推荐生成顺序

不要再像前面那样同时先给全部YAML和Schema。

正确顺序是：

```text
① Master共通設計書
② 各Master設計書
③ 各Master Markdown模板
④ Master内容冻结
⑤ YAML Definition
⑥ JSON Schema
⑦ Semantic Validation
⑧ Valid Sample
⑨ Invalid Sample
⑩ 自动化测试
```

也就是：

```text
先冻结设计契约
再生成机器执行资产
```

否则设计一变，所有YAML、Schema、Sample都必须重做，前面发生的正是这个问题。

# 7. 当前Repository职责

```text
system/
├── 01_repository/
│   └── 仓库结构、命名、版本和管理规则
│
├── 02_master/
│   └── Master Markdown设计与人工维护资料
│
├── 03_api_design/
│   └── 单API设计与验证观点
│
├── 04_usecase_design/
│   └── 多API链路及UseCase设计
│
├── 05_run_context/
│   └── 执行时Context相关设计
│
├── 06_verification_assets/
│   └── 程序可读取的验证资产
│       └── master/
│           ├── definitions/
│           ├── schemas/
│           ├── validation/
│           └── samples/
│
└── 07_report/
    └── 结果及报告设计
```

这里的`06_verification_assets/master/`结构在正式冻结前，应当记录到：

```text
01_repository/Repository_Structure.md
```

不能只在对话中决定后直接使用。

---

# 当前`system/02_master/`完整文件结构与状态

从现在开始，树中不再包含YAML、JSON Schema和机器测试数据。

```text
system/
└── 02_master/
    ├── README.md
    │   └── 【需要重做】
    ├── Business_Master.md
    │   └── 【已给出内容】
    ├── Environment_Master.md
    │   └── 【已给出内容】
    ├── E6_API_Master.md
    │   └── 【待确认】
    ├── UseCase_Master.md
    │   └── 【已给出内容】
    ├── Scenario_Master.md
    │   └── 【需要重做】
    ├── API_UseCase_Scenario対応表.md
    │   └── 【需要重做】
    ├── Context_Master.md
    │   └── 【需要重做】
    ├── Verification_Master.md
    │   └── 【需要重做】
    ├── Verification_Policy_Master.md
    │   └── 【需要重做】
    ├── Compare_Policy_Master.md
    │   └── 【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md
    │   │   └── 【需要重做】
    │   ├── Business_Master設計書.md
    │   │   └── 【已给出内容】
    │   ├── Environment_Master設計書.md
    │   │   └── 【已给出内容】
    │   ├── API_Master設計書.md
    │   │   └── 【待确认】
    │   ├── UseCase_Master設計書.md
    │   │   └── 【已给出内容】
    │   ├── Scenario_Master設計書.md
    │   │   └── 【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md
    │   │   └── 【需要重做】
    │   ├── Context_Master設計書.md
    │   │   └── 【需要重做】
    │   ├── Verification_Master設計書.md
    │   │   └── 【需要重做】
    │   ├── Verification_Policy_Master設計書.md
    │   │   └── 【需要重做】
    │   └── Compare_Policy_Master設計書.md
    │       └── 【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md
    │   │   └── 【需要重做】
    │   └── Master_ID・Reference記述ガイド.md
    │       └── 【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md
    │   │   └── 【需要重做】
    │   └── Master整合性Checklist.md
    │       └── 【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md
        │   └── 【已给出内容】
        ├── Environment_Master_Example.md
        │   └── 【已给出内容】
        ├── E6_API_Master_Example.md
        │   └── 【待确认】
        ├── UseCase_Master_Example.md
        │   └── 【已给出内容】
        ├── Scenario_Master_Example.md
        │   └── 【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md
        │   └── 【需要重做】
        ├── Context_Master_Example.md
        │   └── 【需要重做】
        ├── Verification_Master_Example.md
        │   └── 【需要重做】
        ├── Verification_Policy_Master_Example.md
        │   └── 【需要重做】
        └── Compare_Policy_Master_Example.md
            └── 【需要重做】
```

# 本次新增或变更

```text
1. 纠正之前的目录冲突。
2. 02_master不再列出definitions、schemas、validation、samples。
3. 原YAML和JSON内容不删除。
4. 机器执行资产统一迁移到：
   system/06_verification_assets/master/
5. Scenario、Context、Verification和Policy相关机器文件必须重做后再迁移。
6. 该结构正式使用前，需要写入并冻结Repository_Structure.md。
```

# 下一份计划文件

结构记录优先：

```text
system/01_repository/Repository_Structure.md
【需要补充06_verification_assets/master机器资产结构】
```

随后继续：

```text
system/02_master/design/Master共通設計書.md
【下一份／补充Expectation、Observation、Rule Evaluation及Step执行模型】
```

## 第 104 轮

### 你

那不按照usecase来单位生产吗  你这个不是总体的设计  生产yml和json有什么用途

### ChatGPT

你说得对：**真正的生产单位应该是UseCase／Scenario，不是把所有业务内容集中生成一套总YAML。** 总体Schema只负责定义“这种文件怎么写”，实际可执行YAML应按UseCase生成。

### ChatGPT

对，**真正的执行资产应该按UseCase为单位生产**。我上一条把`business-master.yml`、`verification-master.yml`等集中列成一套运行资产，容易把“总体设计定义”和“实际业务执行文件”混在一起，这个方向需要修正。

正确模型应当是：

```text
总体Master和Schema
    负责定义规则语言、字段含义和约束

UseCase Package
    负责描述某个业务实际上怎么执行、怎么验证

Runtime JSON
    负责保存本次执行计划、实际结果和证据
```

# 一、真正的生产单位

应该是：

```text
一个UseCase
    ├── 一个或多个Scenario
    ├── 多个API Step
    ├── Request数据来源
    ├── 前后API字段Mapping
    ├── 每个Step的验证规则
    ├── 分支和依赖条件
    ├── 失败后的继续／停止规则
    └── UseCase整体结果聚合规则
```

例如：

```text
UC-E6-001 会员信息取得业务
│
├── SC-001 正常会员
│   ├── STEP-001 登录API
│   ├── STEP-002 会员查询API
│   └── STEP-003 属性取得API
│
├── SC-002 不存在会员
│   ├── STEP-001 登录API
│   └── STEP-002 会员查询API
│
└── SC-003 登录失败
    └── STEP-001 登录API
```

所以实际执行时，不是加载一个巨大的：

```text
verification-master.yml
```

然后全系统一起运行。

而是加载：

```text
UC-E6-001
```

并解析这个UseCase下面相关的Scenario、Step、API和Verification。

---

# 二、总体设计和UseCase资产的关系

## 总体设计负责定义“语言”

例如总体设计规定：

```text
API步骤必须有stepId
后续步骤可以声明dependsOn
验证规则支持TYPE、LENGTH、RANGE、REFERENCE等
Expectation无法取得时结果为BLOCKED
API超时时结果为ERROR
前置步骤失败导致未执行时为SKIPPED
```

这些是全平台共同规则。

它们不包含某个具体业务的内容。

---

## UseCase资产负责填写“业务内容”

例如：

```yaml
usecaseId: "UC-E6-001"
name: "会員情報取得"

scenarios:
  - scenarioId: "SC-001"
    steps:
      - stepId: "STEP-001"
        apiRef: "API-AUTH-001"

      - stepId: "STEP-002"
        apiRef: "API-MEMBER-001"
        dependsOn:
          - stepId: "STEP-001"
            requiredResult: "PASS"
```

这才是程序真正执行的业务定义。

---

# 三、YAML具体有什么用

YAML是**UseCase的人工维护源文件**。

它告诉执行引擎：

```text
调用哪些API
以什么顺序调用
Request值从哪里取得
前一个API的哪个字段传给后一个API
每一步期待什么
动态数据怎样检查
失败后继续还是停止
哪些分支需要进入
最终UseCase怎么聚合
```

一个UseCase可以组织为：

```text
system/
└── 06_verification_assets/
    └── usecases/
        └── UC-E6-001/
            ├── usecase.yml
            ├── scenarios/
            │   ├── SC-001.yml
            │   ├── SC-002.yml
            │   └── SC-003.yml
            ├── verifications/
            │   ├── STEP-001-verification.yml
            │   ├── STEP-002-verification.yml
            │   └── STEP-003-verification.yml
            ├── data/
            │   ├── default-input.yml
            │   └── test-patterns.yml
            └── README.md
```

也可以小型UseCase只用一个文件：

```text
UC-E6-001/
└── usecase.yml
```

规模扩大后再拆分。

---

# 四、一个UseCase YAML实际能做什么

下面是接近实际运行形态的例子：

```yaml
metadata:
  usecaseId: "UC-E6-001"
  version: "1.0.0"
  businessId: "BUS-E6-001"

scenario:
  scenarioId: "SC-001"
  name: "正常会員情報取得"

steps:
  - stepId: "STEP-001"
    apiRef: "API-AUTH-001"

    request:
      bindings:
        userId: "${input.userId}"
        password: "${secret.loginPassword}"

    expectations:
      - ruleId: "RULE-001"
        target: "$http.status"
        ruleType: "EXACT"
        expectedValue: 200

      - ruleId: "RULE-002"
        target: "$response.accessToken"
        ruleType: "REQUIRED"

      - ruleId: "RULE-003"
        target: "$response.accessToken"
        ruleType: "LENGTH"
        minimum: 20

    exports:
      accessToken: "$response.accessToken"

  - stepId: "STEP-002"
    apiRef: "API-MEMBER-001"

    dependencies:
      - stepId: "STEP-001"
        requiredExecutionStatus: "SUCCEEDED"
        requiredVerificationResult: "PASS"

    request:
      headers:
        Authorization: "Bearer ${context.STEP-001.accessToken}"

      bindings:
        memberId: "${input.memberId}"

    expectations:
      - ruleId: "RULE-101"
        target: "$http.status"
        ruleType: "EXACT"
        expectedValue: 200

      - ruleId: "RULE-102"
        target: "$response.memberId"
        ruleType: "REFERENCE"
        expectedReference: "${input.memberId}"

      - ruleId: "RULE-103"
        target: "$response.updateDate"
        ruleType: "TEMPORAL"
        condition:
          operator: "IN_MONTH"
          reference: "${runContext.targetMonth}"

      - ruleId: "RULE-104"
        target: "$response.transactionNumber"
        ruleType: "LENGTH"
        exactLength: 12

    onDependencyUnmet:
      executionStatus: "NOT_EXECUTED"
      verificationResult: "SKIPPED"
      reasonCode: "DEPENDENCY_UNMET"

aggregation:
  requiredSteps:
    - "STEP-001"
    - "STEP-002"

  onRequiredStepFail:
    result: "FAIL"

  onRequiredStepError:
    result: "ERROR"
```

这里没有要求动态数据等于固定值。

它可以检查：

- 必须有值；
- 必须是12位；
- 必须属于当月；
- 必须等于输入值；
- 必须等于前一API返回值；
- 必须满足汇总关系；
- 必须执行成功。

---

# 五、JSON Schema有什么用途

JSON Schema不是业务执行文件。

它的用途是检查UseCase YAML有没有写错。

虽然文件是YAML，但YAML加载后也是Object／Array结构，所以可以使用JSON Schema验证。

例如总体Schema规定：

```text
stepId必须存在
apiRef必须存在
ruleType必须是合法值
LENGTH规则必须有长度条件
REFERENCE规则必须有expectedReference
dependsOn引用的Step必须存在
```

例如错误YAML：

```yaml
ruleType: "LENGTH"
```

但是没有写：

```yaml
exactLength: 12
```

Schema就可以在执行前阻止它进入运行环境。

---

## 共通Schema不是按业务写的

Schema定义：

```text
UseCase文件允许写哪些字段
Scenario文件允许写哪些字段
Step如何定义
Verification Rule如何定义
Dependency如何定义
```

所以共通Schema数量不会很多：

```text
system/
└── 06_verification_assets/
    └── common/
        └── schemas/
            ├── usecase.schema.json
            ├── scenario.schema.json
            ├── api-step.schema.json
            ├── verification-rule.schema.json
            ├── dependency.schema.json
            └── aggregation.schema.json
```

所有UseCase共用这些Schema。

不是每一个UseCase都重新写一整套Schema。

只有某个UseCase有特殊数据契约时，才可能产生UseCase专用Schema。

---

# 六、JSON文件有什么用途

这里要区分三类JSON。

## 1. 编译后的执行计划

YAML适合人工维护，但执行引擎最好先将其编译为统一JSON：

```text
usecase.yml
scenario.yml
verification.yml
       ↓
加载、合并、Reference解析
       ↓
execution-plan.json
```

例如：

```json
{
  "runDefinitionId": "UC-E6-001:SC-001:1.0.0",
  "steps": [
    {
      "stepId": "STEP-001",
      "apiId": "API-AUTH-001",
      "resolvedPolicies": [],
      "resolvedRules": []
    }
  ]
}
```

这个JSON是机器运行用的Canonical Plan。

通常由程序生成，不需要人工编写。

---

## 2. Runtime结果

每次执行都会生成JSON证据：

```text
run-context.json
current-snapshot.json
baseline-snapshot.json
expected-snapshot.json
diff.json
verification-result.json
```

这些JSON用于：

- 记录每个API是否执行；
- 保存Request和Response；
- 保存Value State；
- 保存每条规则的判定；
- 区分FAIL、ERROR、BLOCKED和SKIPPED；
- 生成日报；
- 与前一日比较；
- 审计和再现。

---

## 3. Report中间数据

Markdown、HTML或Excel报告可以从统一JSON结果生成。

```text
verification-result.json
        ↓
report generator
        ↓
daily-report.html
daily-report.xlsx
summary.md
```

这样报告层不需要重新计算判定，只负责显示结果。

---

# 七、生产时不需要人为同时写YAML和JSON

正确做法是：

```text
人工维护：
YAML

程序验证：
JSON Schema

程序生成：
Canonical JSON

运行产生：
Result JSON
```

也就是说，不应该要求开发人员对同一个UseCase同时手写：

```text
UC-E6-001.yml
UC-E6-001.json
```

那会产生双重维护。

应该是：

```text
UC-E6-001.yml
    ↓ 自动编译
UC-E6-001.execution-plan.json
```

JSON属于生成物。

---

# 八、之前给出的Master YAML和JSON怎么重新定位

之前给出的：

```text
business-master.yml
environment-master.yml
usecase-master.yml
verification-master.yml
compare-policy-master.yml
```

不应该全部理解为“每次业务执行的文件”。

它们应该重新分类。

## 可以作为共通定义或Registry的文件

例如：

```text
business-registry.yml
environment-registry.yml
api-registry.yml
```

它们保存全系统共通ID和基础信息。

例如：

```yaml
apis:
  - apiId: "API-AUTH-001"
    method: "POST"
    path: "/auth/login"

  - apiId: "API-MEMBER-001"
    method: "GET"
    path: "/members/{memberId}"
```

UseCase通过`apiRef`引用它们。

---

## 不应该作为一个巨大总文件的内容

例如：

```text
verification-master.yml
scenario-master.yml
compare-policy-master.yml
```

不应把所有UseCase的所有规则堆在一个文件里。

应该按UseCase或可复用Policy拆分：

```text
06_verification_assets/
├── common/
│   ├── policies/
│   │   ├── default-compare-policy.yml
│   │   └── default-verification-policy.yml
│   └── schemas/
│
└── usecases/
    ├── UC-E6-001/
    │   ├── usecase.yml
    │   └── verifications/
    │
    ├── UC-E6-002/
    │   ├── usecase.yml
    │   └── verifications/
    │
    └── UC-E6-003/
        ├── usecase.yml
        └── verifications/
```

所以正确原则是：

```text
共通且可复用的内容放Common。

与业务执行相关的内容按UseCase生产。

运行时JSON由程序自动生成。
```

---

# 九、总体架构应当这样理解

```mermaid
flowchart TD
    A[02_master Markdown总体契约] --> B[Common Schema和Policy]
    C[03_api_design API设计] --> D[API Registry]
    E[04_usecase_design UseCase设计] --> F[UseCase YAML Package]

    B --> G[UseCase Compiler]
    D --> G
    F --> G

    G --> H[Execution Plan JSON]
    H --> I[Verification Runtime]
    I --> J[RunContext JSON]
    I --> K[Snapshot JSON]
    I --> L[Diff JSON]
    I --> M[Verification Result JSON]
    M --> N[07_report]
```

---

# 十、最终职责划分

|内容|单位|用途|
|---|---|---|
|总体规则设计|全系统|定义平台统一语言和责任|
|API Registry|API单位|定义API基础契约|
|UseCase YAML|UseCase单位|定义业务执行内容|
|Scenario YAML|Scenario单位|定义路径和分支|
|Verification YAML|Step／字段／规则单位|定义具体检查|
|Common JSON Schema|全系统共用|验证YAML格式|
|Execution Plan JSON|UseCase＋Scenario单位|机器执行|
|Run Result JSON|一次Run单位|记录实际结果|
|Snapshot／Diff JSON|一次Run／比较单位|变化检测和证据|
|Report|日次／UseCase／Run单位|给人工查看|

---

# 当前修正结论

前面的说法：

```text
把所有Master YAML统一放到
06_verification_assets/master/definitions/
```

不够准确。

应修正为：

```text
06_verification_assets/
├── common/
│   ├── schemas/
│   ├── policies/
│   └── registries/
│
└── usecases/
    ├── UC-001/
    ├── UC-002/
    └── UC-003/
```

其中：

```text
Common：
平台共通Schema、Policy、API Registry等

UseCases：
按UseCase生产的可执行YAML

JSON：
主要由编译和运行过程自动生成
```

这才符合你之前确定的“以UseCase为业务执行单位”。

---

# 当前`system/02_master/`完整结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
1. 确认执行资产以UseCase为主要生产单位。
2. 否定“所有业务Master集中成一个巨大YAML文件”的方式。
3. YAML定位为UseCase人工维护源文件。
4. JSON Schema定位为共通结构校验契约。
5. JSON定位为编译计划和运行结果，原则上自动生成。
6. 06_verification_assets改为common与usecases两类资产。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【下一份／将UseCase Package、Expectation Evaluation、
Execution Result及生成资产关系写入共通设计】
```

## 第 105 轮

### 你

期待值如果写不出来或者很长很大，可以验证得到 对吗
或者说所有的验证都可以用yml文件来写吗
比如说我在验证java里写逻辑来验证对比也是一种方式，
比方说yml的期待值定义方式或者对比逻辑很复杂
我就可以通过写java验证逻辑，然后返回对错
java从逻辑上验证通过了，这个时候yml这边该怎么写返回值对比呢

### ChatGPT

核心要区分两句话：**所有验证都可以在YAML中登记和编排，但不是所有验证逻辑都应该用YAML实现。** 复杂规则由Java Validator执行，YAML只声明调用谁、输入什么、失败如何处理。

### ChatGPT

对，**期待值写不出来、非常大、每天变化或业务逻辑复杂，都仍然可以验证。**

但这里必须确立一个重要原则：

> **所有验证都可以在YAML中“登记、配置、编排”，但不是所有验证逻辑都必须用YAML实现。**

推荐采用两种验证方式并存：

```text
声明式验证
YAML直接描述规则

程序式验证
YAML引用Java Validator，由Java执行复杂逻辑
```

# 1. 两种验证方式

## 1.1 YAML声明式验证

适合常见规则：

```text
必填
null
类型
长度
位数
正则表达式
固定值
枚举值
范围
日期范围
前后API值一致
数组件数
唯一性
合计关系
JSON Schema
```

例如只要求12位：

```yaml
ruleId: RULE-001
evaluationMode: DECLARATIVE
target: "$.transactionId"

expectation:
  ruleType: LENGTH
  exactLength: 12
```

例如每月变化，但必须属于执行月份：

```yaml
ruleId: RULE-002
evaluationMode: DECLARATIVE
target: "$.transactionDate"

expectation:
  ruleType: TEMPORAL
  operator: IN_MONTH
  expectedReference: "${runContext.targetMonth}"
```

这种不需要Java。

---

## 1.2 Java程序式验证

以下情况适合Java：

- 业务逻辑非常复杂；
- 需要循环处理大量数据；
- 需要关联多个API Response；
- 需要查询数据库后判断；
- 需要进行复杂计算；
- 需要调用既有Java业务方法；
- YAML表达式会变得非常长；
- 需要特殊算法；
- 需要解析特殊数据格式；
- 需要复杂的父子关系、汇总关系；
- 期待值本身无法直接写出。

例如：

```text
API返回10万条数据。

需要按照会员种类、业务日期、状态、
交易类型和税率分组计算。

计算结果还要与DB数据交叉检查。
```

这种逻辑不应该强行写成几百行YAML表达式。

应该由Java Validator完成。

---

# 2. YAML负责什么，Java负责什么

## YAML负责

```text
这个UseCase要执行哪个验证
调用哪个Validator
向Validator传入什么
Validator需要哪些前置数据
Validator超时时间
这个验证是否必需
验证失败后是否继续
结果如何聚合
```

## Java负责

```text
具体怎么计算
具体怎么循环
具体怎么关联数据
具体怎么进行复杂业务判断
具体收集哪些违反项目
具体生成什么Evidence
```

正确关系是：

```text
UseCase YAML
    ↓
指定Java Validator
    ↓
Java执行复杂验证
    ↓
返回标准Evaluation Result
    ↓
Verification Policy决定PASS／FAIL／ERROR
```

---

# 3. YAML不应该直接填写Java类名

不建议这样写：

```yaml
validatorClass: "com.example.MemberBusinessValidator"
```

原因是：

- YAML与Java包结构强绑定；
- Java改包名会导致业务资产全部修改；
- 存在任意类加载风险；
- 无法方便管理版本；
- 不利于白名单管理。

建议YAML只引用Validator ID：

```yaml
validatorRef: "VAL-MEMBER-BUSINESS-001"
```

系统内部Registry负责映射：

```text
VAL-MEMBER-BUSINESS-001
    ↓
Spring Bean: memberBusinessValidator
    ↓
Java Class:
MemberBusinessValidator
    ↓
Version:
2.1.0
```

---

# 4. Java验证通过后，YAML怎么判定

关键点是：

> Java不要只返回`true`或`false`。

因为单纯Boolean无法说明：

- Java正常执行但业务不符合；
- Java自己运行出错；
- 输入数据没有取得；
- 验证没有执行；
- 哪些项目不符合；
- 使用了什么证据；
- 为什么失败。

Java应该返回标准结果对象。

例如Java验证通过：

```json
{
  "validatorExecutionStatus": "SUCCEEDED",
  "evaluationOutcome": "SATISFIED",
  "reasonCode": "BUSINESS_RULE_SATISFIED",
  "message": "All member transaction rules were satisfied.",
  "evidence": {
    "checkedRecordCount": 100000,
    "violationCount": 0
  }
}
```

Java业务验证不通过：

```json
{
  "validatorExecutionStatus": "SUCCEEDED",
  "evaluationOutcome": "VIOLATED",
  "reasonCode": "BUSINESS_TOTAL_MISMATCH",
  "message": "Detail total does not equal header total.",
  "evidence": {
    "headerTotal": 1500000,
    "calculatedDetailTotal": 1499000,
    "difference": 1000
  }
}
```

Java自身异常：

```json
{
  "validatorExecutionStatus": "FAILED",
  "evaluationOutcome": "INDETERMINATE",
  "reasonCode": "CUSTOM_VALIDATOR_EXECUTION_ERROR",
  "message": "Database connection failed."
}
```

---

# 5. YAML写法

例如某个UseCase的第二个API需要复杂Java验证：

```yaml
- ruleId: "RULE-API2-BUSINESS-001"
  name: "会員取引整合性検証"

  evaluationMode: "CUSTOM_VALIDATOR"

  targetStepId: "STEP-002"

  validator:
    validatorRef: "VAL-MEMBER-BUSINESS-001"
    version: "2.1.0"

  inputs:
    request:
      reference: "${steps.STEP-002.request}"

    response:
      reference: "${steps.STEP-002.response}"

    previousResponse:
      reference: "${baseline.STEP-002.response}"
      required: false

    businessDate:
      reference: "${runContext.businessDate}"

    memberId:
      reference: "${input.memberId}"

  parameters:
    checkDuplicateTransaction: true
    checkTotalAmount: true
    checkBusinessDate: true
    maximumViolationDetails: 100

  executionPolicy:
    timeoutMilliseconds: 30000

  required: true
```

这个YAML里没有写具体期待值。

因为Expectation就是：

```text
VAL-MEMBER-BUSINESS-001定义的业务规则必须满足
```

Java返回：

```text
SATISFIED
```

平台就按照统一Policy转换为：

```text
PASS
```

Java返回：

```text
VIOLATED
```

转换为：

```text
FAIL
```

Java运行异常：

```text
validatorExecutionStatus = FAILED
```

转换为：

```text
ERROR
```

---

# 6. YAML是否需要写“期待返回SATISFIED”

可以写，但通常不必每条规则重复写。

例如可以显式写：

```yaml
expectedEvaluationOutcome: "SATISFIED"
```

完整写法：

```yaml
validator:
  validatorRef: "VAL-MEMBER-BUSINESS-001"
  version: "2.1.0"

expectedEvaluationOutcome: "SATISFIED"
```

但是由于所有Validator正常的目标都是：

```text
SATISFIED
```

所以推荐把它作为平台默认规则：

```text
CUSTOM_VALIDATOR默认期待：
evaluationOutcome = SATISFIED
```

YAML只在特殊情况下覆盖。

---

# 7. 不应该让Java直接决定整个Scenario的PASS／FAIL

Java Validator最好不要直接返回：

```text
Scenario Result = PASS
```

它应该只返回自己的Evaluation结果：

```text
SATISFIED
VIOLATED
INDETERMINATE
```

然后由统一Verification Policy决定：

|Java执行状态|Java评价结果|Rule Result|
|---|---|---|
|SUCCEEDED|SATISFIED|PASS|
|SUCCEEDED|VIOLATED|FAIL|
|FAILED|INDETERMINATE|ERROR|
|未执行|-|SKIPPED|
|必要输入无法取得|-|BLOCKED|

这样有几个好处：

- 所有Java Validator判定标准统一；
- Java不能绕过全局Policy；
- Scenario聚合逻辑不会散落在Java类中；
- 报告可以统一生成；
- Java只负责业务判断；
- YAML和Master仍然控制执行流程。

---

# 8. Java接口建议

Java可以定义统一接口：

```java
public interface CustomValidator {

    ValidatorEvaluationResult evaluate(
        ValidatorExecutionContext context
    );
}
```

结果对象：

```java
public record ValidatorEvaluationResult(
    ValidatorExecutionStatus executionStatus,
    EvaluationOutcome outcome,
    String reasonCode,
    String message,
    Severity severity,
    Map<String, Object> evidence,
    List<ValidationViolation> violations
) {
}
```

Enum：

```java
public enum ValidatorExecutionStatus {
    SUCCEEDED,
    FAILED
}
```

```java
public enum EvaluationOutcome {
    SATISFIED,
    VIOLATED,
    INDETERMINATE
}
```

Violation：

```java
public record ValidationViolation(
    String path,
    String violationCode,
    String message,
    Object actualValue,
    Object expectedCondition
) {
}
```

---

# 9. Java验证实现示例

例如检查：

```text
Header总金额
=
所有Detail金额之和
```

```java
@Component("memberBusinessValidator")
public class MemberBusinessValidator implements CustomValidator {

    @Override
    public ValidatorEvaluationResult evaluate(
            ValidatorExecutionContext context) {

        try {
            MemberResponse response =
                context.getRequiredInput(
                    "response",
                    MemberResponse.class
                );

            BigDecimal headerTotal =
                response.getTotalAmount();

            BigDecimal detailTotal =
                response.getItems()
                    .stream()
                    .map(TransactionItem::getAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            if (headerTotal.compareTo(detailTotal) == 0) {
                return new ValidatorEvaluationResult(
                    ValidatorExecutionStatus.SUCCEEDED,
                    EvaluationOutcome.SATISFIED,
                    "BUSINESS_TOTAL_MATCHED",
                    "Header total matched detail total.",
                    Severity.INFO,
                    Map.of(
                        "headerTotal", headerTotal,
                        "detailTotal", detailTotal,
                        "checkedCount", response.getItems().size()
                    ),
                    List.of()
                );
            }

            ValidationViolation violation =
                new ValidationViolation(
                    "$.totalAmount",
                    "BUSINESS_TOTAL_MISMATCH",
                    "Header total does not equal detail total.",
                    headerTotal,
                    detailTotal
                );

            return new ValidatorEvaluationResult(
                ValidatorExecutionStatus.SUCCEEDED,
                EvaluationOutcome.VIOLATED,
                "BUSINESS_TOTAL_MISMATCH",
                "Business total verification failed.",
                Severity.MAJOR,
                Map.of(
                    "headerTotal", headerTotal,
                    "detailTotal", detailTotal
                ),
                List.of(violation)
            );

        } catch (Exception exception) {
            return new ValidatorEvaluationResult(
                ValidatorExecutionStatus.FAILED,
                EvaluationOutcome.INDETERMINATE,
                "CUSTOM_VALIDATOR_EXECUTION_ERROR",
                exception.getMessage(),
                Severity.MAJOR,
                Map.of(),
                List.of()
            );
        }
    }
}
```

---

# 10. Runtime最终输出

YAML不是用来接收结果的。

YAML是执行定义。

实际运行结果应该生成JSON：

```json
{
  "ruleId": "RULE-API2-BUSINESS-001",
  "validatorRef": "VAL-MEMBER-BUSINESS-001",
  "validatorVersion": "2.1.0",

  "validatorExecutionStatus": "SUCCEEDED",
  "evaluationOutcome": "SATISFIED",

  "verificationResult": "PASS",
  "reasonCode": "BUSINESS_RULE_SATISFIED",

  "evidence": {
    "checkedRecordCount": 100000,
    "violationCount": 0
  }
}
```

关系是：

```text
YAML：
定义怎么验证

Java：
执行复杂验证

Result JSON：
保存本次验证结果
```

不应该把运行结果反写进UseCase YAML。

---

# 11. 第一个API成功、第二个API复杂验证的例子

```yaml
steps:
  - stepId: "STEP-001"
    apiRef: "API-001"

    expectations:
      - ruleId: "RULE-001"
        evaluationMode: "DECLARATIVE"
        target: "$http.status"
        expectation:
          ruleType: "EXACT"
          expectedValue: 200

  - stepId: "STEP-002"
    apiRef: "API-002"

    dependencies:
      - stepId: "STEP-001"
        requiredVerificationResult: "PASS"

    expectations:
      - ruleId: "RULE-002"
        evaluationMode: "CUSTOM_VALIDATOR"

        validator:
          validatorRef: "VAL-API2-BUSINESS-001"
          version: "1.0.0"

        inputs:
          api1Response:
            reference: "${steps.STEP-001.response}"

          api2Response:
            reference: "${steps.STEP-002.response}"

          businessDate:
            reference: "${runContext.businessDate}"
```

可能产生以下结果。

## API1成功，API2 Java验证成功

```text
STEP-001 = PASS
STEP-002 = PASS
Scenario = PASS
```

## API1成功，API2 Java发现业务不一致

```text
STEP-001 = PASS
STEP-002 = FAIL
Scenario = FAIL
```

## API1成功，API2 Validator自身异常

```text
STEP-001 = PASS
STEP-002 = ERROR
Scenario = ERROR
```

## API1失败，API2没有执行

```text
STEP-001 = FAIL
STEP-002 = SKIPPED
Reason = DEPENDENCY_UNMET
Scenario = FAIL
```

---

# 12. 期待值很长很大怎么办

可以采用多种方式。

## 方式一：Java直接验证业务性质

不保存巨大Expected，只验证：

```text
结构是否合法
合计是否一致
数据是否重复
数据关系是否成立
日期是否正确
全部数据是否满足业务条件
```

这是最推荐的方式。

---

## 方式二：Expected放到外部文件

YAML只引用：

```yaml
expectation:
  ruleType: "EXTERNAL_DATA"
  expectedDataRef: "file://expected/UC-E6-001/result-202607.json"
```

适合：

```text
大JSON
大CSV
大型固定Master
承认済みBaseline
```

---

## 方式三：Hash验证

```yaml
expectation:
  ruleType: "CANONICAL_HASH"
  expectedHashRef: "${expectedAssets.monthlyDataHash}"
```

适合内容巨大但要求完全一致的数据。

---

## 方式四：Java动态生成期待值

```yaml
expectation:
  ruleType: "CUSTOM_VALIDATOR"

validator:
  validatorRef: "VAL-MONTHLY-DYNAMIC-EXPECTED-001"
```

Java可以：

```text
根据月份生成Expected
从DB取得Expected
根据API1结果推导Expected
根据业务日期计算Expected
根据多张表生成Expected
```

---

# 13. 三种Evaluation Mode应当正式冻结

建议统一为：

```text
DECLARATIVE
CUSTOM_VALIDATOR
COMPOSITE
```

## DECLARATIVE

YAML内直接描述：

```yaml
evaluationMode: "DECLARATIVE"
```

## CUSTOM_VALIDATOR

Java实现复杂判断：

```yaml
evaluationMode: "CUSTOM_VALIDATOR"
validatorRef: "VAL-XXX-001"
```

## COMPOSITE

组合YAML规则和Java验证：

```yaml
evaluationMode: "COMPOSITE"

components:
  - ruleRef: "RULE-TYPE-001"
  - ruleRef: "RULE-LENGTH-001"
  - validatorRef: "VAL-BUSINESS-001"

aggregation:
  operator: "ALL"
```

---

# 14. 最终设计结论

应该冻结为：

```text
1. 所有验证必须能够在UseCase YAML中登记。
2. 简单验证逻辑可以完整写在YAML中。
3. 复杂验证逻辑由Java Custom Validator实现。
4. YAML通过validatorRef引用Java实现。
5. Java不得只返回Boolean。
6. Java返回标准Evaluation Result、ReasonCode和Evidence。
7. Java返回SATISFIED时，Policy转换为PASS。
8. Java返回VIOLATED时，Policy转换为FAIL。
9. Java自身运行异常时，结果为ERROR。
10. 必要输入无法取得时，结果为BLOCKED。
11. 因前置Step失败而未执行时，结果为SKIPPED。
12. 运行结果写入Result JSON，不反写UseCase YAML。
13. Java Validator必须有ID、版本、超时和白名单管理。
14. Java Validator只负责规则评价，不直接决定整个Scenario结果。
```

这套模式可以称为：

```text
Hybrid Verification Model
混合验证模型
```

也就是：

```text
Declarative Rule Engine
        +
Java Custom Validator
        +
Unified Decision Policy
```

# 对当前设计文件的影响

这次讨论需要在`Master共通設計書.md`中增加：

```text
Custom Validator Contract
Evaluation Mode
Validator Registry
Standard Evaluation Result
Validator Evidence
Validator Version
Validator Timeout
Validator Error Mapping
Declarative／Custom／Composite关系
```

还需要影响：

```text
Verification_Master設計書.md
Verification_Policy_Master設計書.md
Context_Master設計書.md
Scenario_Master設計書.md
Compare_Policy_Master設計書.md
```

---

# 当前`system/02_master/`完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更文件

```text
本次未给出新的文件内容。

确认新增设计要求：
Hybrid Verification Model
Custom Validator Contract
Standard Evaluation Result
Validator Registry
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
```

下一版将统一纳入：

```text
Expectation Definition
Value Observation
Declarative Rule
Java Custom Validator
Composite Validation
Rule Result
Step Result
Scenario Result
```

## 第 106 轮

### 你

usecase api调用 几次java api  比如刚刚java validator 有多个复杂逻辑时候呢

### ChatGPT

这里需要把层级再拆清楚：**一次API调用是一个Step；一个Step可以挂多个Java Validator；Validator之间还可以并行、串行或组合执行。** 最终结果分Rule、Validator、Step、Scenario四层聚合。

### ChatGPT

可以。一个UseCase里可以：

```text
调用多个API
每个API调用后执行多个Java Validator
最后再执行跨API、跨Step的综合Validator
```

关键是不要把它们混成一个“大Java验证方法”。需要明确四层：

```text
UseCase
  └─ Scenario
      ├─ API Step
      │   ├─ API Invocation
      │   ├─ Validation Set
      │   │   ├─ Validator 1
      │   │   ├─ Validator 2
      │   │   └─ Validator 3
      │   └─ Step Result
      ├─ Cross-Step Validation
      └─ Scenario Result
```

# 一、同一个API调用多次怎么办

同一个API即使调用三次，也必须作为三个不同的Step实例管理。

例如：

```yaml
steps:
  - stepId: "STEP-010"
    apiRef: "API-MEMBER-001"
    invocationName: "初回会員情報取得"

  - stepId: "STEP-020"
    apiRef: "API-UPDATE-001"
    invocationName: "会員情報更新"

  - stepId: "STEP-030"
    apiRef: "API-MEMBER-001"
    invocationName: "更新後会員情報再取得"
```

这里：

```text
STEP-010和STEP-030引用同一个API
但是它们是两次独立调用
```

必须分别保存：

- Request；
- Response；
- HTTP状态；
- 开始、结束时间；
- Execution Status；
- Validator结果；
- Snapshot；
- Diff；
- Evidence。

不能只通过`apiId`识别一次执行，必须使用：

```text
runId + scenarioId + stepId + invocationId
```

---

# 二、一个API后有多个Java复杂验证

例如第二个API返回大量会员交易数据，需要检查：

1. Header与明细金额是否一致；
2. 交易ID是否重复；
3. 业务日期是否合法；
4. 会员状态与API1返回值是否一致；
5. DB数据与API返回数据是否一致。

不要全部写成一个：

```text
HugeMemberValidator
```

推荐拆成多个职责单一的Validator：

```text
VAL-TRANSACTION-TOTAL-001
VAL-TRANSACTION-UNIQUE-001
VAL-BUSINESS-DATE-001
VAL-MEMBER-CROSS-API-001
VAL-MEMBER-DB-CONSISTENCY-001
```

YAML中可以这样编排：

```yaml
- stepId: "STEP-020"
  apiRef: "API-TRANSACTION-001"

  dependencies:
    - stepId: "STEP-010"
      requiredExecutionStatus: "SUCCEEDED"
      requiredVerificationResult: "PASS"

  validations:
    executionMode: "PARALLEL"
    completionPolicy: "COLLECT_ALL"

    items:
      - validationId: "VER-020-001"
        evaluationMode: "CUSTOM_VALIDATOR"
        validatorRef: "VAL-TRANSACTION-TOTAL-001"
        required: true

        inputs:
          response:
            reference: "${steps.STEP-020.response}"

      - validationId: "VER-020-002"
        evaluationMode: "CUSTOM_VALIDATOR"
        validatorRef: "VAL-TRANSACTION-UNIQUE-001"
        required: true

        inputs:
          items:
            reference: "${steps.STEP-020.response.items}"

      - validationId: "VER-020-003"
        evaluationMode: "CUSTOM_VALIDATOR"
        validatorRef: "VAL-BUSINESS-DATE-001"
        required: true

        inputs:
          items:
            reference: "${steps.STEP-020.response.items}"
          businessDate:
            reference: "${runContext.businessDate}"

      - validationId: "VER-020-004"
        evaluationMode: "CUSTOM_VALIDATOR"
        validatorRef: "VAL-MEMBER-CROSS-API-001"
        required: true

        inputs:
          api1Response:
            reference: "${steps.STEP-010.response}"
          api2Response:
            reference: "${steps.STEP-020.response}"

      - validationId: "VER-020-005"
        evaluationMode: "CUSTOM_VALIDATOR"
        validatorRef: "VAL-MEMBER-DB-CONSISTENCY-001"
        required: false
        severity: "MINOR"

        inputs:
          response:
            reference: "${steps.STEP-020.response}"
          memberId:
            reference: "${input.memberId}"
```

这表示：

```text
STEP-020调用一次API
API返回后，执行5个Java Validator
4个是必须验证
1个是非必须验证
```

---

# 三、多个Validator是并行还是串行

支持三种模式。

## 1. 并行执行

彼此独立，只读取同一Response：

```yaml
validations:
  executionMode: "PARALLEL"
```

适合：

- 类型验证；
- 重复数据验证；
- 日期验证；
- 合计验证；
- DB一致性验证。

优点是速度快。

但Validator必须：

```text
只读
无副作用
线程安全
不能修改Response和RunContext原值
```

---

## 2. 串行执行

后一个Validator依赖前一个Validator的结果或派生数据：

```yaml
validations:
  executionMode: "SEQUENTIAL"
```

例如：

```yaml
items:
  - validationId: "VER-020-010"
    validatorRef: "VAL-NORMALIZE-TRANSACTION-001"

  - validationId: "VER-020-020"
    validatorRef: "VAL-CALCULATE-TOTAL-001"

    dependsOnValidations:
      - validationId: "VER-020-010"
        requiredOutcome: "SATISFIED"
```

但从设计上说，**数据转换和验证最好分开**。

更推荐：

```text
Normalizer
    ↓
生成Normalized Observation
    ↓
Validator
```

不要让Validator一边改变数据，一边验证数据。

---

## 3. 混合执行

先执行基础Validator，然后并行执行多个业务Validator：

```yaml
validations:
  stages:
    - stageId: "STAGE-001"
      executionMode: "SEQUENTIAL"

      items:
        - validationId: "VER-STRUCTURE"
          validatorRef: "VAL-RESPONSE-STRUCTURE-001"

    - stageId: "STAGE-002"
      dependsOnStage: "STAGE-001"
      requiredOutcome: "SATISFIED"
      executionMode: "PARALLEL"

      items:
        - validationId: "VER-TOTAL"
          validatorRef: "VAL-TRANSACTION-TOTAL-001"

        - validationId: "VER-UNIQUE"
          validatorRef: "VAL-TRANSACTION-UNIQUE-001"

        - validationId: "VER-DATE"
          validatorRef: "VAL-BUSINESS-DATE-001"
```

执行流程：

```text
先确认Response结构正常
        ↓
结构正常后
        ↓
金额、重复、日期三个验证并行执行
```

如果结构验证失败，后面无法安全读取数据：

```text
VER-STRUCTURE = FAIL
VER-TOTAL     = SKIPPED
VER-UNIQUE    = SKIPPED
VER-DATE      = SKIPPED
```

原因：

```text
DEPENDENCY_UNMET
```

---

# 四、一个Java Validator内部有多个复杂逻辑怎么办

这里有两种选择。

## 方式A：拆成多个Validator，推荐

例如一个Validator只负责一个明确的业务观点：

```text
金额一致性
日期有效性
重复检查
状态迁移检查
跨API一致性
```

优点：

- 报告容易理解；
- 可以单独重跑；
- 可以单独修改；
- 可以单独版本管理；
- 一个失败不会掩盖其他失败；
- 更容易测试；
- 更容易复用。

---

## 方式B：一个Validator返回多个Violation

当多个检查必须共享一次非常昂贵的数据准备时，可以放在一个Validator中。

例如Java先查询DB、构建索引、计算分组，成本很高。

这时：

```text
VAL-MONTHLY-TRANSACTION-COMPOSITE-001
```

可以一次完成多个检查，但不能只返回一个Boolean。

应该返回：

```json
{
  "validatorExecutionStatus": "SUCCEEDED",
  "evaluationOutcome": "VIOLATED",
  "reasonCode": "MULTIPLE_BUSINESS_RULES_VIOLATED",
  "evidence": {
    "checkedRecordCount": 100000,
    "checkedRuleCount": 5,
    "violationCount": 123
  },
  "ruleResults": [
    {
      "subRuleId": "TOTAL_AMOUNT",
      "outcome": "SATISFIED"
    },
    {
      "subRuleId": "UNIQUE_TRANSACTION_ID",
      "outcome": "VIOLATED",
      "violationCount": 20
    },
    {
      "subRuleId": "BUSINESS_DATE",
      "outcome": "VIOLATED",
      "violationCount": 103
    }
  ],
  "violations": [
    {
      "subRuleId": "UNIQUE_TRANSACTION_ID",
      "path": "$.items[120].transactionId",
      "reasonCode": "DUPLICATE_TRANSACTION_ID"
    }
  ]
}
```

也就是说：

```text
一个Validator可以返回多个子规则结果
但每个子规则仍然必须有独立ID
```

这样报告才能显示：

```text
总金额检查：PASS
重复ID检查：FAIL
业务日期检查：FAIL
```

而不是只显示：

```text
复杂业务验证：FAIL
```

---

# 五、什么时候应该拆，什么时候应该合并

|情况|推荐|
|---|---|
|逻辑完全独立|拆成多个Validator|
|可以并行执行|拆成多个Validator|
|需要单独报告|拆成多个Validator|
|需要单独版本管理|拆成多个Validator|
|会被多个UseCase复用|拆成多个Validator|
|共享昂贵的DB查询|可组合为一个Composite Validator|
|必须一次性保持原子判断|可组合|
|多个规则之间高度耦合|可组合|
|只是为了少写几个Java类|不应组合|

核心原则：

> **按业务验证责任拆分，不按Java代码行数拆分。**

---

# 六、Java Validator之间能否传值

可以，但不应该随意修改共享Context。

推荐Java Validator只能返回：

```text
Evidence
Violation
Derived Fact
```

例如：

```json
{
  "derivedFacts": {
    "calculatedTotalAmount": 1500000,
    "uniqueTransactionCount": 99980
  }
}
```

YAML中显式声明输出：

```yaml
- validationId: "VER-020-001"
  validatorRef: "VAL-TRANSACTION-ANALYSIS-001"

  exports:
    calculatedTotalAmount:
      source: "$result.derivedFacts.calculatedTotalAmount"

    uniqueTransactionCount:
      source: "$result.derivedFacts.uniqueTransactionCount"
```

后续Validator引用：

```yaml
- validationId: "VER-020-002"
  validatorRef: "VAL-TOTAL-CONSISTENCY-001"

  dependsOnValidations:
    - validationId: "VER-020-001"
      requiredOutcome: "SATISFIED"

  inputs:
    calculatedTotal:
      reference: "${validations.VER-020-001.calculatedTotalAmount}"

    headerTotal:
      reference: "${steps.STEP-020.response.totalAmount}"
```

但这些派生值必须：

- 不覆盖原始Response；
- 不修改原始Snapshot；
- 带Validator ID和版本；
- 带生成时间；
- 可追踪来源；
- 在同一次Run内不可变。

---

# 七、Validator执行失败时其他Validator怎么办

需要在YAML中定义完成策略。

## 收集全部结果

```yaml
completionPolicy: "COLLECT_ALL"
```

某个Validator异常时，其余独立Validator继续执行。

例如：

```text
VAL-A = PASS
VAL-B = ERROR
VAL-C = FAIL
VAL-D = PASS
```

Step最终：

```text
ERROR
```

但报告仍然保留：

```text
VAL-C发现了业务错误
```

不能因为VAL-B异常就丢掉其他结果。

---

## 立即停止

```yaml
completionPolicy: "FAIL_FAST"
```

适合：

- Response结构已经损坏；
- 数据安全条件不满足；
- 后续验证可能产生误判；
- 后续检查成本特别高。

不过一般业务验证建议：

```text
COLLECT_ALL
```

基础结构验证可以：

```text
FAIL_FAST
```

---

# 八、Step最终结果怎么聚合

每个Validator先产生自己的结果。

例如：

|Validator|执行状态|评价结果|Rule Result|
|---|---|---|---|
|总金额检查|SUCCEEDED|SATISFIED|PASS|
|重复检查|SUCCEEDED|VIOLATED|FAIL|
|日期检查|SUCCEEDED|SATISFIED|PASS|
|DB检查|FAILED|INDETERMINATE|ERROR|

如果DB检查是必须项：

```text
Step Result = ERROR
```

如果DB检查是非必须项：

```text
Step Result = FAIL
```

原因来自重复检查。

默认聚合优先级建议：

```text
ERROR
  ↓
BLOCKED
  ↓
FAIL
  ↓
PASS
```

`SKIPPED`不简单参与这个优先级。

例如：

```text
一个必须Validator FAIL
后续两个Validator因依赖未满足而SKIPPED

Step最终仍然是FAIL
```

不是SKIPPED。

---

# 九、Scenario整体结果

例如UseCase中有三个API Step：

|Step|内容|结果|
|---|---|---|
|STEP-010|API1执行及验证|PASS|
|STEP-020|API2执行，5个Validator中1个FAIL|FAIL|
|STEP-030|依赖STEP-020，未执行|SKIPPED|

Scenario结果：

```yaml
scenarioResult:
  result: "FAIL"
  reasonCode: "REQUIRED_STEP_FAILED"
  primaryFailedStepId: "STEP-020"
```

如果STEP-020中的Java Validator技术异常：

```text
STEP-010 = PASS
STEP-020 = ERROR
STEP-030 = SKIPPED
Scenario = ERROR
```

---

# 十、跨多个API的Java Validator放在哪里

有些验证不属于某一个API。

例如：

```text
API1返回余额
API2执行扣款
API3返回扣款后余额

需要验证：
API3余额 = API1余额 - API2扣款金额
```

这应该放在Scenario级跨Step验证中：

```yaml
crossStepValidations:
  - validationId: "VER-SC-001"
    evaluationMode: "CUSTOM_VALIDATOR"
    validatorRef: "VAL-BALANCE-TRANSITION-001"
    required: true

    dependencies:
      - stepId: "STEP-010"
        requiredVerificationResult: "PASS"

      - stepId: "STEP-020"
        requiredVerificationResult: "PASS"

      - stepId: "STEP-030"
        requiredVerificationResult: "PASS"

    inputs:
      beforeBalance:
        reference: "${steps.STEP-010.response.balance}"

      deductionAmount:
        reference: "${steps.STEP-020.request.amount}"

      afterBalance:
        reference: "${steps.STEP-030.response.balance}"
```

所以验证位置分为：

```text
Step Validation
    验证单个API调用

Cross-Step Validation
    验证多个API之间的关系

Scenario Validation
    验证整个业务路径和最终状态
```

---

# 十一、推荐的完整层级

```text
UseCase
└── Scenario
    ├── STEP-010 API Invocation
    │   └── Validation Set
    │       ├── Declarative Rule
    │       ├── Java Validator
    │       └── Java Validator
    │
    ├── STEP-020 API Invocation
    │   └── Validation Set
    │       ├── Declarative Rule
    │       ├── Java Validator
    │       ├── Java Validator
    │       └── Composite Java Validator
    │
    ├── STEP-030 API Invocation
    │   └── Validation Set
    │
    ├── Cross-Step Validation Set
    │   ├── API1 ↔ API2
    │   ├── API2 ↔ API3
    │   └── API1 ↔ API3
    │
    └── Scenario Aggregation
```

数量关系不是固定的：

```text
一个UseCase
  = 1..N个Scenario

一个Scenario
  = 1..N个API Step

一个API Step
  = 0..N个Validation

一个Validation
  = Declarative Rule
    或Custom Java Validator
    或Composite Validator
```

---

# 十二、必须新增的Canonical概念

这次设计需要正式增加：

```text
Validation Set
Validation Execution
Validation Stage
Validation Dependency
Validation Aggregation
Cross-Step Validation
Composite Validator
Validator Sub-Rule
Derived Fact
Completion Policy
Execution Mode
```

建议Canonical Enum：

```text
Execution Mode:
SEQUENTIAL
PARALLEL
STAGED

Completion Policy:
COLLECT_ALL
FAIL_FAST

Evaluation Mode:
DECLARATIVE
CUSTOM_VALIDATOR
COMPOSITE
```

---

# 当前 `system/02_master/` 完整结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次没有给出新的文件正文。

新增设计要求：

1. 一个API Step允许配置多个Java Validator。
2. Validator支持并行、串行和阶段式执行。
3. 支持Validator间依赖。
4. 支持Step级和Cross-Step级验证。
5. 支持Composite Validator及子规则结果。
6. 支持COLLECT_ALL与FAIL_FAST。
7. 增加Validator Result → Step Result → Scenario Result多级聚合。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【下一份】
```

下一版必须统一写入：

```text
UseCase → Scenario → API Step → Validation Set
Declarative Rule
Multiple Java Validators
Composite Validator
Cross-Step Validation
Result Aggregation
```

## 第 107 轮

### 你

不觉得定义yml很复杂吗
为什么不把这些比较写出一个个java的共通check方法 ，
特别的就是这个业务的执行环节的一个check处理，
这样一个scenario就是一次java batch调用 不是更简单吗

### ChatGPT

你这个判断是对的。对你现在大约7个业务Flow、24个API、10个以内UseCase的规模，**为了“可配置”而设计一套复杂YAML验证语言，反而会增加实现和维护成本**。

### ChatGPT

对。**你这个方案更适合当前系统。**

前面把YAML设计成可以描述流程、依赖、比较、表达式、Java Validator、聚合规则，已经逐渐变成了另一门“验证编程语言”。这会带来：

- YAML越来越难写；
- 还要开发YAML解析器；
- 还要做表达式引擎；
- 还要做Reference解析；
- 还要设计Schema；
- 出错后不容易调试；
- 复杂业务最终还是要回到Java。

这属于过度设计。

# 一、推荐改为 Java First Verification Model

整体调整为：

```text
一个Scenario
=
一次Java Scenario执行
=
按顺序调用多个API
+
执行共通Check
+
执行业务专用Check
+
生成Scenario结果
```

例如：

```text
SC-001 正常会员更新Scenario

Java Scenario开始
    ↓
调用API1：登录
    ↓
执行API1共通Check
    ↓
调用API2：会员查询
    ↓
执行API2共通Check
    ↓
调用API3：会员更新
    ↓
执行API3共通Check
    ↓
执行会员更新业务Check
    ↓
执行API1、API2、API3跨API整合Check
    ↓
聚合Scenario结果
    ↓
输出JSON报告
```

YAML不再负责描述整套执行逻辑。

---

# 二、推荐的生产单位

正确层级可以固定为：

```text
UseCase
└── Scenario Java Class
    ├── API Step 1
    ├── API Step 2
    ├── API Step 3
    ├── Common Checks
    ├── Business Checks
    ├── Cross-Step Checks
    └── Scenario Result Aggregation
```

对应关系：

|概念|实现单位|
|---|---|
|UseCase|Java package|
|Scenario|Java class|
|一次API调用|ScenarioStep|
|共通验证|Common Check类／方法|
|业务特殊验证|Business Check类|
|跨API验证|Cross-Step Check类|
|一次执行|ScenarioRunner调用|
|执行结果|JSON|
|设计说明|Markdown|

---

# 三、一个Scenario就是一次Java调用

可以这样运行：

```bash
java -jar api-verifier.jar \
  --usecase=UC-E6-001 \
  --scenario=SC-E6-001 \
  --environment=test \
  --input=scenario-input.json
```

一次命令完成整个Scenario。

逻辑上这就是一次Batch执行。

但是目前不一定需要直接使用Spring Batch。对于你现在大约：

```text
7个业务Flow
24个API
10个以内UseCase
```

一个普通的Java Runner就足够。

例如：

```java
public interface VerificationScenario {

    ScenarioResult execute(ScenarioContext context);
}
```

每个Scenario实现这个接口：

```java
@Component("SC-E6-001")
public class MemberUpdateScenario
        implements VerificationScenario {

    @Override
    public ScenarioResult execute(
            ScenarioContext context) {

        ScenarioResultBuilder result =
            ScenarioResultBuilder.create(
                context.runId(),
                "SC-E6-001"
            );

        // API1
        ApiExecutionResult loginResult =
            executeLoginApi(context);

        result.addStep(loginResult);

        // API1验证
        result.addChecks(
            verifyLoginApi(loginResult, context)
        );

        if (!result.canContinue("STEP-001")) {
            result.skipStep(
                "STEP-002",
                "DEPENDENCY_UNMET"
            );

            return result.build();
        }

        // API2
        ApiExecutionResult memberResult =
            executeMemberApi(
                context,
                loginResult
            );

        result.addStep(memberResult);

        // API2共通检查
        result.addChecks(
            verifyMemberApiCommon(
                memberResult,
                context
            )
        );

        // API2业务检查
        result.addChecks(
            memberBusinessCheck.verify(
                memberResult.response(),
                context
            )
        );

        return result.build();
    }
}
```

---

# 四、比较逻辑做成Java共通Check

你的想法完全正确。

常见检查不需要每个UseCase重新写，也不需要通过复杂YAML定义。

统一做成Java共通Check库：

```text
Common Verification Check Library
```

例如：

```java
Checks.required(...)
Checks.notNull(...)
Checks.nullAllowed(...)
Checks.type(...)
Checks.length(...)
Checks.numericDigits(...)
Checks.exact(...)
Checks.enumValue(...)
Checks.range(...)
Checks.regex(...)
Checks.dateFormat(...)
Checks.dateRange(...)
Checks.httpStatus(...)
Checks.jsonPathExists(...)
Checks.arrayCount(...)
Checks.unique(...)
Checks.sumEquals(...)
Checks.referenceEquals(...)
Checks.schema(...)
```

调用例子：

```java
List<CheckResult> checks = new ArrayList<>();

checks.add(
    Checks.httpStatus(
        "CHK-HTTP-001",
        apiResult.httpStatus(),
        200
    )
);

checks.add(
    Checks.required(
        "CHK-ID-001",
        "$.memberId",
        response.getMemberId()
    )
);

checks.add(
    Checks.length(
        "CHK-ID-002",
        "$.memberId",
        response.getMemberId(),
        12
    )
);

checks.add(
    Checks.inMonth(
        "CHK-DATE-001",
        "$.updateDate",
        response.getUpdateDate(),
        context.targetMonth()
    )
);
```

这样比YAML简单很多，并且有：

- Java类型安全；
- IDE自动补全；
- 编译检查；
- 单元测试；
- Debug断点；
- 重构支持；
- 共通方法复用；
- 代码Review；
- Git版本管理。

---

# 五、业务特殊Check怎么做

特殊业务逻辑不放到共通Check里。

例如：

```text
会员状态变化是否合法
余额变化是否正确
明细合计是否等于Header
API1结果和API3结果是否满足业务关系
10万条交易数据是否符合复杂分组规则
```

可以写成业务专用Check：

```java
public interface BusinessCheck {

    List<CheckResult> verify(
        BusinessCheckContext context
    );
}
```

例如：

```java
@Component
public class MemberTransactionBusinessCheck
        implements BusinessCheck {

    @Override
    public List<CheckResult> verify(
            BusinessCheckContext context) {

        List<CheckResult> results =
            new ArrayList<>();

        MemberResponse response =
            context.get(
                "memberResponse",
                MemberResponse.class
            );

        results.add(
            verifyTotalAmount(response)
        );

        results.addAll(
            verifyDuplicateTransactions(response)
        );

        results.addAll(
            verifyBusinessDates(
                response,
                context.businessDate()
            )
        );

        results.add(
            verifyMemberStatusTransition(
                context
            )
        );

        return results;
    }
}
```

一个业务Check内部可以有多个复杂验证。

但最好每个验证返回一个独立`CheckResult`，不要最后只返回一个Boolean。

---

# 六、不要只返回true或false

Java验证逻辑通过时，不能只返回：

```java
return true;
```

否则报告不知道：

- 验证了什么；
- 检查了多少条；
- 使用了什么期待条件；
- 为什么失败；
- 哪一条失败；
- 是业务不一致还是Java异常。

推荐统一结果：

```java
public record CheckResult(
    String checkId,
    String checkName,
    VerificationResult result,
    String reasonCode,
    Severity severity,
    String targetPath,
    Object expectedSummary,
    Object actualSummary,
    Map<String, Object> evidence,
    List<Violation> violations
) {
}
```

结果Enum：

```java
public enum VerificationResult {
    PASS,
    FAIL,
    ERROR,
    BLOCKED,
    SKIPPED
}
```

---

## Java逻辑验证通过

```java
return CheckResult.pass(
    "CHK-BIZ-001",
    "明細合計整合性チェック",
    Map.of(
        "expectedTotal", headerTotal,
        "actualTotal", detailTotal,
        "checkedCount", items.size()
    )
);
```

结果JSON：

```json
{
  "checkId": "CHK-BIZ-001",
  "checkName": "明細合計整合性チェック",
  "result": "PASS",
  "reasonCode": "DETAIL_TOTAL_MATCHED",
  "evidence": {
    "expectedTotal": 150000,
    "actualTotal": 150000,
    "checkedCount": 10000
  }
}
```

---

## Java正常执行，但业务不符合

```java
return CheckResult.fail(
    "CHK-BIZ-001",
    "DETAIL_TOTAL_MISMATCH",
    expectedTotal,
    actualTotal
);
```

结果：

```json
{
  "checkId": "CHK-BIZ-001",
  "result": "FAIL",
  "reasonCode": "DETAIL_TOTAL_MISMATCH",
  "expectedSummary": 150000,
  "actualSummary": 149000
}
```

---

## Java验证逻辑自身异常

```java
catch (Exception exception) {
    return CheckResult.error(
        "CHK-BIZ-001",
        "BUSINESS_CHECK_EXECUTION_ERROR",
        exception
    );
}
```

结果：

```json
{
  "checkId": "CHK-BIZ-001",
  "result": "ERROR",
  "reasonCode": "BUSINESS_CHECK_EXECUTION_ERROR"
}
```

---

# 七、多个复杂逻辑如何组织

不建议一个Scenario中写一个几千行的大方法。

推荐拆成：

```text
Scenario Orchestrator
    只负责流程顺序

API Client
    负责API调用

Common Check
    负责通用验证

Business Check
    负责业务专用验证

Cross-Step Check
    负责多个API之间验证

Result Aggregator
    负责最终结果
```

例如：

```text
MemberUpdateScenario
├── LoginApiStep
├── MemberGetApiStep
├── MemberUpdateApiStep
├── CommonResponseChecks
├── MemberStatusBusinessCheck
├── MemberBalanceBusinessCheck
├── MemberCrossApiCheck
└── ScenarioResultAggregator
```

---

# 八、跨多个API的验证

例如：

```text
API1返回更新前余额：1000
API2扣款金额：300
API3返回更新后余额：700
```

共通关系：

```text
更新后余额
=
更新前余额 - 扣款金额
```

Java：

```java
public CheckResult verifyBalanceTransition(
        BigDecimal beforeBalance,
        BigDecimal deductionAmount,
        BigDecimal afterBalance) {

    BigDecimal expectedAfter =
        beforeBalance.subtract(
            deductionAmount
        );

    return Checks.exact(
        "CHK-CROSS-001",
        "$.afterBalance",
        afterBalance,
        expectedAfter
    );
}
```

这里期待值是Java运行时动态计算出来的，不需要写到YAML。

---

# 九、期待值很长很大怎么办

Java First模式下更容易处理。

## 方式一：验证业务条件

不保存完整期待值，只验证：

```text
结构
类型
件数
唯一性
日期
合计
父子关系
状态迁移
业务计算结果
```

---

## 方式二：读取外部文件

Java读取大型Expected文件：

```java
ExpectedData expected =
    expectedDataLoader.load(
        context.expectedFilePath()
    );
```

文件可以是：

```text
JSON
CSV
数据库
Baseline Snapshot
```

不需要把大数据塞进YAML。

---

## 方式三：动态生成期待值

```java
ExpectedData expected =
    expectedGenerator.generate(
        context.businessDate(),
        api1Response,
        databaseResult
    );
```

---

## 方式四：Hash对比

```java
CheckResult result =
    Checks.canonicalHash(
        actualLargeData,
        expectedHash,
        normalizationPolicy
    );
```

---

# 十、YAML还需要吗

在这个新方案下，**UseCase执行和验证不再依赖复杂YAML**。

YAML只保留非常简单的环境配置，例如：

```yaml
environments:
  test:
    baseUrl: "https://test.example.com"
    connectTimeoutMs: 5000
    readTimeoutMs: 30000
```

以及可能经常变化、又不希望重新编译的简单参数：

```yaml
scenarioParameters:
  targetMonth: "2026-07"
  maximumRecordCount: 100000
```

不建议再用YAML描述：

```text
API执行顺序
依赖链
Validator执行顺序
复杂Expectation
复杂表达式
结果聚合
```

这些都放Java。

---

# 十一、JSON Schema还有什么用途

在Java First方案下，JSON Schema的重要性降低。

它只用于：

1. 检查外部输入JSON；
2. 检查API Request／Response结构；
3. 检查执行结果JSON格式；
4. 检查大型Expected JSON文件；
5. 与API契约进行Schema验证。

不再需要为每一个UseCase设计一整套复杂YAML Schema。

所以之前规划的：

```text
usecase.schema.json
scenario.schema.json
verification-rule.schema.json
dependency.schema.json
aggregation.schema.json
```

可以删除或取消规划。

这是架构简化。

---

# 十二、最终推荐架构

```mermaid
flowchart TD
    A[ScenarioRunner] --> B[Java Scenario Class]
    B --> C1[API Step 1]
    B --> C2[API Step 2]
    B --> C3[API Step 3]

    C1 --> D1[Common Checks]
    C2 --> D2[Common Checks]
    C3 --> D3[Common Checks]

    B --> E1[Business Checks]
    B --> E2[Cross-Step Checks]

    D1 --> F[Result Aggregator]
    D2 --> F
    D3 --> F
    E1 --> F
    E2 --> F

    F --> G[Scenario Result JSON]
```

---

# 十三、推荐的Java工程结构

```text
src/main/java/
└── com/company/apiverifier/
    ├── core/
    │   ├── scenario/
    │   │   ├── VerificationScenario.java
    │   │   ├── ScenarioContext.java
    │   │   ├── ScenarioResult.java
    │   │   └── ScenarioRunner.java
    │   │
    │   ├── step/
    │   │   ├── ApiStep.java
    │   │   ├── ApiExecutionResult.java
    │   │   └── StepResult.java
    │   │
    │   ├── check/
    │   │   ├── CheckResult.java
    │   │   ├── Checks.java
    │   │   ├── VerificationResult.java
    │   │   └── ResultAggregator.java
    │   │
    │   ├── client/
    │   │   └── ApiClient.java
    │   │
    │   └── report/
    │       └── ResultWriter.java
    │
    └── usecases/
        ├── uc_e6_001/
        │   ├── MemberUpdateScenario.java
        │   ├── MemberStatusBusinessCheck.java
        │   ├── MemberBalanceBusinessCheck.java
        │   └── MemberCrossApiCheck.java
        │
        └── uc_e6_002/
            └── ...
```

测试：

```text
src/test/java/
├── core/check/
│   ├── RequiredCheckTest.java
│   ├── LengthCheckTest.java
│   ├── RangeCheckTest.java
│   └── AggregateCheckTest.java
│
└── usecases/
    └── uc_e6_001/
        ├── MemberUpdateScenarioTest.java
        ├── MemberStatusBusinessCheckTest.java
        └── MemberCrossApiCheckTest.java
```

---

# 十四、最终结论

这次应该正式调整为：

```text
Java First Verification Model
```

核心原则：

```text
1. 一个Scenario对应一次Java执行入口。
2. Scenario中按业务顺序调用多个API。
3. 常见比较做成Java共通Check方法。
4. 特殊业务验证做成业务专用Check。
5. 跨API关系做成Cross-Step Check。
6. 所有Check返回统一CheckResult。
7. 不设计复杂YAML验证语言。
8. YAML仅用于环境和少量外部参数。
9. JSON用于输入、证据、Snapshot、Diff和结果。
10. Scenario整体结果由统一Aggregator生成。
```

**这比复杂YAML方案更简单，也更适合你的Java开发团队。**

---

# 当前 `system/02_master/` 完整结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
架构结论从：

YAML Driven Hybrid Verification

修正为：

Java First Verification Model
```

取消或降级：

```text
复杂UseCase YAML
复杂Scenario YAML
Validation DSL
YAML Expression Engine
YAML Dependency Engine
每个验证规则对应的复杂JSON Schema
```

保留：

```text
Java Scenario
Java Common Check
Java Business Check
Java Cross-Step Check
统一Result Model
环境配置YAML
输入及结果JSON
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【下一份／按Java First Verification Model重新编写】
```

## 第 108 轮

### 你

还是之前那问题，这种设计里面我仍然需要每一个api调用前后的json 以及每一个check的比较值，值依然会有预期，前回，今回  3个，然后按照比较结果来决定是否成功， 如何处理，以及diff snapshot report表示

### ChatGPT

Java First只改变“比较逻辑写在哪里”，**不会取消Previous／Current／Expected、Snapshot、Diff和Report**。这些应当作为统一证据模型，由每个Java Check按标准格式返回。

### ChatGPT

对。**Java First并不等于只在Java里返回一个PASS／FAIL。**
Java负责执行比较逻辑，但每次API调用前后的JSON、每个Check的Previous／Current／Expected、Diff、Snapshot、Report仍然必须完整保存。

真正应该冻结的是：

```text
Java负责“怎么算”

统一Evidence Model负责“保存算了什么”

Verification Policy负责“最后判定什么结果”

Snapshot／Diff／Report负责“怎样留下证据和展示”
```

# 一、整体执行模型

```mermaid
flowchart TD
    A[Scenario Java Batch开始] --> B[加载Previous Snapshot]
    A --> C[加载或生成Expected Definition]

    B --> D[API Step执行前]
    C --> D

    D --> E[保存Request Current JSON]
    E --> F[调用API]
    F --> G[保存Response Current JSON或Execution Error]

    G --> H[执行Common Check]
    G --> I[执行Business Check]
    G --> J[执行Cross-Step Check]

    H --> K[生成Check Evidence]
    I --> K
    J --> K

    K --> L[Previous ↔ Current Baseline Diff]
    K --> M[Expected ↔ Current Verification Evaluation]

    L --> N[Result Decision]
    M --> N

    N --> O[Step Result]
    O --> P[Scenario Result]
    P --> Q[Snapshot / Diff / Report]
```

核心不变：

```text
Previous
Current
Expected
```

两种比较也不变：

```text
Previous ↔ Current
用于确认发生了什么变化

Expected ↔ Current
用于确认本次结果是否正确
```

---

# 二、每个API Step必须保存哪些JSON

建议每次Scenario执行生成一个Run目录。

```text
runs/
└── RUN-20260724-001/
    ├── run-context.json
    ├── scenario-result.json
    │
    └── steps/
        ├── STEP-001/
        │   ├── request/
        │   │   ├── request-resolved.json
        │   │   └── request-sent.json
        │   │
        │   ├── response/
        │   │   ├── response-received.json
        │   │   └── execution-metadata.json
        │   │
        │   ├── snapshots/
        │   │   ├── previous-snapshot.json
        │   │   ├── current-snapshot.json
        │   │   └── expected-snapshot.json
        │   │
        │   ├── checks/
        │   │   └── check-results.json
        │   │
        │   └── diff/
        │       ├── baseline-diff.json
        │       └── expected-diff.json
        │
        └── STEP-002/
            └── ...
```

## API调用前

保存：

```text
request-resolved.json
```

表示参数映射、Context引用和默认值处理完成后的Request。

例如：

```json
{
  "stepId": "STEP-002",
  "apiId": "API-MEMBER-001",
  "request": {
    "memberId": "M000001",
    "targetMonth": "2026-07"
  }
}
```

必要时再保存：

```text
request-sent.json
```

表示真正发送出去的内容。

敏感值需要脱敏：

```json
{
  "headers": {
    "Authorization": "***MASKED***"
  }
}
```

## API调用后

有HTTP Response时保存：

```text
response-received.json
```

没有Response，例如连接失败、超时，则不伪造空Response，而是保存：

```json
{
  "executionStatus": "FAILED",
  "reasonCode": "API_TIMEOUT",
  "responseState": "NOT_RECEIVED"
}
```

也就是：

```text
Response为null
```

和：

```text
没有取得Response
```

必须区分。

---

# 三、每一个Check都保留三个Evidence

每个Check统一保存：

```text
Previous Evidence
Current Evidence
Expected Evidence
```

这里不要求三个一定都是简单值。

它们可以是：

- 单一值；
- JSON对象；
- 数组；
- 汇总结果；
- 长度、件数；
- Hash；
- 业务条件；
- Java动态计算结果；
- 外部数据Reference。

标准结构：

```json
{
  "checkId": "CHK-BALANCE-001",
  "checkName": "残高遷移整合性チェック",
  "checkType": "BUSINESS",

  "previous": {
    "state": "PRESENT",
    "value": 900
  },

  "current": {
    "state": "PRESENT",
    "value": 700
  },

  "expected": {
    "mode": "DERIVED",
    "state": "RESOLVED",
    "value": 700,
    "formulaSummary": "beforeBalance - deductionAmount"
  },

  "baselineComparison": {
    "outcome": "MISMATCH",
    "reasonCode": "VALUE_CHANGED"
  },

  "expectedEvaluation": {
    "outcome": "SATISFIED",
    "reasonCode": "EXPECTED_VALUE_MATCHED"
  },

  "verificationResult": {
    "result": "PASS",
    "reasonCode": "BASELINE_CHANGED_EXPECTED_SATISFIED"
  }
}
```

这个例子表示：

```text
Previous = 900
Current  = 700
Expected = 700
```

所以：

```text
Baseline Diff = MISMATCH
Expected Evaluation = SATISFIED
最终 = PASS
```

---

# 四、Expected不一定是固定值

这是最重要的一点。

每个Check必须有Expected槽位，但Expected可以有多种表现形式。

```text
EXACT_VALUE
CONSTRAINT
DERIVED_VALUE
REFERENCE_VALUE
BUSINESS_RULE
CUSTOM_LOGIC
OBSERVATION_ONLY
```

## 固定值

```json
{
  "expected": {
    "mode": "EXACT_VALUE",
    "value": "SUCCESS"
  }
}
```

## 长度规则

例如值每天变化，只要求12位：

```json
{
  "current": {
    "value": "202607240001",
    "derivedMetrics": {
      "length": 12
    }
  },
  "expected": {
    "mode": "CONSTRAINT",
    "condition": {
      "type": "LENGTH",
      "exactLength": 12
    }
  }
}
```

Report中不是显示：

```text
Expected Value = 某个固定编号
```

而是显示：

```text
Expected Condition = 长度12位
Current Evidence = 长度12位
Result = PASS
```

## Java动态计算期待值

```json
{
  "expected": {
    "mode": "DERIVED_VALUE",
    "value": 700,
    "derivation": {
      "checkImplementationId": "CHK-BALANCE-TRANSITION",
      "formulaSummary": "1000 - 300",
      "inputReferences": [
        "STEP-001.response.balance",
        "STEP-002.request.amount"
      ]
    }
  }
}
```

## 复杂业务逻辑

复杂逻辑没有单一期待值时：

```json
{
  "expected": {
    "mode": "BUSINESS_RULE",
    "ruleId": "RULE-MONTHLY-TRANSACTION-CONSISTENCY",
    "ruleVersion": "1.2.0",
    "conditionSummary": "明細、集計、業務日及びステータス間の整合性が成立すること"
  }
}
```

Java执行后返回：

```json
{
  "current": {
    "state": "PRESENT",
    "summary": {
      "checkedRecordCount": 100000,
      "calculatedTotal": 1500000,
      "duplicateCount": 0,
      "invalidBusinessDateCount": 0
    }
  },
  "expectedEvaluation": {
    "outcome": "SATISFIED"
  },
  "verificationResult": {
    "result": "PASS"
  }
}
```

所以：

> Expected不一定是一个“值”，但必须有明确的期待定义、版本和判定证据。

---

# 五、Java Check不能只返回Boolean

Java共通Check或业务Check应统一返回`CheckResult`。

```java
public record CheckResult(
    String checkId,
    String checkName,
    String implementationId,
    String implementationVersion,

    Evidence previous,
    Evidence current,
    ExpectedEvidence expected,

    ComparisonResult baselineComparison,
    EvaluationResult expectedEvaluation,

    VerificationResult verificationResult,

    Map<String, Object> evidence,
    List<Violation> violations
) {
}
```

Java Check的职责：

```text
1. 取得或计算Current Evidence
2. 取得Previous Evidence
3. 生成或解析Expected Evidence
4. 执行Baseline Compare
5. 执行Expected Evaluation
6. 返回完整CheckResult
```

但文件写入由Framework统一完成。

Java Check本身不要直接写：

```text
snapshot.json
diff.json
report.json
```

否则每个业务Check会产生不同格式。

---

# 六、Java Check的标准返回结果

## 正常验证通过

```java
return CheckResultBuilder.create("CHK-001")
    .previous(previousValue)
    .current(currentValue)
    .expected(expectedValue)
    .baselineOutcome(MISMATCH)
    .expectedOutcome(SATISFIED)
    .result(PASS)
    .reasonCode("BASELINE_CHANGED_EXPECTED_SATISFIED")
    .build();
```

## 正常执行，但业务不满足

```java
return CheckResultBuilder.create("CHK-001")
    .previous(previousValue)
    .current(currentValue)
    .expected(expectedValue)
    .baselineOutcome(MISMATCH)
    .expectedOutcome(VIOLATED)
    .result(FAIL)
    .reasonCode("EXPECTED_NOT_SATISFIED")
    .build();
```

## Java Check自身异常

```java
return CheckResultBuilder.create("CHK-001")
    .currentUnresolved()
    .expectedNotEvaluated()
    .result(ERROR)
    .reasonCode("CHECK_EXECUTION_ERROR")
    .exception(exception)
    .build();
```

## 必要Expected无法取得

```java
return CheckResultBuilder.create("CHK-001")
    .current(currentValue)
    .expectedUnresolved()
    .result(BLOCKED)
    .reasonCode("EXPECTED_SOURCE_UNAVAILABLE")
    .build();
```

---

# 七、Snapshot如何设计

Snapshot不是只有一个大Response文件。

应分为两层。

## 1. Raw Snapshot

保存API调用本身。

```text
Request
Response
HTTP Status
Headers
Execution Time
Transport Result
```

例如：

```json
{
  "stepId": "STEP-002",
  "requestRef": "request/request-sent.json",
  "responseRef": "response/response-received.json",
  "httpStatus": 200,
  "executionStatus": "SUCCEEDED"
}
```

## 2. Verification Snapshot

保存Check级Evidence。

```json
{
  "stepId": "STEP-002",
  "checks": [
    {
      "checkId": "CHK-001",
      "previous": {
        "value": 900
      },
      "current": {
        "value": 700
      },
      "expected": {
        "value": 700
      },
      "result": "PASS"
    }
  ]
}
```

---

## 三种Snapshot

### Baseline Snapshot

来源：

```text
前一次承认済みRun
```

注意不是简单使用“昨天最后一次运行”。

必须通过Baseline Policy选择：

```text
最新承认済み结果
指定Release版本
指定Baseline版本
指定Run ID
```

### Current Snapshot

来源：

```text
本次实际执行
```

包含：

- Request；
- Response；
- Execution Metadata；
- Check Evidence；
- Derived Value；
- Check Result。

### Expected Snapshot

来源：

```text
本次运行时解析出来的期待定义和期待值
```

Expected Snapshot必须保存运行时解析结果。

因为期待值可能来自：

- 业务日期；
- 前一个API；
- DB；
- Java计算；
- 外部文件；
- Baseline；
- 环境变量。

例如：

```json
{
  "checkId": "CHK-BALANCE-001",
  "expectedMode": "DERIVED_VALUE",
  "resolvedValue": 700,
  "resolvedAt": "2026-07-24T10:05:00+09:00",
  "resolverId": "BALANCE-EXPECTED-RESOLVER",
  "resolverVersion": "1.0.0"
}
```

以后重现运行时，才能知道当时为什么判定为PASS。

---

# 八、Diff如何设计

仍然保留两种Diff。

## 1. Baseline Diff

```text
Previous ↔ Current
```

作用：

- 发现API返回结构变化；
- 发现字段值变化；
- 发现件数变化；
- 发现执行状态变化；
- 发现Check结果变化。

文件：

```text
baseline-diff.json
```

例如：

```json
{
  "path": "$.balance",
  "previous": 900,
  "current": 700,
  "outcome": "MISMATCH",
  "changeType": "VALUE_CHANGED"
}
```

---

## 2. Expected Diff／Verification Diff

```text
Expected ↔ Current
```

作用：

- 判定业务正确性；
- 决定PASS／FAIL。

文件：

```text
expected-diff.json
```

例如：

```json
{
  "checkId": "CHK-BALANCE-001",
  "expected": 700,
  "current": 700,
  "outcome": "SATISFIED",
  "verificationResult": "PASS"
}
```

对于长度Check：

```json
{
  "checkId": "CHK-ID-LENGTH-001",
  "expected": {
    "condition": "length == 12"
  },
  "current": {
    "value": "202607240001",
    "length": 12
  },
  "outcome": "SATISFIED",
  "verificationResult": "PASS"
}
```

对于复杂Java业务Check：

```json
{
  "checkId": "CHK-MONTHLY-BUSINESS-001",
  "expected": {
    "ruleId": "RULE-MONTHLY-CONSISTENCY",
    "ruleVersion": "1.2.0"
  },
  "current": {
    "checkedRecordCount": 100000,
    "violationCount": 3
  },
  "outcome": "VIOLATED",
  "verificationResult": "FAIL",
  "violationsRef": "checks/CHK-MONTHLY-BUSINESS-001-violations.json"
}
```

---

# 九、数据很长时Diff怎么表示

不能把十万条Previous、Current、Expected全部塞进Report。

需要：

```text
完整数据保存到Snapshot文件

Diff保存变化结果

Report显示摘要和代表性明细
```

例如：

```json
{
  "checkId": "CHK-LARGE-DATA-001",

  "previous": {
    "contentRef": "snapshots/previous/items.json",
    "recordCount": 100000,
    "canonicalHash": "abc123"
  },

  "current": {
    "contentRef": "snapshots/current/items.json",
    "recordCount": 100005,
    "canonicalHash": "def456"
  },

  "expected": {
    "mode": "BUSINESS_RULE",
    "ruleId": "RULE-TRANSACTION-DATASET-001"
  },

  "baselineDiff": {
    "addedCount": 10,
    "removedCount": 5,
    "changedCount": 20
  },

  "expectedEvaluation": {
    "violationCount": 3
  }
}
```

Report只显示：

```text
检查件数：100,005
新增：10
删除：5
变更：20
业务违反：3
详细Diff：baseline-diff-detail.json
详细违反：violations.json
```

---

# 十、Report如何显示

## Scenario汇总

|Step|API|Execution|Check PASS|Check FAIL|ERROR|Step Result|
|---|---|---:|---:|---:|---:|---|
|STEP-001|登录API|SUCCEEDED|5|0|0|PASS|
|STEP-002|会员查询API|SUCCEEDED|8|1|0|FAIL|
|STEP-003|更新API|NOT_EXECUTED|0|0|0|SKIPPED|

Scenario结果：

```text
FAIL
```

原因：

```text
STEP-002存在Required Check失败
```

---

## Check明细

|Check|Previous|Current|Expected|Baseline Diff|Expected Evaluation|Final|
|---|---|---|---|---|---|---|
|HTTP Status|200|200|200|MATCH|SATISFIED|PASS|
|会员ID长度|12位|12位|12位|MATCH|SATISFIED|PASS|
|余额|900|700|700|MISMATCH|SATISFIED|PASS|
|交易合计|1,500,000|1,499,000|1,500,000|MISMATCH|VIOLATED|FAIL|
|业务整合Check|PASS证据|3件违反|违反0件|MISMATCH|VIOLATED|FAIL|

这里明确显示：

> Baseline发生变化不等于失败。

---

# 十一、Step和Scenario如何判定

## Check Result

|情况|结果|
|---|---|
|Expected满足|PASS|
|Expected不满足|FAIL|
|Java Check技术异常|ERROR|
|必要Expected或输入无法取得|BLOCKED|
|依赖未满足而未执行|SKIPPED|

## Step Result

建议统一聚合顺序：

```text
Required ERROR
    ↓
Required BLOCKED
    ↓
Required FAIL
    ↓
PASS
```

例如：

```text
5个Check

4个PASS
1个FAIL
```

Step结果：

```text
FAIL
```

如果有一个Required Check自身异常：

```text
ERROR
```

## Scenario Result

```text
Required Step ERROR    → Scenario ERROR
Required Step BLOCKED  → Scenario BLOCKED
Required Step FAIL     → Scenario FAIL
全部Required Step PASS → Scenario PASS
```

后续Step因为前置FAIL而SKIPPED，不会覆盖最初的FAIL。

---

# 十二、关键设计结论

应冻结为：

```text
1. 一个Scenario对应一次Java Batch执行。
2. 一个Scenario包含多次API Step。
3. 每个API Step都保存调用前Request JSON。
4. 每个API Step都保存调用后Response JSON或Execution Error。
5. 每个Check必须返回Previous／Current／Expected Evidence。
6. Expected可以是值、条件、动态计算、Reference或业务规则。
7. Java Check不能只返回Boolean。
8. Java Check必须返回统一CheckResult。
9. Previous ↔ Current生成Baseline Diff。
10. Expected ↔ Current生成Verification Evaluation。
11. Baseline Diff只表示变化，不直接决定FAIL。
12. Expected Evaluation决定PASS／FAIL。
13. Raw Snapshot保存完整Request／Response。
14. Verification Snapshot保存Check级Evidence。
15. Expected Snapshot保存本次运行时解析出的期待条件和值。
16. 大数据通过contentRef、Hash、件数和摘要表示。
17. Report不重新计算，只显示Result JSON中的结果。
18. Previous必须来自承认済みBaseline，不能简单取最后一次失败Run。
```

这就是：

```text
Java First Execution
+
Three-Evidence Verification
+
Dual Diff
+
Immutable Snapshot
+
Unified Report
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次未新增文件正文。

新增并确认的设计内容：

1. Java First不取消三方Evidence模型。
2. 每次API调用保存Request／Response JSON。
3. 每个Check保存Previous／Current／Expected。
4. Snapshot分为Raw Snapshot和Verification Snapshot。
5. Diff分为Baseline Diff和Expected Diff。
6. Expected支持固定值、约束、动态值和复杂业务规则。
7. Java Check必须返回完整Evidence，不允许只返回Boolean。
8. Report以Step和Check两个层次显示三方值和最终结果。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【下一份／按以下最终模型重写】
```

```text
Java First Scenario Execution
Previous／Current／Expected Evidence
Raw／Verification Snapshot
Baseline／Expected Diff
Check／Step／Scenario Result Aggregation
```

## 第 109 轮

### 你

我想说的是 比较不是用json结果来比较  比如在java逻辑里就比较好了，只是打印出来比较对象的json情报和结果

### ChatGPT

对，你这次表达得很准确：**比较动作全部在Java内存对象上完成；JSON只是比较完成后的证据输出格式，不是拿两个JSON文件再做二次比较。**

### ChatGPT

对。你说的才是最终正确形态。

> **Java负责真正比较。JSON不参与判定，只负责保存和打印比较对象、比较过程、证据及结果。**

我前面说“Expected JSON与Current JSON比较”，容易让人理解成框架读取两个JSON文件做通用Diff。这个理解需要纠正。

# 1. 正确的处理流程

```mermaid
flowchart TD
    A[读取Previous Snapshot JSON] --> B[反序列化为Java对象]
    C[执行API] --> D[取得Current Java对象]
    E[Java生成或取得Expected] --> F[Expected Java对象或条件]

    B --> G[Java Check]
    D --> G
    F --> G

    G --> H[Java内完成比较]
    H --> I[生成CheckResult对象]

    I --> J[序列化Check Result JSON]
    I --> K[序列化Diff JSON]
    D --> L[保存Current Snapshot JSON]

    J --> M[Report Generator]
    K --> M
    L --> M
```

核心分为三层：

```text
Java对象：
真正用于比较

Java CheckResult：
保存比较结论和证据

JSON：
把Java CheckResult序列化后输出
```

---

# 2. 三方值在Java中比较

例如余额检查：

```java
BigDecimal previous = previousSnapshot.getBalance();
BigDecimal current = currentResponse.getBalance();

BigDecimal expected =
        beforeBalance.subtract(deductionAmount);

CheckResult result = Checks.exact(
        "CHK-BALANCE-001",
        "残高遷移チェック",
        previous,
        current,
        expected
);
```

`Checks.exact()`内部完成两个判断：

```java
boolean baselineMatched =
        Objects.equals(previous, current);

boolean expectedSatisfied =
        Objects.equals(expected, current);
```

然后决定：

```java
VerificationResult finalResult =
        expectedSatisfied
            ? VerificationResult.PASS
            : VerificationResult.FAIL;
```

这里没有进行任何JSON比较。

JSON只在最后产生：

```json
{
  "checkId": "CHK-BALANCE-001",
  "previous": 900,
  "current": 700,
  "expected": 700,
  "baselineComparison": {
    "outcome": "MISMATCH"
  },
  "expectedEvaluation": {
    "outcome": "SATISFIED"
  },
  "result": "PASS"
}
```

---

# 3. API前后的JSON是什么

每次API调用仍然保存：

```text
request.json
response.json
execution.json
```

但这些文件的主要用途是：

- 执行证据；
- 问题调查；
- 重现；
- 审计；
- 报告查看；
- 下一次Baseline输入；
- Java反序列化的数据来源。

不是说运行结束后，再让一个JSON Diff工具决定业务成功失败。

正确顺序是：

```text
API Response
    ↓
Java Response对象
    ↓
Java Check比较
    ↓
生成CheckResult
    ↓
打印为JSON
```

---

# 4. Previous怎么进入Java

Previous通常保存在前一次承认済みSnapshot中。

例如：

```text
previous-response.json
```

运行时：

```java
MemberResponse previousResponse =
        snapshotLoader.load(
            baselineRunId,
            "STEP-002",
            MemberResponse.class
        );
```

这一步只是：

```text
JSON文件
    ↓ 反序列化
Java对象
```

之后比较的是：

```java
previousResponse.getMemberStatus()
```

而不是：

```text
previous-response.json文件
与
current-response.json文件
进行文件Diff
```

当然，对于纯JSON结构验证，可以专门提供一个Java共通方法：

```java
Checks.jsonStructure(...)
Checks.jsonCanonicalEquals(...)
```

但它仍然是**Java Check的一种实现**，不是整个框架默认拿JSON文件比较。

---

# 5. Expected怎么处理

Expected也不需要先写成JSON。

它可以直接在Java中生成。

## 固定值

```java
String expected = "SUCCESS";
```

## 运行时计算

```java
BigDecimal expected =
        beforeBalance.subtract(paymentAmount);
```

## 长度条件

```java
CheckResult result = Checks.length(
        "CHK-ID-LENGTH-001",
        previousId,
        currentId,
        12
);
```

这里Expected不是字符串值，而是Java参数：

```text
exactLength = 12
```

输出JSON时才表示成：

```json
{
  "expected": {
    "type": "LENGTH",
    "exactLength": 12
  },
  "current": {
    "value": "202607240001",
    "actualLength": 12
  },
  "result": "PASS"
}
```

## 复杂业务规则

```java
CheckResult result =
        monthlyTransactionCheck.verify(
            previousData,
            currentData,
            businessDate
        );
```

Java内部执行复杂逻辑，最后输出：

```json
{
  "expected": {
    "type": "BUSINESS_RULE",
    "ruleId": "MONTHLY_TRANSACTION_CONSISTENCY",
    "description": "明細、集計、日付及び状態が業務規則を満たすこと"
  },
  "current": {
    "checkedRecordCount": 100000,
    "violationCount": 3
  },
  "result": "FAIL"
}
```

这份JSON只是Java判断过程的可视化证据。

---

# 6. Java CheckResult应该是什么

建议所有共通Check和业务Check都返回同一个标准对象：

```java
public record CheckResult(
        String checkId,
        String checkName,
        String implementationId,
        String implementationVersion,

        Evidence previous,
        Evidence current,
        Evidence expected,

        ComparisonResult baselineComparison,
        EvaluationResult expectedEvaluation,

        VerificationResult result,
        String reasonCode,
        Severity severity,

        Map<String, Object> evidence,
        List<Violation> violations
) {
}
```

Java内部比较完成以后，填充这个对象。

Framework统一负责：

```text
CheckResult
    ↓
check-result.json

BaselineComparison
    ↓
baseline-diff.json

ExpectedEvaluation
    ↓
expected-evaluation.json

ScenarioResult
    ↓
scenario-result.json
```

业务Java代码不需要自己拼接JSON字符串。

---

# 7. Diff也不是JSON文件比较

Diff应该理解成：

> Java比较逻辑产生的结构化差异结果，然后序列化为JSON。

例如Java：

```java
BaselineComparison baselineComparison =
        compareService.compareValue(
            previous,
            current
        );
```

得到：

```java
new BaselineComparison(
    ComparisonOutcome.MISMATCH,
    "VALUE_CHANGED",
    previous,
    current
);
```

最后输出：

```json
{
  "checkId": "CHK-BALANCE-001",
  "previous": 900,
  "current": 700,
  "outcome": "MISMATCH",
  "changeType": "VALUE_CHANGED"
}
```

所以：

```text
不是：
JSON → JSON Diff Engine → Result

而是：
Java对象 → Java比较 → DiffResult对象 → JSON输出
```

---

# 8. 复杂业务Check的Diff怎么表示

复杂业务逻辑可能没有一个简单的：

```text
Previous = 1
Current = 2
Expected = 3
```

例如检查十万条数据中的：

- 重复ID；
- 汇总金额；
- 业务日期；
- 状态迁移；
- 父子关系。

Java可以返回多个子结果：

```java
List<CheckResult> results = List.of(
    checkDuplicateId(previous, current),
    checkTotalAmount(previous, current),
    checkBusinessDate(current, businessDate),
    checkStatusTransition(previous, current)
);
```

或者一个Composite Check：

```json
{
  "checkId": "CHK-MONTHLY-TRANSACTION-001",
  "previous": {
    "recordCount": 99950,
    "canonicalHash": "abc123"
  },
  "current": {
    "recordCount": 100000,
    "canonicalHash": "def456"
  },
  "expected": {
    "ruleId": "MONTHLY_TRANSACTION_CONSISTENCY"
  },
  "baselineComparison": {
    "addedCount": 60,
    "removedCount": 10,
    "changedCount": 20
  },
  "expectedEvaluation": {
    "violationCount": 3,
    "outcome": "VIOLATED"
  },
  "result": "FAIL"
}
```

这些数字全部由Java逻辑计算完成。

---

# 9. Snapshot的正确定位

Snapshot是**输入证据和结果证据的保存形式**，不是比较引擎。

建议分为：

## Raw Snapshot

保存API原始调用信息：

```text
request.json
response.json
execution.json
```

## Check Snapshot

保存Java Check使用和产生的证据：

```text
previous evidence
current evidence
expected evidence
derived values
check result
```

## Baseline Snapshot

保存下一次执行需要恢复的Previous数据。

下一次执行时：

```text
Baseline Snapshot JSON
    ↓
反序列化
Previous Java对象
    ↓
Java Check
```

---

# 10. Report的正确定位

Report也不能重新执行比较。

正确流程是：

```text
Java Check已经判定完成
    ↓
CheckResult JSON
    ↓
Report只负责展示
```

报告显示：

|Check|Previous|Current|Expected|Baseline变化|期待判定|最终结果|
|---|---:|---:|---:|---|---|---|
|余额检查|900|700|700|MISMATCH|SATISFIED|PASS|
|ID长度|12位|12位|12位|MATCH|SATISFIED|PASS|
|合计检查|1,500,000|1,499,000|1,500,000|MISMATCH|VIOLATED|FAIL|

Report不能自己根据这些显示值重新计算PASS／FAIL。

最终Result只能来自Java的`CheckResult`。

---

# 11. 最终冻结模型

准确表达应该是：

```text
Java First Comparison
+
Three-Way Evidence Output
+
Serialized Snapshot / Diff / Report
```

也就是：

```text
1. Previous、Current、Expected在Java中表示。
2. Java共通Check或业务Check完成实际比较。
3. Java Check直接得出Baseline Comparison。
4. Java Check直接得出Expected Evaluation。
5. Verification Policy根据Java结果决定PASS／FAIL等。
6. JSON只保存比较对象、条件、证据、差异和结果。
7. Snapshot JSON用于保存和恢复数据。
8. Diff JSON是Java DiffResult的序列化结果。
9. Report只展示，不重新比较。
10. 大数据由Java处理，JSON输出摘要、引用、Hash和Violation。
```

所以我们以后不能再写成：

```text
Previous JSON ↔ Current JSON
Expected JSON ↔ Current JSON
```

应该写成：

```text
Previous Java Evidence ↔ Current Java Evidence
Expected Java Condition／Value ↔ Current Java Evidence
```

完成后再输出：

```text
Snapshot JSON
Diff JSON
Result JSON
Report
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次未新增文件正文。

设计结论修正为：

比较主体：
Java对象、Java条件、Java业务逻辑

JSON职责：
Snapshot、Evidence、DiffResult、Result及Report输出

明确禁止：
通过输出JSON文件再次比较并决定最终结果
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【下一份／按Java内比较、JSON证据输出模型重写】
```

## 第 110 轮

### 你

期待的值 可以固定以json的形式  放到baseline或者哪个文件夹作为输入 不想在java程序里定义

### ChatGPT

可以，而且这正是更合适的分工：**固定期待值放外部JSON，Java只读取并比较，不把业务期待值写死在代码里。** 但Expected和Baseline必须分开保存。

### ChatGPT

可以，而且这比把固定期待值写死在Java里更合理。

最终模式应该是：

```text
Expected JSON：人工定义、版本管理的期待输入
Baseline JSON：以前批准过的实际结果
Current Java Object：本次API实际结果
Java Check：在内存中完成三方比较
Result JSON：只输出比较对象、证据和结果
```

# 1. Expected不能放进Baseline目录

两者含义不同：

|对象|含义|来源|
|---|---|---|
|Expected|业务或设计上应该满足的内容|人工定义、外部文件、动态生成|
|Baseline / Previous|以前实际执行并批准的结果|历史Run提升而来|
|Current|本次实际执行结果|本次API调用|

例如：

```text
Expected = status必须为SUCCESS
Baseline = 上次实际返回PROCESSING
Current  = 本次实际返回SUCCESS
```

结果是：

```text
Previous ↔ Current = MISMATCH
Expected ↔ Current = MATCH
Final Result = PASS
```

如果把Expected和Baseline混在一起，就无法表达这个情况。

---

# 2. 推荐目录

固定期待值放在对应UseCase／Scenario下面：

```text
system/
└── 06_verification_assets/
    ├── usecases/
    │   └── UC-E6-001/
    │       └── scenarios/
    │           └── SC-E6-001/
    │               ├── expected/
    │               │   ├── expected-manifest.json
    │               │   │
    │               │   ├── STEP-001/
    │               │   │   ├── request.expected.json
    │               │   │   └── response.expected.json
    │               │   │
    │               │   ├── STEP-002/
    │               │   │   └── response.expected.json
    │               │   │
    │               │   └── STEP-003/
    │               │       └── response.expected.json
    │               │
    │               └── input/
    │                   └── scenario-input.json
    │
    └── baselines/
        └── test/
            └── UC-E6-001/
                └── SC-E6-001/
                    └── BL-20260701-001/
                        ├── baseline-manifest.json
                        ├── STEP-001/
                        │   ├── request.json
                        │   └── response.json
                        ├── STEP-002/
                        │   └── response.json
                        └── STEP-003/
                            └── response.json
```

职责是：

```text
usecases/.../expected/
    设计上的期待输入

baselines/
    批准过的历史实际结果

output/runs/
    每次运行产生的未批准Current结果
```

---

# 3. Expected JSON可以是完整JSON

例如：

```json
{
  "status": "SUCCESS",
  "memberType": "A",
  "enabled": true,
  "resultCode": "0000"
}
```

Java加载：

```java
JsonNode expected =
        expectedLoader.load(
            "UC-E6-001",
            "SC-E6-001",
            "STEP-002",
            "response.expected.json"
        );

JsonNode previous =
        baselineLoader.loadResponse(
            baselineId,
            "STEP-002"
        );

MemberResponse currentResponse =
        memberApiClient.execute(request);

JsonNode current =
        objectMapper.valueToTree(currentResponse);
```

然后在Java中比较：

```java
CheckResult result =
        Checks.compareObject(
            "CHK-STEP002-RESPONSE",
            previous,
            current,
            expected
        );
```

比较主体仍然是Java内存对象。

不是：

```text
生成Current JSON
↓
再启动另外一个JSON文件比较程序
```

而是：

```text
读取Expected JSON
↓
反序列化为Java对象／JsonNode
↓
Java立即比较
↓
输出结果JSON
```

---

# 4. 也可以只写需要固定比较的字段

实际Response可能有100个字段，但固定期待值只有4个。

这时Expected不需要复制完整Response：

```json
{
  "status": "SUCCESS",
  "memberType": "A",
  "enabled": true,
  "resultCode": "0000"
}
```

实际Current：

```json
{
  "status": "SUCCESS",
  "memberType": "A",
  "enabled": true,
  "resultCode": "0000",
  "memberId": "M202607240001",
  "updatedAt": "2026-07-24T10:20:30+09:00",
  "requestId": "REQ-7F82A1"
}
```

Java采用：

```text
Expected中出现的字段必须比较
Expected中未出现的字段不做固定值比较
```

这叫：

```text
PARTIAL_EXPECTED
```

在简单Manifest中写一次即可：

```json
{
  "expectedSetId": "EXP-UC-E6-001-SC-E6-001",
  "version": "1.0.0",
  "comparisonMode": "PARTIAL_EXPECTED",
  "steps": {
    "STEP-002": {
      "responseFile": "STEP-002/response.expected.json"
    }
  }
}
```

这样不需要复杂YAML DSL。

---

# 5. 完全一致时使用FULL_EXPECTED

某些API Response要求整个对象完全一致：

```json
{
  "expectedSetId": "EXP-UC-E6-001-SC-E6-001",
  "version": "1.0.0",
  "comparisonMode": "FULL_EXPECTED"
}
```

Java规则：

```text
Expected有的字段必须一致
Current不能多字段
Current不能少字段
Object结构必须一致
Array件数与顺序必须一致
```

适合：

- 固定Master取得API；
- 固定代码表；
- 配置API；
- 静态业务结果。

---

# 6. 动态字段怎么办

例如：

```text
requestId
updatedAt
transactionId
```

这些不能在固定Expected JSON中写具体值。

可以选择三种方式。

## 方式一：不写入Expected

固定Expected只写稳定字段：

```json
{
  "status": "SUCCESS",
  "resultCode": "0000"
}
```

动态字段由Java共通Check验证：

```java
results.add(
    Checks.required(
        "CHK-REQUEST-ID",
        currentResponse.getRequestId()
    )
);

results.add(
    Checks.length(
        "CHK-TRANSACTION-ID",
        currentResponse.getTransactionId(),
        12
    )
);

results.add(
    Checks.inExecutionPeriod(
        "CHK-UPDATED-AT",
        currentResponse.getUpdatedAt(),
        context.startedAt(),
        context.finishedAt()
    )
);
```

---

## 方式二：Expected JSON保存条件

JSON也可以保存简单条件，但不要发展成复杂DSL：

```json
{
  "fixedValues": {
    "status": "SUCCESS",
    "resultCode": "0000"
  },
  "conditions": {
    "requestId": {
      "check": "REQUIRED"
    },
    "transactionId": {
      "check": "LENGTH",
      "value": 12
    }
  }
}
```

Java读取以后调用已有共通Check。

---

## 方式三：特殊逻辑交给业务Check

```java
CheckResult businessResult =
        memberBusinessCheck.verify(
            previousResponse,
            currentResponse,
            expectedDefinition,
            context
        );
```

Expected JSON只提供业务参数：

```json
{
  "maximumTransactionCount": 100000,
  "allowedMemberStatuses": [
    "ACTIVE",
    "SUSPENDED"
  ],
  "allowNegativeBalance": false
}
```

复杂判断继续由Java完成。

---

# 7. 大型Expected文件

期待内容很大时，不要塞进Java，也不需要塞进Manifest。

直接作为独立JSON文件：

```text
expected/
└── STEP-004/
    ├── response.expected.json
    └── response.expected.metadata.json
```

Metadata：

```json
{
  "expectedAssetId": "EXP-STEP004-RESPONSE-001",
  "version": "2026.07",
  "recordCount": 100000,
  "sha256": "9f86d081884c7d659a2feaa0c55ad015...",
  "comparisonMode": "BUSINESS_KEY"
}
```

Java可以：

- 全量读取；
- Streaming读取；
- 按业务Key建立索引；
- 分块比较；
- Hash快速判断；
- 只把差异部分写到结果中。

不需要把全部Expected内容输出到Report。

---

# 8. Java共通接口

建议统一定义：

```java
public interface ExpectedDataLoader {

    <T> T load(
        String useCaseId,
        String scenarioId,
        String stepId,
        Class<T> type
    );
}
```

Baseline：

```java
public interface BaselineLoader {

    <T> T load(
        String baselineId,
        String stepId,
        Class<T> type
    );
}
```

比较：

```java
public interface ThreeWayCheck<T> {

    CheckResult check(
        T previous,
        T current,
        ExpectedDefinition<T> expected
    );
}
```

Scenario中：

```java
MemberResponse expected =
        expectedDataLoader.load(
            "UC-E6-001",
            "SC-E6-001",
            "STEP-002",
            MemberResponse.class
        );

MemberResponse previous =
        baselineLoader.load(
            baselineId,
            "STEP-002",
            MemberResponse.class
        );

MemberResponse current =
        memberApiClient.execute(request);

CheckResult result =
        memberResponseCheck.check(
            previous,
            current,
            ExpectedDefinition.fixed(expected)
        );
```

这样业务期待数据完全不写死在Java代码中。

---

# 9. Result JSON怎么打印

比较完成以后输出：

```json
{
  "checkId": "CHK-STEP002-RESPONSE",
  "expectedAsset": {
    "expectedAssetId": "EXP-UC-E6-001-SC-E6-001",
    "version": "1.0.0",
    "contentRef": "expected/STEP-002/response.expected.json"
  },
  "baseline": {
    "baselineId": "BL-20260701-001",
    "contentRef": "baselines/test/UC-E6-001/SC-E6-001/BL-20260701-001/STEP-002/response.json"
  },
  "current": {
    "runId": "RUN-20260724-001",
    "contentRef": "steps/STEP-002/response/response-received.json"
  },
  "baselineComparison": {
    "outcome": "MISMATCH",
    "differenceCount": 3
  },
  "expectedEvaluation": {
    "outcome": "SATISFIED",
    "violationCount": 0
  },
  "result": "PASS"
}
```

对于小值，可以直接打印：

```json
{
  "path": "$.status",
  "previous": "PROCESSING",
  "current": "SUCCESS",
  "expected": "SUCCESS",
  "baselineOutcome": "MISMATCH",
  "expectedOutcome": "SATISFIED",
  "result": "PASS"
}
```

对于大型数据只打印：

```text
contentRef
hash
recordCount
differenceCount
violationCount
代表性差异
```

---

# 10. Expected的批准和版本管理

Expected是正式输入资产，不能随意覆盖。

建议：

```json
{
  "expectedSetId": "EXP-UC-E6-001-SC-E6-001",
  "version": "1.2.0",
  "status": "APPROVED",
  "effectiveFrom": "2026-07-01",
  "approvedBy": "reviewer-id",
  "approvedAt": "2026-06-25T15:00:00+09:00"
}
```

一次Run必须记录：

```text
使用了哪个Expected版本
使用了哪个Baseline版本
使用了哪个Java Check版本
```

否则以后无法重现判定。

---

# 11. Baseline提升流程

本次Current执行成功后，不能自动覆盖Baseline。

应该：

```text
Current Run
    ↓
人工或自动Review
    ↓
批准
    ↓
Promote为新Baseline
```

例如：

```text
output/runs/RUN-20260724-001/
    ↓ approve
06_verification_assets/baselines/test/
    UC-E6-001/SC-E6-001/BL-20260724-001/
```

Expected不随这个流程自动变化。

Expected表示业务设计上的期待；Baseline表示以前批准过的实际状态。

---

# 12. 最终确定的模式

```text
固定期待值：
外部Expected JSON

前回值：
Approved Baseline JSON

今回值：
本次API返回的Java对象

实际比较：
Java共通Check／业务Check

输出：
Snapshot JSON
Diff Result JSON
Check Result JSON
Report
```

可以概括为：

```text
External Expected Data
+
Approved Previous Baseline
+
Current Java Object
+
Java In-Memory Comparison
+
JSON Evidence Output
```

这兼顾了：

- 期待值不写死在Java；
- Java比较逻辑简单、可调试；
- Expected可以单独修改和审批；
- Baseline和Expected职责分离；
- 每次比较结果可以完整打印；
- 大型Expected数据也能处理。

---

# 当前`system/02_master/`完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次未给出新文件正文。

新增并确认：

1. 固定Expected以JSON文件形式作为外部输入。
2. Expected不得放入Baseline目录。
3. Expected按UseCase／Scenario／Step管理。
4. Baseline保存批准过的历史实际数据。
5. Java加载Expected、Previous和Current后在内存中比较。
6. Expected JSON支持完整模式和部分字段模式。
7. Java代码不再硬编码固定业务期待值。
8. 输出JSON只保存引用、证据、Diff和结果。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【下一份】
```

下一版需要正式写入：

```text
External Expected JSON
Approved Baseline JSON
Current Java Object
Java In-Memory Comparison
Snapshot／Diff／Report Evidence Model
```

## 第 111 轮

### 你

你说的这些都是什么意思，定义好多

 "checkId": "CHK-MONTHLY-BUSINESS-001",
  "expected": {
    "ruleId": "RULE-MONTHLY-CONSISTENCY",

allowedMemberStatuses": [
    "ACTIVE",
    "SUSPENDED"
  ],
  "allowNegativeBalance": false
}

### ChatGPT

你说得对，刚才那些定义太多了。那是把“可复用规则平台”设计得过重了，和你现在想要的简单Java Batch方式不一致。

你举出的内容其实分别代表四种不同东西。

# 1. `checkId`是什么意思

```json
"checkId": "CHK-MONTHLY-BUSINESS-001"
```

它表示：

> 这一次检查叫什么。

例如一个API返回后执行三个检查：

```text
会员状态检查
余额检查
月份数据整合检查
```

系统为了在日志、Diff、Report中稳定识别它们，可以给每个检查一个编号：

```text
CHK-MEMBER-STATUS
CHK-BALANCE
CHK-MONTHLY-BUSINESS
```

但是不一定非要写进Expected JSON。

更简单的方式是直接在Java里定义：

```java
checkMemberStatus(...);
checkBalance(...);
checkMonthlyBusiness(...);
```

Java共通方法生成结果时自动带上检查名称：

```json
{
  "check": "memberStatus",
  "previous": "ACTIVE",
  "current": "ACTIVE",
  "expected": ["ACTIVE", "SUSPENDED"],
  "result": "PASS"
}
```

所以在你的方案中：

```text
checkId可以保留为报告用稳定编号，
但不需要业务人员每次手工定义很多checkId。
```

---

# 2. `ruleId`是什么意思

```json
"expected": {
  "ruleId": "RULE-MONTHLY-CONSISTENCY"
}
```

它原本表示：

> 当前检查使用哪个可复用业务规则。

例如：

```text
RULE-MONTHLY-CONSISTENCY
```

对应Java：

```java
MonthlyConsistencyCheck
```

但在Java First方案里，如果一个业务规则已经通过Java类或方法明确实现，那么再写一个`ruleId`就重复了。

例如Java已经写成：

```java
monthlyConsistencyCheck.verify(...);
```

那Expected JSON没有必要再写：

```json
{
  "ruleId": "RULE-MONTHLY-CONSISTENCY"
}
```

只需要写这个Java逻辑使用的外部参数。

因此你的项目可以取消大部分`ruleId`。

只有在以下情况下才保留：

- 同一个Java Check支持多套规则版本；
- 报告必须显示业务规则编号；
- 规则需要单独审批；
- 多个UseCase共用同一规则。

否则直接使用Java类或方法名称即可。

---

# 3. `allowedMemberStatuses`是什么意思

```json
{
  "allowedMemberStatuses": [
    "ACTIVE",
    "SUSPENDED"
  ]
}
```

这不是另一套复杂定义。

它只是告诉Java：

> 本次允许会员状态为`ACTIVE`或`SUSPENDED`。

Java可以这样执行：

```java
CheckResult result = Checks.inValues(
    "memberStatus",
    previousResponse.getMemberStatus(),
    currentResponse.getMemberStatus(),
    expected.getAllowedMemberStatuses()
);
```

假设：

```text
Previous = ACTIVE
Current  = SUSPENDED
Expected = ACTIVE或SUSPENDED
```

结果：

```text
Previous ↔ Current = 发生变化
Expected ↔ Current = 符合
Final Result = PASS
```

输出：

```json
{
  "check": "memberStatus",
  "previous": "ACTIVE",
  "current": "SUSPENDED",
  "expected": [
    "ACTIVE",
    "SUSPENDED"
  ],
  "baselineDiff": "CHANGED",
  "expectedResult": "MATCH",
  "result": "PASS"
}
```

所以`allowedMemberStatuses`只是一个外部期待参数，目的是避免把：

```java
List.of("ACTIVE", "SUSPENDED")
```

写死在Java程序里。

---

# 4. `allowNegativeBalance`是什么意思

```json
{
  "allowNegativeBalance": false
}
```

表示：

> 余额是否允许小于0。

Java逻辑：

```java
if (!expected.isAllowNegativeBalance()
        && currentBalance.compareTo(BigDecimal.ZERO) < 0) {
    return CheckResult.fail(...);
}
```

如果：

```text
Current Balance = -100
allowNegativeBalance = false
```

结果：

```text
FAIL
```

如果：

```text
Current Balance = 100
allowNegativeBalance = false
```

结果：

```text
PASS
```

这也是一个简单业务参数，不是期待值文件必须拥有的复杂结构。

---

# 5. 你真正需要的Expected JSON可以很简单

例如某个Scenario的期待文件：

```json
{
  "memberStatus": {
    "allowedValues": [
      "ACTIVE",
      "SUSPENDED"
    ]
  },
  "balance": {
    "allowNegative": false
  },
  "resultCode": "0000",
  "transactionIdLength": 12
}
```

Java读取后执行：

```java
results.add(
    Checks.inValues(
        "memberStatus",
        previous.getMemberStatus(),
        current.getMemberStatus(),
        expected.getMemberStatus().getAllowedValues()
    )
);

results.add(
    Checks.negativeAllowed(
        "balance",
        previous.getBalance(),
        current.getBalance(),
        expected.getBalance().isAllowNegative()
    )
);

results.add(
    Checks.exact(
        "resultCode",
        previous.getResultCode(),
        current.getResultCode(),
        expected.getResultCode()
    )
);

results.add(
    Checks.length(
        "transactionId",
        previous.getTransactionId(),
        current.getTransactionId(),
        expected.getTransactionIdLength()
    )
);
```

Expected JSON中没有：

```text
checkId
ruleId
validatorRef
evaluationMode
aggregationPolicy
comparisonMode
```

这些都没有必要让业务文件重复定义。

---

# 6. 特殊复杂业务Check怎么写

例如月度数据验证非常复杂：

```text
检查10万条数据
检查重复
检查日期
检查金额合计
检查状态关系
```

Java里写：

```java
MonthlyBusinessCheckResult result =
    monthlyBusinessCheck.verify(
        previousResponse,
        currentResponse,
        expectedParameters
    );
```

Expected JSON只保存这个逻辑需要的业务参数：

```json
{
  "monthlyBusiness": {
    "allowDuplicateTransactionId": false,
    "allowNegativeAmount": false,
    "maximumRecordCount": 100000,
    "targetMonth": "CURRENT_RUN_MONTH"
  }
}
```

Java返回多个检查结果：

```json
{
  "checks": [
    {
      "check": "duplicateTransactionId",
      "previous": {
        "duplicateCount": 0
      },
      "current": {
        "duplicateCount": 0
      },
      "expected": {
        "maximumDuplicateCount": 0
      },
      "result": "PASS"
    },
    {
      "check": "negativeAmount",
      "previous": {
        "negativeCount": 0
      },
      "current": {
        "negativeCount": 3
      },
      "expected": {
        "maximumNegativeCount": 0
      },
      "result": "FAIL"
    }
  ]
}
```

业务人员不用理解`ruleId`，只需要维护真正会变化的参数。

---

# 7. 最简单的职责分离

## Expected JSON

只保存：

```text
固定期待值
允许值
最大值、最小值
长度
允许／禁止条件
复杂业务Check所需参数
```

## Java

负责：

```text
API调用
流程顺序
读取Expected
读取Previous
处理Current
执行比较
执行业务判断
生成CheckResult
决定Step和Scenario结果
```

## 输出JSON

负责显示：

```text
检查名称
Previous
Current
Expected
变化结果
正确性结果
最终PASS／FAIL
错误原因
```

---

# 8. 最终推荐格式

Expected输入：

```json
{
  "resultCode": "0000",

  "memberStatus": {
    "allowedValues": [
      "ACTIVE",
      "SUSPENDED"
    ]
  },

  "balance": {
    "allowNegative": false
  },

  "transactionId": {
    "length": 12
  },

  "monthlyData": {
    "maximumRecordCount": 100000,
    "allowDuplicateId": false
  }
}
```

结果输出：

```json
{
  "scenario": "SC-E6-001",
  "step": "STEP-002",

  "checks": [
    {
      "check": "resultCode",
      "previous": "0000",
      "current": "0000",
      "expected": "0000",
      "changed": false,
      "matched": true,
      "result": "PASS"
    },
    {
      "check": "memberStatus",
      "previous": "ACTIVE",
      "current": "SUSPENDED",
      "expected": [
        "ACTIVE",
        "SUSPENDED"
      ],
      "changed": true,
      "matched": true,
      "result": "PASS"
    },
    {
      "check": "balance",
      "previous": 1000,
      "current": -100,
      "expected": {
        "allowNegative": false
      },
      "changed": true,
      "matched": false,
      "result": "FAIL"
    }
  ],

  "stepResult": "FAIL"
}
```

这已经足够支撑：

- Previous／Current／Expected；
- Baseline变化；
- 期待判定；
- Snapshot；
- Diff；
- Report；
- Java共通Check；
- Java特殊业务Check。

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次没有新增文件正文。

设计进一步简化：

1. Expected JSON只保存真实期待值和业务参数。
2. 原则上不在Expected JSON中填写checkId。
3. 原则上取消ruleId。
4. Java方法或业务Check类表示检查逻辑。
5. 输出JSON自动带检查名称、三方值、比较结果和最终结果。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【下一份／按简化后的Java First + External Expected JSON模型重写】
```

## 第 112 轮

### 你

Balance我都觉得不需要  因为本身小于0等 就是在java里面判断就好了 ，本来就和memberStatus一致，api和api之间需要比较 也是在同一个batch执行里面，也是属于一个业务比较 ，我觉得用下面的统一就好了，如果有特别的 那么再加一个说明属性不就可以了吗   因为所有的期待值的比较处理都在java里面执行好了。为什么还要说出是允许负数这样的业务逻辑，本身就是java比较处理成功与失败 仅此而已
 {
      "check": "memberStatus",
      "previous": "ACTIVE",
      "current": "SUSPENDED",
      "expected": [
        "ACTIVE",
        "SUSPENDED"
      ],

### ChatGPT

对，你现在这个归纳更合理：**JSON只统一记录“比较了什么、三方值是什么、结果是什么”**；业务规则本身全部封装在Java Check里，不再把“允许负数、状态枚举、公式”等规则重复写进JSON。

### ChatGPT

对。你这个理解更准确，也更适合当前项目。

**不需要在Expected JSON中再描述业务规则。**

下面这些都可以取消：

```json
"ruleId": "RULE-MONTHLY-CONSISTENCY"
```

```json
"allowNegativeBalance": false
```

```json
"comparisonMode": "CUSTOM_VALIDATOR"
```

业务规则已经写在Java里，再在JSON里描述一遍，确实是重复维护。

---

# 一、最终统一模型

无论是：

- 单字段固定值检查；
- 类型、长度检查；
- 是否允许负数；
- API1与API2字段关系检查；
- API1、API2、API3之间的业务关系；
- 十万条数据的复杂业务检查；

全部由Java完成。

Java比较结束后，统一输出：

```json
{
  "check": "memberStatus",
  "previous": "ACTIVE",
  "current": "SUSPENDED",
  "expected": [
    "ACTIVE",
    "SUSPENDED"
  ],
  "changed": true,
  "matched": true,
  "result": "PASS"
}
```

这套格式已经足够。

---

# 二、余额小于0也不需要配置参数

例如业务规则是：

> 余额不允许小于0。

直接写在Java：

```java
CheckResult checkBalance(
        BigDecimal previous,
        BigDecimal current) {

    boolean matched =
            current != null
            && current.compareTo(BigDecimal.ZERO) >= 0;

    return CheckResult.builder()
            .check("balance")
            .previous(previous)
            .current(current)
            .expected("0以上")
            .changed(!Objects.equals(previous, current))
            .matched(matched)
            .result(matched ? PASS : FAIL)
            .build();
}
```

输出：

```json
{
  "check": "balance",
  "previous": 1000,
  "current": -100,
  "expected": "0以上",
  "changed": true,
  "matched": false,
  "result": "FAIL"
}
```

因此不需要：

```json
{
  "allowNegativeBalance": false
}
```

因为这个规则已经是Java业务逻辑的一部分。

---

# 三、API与API之间的比较也一样

例如同一个Scenario中：

```text
API1：更新前余额 = 1000
API2：扣款金额 = 300
API3：更新后余额 = 700
```

Java内部计算：

```java
BigDecimal expectedAfterBalance =
        api1Response.getBalance()
                .subtract(api2Request.getAmount());

boolean matched =
        expectedAfterBalance.compareTo(
                api3Response.getBalance()
        ) == 0;
```

统一输出：

```json
{
  "check": "balanceTransition",
  "previous": 900,
  "current": 700,
  "expected": 700,
  "changed": true,
  "matched": true,
  "result": "PASS",
  "description": "API3余额应等于API1余额减去API2扣款金额"
}
```

这里：

- `previous`：前一次Scenario执行得到的检查对象或结果值；
- `current`：本次实际值；
- `expected`：Java根据本次API1和API2动态计算出来的期待值；
- `description`：特殊业务检查时才增加。

Expected不需要预先写进JSON。

---

# 四、固定Expected什么时候才放外部JSON

只有真正需要由外部维护的固定值，才放Expected JSON。

例如：

```json
{
  "resultCode": "0000",
  "memberStatus": [
    "ACTIVE",
    "SUSPENDED"
  ]
}
```

Java读取：

```java
List<String> expectedStatuses =
        expectedData.getMemberStatus();

CheckResult result =
        checkMemberStatus(
                previous.getMemberStatus(),
                current.getMemberStatus(),
                expectedStatuses
        );
```

输出仍然是统一格式：

```json
{
  "check": "memberStatus",
  "previous": "ACTIVE",
  "current": "SUSPENDED",
  "expected": [
    "ACTIVE",
    "SUSPENDED"
  ],
  "changed": true,
  "matched": true,
  "result": "PASS"
}
```

所以外部Expected JSON只保存：

```text
真正需要从Java外部输入的期待数据
```

不保存：

```text
业务判断方式
Java方法名
Rule ID
是否允许负数
比较模式
验证器类型
聚合逻辑
```

---

# 五、Expected有三种来源，但输出格式完全相同

## 1. 外部固定值

```text
Expected来源：
expected.json
```

例如：

```json
{
  "resultCode": "0000"
}
```

---

## 2. Java动态计算值

```text
Expected来源：
Java根据本次业务数据计算
```

例如：

```java
expectedBalance =
    beforeBalance.subtract(paymentAmount);
```

---

## 3. 其他API的值

```text
Expected来源：
前面API的Request或Response
```

例如：

```java
expectedMemberId =
    api1Response.getMemberId();
```

不管从哪里得到，输出都是：

```json
{
  "check": "...",
  "previous": "...",
  "current": "...",
  "expected": "...",
  "changed": true,
  "matched": true,
  "result": "PASS"
}
```

---

# 六、统一Java返回对象

可以简化为：

```java
public record CheckResult(
        String check,
        Object previous,
        Object current,
        Object expected,
        Boolean changed,
        Boolean matched,
        VerificationResult result,
        String description,
        CheckError error
) {
}
```

其中：

```text
check
    检查名称

previous
    前一次执行的值或业务检查结果

current
    本次实际值或本次业务计算结果

expected
    固定值、允许值、Java计算值或其他API值

changed
    Previous与Current是否变化

matched
    Current是否符合Expected

result
    PASS、FAIL、ERROR、BLOCKED、SKIPPED

description
    特殊业务检查的补充说明，可选

error
    Java处理异常时使用，可选
```

---

# 七、简单Check与特殊Check使用同一个格式

## 固定值检查

```json
{
  "check": "resultCode",
  "previous": "0000",
  "current": "0000",
  "expected": "0000",
  "changed": false,
  "matched": true,
  "result": "PASS"
}
```

## 允许值检查

```json
{
  "check": "memberStatus",
  "previous": "ACTIVE",
  "current": "SUSPENDED",
  "expected": [
    "ACTIVE",
    "SUSPENDED"
  ],
  "changed": true,
  "matched": true,
  "result": "PASS"
}
```

## 长度检查

```json
{
  "check": "transactionIdLength",
  "previous": 12,
  "current": 12,
  "expected": 12,
  "changed": false,
  "matched": true,
  "result": "PASS"
}
```

注意这里直接输出比较后的“长度”：

```text
previous = 前回长度
current = 今回长度
expected = 期待长度
```

没有必要把整个交易ID作为Expected。

---

## 复杂月度业务检查

复杂逻辑可以拆成几个统一Check：

```json
[
  {
    "check": "monthlyRecordCount",
    "previous": 99950,
    "current": 100000,
    "expected": 100000,
    "changed": true,
    "matched": true,
    "result": "PASS"
  },
  {
    "check": "monthlyDuplicateCount",
    "previous": 0,
    "current": 3,
    "expected": 0,
    "changed": true,
    "matched": false,
    "result": "FAIL"
  },
  {
    "check": "monthlyTotalAmount",
    "previous": 1500000,
    "current": 1499000,
    "expected": 1500000,
    "changed": true,
    "matched": false,
    "result": "FAIL"
  }
]
```

全部计算过程都在Java中。

JSON只打印最后参与判断的值。

---

# 八、特殊业务说明只增加一个可选属性

你说的：

> 特别的再加一个说明属性。

完全可以。

例如：

```json
{
  "check": "memberStatusTransition",
  "previous": "SUSPENDED",
  "current": "ACTIVE",
  "expected": "SUSPENDED状态不能直接恢复为ACTIVE",
  "changed": true,
  "matched": false,
  "result": "FAIL",
  "description": "当前业务要求SUSPENDED必须先经过REVIEW状态"
}
```

不需要为特殊规则设计新的JSON结构。

统一使用：

```text
description
```

必要时再加：

```text
details
```

但也应该是可选的。

---

# 九、异常情况也保持简单

Java逻辑自身异常：

```json
{
  "check": "monthlyBusinessCheck",
  "result": "ERROR",
  "description": "月度业务整合检查执行失败",
  "error": {
    "code": "CHECK_EXECUTION_ERROR",
    "message": "Database connection failed"
  }
}
```

这里不应伪造：

```json
"current": null
```

没有取得值时，直接不输出`current`字段。

规则是：

```text
字段存在且值为null
    表示真实值就是null

字段不存在
    表示没有取得或没有参与比较
```

---

# 十、Snapshot、Diff、Report怎么处理

## Snapshot

保存：

```text
API调用前Request JSON
API调用后Response JSON
所有CheckResult
```

例如：

```text
STEP-001/
├── request.json
├── response.json
└── checks.json
```

---

## Diff

Diff不重新比较JSON。

直接从Java已经生成的CheckResult中抽取：

```json
{
  "check": "memberStatus",
  "previous": "ACTIVE",
  "current": "SUSPENDED",
  "changed": true
}
```

---

## Report

报告显示：

|Check|Previous|Current|Expected|变化|符合期待|结果|
|---|---|---|---|---|---|---|
|memberStatus|ACTIVE|SUSPENDED|ACTIVE／SUSPENDED|是|是|PASS|
|balance|1000|-100|0以上|是|否|FAIL|
|balanceTransition|900|700|700|是|是|PASS|

Report不重新判断，只显示Java结果。

---

# 十一、最终简化后的系统

```text
Scenario Java Batch
    ↓
调用多个API
    ↓
Java共通Check／业务Check
    ↓
Java内部取得：
Previous
Current
Expected
    ↓
Java内部比较
    ↓
统一CheckResult
    ↓
JSON Snapshot／Diff／Report
```

最终不再设计复杂的：

```text
Rule DSL
Rule ID
Validator Ref
Comparison Mode
allowNegativeBalance配置
复杂Expected Definition
复杂YAML Schema
```

只保留：

```text
Java业务逻辑
外部固定Expected数据
统一三方CheckResult
可选description
```

---

# 最终冻结候选

```text
1. 所有比较逻辑在Java中完成。
2. 固定期待数据可以从外部Expected JSON读取。
3. 动态期待值由Java计算或从前序API取得。
4. 不在Expected JSON中描述业务规则实现方式。
5. 不使用ruleId、validatorRef等重复定义。
6. 所有Check统一输出check、previous、current、expected。
7. changed表示前回与今回是否变化。
8. matched表示今回是否满足期待。
9. result表示最终结果。
10. 特殊业务规则只增加可选description。
11. Java异常增加可选error。
12. Snapshot、Diff、Report只消费CheckResult，不重新比较。
```

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更文件

```text
本次没有新增文件正文。

设计进一步简化为：

Java业务逻辑
＋
外部固定Expected JSON
＋
统一Three-Value CheckResult
＋
可选description／error
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成】
```

下一版按这个**简化统一模型**重新编写，不再引入复杂Rule定义。

## 第 113 轮

### 你

你说的也有道理， 比如某个验证如何定位 ，如何判断该加载哪一个expected

### ChatGPT

对，这正是前面`checkId`仍然有价值的地方。

它不是为了描述复杂规则，而是为了回答两个问题：

```text
这是哪一个验证？
应该加载哪一个Expected？
```

因此可以保留一个很简单的稳定定位键：

```text
UseCase + Scenario + Step + Check
```

例如：

```text
UC-E6-001
SC-001
STEP-002
memberStatus
```

组合起来就是：

```text
UC-E6-001 / SC-001 / STEP-002 / memberStatus
```

这已经足够定位Expected，不需要再引入`ruleId`、`validatorRef`等复杂概念。

# 一、验证的最小定位结构

推荐每个验证只需要以下信息：

```java
CheckKey checkKey = new CheckKey(
    "UC-E6-001",
    "SC-001",
    "STEP-002",
    "memberStatus"
);
```

含义：

|字段|含义|
|---|---|
|useCaseId|属于哪个UseCase|
|scenarioId|属于哪条业务路径|
|stepId|属于哪一次API调用或业务处理|
|checkName|具体检查项目|

对于跨API比较，可以把`stepId`写成：

```text
SCENARIO
```

例如：

```text
UC-E6-001 / SC-001 / SCENARIO / balanceTransition
```

表示这是Scenario整体的跨API检查，不属于某一个API Step。

---

# 二、Expected文件如何组织

建议一个Scenario维护一份Expected JSON。

```text
expected/
└── UC-E6-001/
    └── SC-001/
        └── expected.json
```

内容：

```json
{
  "STEP-001": {
    "resultCode": "0000",
    "loginStatus": "SUCCESS"
  },
  "STEP-002": {
    "memberStatus": [
      "ACTIVE",
      "SUSPENDED"
    ],
    "responseType": "NORMAL"
  },
  "STEP-003": {
    "resultCode": "0000"
  },
  "SCENARIO": {
    "finalStatus": "COMPLETED"
  }
}
```

Java根据当前执行位置读取：

```text
STEP-002.memberStatus
```

得到：

```json
[
  "ACTIVE",
  "SUSPENDED"
]
```

这样文件很简单，没有：

```text
ruleId
comparisonMode
validatorRef
allowNegative
aggregationPolicy
```

只保存真正需要外部维护的期待值。

---

# 三、Java如何加载正确的Expected

可以做一个共通的`ExpectedLoader`：

```java
public interface ExpectedLoader {

    <T> T get(
        String useCaseId,
        String scenarioId,
        String stepId,
        String checkName,
        Class<T> valueType
    );
}
```

Scenario中：

```java
List<String> expectedStatuses =
    expectedLoader.get(
        "UC-E6-001",
        "SC-001",
        "STEP-002",
        "memberStatus",
        new TypeReference<List<String>>() {}
    );
```

内部定位规则：

```text
文件：
expected/UC-E6-001/SC-001/expected.json

JSON Path：
$.STEP-002.memberStatus
```

然后Java比较：

```java
CheckResult result = Checks.allowedValues(
    "memberStatus",
    previousStatus,
    currentStatus,
    expectedStatuses
);
```

---

# 四、避免在Java里重复写UseCase、Scenario、Step

实际代码中，不需要每次手写四个ID。

Scenario执行时，Context已经知道：

```java
ScenarioContext context;
```

例如：

```java
context.useCaseId();   // UC-E6-001
context.scenarioId();  // SC-001
context.currentStepId(); // STEP-002
```

所以实际调用可以简化成：

```java
List<String> expectedStatuses =
    context.expected()
        .getList("memberStatus", String.class);
```

Framework自动补齐定位信息：

```text
UC-E6-001
SC-001
STEP-002
memberStatus
```

Java代码最终很简单：

```java
results.add(
    Checks.allowedValues(
        "memberStatus",
        previous.getMemberStatus(),
        current.getMemberStatus(),
        context.expected().getList(
            "memberStatus",
            String.class
        )
    )
);
```

---

# 五、`check`名称必须稳定

例如今天Java写：

```java
Checks.allowedValues("memberStatus", ...);
```

明天不能随便改成：

```java
Checks.allowedValues("status", ...);
```

否则Expected Loader会找不到：

```text
STEP-002.status
```

因此`check`不仅是显示名称，也可以作为Expected定位键。

推荐区分：

```text
checkKey
    稳定的机器定位名称，不随便修改

checkName
    报告中显示的人类可读名称，可以修改
```

例如：

```java
CheckResult result = Checks.allowedValues(
    "memberStatus",
    "会員状態チェック",
    previousStatus,
    currentStatus,
    expectedStatuses
);
```

结果：

```json
{
  "check": "memberStatus",
  "checkName": "会員状態チェック",
  "previous": "ACTIVE",
  "current": "SUSPENDED",
  "expected": [
    "ACTIVE",
    "SUSPENDED"
  ],
  "changed": true,
  "matched": true,
  "result": "PASS"
}
```

其中：

```text
memberStatus
```

用于机器定位；

```text
会員状態チェック
```

用于Report显示。

---

# 六、不是所有Check都要加载Expected文件

Expected可以分成三类来源。

## 1. 外部Expected

适合固定值、允许值等：

```java
expectedStatuses =
    context.expected().getList("memberStatus");
```

来源：

```text
expected.json
```

---

## 2. Java动态Expected

例如：

```text
API3余额 = API1余额 - API2扣款额
```

Java直接计算：

```java
BigDecimal expected =
    api1Balance.subtract(api2Amount);
```

不加载Expected文件。

输出仍然统一：

```json
{
  "check": "balanceTransition",
  "previous": 900,
  "current": 700,
  "expected": 700,
  "changed": true,
  "matched": true,
  "result": "PASS",
  "description": "API3余额与业务计算结果比较"
}
```

---

## 3. Java内部规则Expected

例如：

```text
余额必须大于等于0
```

Java直接判断：

```java
boolean matched =
    currentBalance.compareTo(BigDecimal.ZERO) >= 0;
```

输出时把Java实际使用的判断条件写成简单说明：

```json
{
  "check": "balance",
  "previous": 1000,
  "current": -100,
  "expected": "0以上",
  "changed": true,
  "matched": false,
  "result": "FAIL"
}
```

也不需要Expected文件。

所以不是：

> 每个Check都必须从Expected JSON加载。

而是：

> 只有外部维护型Expected才从Expected JSON加载。

---

# 七、Java如何知道这个Check要不要加载Expected

有两种简单方式。

## 方式A：调用不同的共通方法，最推荐

固定Expected：

```java
Checks.externalExpected(
    "memberStatus",
    previous,
    current,
    context.expected().get("memberStatus")
);
```

动态Expected：

```java
Checks.dynamicExpected(
    "balanceTransition",
    previous,
    current,
    calculatedExpected
);
```

Java内部规则：

```java
Checks.condition(
    "balance",
    previous,
    current,
    current.signum() >= 0,
    "0以上"
);
```

从方法调用本身就知道Expected来源，不需要配置。

---

## 方式B：统一Builder

```java
CheckResult result = CheckResultBuilder
    .check("memberStatus")
    .previous(previous)
    .current(current)
    .expectedFromExternal(
        context.expected().get("memberStatus")
    )
    .matched(expectedStatuses.contains(current))
    .build();
```

也可以，但写法稍长。

对当前项目，方式A更简单。

---

# 八、Expected缺失时怎么处理

如果Java明确要求外部Expected：

```java
context.expected().getRequired("memberStatus");
```

但文件里没有：

```text
STEP-002.memberStatus
```

结果不能是FAIL。

因为不是Current不符合，而是验证前提不足。

应该：

```json
{
  "check": "memberStatus",
  "current": "ACTIVE",
  "matched": null,
  "result": "BLOCKED",
  "description": "Expected值未定义",
  "error": {
    "code": "EXPECTED_NOT_FOUND",
    "path": "STEP-002.memberStatus"
  }
}
```

如果Expected是可选的：

```java
context.expected().getOptional("memberStatus");
```

没有时可以不执行：

```json
{
  "check": "memberStatus",
  "result": "SKIPPED",
  "description": "Optional Expected未定义"
}
```

---

# 九、同一个Scenario有多个Expected版本

例如测试环境和生产验证的Expected不同：

```text
expected/
└── UC-E6-001/
    └── SC-001/
        ├── default/
        │   └── expected.json
        ├── test/
        │   └── expected.json
        └── prod/
            └── expected.json
```

加载优先级：

```text
1. 指定版本或环境Expected
2. Scenario默认Expected
3. 无Expected时BLOCKED或SKIPPED
```

例如：

```java
ExpectedContext expected =
    expectedLoader.load(
        context.useCaseId(),
        context.scenarioId(),
        context.environmentId()
    );
```

但是不建议设计太多Fallback层级。

当前阶段可简单固定为：

```text
UseCase + Scenario + Environment
```

---

# 十、推荐的最终定位规则

建议正式冻结为：

```text
Expected文件定位：

expected/
  {useCaseId}/
    {scenarioId}/
      {environmentId}/
        expected.json
```

文件内部定位：

```text
{stepId}.{checkKey}
```

完整定位例子：

```text
文件：
expected/UC-E6-001/SC-001/test/expected.json

项目：
STEP-002.memberStatus
```

跨API检查：

```text
SCENARIO.balanceTransition
```

---

# 十一、结果中要记录Expected来源

即使结构保持简单，结果中最好记录Expected从哪里加载，以便调查。

```json
{
  "check": "memberStatus",
  "previous": "ACTIVE",
  "current": "SUSPENDED",
  "expected": [
    "ACTIVE",
    "SUSPENDED"
  ],
  "changed": true,
  "matched": true,
  "result": "PASS",
  "expectedSource": {
    "file": "expected/UC-E6-001/SC-001/test/expected.json",
    "path": "STEP-002.memberStatus"
  }
}
```

`expectedSource`可以作为可选属性。

它不是业务规则，只是证据定位。

这对以下问题很有用：

```text
为什么这次判定为PASS？
到底加载了哪个Expected？
是否误用了其他环境的Expected？
Expected文件是否已经更新？
```

---

# 十二、最简最终结构

Expected输入：

```json
{
  "STEP-001": {
    "resultCode": "0000"
  },
  "STEP-002": {
    "memberStatus": [
      "ACTIVE",
      "SUSPENDED"
    ]
  },
  "SCENARIO": {
    "finalStatus": "COMPLETED"
  }
}
```

Java：

```java
List<String> expected =
    context.expected()
        .getList("memberStatus", String.class);

CheckResult result =
    Checks.allowedValues(
        "memberStatus",
        "会員状態チェック",
        previousStatus,
        currentStatus,
        expected
    );
```

结果：

```json
{
  "check": "memberStatus",
  "checkName": "会員状態チェック",
  "previous": "ACTIVE",
  "current": "SUSPENDED",
  "expected": [
    "ACTIVE",
    "SUSPENDED"
  ],
  "changed": true,
  "matched": true,
  "result": "PASS",
  "expectedSource": {
    "path": "STEP-002.memberStatus"
  }
}
```

# 最终结论

这次可以确定：

```text
1. checkKey必须保留，用于稳定定位验证。
2. Expected按照UseCase、Scenario、Environment定位文件。
3. 文件内部按照Step和checkKey定位具体Expected。
4. Java Scenario Context自动携带UseCase、Scenario、Step信息。
5. Java业务代码只需要提供checkKey。
6. 外部Expected才加载JSON。
7. Java动态Expected和Java条件检查不加载Expected JSON。
8. Expected缺失时，根据Required设置返回BLOCKED或SKIPPED。
9. 结果中可以增加expectedSource，便于审计和调查。
10. 不需要ruleId、validatorRef或复杂DSL。
```

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次未新增文件正文。

新增确认：

- Expected定位主键：
  UseCase + Scenario + Step + CheckKey
- Expected文件按UseCase／Scenario／Environment管理
- 结果增加可选expectedSource
- checkKey保留为机器定位键
- checkName作为报告显示名称
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入Expected定位和加载规则】
```

## 第 114 轮

### 你

我觉得还是得有一个预期值，比如这一个batch完成后，会有一个结果代表执行成功，那么里面每一个api调用有期待的结果，每一个特殊的check会有一个期待结果。这样出力的文件里面就可以相互对应着看。如果期待值只定义了一部分，有一部分处理值有，那么比较的时候因为在期待值里找不到 ，本来java里面就是实现了，就不需要了。
但是input.json里面 不光有一个batch入口，还想按照这种想法，去让java程序知道读取哪一部分的inputjson情报，那么入力的json文件也需要特别定义。和期待json完全是2回事

### ChatGPT

我理解你的意思了：**Input JSON负责告诉Java“这次Batch从哪里取输入”；Expected JSON负责告诉Java“这次Batch、每个API、每个特殊Check应该得到什么结果”。两者必须完全分开，但使用同一套UseCase／Scenario／Step／Check定位键。**

### ChatGPT

对，你现在把两个问题分清了：

```text
input.json
负责“这次Batch拿什么数据执行”

expected.json
负责“这次Batch、每个API、每个Check应该得到什么结果”
```

它们使用相同的定位键，但内容和职责完全不同。

---

# 一、整体结构

一次Scenario执行需要四类数据：

```text
Input
    本次执行使用的输入

Expected
    本次执行应该出现的结果

Previous
    前一次批准运行的实际结果

Current
    本次Java Batch产生的实际结果
```

运行方式：

```text
input.json
    ↓
Java Scenario Batch执行
    ↓
多次API调用和Java Check
    ↓
产生Current Result
    ↓
与expected.json对应
    ↓
与Previous Snapshot比较
    ↓
输出Snapshot、Diff、Report
```

---

# 二、Input JSON负责什么

Input JSON不只写Batch入口。

它还要根据Scenario、Step，让Java明确知道每一次API调用应该读取哪一部分输入。

例如：

```json
{
  "batch": {
    "useCaseId": "UC-E6-001",
    "scenarioId": "SC-001",
    "environment": "test",
    "businessDate": "2026-07-24"
  },

  "steps": {
    "STEP-001": {
      "request": {
        "userId": "USER001",
        "password": "SECRET_REF_001"
      }
    },

    "STEP-002": {
      "request": {
        "memberId": "M000001",
        "targetMonth": "2026-07"
      }
    },

    "STEP-003": {
      "request": {
        "memberId": "M000001",
        "updateType": "NORMAL"
      }
    }
  },

  "checkInputs": {
    "balanceTransition": {
      "roundingScale": 0
    }
  }
}
```

Java读取时：

```java
StepInput step1Input =
    inputContext.getStep("STEP-001");

StepInput step2Input =
    inputContext.getStep("STEP-002");
```

特殊Check需要额外输入时：

```java
BalanceCheckInput checkInput =
    inputContext.getCheckInput(
        "balanceTransition",
        BalanceCheckInput.class
    );
```

但大多数特殊Check直接使用多个API的Request、Response，不需要额外`checkInputs`。

---

# 三、Expected JSON负责什么

Expected JSON应该和Java的执行结构相互对应。

至少包括：

```text
Batch期待结果
每个API Step期待结果
每个API调用的期待状态
每个特殊Check期待结果
必要时的期待值
```

例如：

```json
{
  "batch": {
    "expectedResult": "PASS"
  },

  "steps": {
    "STEP-001": {
      "expectedResult": "PASS",

      "api": {
        "expectedExecutionResult": "SUCCEEDED",
        "expectedHttpStatus": 200
      },

      "checks": {
        "resultCode": {
          "expectedValue": "0000",
          "expectedResult": "PASS"
        },

        "accessToken": {
          "expectedResult": "PASS"
        }
      }
    },

    "STEP-002": {
      "expectedResult": "PASS",

      "api": {
        "expectedExecutionResult": "SUCCEEDED",
        "expectedHttpStatus": 200
      },

      "checks": {
        "memberStatus": {
          "expectedValue": [
            "ACTIVE",
            "SUSPENDED"
          ],
          "expectedResult": "PASS"
        },

        "balanceNonNegative": {
          "expectedResult": "PASS"
        }
      }
    }
  },

  "scenarioChecks": {
    "balanceTransition": {
      "expectedResult": "PASS"
    },

    "memberStatusTransition": {
      "expectedResult": "PASS"
    }
  }
}
```

这里非常关键：

```json
"balanceNonNegative": {
  "expectedResult": "PASS"
}
```

不需要写：

```json
"allowNegativeBalance": false
```

因为“余额不能为负数”已经由Java逻辑定义。

Expected JSON只表达：

> 我期待这个Java Check执行后的结果是PASS。

---

# 四、Expected Value和Expected Result是两回事

建议正式区分：

## Expected Value

用于外部固定值比较：

```json
{
  "expectedValue": "0000"
}
```

或者：

```json
{
  "expectedValue": [
    "ACTIVE",
    "SUSPENDED"
  ]
}
```

## Expected Result

用于表示这个Check最后应得到什么业务结果：

```json
{
  "expectedResult": "PASS"
}
```

对于Java内部规则，只需要Expected Result。

例如：

```json
{
  "balanceNonNegative": {
    "expectedResult": "PASS"
  }
}
```

Java执行：

```java
boolean valid =
    currentBalance.compareTo(BigDecimal.ZERO) >= 0;

ActualCheckResult actual =
    valid ? PASS : FAIL;
```

然后比较：

```text
Java实际Check结果 = FAIL
Expected文件结果   = PASS
```

最终验证结果：

```text
FAIL
```

---

# 五、为什么Batch和Step也要有Expected Result

因为可能存在异常Scenario。

例如一个“会员不存在”的异常Scenario，预期API返回业务错误。

Expected：

```json
{
  "steps": {
    "STEP-002": {
      "expectedResult": "FAIL",

      "api": {
        "expectedExecutionResult": "SUCCEEDED",
        "expectedHttpStatus": 404
      }
    }
  },

  "batch": {
    "expectedResult": "FAIL"
  }
}
```

实际执行：

```text
STEP-002实际业务结果 = FAIL
STEP-002期待业务结果 = FAIL
```

两者一致，因此测试验证本身可以是：

```text
PASS
```

所以必须区分：

```text
Actual Result
    实际发生了什么

Expected Result
    原本期待发生什么

Verification Result
    实际与期待是否一致
```

例如：

```json
{
  "actualResult": "FAIL",
  "expectedResult": "FAIL",
  "matched": true,
  "verificationResult": "PASS"
}
```

这对异常Scenario非常重要。

---

# 六、统一Check输出格式

## 有固定Expected Value的Check

```json
{
  "check": "memberStatus",
  "checkName": "会員状態チェック",

  "previous": "ACTIVE",
  "current": "SUSPENDED",
  "expected": [
    "ACTIVE",
    "SUSPENDED"
  ],

  "previousResult": "PASS",
  "currentResult": "PASS",
  "expectedResult": "PASS",

  "changed": true,
  "matched": true,
  "verificationResult": "PASS"
}
```

含义：

```text
Previous → Current发生了变化
但Current符合Expected
所以验证通过
```

---

## 只有Expected Result的Java业务Check

```json
{
  "check": "balanceNonNegative",
  "checkName": "残高非負チェック",

  "previous": 1000,
  "current": -100,

  "previousResult": "PASS",
  "currentResult": "FAIL",
  "expectedResult": "PASS",

  "changed": true,
  "matched": false,
  "verificationResult": "FAIL",

  "description": "Java业务检查结果与期待结果不一致"
}
```

这里不需要`expected`值。

因为Java已经知道判断规则。

---

## 跨API业务Check

```json
{
  "check": "balanceTransition",
  "checkName": "残高遷移整合性チェック",

  "previous": {
    "beforeBalance": 1000,
    "paymentAmount": 200,
    "afterBalance": 800
  },

  "current": {
    "beforeBalance": 1000,
    "paymentAmount": 300,
    "afterBalance": 700
  },

  "currentResult": "PASS",
  "expectedResult": "PASS",

  "changed": true,
  "matched": true,
  "verificationResult": "PASS",

  "description": "API3残高がAPI1残高－API2処理金額と一致すること"
}
```

这里Java内部已经完成：

```text
1000 - 300 = 700
```

Expected JSON只写：

```json
{
  "balanceTransition": {
    "expectedResult": "PASS"
  }
}
```

---

# 七、Expected只定义一部分怎么办

你的理解是正确的：

> Expected JSON不是Current输出的完整Schema。

Expected文件只定义需要从外部指定期待结果或期待值的部分。

例如Expected只定义：

```json
{
  "steps": {
    "STEP-002": {
      "checks": {
        "memberStatus": {
          "expectedValue": [
            "ACTIVE",
            "SUSPENDED"
          ],
          "expectedResult": "PASS"
        }
      }
    }
  }
}
```

而Java实际还产生：

```text
balanceNonNegative
transactionIdLength
monthlyBusinessCheck
```

这些Check在Expected中找不到时：

```text
不能认为是Expected缺失错误
不能自动FAIL
不能自动BLOCKED
```

因为它们可能是Java内部完成的验证。

正确规则是：

## Expected中存在

执行外部Expected比较：

```text
Actual Result ↔ Expected Result
Current Value ↔ Expected Value（有值时）
```

## Expected中不存在

Java Check照常执行。

其`currentResult`按照Java逻辑直接参与Step聚合，不再做外部Expected比较。

输出可以表示：

```json
{
  "check": "transactionIdLength",
  "current": 12,
  "currentResult": "PASS",
  "expectedConfigured": false,
  "verificationResult": "PASS"
}
```

不需要强制设置`expected`。

---

# 八、反过来：Expected有，但Java没有产生Check

这个情况不能忽略。

例如Expected写了：

```json
{
  "checks": {
    "memberStatus": {
      "expectedResult": "PASS"
    }
  }
}
```

但是Java没有执行或没有输出`memberStatus`。

结果应该是：

```json
{
  "check": "memberStatus",
  "expectedResult": "PASS",
  "currentResult": "NOT_PRODUCED",
  "matched": false,
  "verificationResult": "BLOCKED",
  "description": "Expected中定义的Check没有被Java执行"
}
```

这通常代表：

- Java漏实现；
- Check名称写错；
- Expected文件写错；
- 分支没有按预期执行。

---

# 九、Input和Expected使用同一定位体系

两者虽然完全不同，但使用同一组定位键：

```text
UseCase
Scenario
Step
Check
```

## Input定位

```text
UC-E6-001
SC-001
STEP-002
request.memberId
```

## Expected定位

```text
UC-E6-001
SC-001
STEP-002
checks.memberStatus
```

## Output定位

```text
UC-E6-001
SC-001
STEP-002
checks.memberStatus
```

这样输入、期待、结果可以相互对应。

---

# 十、文件建议

这是候选结构：

```text
UC-E6-001/
└── SC-001/
    ├── input/
    │   └── input.json
    │
    ├── expected/
    │   └── expected.json
    │
    └── baseline/
        └── previous-snapshot.json
```

运行输出：

```text
RUN-20260724-001/
├── input-used.json
├── expected-used.json
├── previous-used.json
├── current-snapshot.json
├── check-results.json
├── baseline-diff.json
├── expected-result-diff.json
└── report.json
```

其中：

```text
input-used.json
    保存本次真正使用的输入

expected-used.json
    保存本次真正使用的期待定义

previous-used.json
    保存本次使用的前回Baseline

current-snapshot.json
    本次实际执行结果

check-results.json
    Java产生的各Check结果
```

---

# 十一、Java执行模型

```java
ScenarioInput input =
    inputLoader.load(
        useCaseId,
        scenarioId,
        inputSetId
    );

ScenarioExpected expected =
    expectedLoader.load(
        useCaseId,
        scenarioId,
        expectedSetId
    );

ScenarioResult current =
    scenario.execute(input);

VerificationResult verification =
    resultVerifier.verify(
        previous,
        current,
        expected
    );
```

注意：

```text
API调用和业务Check：
scenario.execute()内部执行

Expected结果对应：
resultVerifier完成

真正的业务判断：
Java Check内部完成

JSON：
输入和输出载体
```

---

# 十二、最终统一定义

建议冻结为下面这套简化模型：

```text
Input JSON
    定义Batch、Step、API Request和必要Check输入

Expected JSON
    定义Batch Expected Result
    定义Step Expected Result
    定义API Expected Result
    定义Check Expected Result
    必要时定义Expected Value

Java Scenario
    调用API
    执行共通Check
    执行业务Check
    产生Current Result

Previous Snapshot
    保存前一次批准的实际结果

Output
    对应显示Previous、Current、Expected及最终验证结果
```

最关键规则：

```text
1. Expected Value是可选的。
2. Expected Result可以定义在Batch、Step、API和Check层。
3. Java内部规则不需要在Expected JSON重复描述。
4. Expected未定义某个Java Check时，不认为错误。
5. Expected定义了Check但Java未产生时，判定BLOCKED。
6. Input JSON与Expected JSON完全分开。
7. Input和Expected使用同一UseCase／Scenario／Step／Check定位体系。
8. Output结构尽量与Expected结构镜像对应。
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次未新增文件正文。

已确认新增设计：

1. Input JSON与Expected JSON完全分离。
2. Input按Batch／Step定位API输入。
3. Expected按Batch／Step／API／Check定义期待结果。
4. Expected Value可选，Expected Result为主要对应内容。
5. Expected只定义部分内容时，未定义的Java Check仍可正常执行。
6. Expected定义但Java未产生的Check判定为BLOCKED。
7. Output与Expected采用镜像结构，便于逐项对应。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成】
```

下一版应正式纳入：

```text
Input Model
Expected Result Model
Java Actual Result Model
Partial Expected规则
Expected与Actual对应规则
Batch／Step／API／Check多层结果结构
```

## 第 115 轮

### 你

比如api的返回值 这种期待值 他就有项目不一样的变化，但是项目的某种业务逻辑，我觉得验证方式不都是java写好了吗 对于客户来说就只需要知道 执行成功了 预期不就是什么业务逻辑 比如memberStatus 是PASS不就可以了吗 为什么还有ACTIVE和SUSPENDED

### ChatGPT

对。按照你现在确定的方向，`memberStatus`的Expected里**不需要再写`ACTIVE`、`SUSPENDED`**。

因为：

```text
ACTIVE／SUSPENDED是否合法
```

已经属于Java中的业务检查逻辑。Expected文件再保存一次允许值，会造成业务规则在Java和JSON中重复定义。

正确模型应当是：

```text
Java判断业务逻辑是否成功
Expected只定义期待的检查结果
```

# 1. Expected只写PASS／FAIL

例如：

```json
{
  "batch": {
    "expectedResult": "PASS"
  },
  "steps": {
    "STEP-001": {
      "expectedResult": "PASS",
      "api": {
        "expectedResult": "PASS"
      },
      "checks": {
        "memberStatus": {
          "expectedResult": "PASS"
        },
        "responseRequiredFields": {
          "expectedResult": "PASS"
        }
      }
    },
    "STEP-002": {
      "expectedResult": "PASS",
      "api": {
        "expectedResult": "PASS"
      },
      "checks": {
        "balanceTransition": {
          "expectedResult": "PASS"
        }
      }
    }
  }
}
```

客户只需要理解：

```text
memberStatus检查期待成功
balanceTransition检查期待成功
STEP-001期待成功
整个Batch期待成功
```

不需要知道Java内部怎样判断。

# 2. Java内部负责全部业务规则

例如：

```java
CheckResult checkMemberStatus(
        MemberResponse response) {

    boolean passed =
            response.getMemberStatus() != null
            && isValidStatusForCurrentBusinessFlow(
                    response.getMemberStatus()
            );

    return CheckResult.of(
            "memberStatus",
            passed ? PASS : FAIL
    );
}
```

Java内部可以检查：

```text
是否为合法状态
是否符合当前业务分支
是否与前一个API结果一致
是否符合状态迁移规则
是否为空
类型是否正确
```

这些都不需要写入Expected JSON。

# 3. 输出比较的是三个“检查结果”

对于这种业务Check，三方比较应该是：

```text
Previous Result
Current Result
Expected Result
```

而不是：

```text
Previous memberStatus值
Current memberStatus值
Expected ACTIVE／SUSPENDED
```

例如：

```json
{
  "check": "memberStatus",
  "checkName": "会員状態業務チェック",

  "previousResult": "PASS",
  "currentResult": "PASS",
  "expectedResult": "PASS",

  "changed": false,
  "matched": true,
  "verificationResult": "PASS"
}
```

这就非常清楚：

```text
前回检查成功
今回检查成功
期待检查成功
此次验证成功
```

# 4. 实际值放到details中即可

为了发生问题时能够调查，Java可以选择输出实际使用的数据，但这些不是Expected定义。

```json
{
  "check": "memberStatus",
  "checkName": "会員状態業務チェック",

  "previousResult": "PASS",
  "currentResult": "FAIL",
  "expectedResult": "PASS",

  "changed": true,
  "matched": false,
  "verificationResult": "FAIL",

  "details": {
    "previousValue": "ACTIVE",
    "currentValue": "UNKNOWN",
    "message": "今回の会員状態は業務上許可されていません。"
  }
}
```

客户首先看到：

```text
期待：PASS
实际：FAIL
验证：FAIL
```

需要调查时，才查看：

```text
Current Value = UNKNOWN
```

因此分成两个层次：

|层次|内容|
|---|---|
|主要判定层|Previous Result／Current Result／Expected Result|
|调查证据层|实际字段值、API值、计算值、错误内容|

# 5. API返回值如何处理

完整API返回值仍然保存为Raw Snapshot：

```text
STEP-001/
├── request.json
├── response.json
├── execution-result.json
└── check-results.json
```

例如：

```json
{
  "memberId": "M001",
  "memberStatus": "ACTIVE",
  "updatedAt": "2026-07-24T10:00:00+09:00"
}
```

但是Expected文件不需要复制这份Response，也不需要逐字段定义允许值。

Java读取Response以后执行所有检查：

```text
Response
   ↓
Java业务Check
   ↓
PASS／FAIL
   ↓
Check Result输出
```

# 6. Previous、Current、Expected的最终定义

## 对业务Check

```text
Previous = 前回该Check的执行结果
Current  = 今回该Check的执行结果
Expected = 本Scenario期待的Check结果
```

例如：

```json
{
  "check": "balanceTransition",
  "previousResult": "PASS",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "changed": false,
  "matched": true,
  "verificationResult": "PASS"
}
```

## 对API Step

```text
Previous = 前回Step结果
Current  = 今回Step结果
Expected = Expected JSON中的Step期待结果
```

```json
{
  "step": "STEP-002",
  "previousResult": "PASS",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "changed": true,
  "matched": false,
  "verificationResult": "FAIL"
}
```

## 对Batch／Scenario

```text
Previous = 前回Batch结果
Current  = 今回Batch结果
Expected = Expected JSON中的Batch期待结果
```

# 7. 异常Scenario也能正确表示

例如“会员不存在”本来就是预期业务错误。

Expected：

```json
{
  "steps": {
    "STEP-002": {
      "checks": {
        "memberNotFound": {
          "expectedResult": "FAIL"
        }
      }
    }
  },
  "batch": {
    "expectedResult": "FAIL"
  }
}
```

Java实际检查：

```text
Current Result = FAIL
Expected Result = FAIL
```

最终验证：

```json
{
  "check": "memberNotFound",
  "previousResult": "FAIL",
  "currentResult": "FAIL",
  "expectedResult": "FAIL",
  "changed": false,
  "matched": true,
  "verificationResult": "PASS"
}
```

也就是：

> 业务处理实际失败，但这是这个异常Scenario所期待的结果，因此测试验证成功。

# 8. Diff如何表示

## Baseline Diff

只比较前回和今回：

```json
{
  "check": "memberStatus",
  "previousResult": "PASS",
  "currentResult": "FAIL",
  "changed": true
}
```

## Expected Diff

比较今回和期待：

```json
{
  "check": "memberStatus",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "matched": false,
  "verificationResult": "FAIL"
}
```

需要时可以附带调查证据：

```json
{
  "details": {
    "previousValue": "ACTIVE",
    "currentValue": "UNKNOWN"
  }
}
```

但它不是Expected定义。

# 9. Report如何显示

主要报告只需要：

|检查项目|前回结果|今回结果|期待结果|前回差异|期待一致|验证结果|
|---|---|---|---|---|---|---|
|memberStatus|PASS|PASS|PASS|无|一致|PASS|
|balanceTransition|PASS|FAIL|PASS|有|不一致|FAIL|
|monthlyDataCheck|PASS|PASS|PASS|无|一致|PASS|

详细页面再显示：

```text
使用了哪些API值
Java比较了哪些对象
失败原因
异常位置
Request／Response文件链接
```

# 10. 最终简化模型

正式建议冻结为：

```text
1. API返回值和业务数据由Java检查。
2. Java中定义所有字段、状态、类型、长度和跨API业务逻辑。
3. Expected JSON原则上只定义Expected Result。
4. Expected JSON不重复定义ACTIVE／SUSPENDED等业务允许值。
5. Previous／Current／Expected主要比较Check Result。
6. 实际业务数据仅作为details／evidence输出。
7. Raw Request／Response继续完整保存。
8. Baseline Diff比较Previous Result与Current Result。
9. Expected Diff比较Current Result与Expected Result。
10. Report首先展示结果，详细数据用于调查。
```

最终输出可以统一到这个最小结构：

```json
{
  "check": "memberStatus",
  "previousResult": "PASS",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "changed": false,
  "matched": true,
  "verificationResult": "PASS",
  "description": "会員状態が業務条件を満たすこと"
}
```

只有失败或者需要详细证据时，再增加：

```json
{
  "details": {
    "previousValue": "ACTIVE",
    "currentValue": "UNKNOWN",
    "message": "業務上許可されていない状態です。"
  }
}
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
新增确认：

1. Expected以Expected Result为中心。
2. memberStatus等业务规则不在Expected JSON重复定义。
3. ACTIVE／SUSPENDED等允许值由Java业务Check管理。
4. 三方比较主要比较Previous Result／Current Result／Expected Result。
5. 实际业务值作为可选details或evidence输出。
6. Raw API Request／Response仍完整保存。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需要按Result中心模型重写】
```

## 第 116 轮

### 你

那就是说 batch执行完之后 比较的结果文件 会有batch的预期，api step的预期，以及各个业务逻辑的预期

### ChatGPT

对。准确地说，Batch执行完成后的结果文件，会按三个层次保存：

```text
Batch层
API Step层
业务Check层
```

每一层都不是只保存“预期”，而是同时保存：

```text
previousResult      前回结果
currentResult       今回实际结果
expectedResult      预期结果
changed             前回与今回是否变化
matched             今回与预期是否一致
verificationResult  本次验证最终结果
```

# 一、结果层级

```text
Batch Result
├── Batch预期与实际
│
├── STEP-001 API调用
│   ├── API执行预期与实际
│   ├── memberStatus业务Check
│   ├── requiredField业务Check
│   └── STEP-001汇总结果
│
├── STEP-002 API调用
│   ├── API执行预期与实际
│   ├── balanceTransition业务Check
│   └── STEP-002汇总结果
│
├── Scenario级跨API Check
│   └── API1、API2之间的业务整合检查
│
└── Batch最终验证结果
```

# 二、最终结果文件示例

```json
{
  "batch": {
    "previousResult": "PASS",
    "currentResult": "FAIL",
    "expectedResult": "PASS",
    "changed": true,
    "matched": false,
    "verificationResult": "FAIL"
  },

  "steps": [
    {
      "stepId": "STEP-001",
      "apiName": "会員情報取得API",

      "apiExecution": {
        "previousResult": "PASS",
        "currentResult": "PASS",
        "expectedResult": "PASS",
        "changed": false,
        "matched": true,
        "verificationResult": "PASS"
      },

      "checks": [
        {
          "check": "memberStatus",
          "checkName": "会員状態業務チェック",

          "previousResult": "PASS",
          "currentResult": "PASS",
          "expectedResult": "PASS",

          "changed": false,
          "matched": true,
          "verificationResult": "PASS"
        },
        {
          "check": "requiredResponseItems",
          "checkName": "必須返却項目チェック",

          "previousResult": "PASS",
          "currentResult": "FAIL",
          "expectedResult": "PASS",

          "changed": true,
          "matched": false,
          "verificationResult": "FAIL",

          "details": {
            "missingItems": [
              "memberName"
            ]
          }
        }
      ],

      "previousResult": "PASS",
      "currentResult": "FAIL",
      "expectedResult": "PASS",
      "changed": true,
      "matched": false,
      "verificationResult": "FAIL"
    }
  ],

  "scenarioChecks": [
    {
      "check": "memberInformationConsistency",
      "checkName": "API間会員情報整合性チェック",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    }
  ]
}
```

# 三、各层的Expected代表什么

## 1. Batch的Expected

```json
{
  "batch": {
    "expectedResult": "PASS"
  }
}
```

表示：

> 这次整个Scenario Batch最终应当成功。

Java执行结束得到：

```text
currentResult = FAIL
expectedResult = PASS
```

所以：

```text
verificationResult = FAIL
```

---

## 2. API Step的Expected

```json
{
  "steps": {
    "STEP-001": {
      "expectedResult": "PASS"
    }
  }
}
```

表示：

> STEP-001包括API调用和该Step下所有必要Check，最终应当成功。

Step的`currentResult`由Java聚合：

```text
API调用结果
＋
该Step下所有Required Check结果
```

例如：

```text
API调用       PASS
memberStatus PASS
必填项目检查  FAIL
```

则：

```text
STEP-001 currentResult = FAIL
```

与：

```text
STEP-001 expectedResult = PASS
```

不一致，所以Step验证失败。

---

## 3. API调用本身的Expected

API Step里面还可以单独保存：

```json
{
  "apiExecution": {
    "expectedResult": "PASS"
  }
}
```

这个只代表：

```text
API是否成功调用
是否取得Response
HTTP通信是否正常
Response是否可以解析
```

它不代表业务字段一定正确。

例如：

```text
API调用成功          PASS
memberStatus业务验证 FAIL
```

因此：

```text
apiExecution.currentResult = PASS
step.currentResult = FAIL
```

这两个不能混在一起。

---

## 4. 每个业务逻辑Check的Expected

```json
{
  "check": "memberStatus",
  "expectedResult": "PASS"
}
```

表示：

> Java中的memberStatus业务逻辑检查，期待执行结果为PASS。

Java内部具体如何判断：

```text
状态是否合法
状态迁移是否正确
是否与前一个API一致
是否满足本Scenario业务条件
```

都不需要写到Expected JSON中。

只保存：

```text
memberStatus检查预期为PASS
```

# 四、Expected文件可以很简单

输入Expected文件可以只保存预期结果：

```json
{
  "batch": {
    "expectedResult": "PASS"
  },

  "steps": {
    "STEP-001": {
      "apiExecution": {
        "expectedResult": "PASS"
      },

      "checks": {
        "memberStatus": {
          "expectedResult": "PASS"
        },
        "requiredResponseItems": {
          "expectedResult": "PASS"
        },

      "expectedResult": "PASS"
    },

    "STEP-002": {
      "apiExecution": {
        "expectedResult": "PASS"
      },

      "checks": {
        "balanceTransition": {
          "expectedResult": "PASS"
        }
      },

      "expectedResult": "PASS"
    }
  },

  "scenarioChecks": {
    "memberInformationConsistency": {
      "expectedResult": "PASS"
    }
  }
}
```

这里没有：

```text
ACTIVE
SUSPENDED
余额计算公式
允许负数
字段长度
API之间的映射表达式
```

这些规则全部在Java中。

# 五、前回、今回、期待的比较关系

每一层都执行两种比较。

## Baseline比较

```text
previousResult ↔ currentResult
```

回答：

> 与前一次相比，有没有变化？

例如：

```text
Previous = PASS
Current  = FAIL
changed  = true
```

这只表示发生变化。

---

## Expected比较

```text
currentResult ↔ expectedResult
```

回答：

> 本次实际结果是否符合预期？

例如：

```text
Current  = FAIL
Expected = PASS
matched  = false
verificationResult = FAIL
```

最终成功与否，主要由Expected比较决定。

# 六、异常Scenario也能表示

例如这是一个“会员不存在”的异常Scenario。

Java中的业务Check预期就可能是：

```json
{
  "checks": {
    "memberExists": {
      "expectedResult": "FAIL"
    },
    "memberNotFoundResponse": {
      "expectedResult": "PASS"
    }
  }
}
```

实际结果：

```json
{
  "check": "memberExists",
  "currentResult": "FAIL",
  "expectedResult": "FAIL",
  "matched": true,
  "verificationResult": "PASS"
}
```

这里业务检查结果是`FAIL`，但它符合异常Scenario的预期，因此测试验证结果是`PASS`。

所以必须区分：

```text
currentResult
    Java业务检查实际结果

expectedResult
    Scenario期待的业务检查结果

verificationResult
    两者是否一致
```

# 七、建议最终输出文件

```text
RUN-20260724-001/
├── input-used.json
├── expected-used.json
├── previous-result.json
│
├── steps/
│   ├── STEP-001/
│   │   ├── request.json
│   │   ├── response.json
│   │   ├── api-execution-result.json
│   │   └── check-results.json
│   └── STEP-002/
│       └── ...
│
├── current-result.json
├── baseline-diff.json
├── expected-diff.json
├── verification-result.json
└── report.json
```

其中：

```text
current-result.json
    Java实际执行产生的Batch、Step、API、Check结果

baseline-diff.json
    Previous Result与Current Result的变化

expected-diff.json
    Current Result与Expected Result的对应结果

verification-result.json
    最终完整验证结论

report.json
    面向客户和承认者的显示内容
```

# 八、最终确定

是的，Batch执行完成后，最终比较结果中会有：

```text
1. Batch的期待结果
2. 每个API Step的期待结果
3. 每次API调用本身的期待结果
4. 每个Java业务Check的期待结果
5. Scenario级跨API业务Check的期待结果
```

并且每一项都能对应看到：

```text
Previous
Current
Expected
Changed
Matched
Verification Result
```

这是目前最统一、也最容易给客户理解的结构。

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更文件

```text
本次没有新增文件正文。

进一步确认：

1. Expected Result定义为多层结构。
2. 层级包括Batch、API Step、API Execution、Business Check。
3. 跨API Check放在Scenario Check层。
4. 每层都显示Previous／Current／Expected。
5. Current Result和Expected Result一致时，Verification Result为PASS。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需要按多层Expected Result模型重写】
```

## 第 117 轮

### 你

你这顺序不是有问题吗 不就是batch总的结果，然后api1返回值对比，api1的结果的check，api2返回值对比，api2的结果的check，api1和api2的逻辑对比

### ChatGPT

对，你说得对。前面我把“层级结构”和“结果文件的表示顺序”混在一起了，而且又增加了不必要的`API Execution Result`、`Step Result`等层次。

按照你现在的业务理解，结果内容就应该是：

```text
Batch总结果
↓
API1返回值比较结果
↓
API1返回内容的各业务Check结果
↓
API2返回值比较结果
↓
API2返回内容的各业务Check结果
↓
API1与API2之间的业务逻辑比较结果
```

# 一、实际执行顺序

Java Batch真正运行时，Batch总结果只能最后计算：

```text
1. 调用API1
2. 比较API1返回结果
3. 执行API1相关业务Check
4. 调用API2
5. 比较API2返回结果
6. 执行API2相关业务Check
7. 执行API1与API2之间的业务Check
8. 汇总所有结果，生成Batch总结果
```

也就是：

```mermaid
flowchart TD
    A[调用API1] --> B[API1返回值比较]
    B --> C[API1业务Check]
    C --> D[调用API2]
    D --> E[API2返回值比较]
    E --> F[API2业务Check]
    F --> G[API1与API2业务逻辑比较]
    G --> H[汇总Batch总结果]
```

# 二、结果文件的显示顺序

虽然Batch总结果最后计算，但为了让客户打开报告时先看到结论，结果JSON可以把Batch总结果放在最前面。

```json
{
  "batchResult": {
    "previousResult": "PASS",
    "currentResult": "FAIL",
    "expectedResult": "PASS",
    "changed": true,
    "matched": false,
    "verificationResult": "FAIL"
  },

  "apiSteps": [
    {
      "stepId": "STEP-001",
      "apiName": "会員情報取得API",

      "responseComparison": {
        "previousResult": "PASS",
        "currentResult": "PASS",
        "expectedResult": "PASS",
        "changed": false,
        "matched": true,
        "verificationResult": "PASS"
      },

      "checks": [
        {
          "check": "memberStatus",
          "checkName": "会員状態チェック",
          "previousResult": "PASS",
          "currentResult": "PASS",
          "expectedResult": "PASS",
          "changed": false,
          "matched": true,
          "verificationResult": "PASS"
        },
        {
          "check": "requiredItems",
          "checkName": "必須項目チェック",
          "previousResult": "PASS",
          "currentResult": "PASS",
          "expectedResult": "PASS",
          "changed": false,
          "matched": true,
          "verificationResult": "PASS"
        }
      ]
    },

    {
      "stepId": "STEP-002",
      "apiName": "会員情報更新API",

      "responseComparison": {
        "previousResult": "PASS",
        "currentResult": "FAIL",
        "expectedResult": "PASS",
        "changed": true,
        "matched": false,
        "verificationResult": "FAIL"
      },

      "checks": [
        {
          "check": "updateResult",
          "checkName": "更新結果チェック",
          "previousResult": "PASS",
          "currentResult": "FAIL",
          "expectedResult": "PASS",
          "changed": true,
          "matched": false,
          "verificationResult": "FAIL",
          "details": {
            "message": "更新結果が業務条件を満たしていません。"
          }
        }
      ]
    }
  ],

  "crossApiChecks": [
    {
      "check": "memberInformationConsistency",
      "checkName": "API間会員情報整合性チェック",
      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",
      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    }
  ]
}
```

# 三、不需要另外增加Step总结果

按照你现在的思路，暂时没有必要再为每个Step增加一个重复的：

```json
{
  "stepResult": "FAIL"
}
```

因为API1下面已经能直接看到：

```text
API1返回值比较结果
API1的业务Check结果
```

API2也是一样。

最终只需要由这些项目汇总出：

```text
Batch总结果
```

因此最简单的层次就是：

```text
Batch
├── API1
│   ├── 返回值比较
│   └── 业务Check
├── API2
│   ├── 返回值比较
│   └── 业务Check
└── API间业务Check
```

只有以后确实需要“单独判断STEP-001整体成功还是失败”时，才增加Step Result。现在不必提前加入。

# 四、API返回值比较和业务Check的区别

## API返回值比较

表示对API整体Response进行的共通验证，例如：

```text
HTTP返回是否正常
Response是否取得
JSON是否解析成功
返回项目是否齐全
类型是否正确
固定项目是否正确
整体Response验证是否成功
```

结果：

```json
{
  "responseComparison": {
    "previousResult": "PASS",
    "currentResult": "PASS",
    "expectedResult": "PASS",
    "verificationResult": "PASS"
  }
}
```

完整Request／Response本体不塞进结果摘要，而是通过文件引用保存：

```json
{
  "requestRef": "steps/STEP-001/request.json",
  "responseRef": "steps/STEP-001/response.json"
}
```

## API结果的业务Check

表示针对该API结果执行的Java业务验证：

```text
memberStatus是否符合当前业务状态
返回记录件数是否符合业务条件
金额是否满足业务规则
返回状态和输入状态是否一致
```

Expected只需要：

```text
PASS
```

Java内部具体判断什么，不需要在Expected JSON中重复定义。

## API1与API2之间的业务Check

表示跨API关系：

```text
API2的memberId是否与API1一致
API2的更新后状态是否符合API1的更新前状态
API2金额是否与API1取得的余额满足业务关系
```

统一放到：

```json
{
  "crossApiChecks": []
}
```

# 五、Expected JSON也按相同顺序

```json
{
  "batchResult": "PASS",

  "apiSteps": {
    "STEP-001": {
      "responseComparison": "PASS",
      "checks": {
        "memberStatus": "PASS",
        "requiredItems": "PASS"
      }
    },

    "STEP-002": {
      "responseComparison": "PASS",
      "checks": {
        "updateResult": "PASS"
      }
    }
  },

  "crossApiChecks": {
    "memberInformationConsistency": "PASS"
  }
}
```

这个Expected文件已经足够。

客户看到的是：

```text
整个Batch期待PASS
API1返回值检查期待PASS
API1的memberStatus检查期待PASS
API2返回值检查期待PASS
API2的updateResult检查期待PASS
API1与API2整合检查期待PASS
```

不需要看到：

```text
ACTIVE
SUSPENDED
余额不能小于0
具体公式
Java类名
ruleId
validatorRef
```

# 六、最终汇总规则

Batch的`currentResult`由所有必要项目汇总：

```text
API1返回值比较
＋
API1业务Check
＋
API2返回值比较
＋
API2业务Check
＋
API1与API2业务Check
```

例如：

|项目|今回结果|
|---|---|
|API1返回值比较|PASS|
|API1 memberStatus Check|PASS|
|API2返回值比较|PASS|
|API2 updateResult Check|FAIL|
|API1与API2整合Check|PASS|

那么：

```text
Batch Current Result = FAIL
Batch Expected Result = PASS
Batch Verification Result = FAIL
```

前回是PASS时：

```text
Previous Result = PASS
Current Result  = FAIL
Changed         = true
```

# 七、最终固定结构

建议按下面结构冻结：

```text
Batch Result
│
├── API STEP-001
│   ├── Response Comparison
│   └── Business Checks
│
├── API STEP-002
│   ├── Response Comparison
│   └── Business Checks
│
├── API STEP-003
│   ├── Response Comparison
│   └── Business Checks
│
└── Cross API Checks
```

其中：

```text
执行顺序：
API1 → API1比较 → API1 Check
→ API2 → API2比较 → API2 Check
→ API间Check → Batch汇总

结果显示顺序：
Batch总结果
→ API1比较及Check
→ API2比较及Check
→ API间Check
```

这次你指出的是正确的：**Batch结果是最终汇总结果，不应该和API Step、API Execution、Scenario Check拆成很多重复层级。**

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次没有新增文件正文。

修正内容：

1. 删除不必要的独立API Execution层。
2. 暂不设置重复的Step汇总结果。
3. 每个API Step只包含返回值比较和业务Check。
4. 跨API比较统一放在Cross API Checks。
5. Batch Result作为所有API比较和业务Check的最终汇总。
6. 区分实际执行顺序与结果文件显示顺序。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需按此次最终顺序重写】
```

## 第 118 轮

### 你

但是你这样不也是把api1和api2的逻辑check和代码位置不一致了  是不是需要同步出，不需要归纳到哪一个api里

### ChatGPT

对。**结果明细应该按Java代码实际执行顺序同步输出**，而不是为了报告好看，事后强行把Check归类到某个API下面。尤其跨API Check本来就不属于API1或API2。

### ChatGPT

对。**不应该把所有Check事后归纳到API1或API2下面。**

正确方式是：

> Java代码执行到哪里，就在那里生成一条结果；结果文件按照实际执行顺序排列。

跨API业务Check只记录它关联了哪些API，不强行隶属于某个API。

# 一、正确的执行与输出顺序

Java代码执行顺序：

```text
1. 调用API1
2. API1返回值验证
3. API1相关业务Check
4. 调用API2
5. API2返回值验证
6. API2相关业务Check
7. API1与API2之间的业务Check
8. 汇总Batch结果
```

结果明细也按照同样顺序输出：

```text
API1返回值验证结果
API1业务Check结果
API2返回值验证结果
API2业务Check结果
API1与API2业务Check结果
```

Batch总结果虽然最后计算，但可以作为摘要放在文件最上面。

---

# 二、结果不要再嵌套到API下面

不建议：

```json
{
  "apiSteps": [
    {
      "stepId": "STEP-001",
      "checks": []
    }
  ],
  "crossApiChecks": []
}
```

因为这样会人为改变Java代码本来的执行结构。

推荐改成一个平铺、有顺序的结果数组：

```json
{
  "batchResult": {
    "previousResult": "PASS",
    "currentResult": "FAIL",
    "expectedResult": "PASS",
    "changed": true,
    "matched": false,
    "verificationResult": "FAIL"
  },

  "executionResults": [
    {
      "sequence": 1,
      "key": "API1_RESPONSE",
      "name": "API1返却結果チェック",
      "type": "API_RESPONSE",

      "relatedSteps": [
        "STEP-001"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },

    {
      "sequence": 2,
      "key": "API1_MEMBER_STATUS",
      "name": "会員状態業務チェック",
      "type": "BUSINESS_CHECK",

      "relatedSteps": [
        "STEP-001"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },

    {
      "sequence": 3,
      "key": "API2_RESPONSE",
      "name": "API2返却結果チェック",
      "type": "API_RESPONSE",

      "relatedSteps": [
        "STEP-002"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },

    {
      "sequence": 4,
      "key": "API2_UPDATE_RESULT",
      "name": "更新結果業務チェック",
      "type": "BUSINESS_CHECK",

      "relatedSteps": [
        "STEP-002"
      ],

      "previousResult": "PASS",
      "currentResult": "FAIL",
      "expectedResult": "PASS",

      "changed": true,
      "matched": false,
      "verificationResult": "FAIL"
    },

    {
      "sequence": 5,
      "key": "API1_API2_MEMBER_CONSISTENCY",
      "name": "API間会員情報整合性チェック",
      "type": "BUSINESS_CHECK",

      "relatedSteps": [
        "STEP-001",
        "STEP-002"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    }
  ]
}
```

这样：

```text
API1相关Check
    relatedSteps = [STEP-001]

API2相关Check
    relatedSteps = [STEP-002]

API1与API2之间的Check
    relatedSteps = [STEP-001, STEP-002]
```

跨API Check没有归入API2，只是因为它在API2执行完成后才具备验证条件，所以出现在API2后面。

---

# 三、Java代码也按照这个顺序写入结果

例如：

```java
public ScenarioResult execute(ScenarioContext context) {

    ResultCollector results = new ResultCollector();

    ApiResult api1 = callApi1(context);
    saveApiSnapshot("STEP-001", api1);

    results.add(
        checkApi1Response(api1)
    );

    results.add(
        checkMemberStatus(api1)
    );

    ApiResult api2 = callApi2(context, api1);
    saveApiSnapshot("STEP-002", api2);

    results.add(
        checkApi2Response(api2)
    );

    results.add(
        checkUpdateResult(api2)
    );

    results.add(
        checkMemberConsistency(api1, api2)
    );

    return results.buildBatchResult();
}
```

`ResultCollector.add()`每调用一次，就追加一条结果：

```text
第一次add  → sequence 1
第二次add  → sequence 2
第三次add  → sequence 3
```

因此结果顺序与Java代码位置天然一致。

不需要运行结束后再执行：

```text
把Check重新分类
重新归纳到API1
重新归纳到API2
重新移动跨API Check
```

---

# 四、Expected文件也使用平铺结构

Expected也不需要嵌套成很多层。

可以直接按结果Key对应：

```json
{
  "batchExpectedResult": "PASS",

  "expectedResults": {
    "API1_RESPONSE": "PASS",
    "API1_MEMBER_STATUS": "PASS",
    "API2_RESPONSE": "PASS",
    "API2_UPDATE_RESULT": "PASS",
    "API1_API2_MEMBER_CONSISTENCY": "PASS"
  }
}
```

Java执行某个Check时，用同一个`key`取得期待结果：

```java
ExpectedResult expected =
    expectedContext.get(
        "API1_API2_MEMBER_CONSISTENCY"
    );
```

这样对应关系非常直接：

```text
Java结果Key
    ↓
Expected中的同名Key
    ↓
Previous中的同名Key
```

例如：

```text
API1_API2_MEMBER_CONSISTENCY
```

能够同时定位：

```text
前回结果
今回结果
期待结果
```

---

# 五、为什么仍然需要稳定Key

这里的`key`不是复杂的规则ID。

它只解决：

```text
这条Java结果是谁？
去Expected中的哪里取期待结果？
去Previous中找哪一条历史结果？
Report中如何对应同一条验证？
```

例如：

```text
API1_MEMBER_STATUS
API2_UPDATE_RESULT
API1_API2_MEMBER_CONSISTENCY
```

它相当于结果项目名称。

Java方法名可以修改，但这个Key一旦用于Expected和Baseline，原则上就不能随意修改。

显示名称可以调整：

```json
{
  "key": "API1_API2_MEMBER_CONSISTENCY",
  "name": "API間会員情報整合性チェック"
}
```

---

# 六、Input仍然按照API Step读取

Input JSON和Expected JSON依然不同。

Input需要告诉Java每次API调用使用什么输入，所以适合按Step组织：

```json
{
  "batch": {
    "useCaseId": "UC-E6-001",
    "scenarioId": "SC-001"
  },

  "steps": {
    "STEP-001": {
      "request": {
        "memberId": "M000001"
      }
    },

    "STEP-002": {
      "request": {
        "updateType": "NORMAL"
      }
    }
  }
}
```

因为Java代码明确执行：

```java
input.getStep("STEP-001");
input.getStep("STEP-002");
```

Expected则按结果Key读取：

```json
{
  "batchExpectedResult": "PASS",

  "expectedResults": {
    "API1_RESPONSE": "PASS",
    "API1_MEMBER_STATUS": "PASS",
    "API2_RESPONSE": "PASS",
    "API2_UPDATE_RESULT": "PASS",
    "API1_API2_MEMBER_CONSISTENCY": "PASS"
  }
}
```

两者定位方式不同：

```text
Input
    按Step定位执行数据

Expected
    按结果Key定位期待结果
```

---

# 七、Snapshot、Diff、Report也维持相同顺序

## Current Result

按Java实际输出顺序：

```text
sequence 1
sequence 2
sequence 3
sequence 4
sequence 5
```

## Baseline Diff

按照相同Key寻找Previous：

```json
{
  "key": "API2_UPDATE_RESULT",
  "previousResult": "PASS",
  "currentResult": "FAIL",
  "changed": true
}
```

## Expected Diff

按照相同Key寻找Expected：

```json
{
  "key": "API2_UPDATE_RESULT",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "matched": false,
  "verificationResult": "FAIL"
}
```

## Report

按照`sequence`显示：

|顺序|结果项目|关联处理|前回|今回|期待|验证结果|
|---:|---|---|---|---|---|---|
|1|API1返却結果チェック|STEP-001|PASS|PASS|PASS|PASS|
|2|会員状態業務チェック|STEP-001|PASS|PASS|PASS|PASS|
|3|API2返却結果チェック|STEP-002|PASS|PASS|PASS|PASS|
|4|更新結果業務チェック|STEP-002|PASS|FAIL|PASS|FAIL|
|5|API間会員情報整合性チェック|STEP-001、STEP-002|PASS|PASS|PASS|PASS|

---

# 八、最终确定

结果模型应调整为：

```text
Batch摘要
+
按Java实际执行顺序排列的Execution Results
```

每一条结果只记录：

```text
sequence
key
name
type
relatedSteps
previousResult
currentResult
expectedResult
changed
matched
verificationResult
details（可选）
```

不再强制分成：

```text
API1 Checks
API2 Checks
Cross API Checks
```

`relatedSteps`只表示它和哪些API有关，不改变结果在代码中的实际位置。

这可以保证：

```text
Java执行顺序
=
Current Result顺序
=
Diff顺序
=
Report明细顺序
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更文件

本次未新增文件正文。

本次修正内容：

```text
1. 结果明细不再按API强制归类。
2. 结果按照Java实际执行位置依次输出。
3. 跨API Check不归属于API1或API2。
4. relatedSteps只记录关联API，不改变输出位置。
5. Expected按照稳定结果Key定位。
6. Input仍按照Step定位API调用数据。
7. Current、Diff、Report采用同一结果顺序。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需要按顺序型Execution Result模型重写】
```

## 第 119 轮

### 你

所以你在产出执行信息的时候是不是，如何定位呢比较的key呢

### ChatGPT

关键点是：**比较用的Key必须由Java在产出结果时明确给出，不能靠数组顺序、方法名或报告位置推断。** `sequence`只负责显示顺序，`resultKey`负责定位Previous和Expected。

### ChatGPT

对。**在Java产出执行信息的那一刻，就必须同时给出一个稳定的`resultKey`。**

这个Key负责定位：

```text
本次Java执行结果
↔ 前回Baseline中的同一项结果
↔ Expected文件中的同一项期待结果
```

不能用下面这些定位：

```text
数组第几个
Java方法执行顺序
类名
方法名
报告中的显示名称
```

因为这些都可能变化。

---

# 一、最小定位规则

一个结果的完整定位建议是：

```text
UseCaseId + ScenarioId + ResultKey
```

例如：

```text
UC-E6-001
SC-001
API1_MEMBER_STATUS
```

完整身份：

```text
UC-E6-001 / SC-001 / API1_MEMBER_STATUS
```

由于一个Expected文件本身已经属于某个UseCase和Scenario，文件内部只需要：

```text
API1_MEMBER_STATUS
```

---

# 二、Java产出结果时明确指定Key

例如Scenario Java：

```java
private static final String API1_RESPONSE =
        "API1_RESPONSE";

private static final String API1_MEMBER_STATUS =
        "API1_MEMBER_STATUS";

private static final String API2_RESPONSE =
        "API2_RESPONSE";

private static final String API2_UPDATE_RESULT =
        "API2_UPDATE_RESULT";

private static final String API1_API2_CONSISTENCY =
        "API1_API2_CONSISTENCY";
```

执行代码：

```java
Api1Response api1Response = callApi1(input);

results.add(
    API1_RESPONSE,
    checkApi1Response(api1Response)
);

results.add(
    API1_MEMBER_STATUS,
    checkMemberStatus(api1Response)
);

Api2Response api2Response =
        callApi2(input, api1Response);

results.add(
    API2_RESPONSE,
    checkApi2Response(api2Response)
);

results.add(
    API2_UPDATE_RESULT,
    checkUpdateResult(api2Response)
);

results.add(
    API1_API2_CONSISTENCY,
    checkApiConsistency(
        api1Response,
        api2Response
    )
);
```

这里每次调用：

```java
results.add(resultKey, checkResult);
```

Framework就知道当前结果是谁。

---

# 三、Expected按照同一个Key定义

```json
{
  "batchExpectedResult": "PASS",

  "expectedResults": {
    "API1_RESPONSE": "PASS",
    "API1_MEMBER_STATUS": "PASS",
    "API2_RESPONSE": "PASS",
    "API2_UPDATE_RESULT": "PASS",
    "API1_API2_CONSISTENCY": "PASS"
  }
}
```

Java执行到：

```java
results.add(
    "API1_MEMBER_STATUS",
    checkMemberStatus(api1Response)
);
```

Framework自动查找：

```text
expectedResults.API1_MEMBER_STATUS
```

得到：

```text
PASS
```

不需要Java业务代码自己查Expected。

---

# 四、Previous也按照相同Key保存

前回结果：

```json
{
  "results": {
    "API1_RESPONSE": {
      "currentResult": "PASS"
    },
    "API1_MEMBER_STATUS": {
      "currentResult": "PASS"
    },
    "API2_RESPONSE": {
      "currentResult": "PASS"
    },
    "API2_UPDATE_RESULT": {
      "currentResult": "PASS"
    },
    "API1_API2_CONSISTENCY": {
      "currentResult": "PASS"
    }
  }
}
```

本次Java产生：

```json
{
  "key": "API2_UPDATE_RESULT",
  "currentResult": "FAIL"
}
```

Framework通过Key找到：

```text
Previous = PASS
Current  = FAIL
Expected = PASS
```

然后生成：

```json
{
  "key": "API2_UPDATE_RESULT",
  "previousResult": "PASS",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "changed": true,
  "matched": false,
  "verificationResult": "FAIL"
}
```

---

# 五、`sequence`和`resultKey`职责不同

结果可以这样输出：

```json
{
  "sequence": 4,
  "resultKey": "API2_UPDATE_RESULT",
  "resultName": "更新結果業務チェック",
  "currentResult": "FAIL"
}
```

其中：

```text
sequence
    本次Java代码中的输出顺序
    仅用于Report排序

resultKey
    Previous、Current、Expected之间的稳定对应键

resultName
    客户看到的名称
    可以修改，不用于定位
```

例如报告名称从：

```text
更新結果業務チェック
```

改成：

```text
会員情報更新結果確認
```

只要：

```text
resultKey = API2_UPDATE_RESULT
```

不变，Expected和Baseline就不会受到影响。

---

# 六、跨API Check如何定位

不需要把它归到API1或者API2。

Java：

```java
results.add(
    "API1_API2_CONSISTENCY",
    checkApiConsistency(
        api1Response,
        api2Response
    ),
    List.of("STEP-001", "STEP-002")
);
```

输出：

```json
{
  "sequence": 5,
  "resultKey": "API1_API2_CONSISTENCY",
  "resultName": "API間データ整合性チェック",
  "relatedSteps": [
    "STEP-001",
    "STEP-002"
  ],
  "previousResult": "PASS",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "changed": false,
  "matched": true,
  "verificationResult": "PASS"
}
```

`relatedSteps`只是说明它使用了哪些API结果。

真正定位仍然只看：

```text
API1_API2_CONSISTENCY
```

---

# 七、Batch总结果也有固定Key吗

Batch结果可以使用Framework保留Key：

```text
BATCH_RESULT
```

Expected：

```json
{
  "batchExpectedResult": "PASS"
}
```

或者统一到同一个Map中：

```json
{
  "expectedResults": {
    "BATCH_RESULT": "PASS",
    "API1_RESPONSE": "PASS",
    "API1_MEMBER_STATUS": "PASS",
    "API2_RESPONSE": "PASS",
    "API2_UPDATE_RESULT": "PASS",
    "API1_API2_CONSISTENCY": "PASS"
  }
}
```

但为了客户容易阅读，建议Batch单独放：

```json
{
  "batchExpectedResult": "PASS",
  "expectedResults": {
    "API1_RESPONSE": "PASS",
    "API1_MEMBER_STATUS": "PASS"
  }
}
```

内部Framework仍然可以把它当作：

```text
BATCH_RESULT
```

处理。

---

# 八、Key应该定义在哪里

不建议建立一个全系统巨大的Key Master。

推荐每个Scenario Java类维护自己的稳定Key：

```java
public class MemberUpdateScenario {

    private static final String API1_RESPONSE =
            "API1_RESPONSE";

    private static final String API1_MEMBER_STATUS =
            "API1_MEMBER_STATUS";

    private static final String API2_RESPONSE =
            "API2_RESPONSE";

    private static final String API2_UPDATE_RESULT =
            "API2_UPDATE_RESULT";

    private static final String API1_API2_CONSISTENCY =
            "API1_API2_CONSISTENCY";
}
```

或者单独一个Scenario内部类：

```java
final class ResultKeys {

    static final String API1_RESPONSE =
            "API1_RESPONSE";

    static final String API1_MEMBER_STATUS =
            "API1_MEMBER_STATUS";

    static final String API2_RESPONSE =
            "API2_RESPONSE";

    static final String API2_UPDATE_RESULT =
            "API2_UPDATE_RESULT";

    static final String API1_API2_CONSISTENCY =
            "API1_API2_CONSISTENCY";

    private ResultKeys() {
    }
}
```

这样Key和Scenario代码放在一起，最容易维护。

---

# 九、运行时的完整定位过程

```text
1. Batch启动
2. RunContext确定UseCaseId和ScenarioId
3. 加载该Scenario的Expected JSON
4. Java执行到某个比较位置
5. Java调用results.add(resultKey, checkResult)
6. Framework根据resultKey查Expected
7. Framework根据resultKey查Previous
8. 生成三方比较结果
9. sequence按add顺序自动生成
10. Report按照sequence显示
```

例如：

```text
当前Context：
UC-E6-001 / SC-001

Java产出Key：
API2_UPDATE_RESULT

Expected定位：
UC-E6-001/SC-001/expected.json
→ expectedResults.API2_UPDATE_RESULT

Previous定位：
UC-E6-001/SC-001/baseline.json
→ results.API2_UPDATE_RESULT
```

---

# 十、Key不存在时如何处理

## Java产生了Key，但Expected没有

假设Java产生：

```text
API2_UPDATE_RESULT
```

Expected里没有。

如果这套设计要求所有正式结果都必须有Expected，那么应该：

```text
Current Result = PASS
Expected Result = NOT_DEFINED
Verification Result = BLOCKED
```

输出：

```json
{
  "resultKey": "API2_UPDATE_RESULT",
  "currentResult": "PASS",
  "expectedResult": "NOT_DEFINED",
  "verificationResult": "BLOCKED",
  "message": "期待結果が定義されていません。"
}
```

按照你现在的设计，**正式产出的结果项目原则上都应该在Expected中存在**。

---

## Expected有Key，但Java没有产生

例如Expected定义：

```text
API1_MEMBER_STATUS
```

Java没有执行或忘记`results.add()`。

则：

```json
{
  "resultKey": "API1_MEMBER_STATUS",
  "currentResult": "NOT_PRODUCED",
  "expectedResult": "PASS",
  "verificationResult": "BLOCKED",
  "message": "Java実行結果が生成されていません。"
}
```

---

## Java重复产生相同Key

例如Scenario中调用了两次：

```java
results.add(
    "API1_MEMBER_STATUS",
    firstResult
);

results.add(
    "API1_MEMBER_STATUS",
    secondResult
);
```

Framework必须立即报错：

```text
DUPLICATE_RESULT_KEY
```

不能默默覆盖。

---

# 十一、循环数据怎么处理

例如API返回10万条数据。

不应该为每一条生成：

```text
MEMBER_STATUS_000001
MEMBER_STATUS_000002
MEMBER_STATUS_000003
```

推荐Java内部完成全部检查，只产出一个稳定结果：

```text
API1_MEMBER_STATUS
```

输出详细证据：

```json
{
  "resultKey": "API1_MEMBER_STATUS",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "verificationResult": "FAIL",
  "details": {
    "checkedCount": 100000,
    "violationCount": 3,
    "violations": [
      {
        "memberId": "M001",
        "actualStatus": "UNKNOWN"
      }
    ]
  }
}
```

只有确实要求每一条都与独立Expected对应时，才生成动态子Key。

当前系统不建议这样做。

---

# 十二、推荐的最终结果模型

```json
{
  "batchResult": {
    "resultKey": "BATCH_RESULT",
    "previousResult": "PASS",
    "currentResult": "FAIL",
    "expectedResult": "PASS",
    "changed": true,
    "matched": false,
    "verificationResult": "FAIL"
  },

  "executionResults": [
    {
      "sequence": 1,
      "resultKey": "API1_RESPONSE",
      "resultName": "API1返却結果チェック",
      "relatedSteps": [
        "STEP-001"
      ],
      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",
      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },
    {
      "sequence": 2,
      "resultKey": "API1_MEMBER_STATUS",
      "resultName": "会員状態チェック",
      "relatedSteps": [
        "STEP-001"
      ],
      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",
      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },
    {
      "sequence": 3,
      "resultKey": "API2_RESPONSE",
      "resultName": "API2返却結果チェック",
      "relatedSteps": [
        "STEP-002"
      ],
      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",
      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },
    {
      "sequence": 4,
      "resultKey": "API1_API2_CONSISTENCY",
      "resultName": "API間整合性チェック",
      "relatedSteps": [
        "STEP-001",
        "STEP-002"
      ],
      "previousResult": "PASS",
      "currentResult": "FAIL",
      "expectedResult": "PASS",
      "changed": true,
      "matched": false,
      "verificationResult": "FAIL"
    }
  ]
}
```

# 最终确定

比较定位的核心就是：

```text
UseCaseId
+
ScenarioId
+
ResultKey
```

其中：

```text
UseCaseId、ScenarioId
    由Batch RunContext提供

ResultKey
    在Java产出每一条执行结果时明确指定

sequence
    Framework根据实际add顺序自动生成

relatedSteps
    可选，仅说明关联哪些API

resultName
    可修改的客户显示名称
```

因此：

```text
Java执行位置
    决定sequence

Java显式传入的resultKey
    决定Previous／Expected定位

不是靠结果归类来定位
也不是靠数组顺序来定位
```

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更文件

本次没有新增文件正文。

本次确认：

```text
1. 比较定位主键为UseCaseId＋ScenarioId＋ResultKey。
2. ResultKey由Java产出结果时明确指定。
3. sequence只表示实际执行顺序。
4. Expected和Previous均按照ResultKey定位。
5. 重复ResultKey立即判定为Framework ERROR。
6. Expected存在但Java未产出时判定BLOCKED。
7. Java产出但Expected不存在时，正式结果原则上判定BLOCKED。
8. 跨API检查使用独立ResultKey，不归属于任何单一API。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入ResultKey定位规则】
```

## 第 120 轮

### 你

sequence有什么用  不都有key了吗

### ChatGPT

对，**在你现在的同步Java Batch设计里，`sequence`基本没有必要。**

`resultKey`已经解决了最重要的问题：

```text
定位前回结果
定位今回结果
定位期待结果
生成Diff
生成Report
```

只要结果按Java实际执行顺序追加到数组中，数组本身就已经保留顺序。

# 一、`sequence`和`resultKey`原本的区别

```text
resultKey
    用来确认“这是谁”

sequence
    用来表示“第几个执行”
```

例如：

```json
{
  "sequence": 2,
  "resultKey": "API1_MEMBER_STATUS"
}
```

但是你现在的Java代码是同步顺序执行：

```java
results.add(checkApi1Response());
results.add(checkMemberStatus());
results.add(checkApi2Response());
results.add(checkApi1Api2Consistency());
```

输出数组自然就是：

```json
[
  {
    "resultKey": "API1_RESPONSE"
  },
  {
    "resultKey": "API1_MEMBER_STATUS"
  },
  {
    "resultKey": "API2_RESPONSE"
  },
  {
    "resultKey": "API1_API2_CONSISTENCY"
  }
]
```

这已经能表示代码实际执行顺序，不需要再输出：

```json
"sequence": 1
```

# 二、最终只保留`resultKey`

推荐结果：

```json
{
  "batchResult": {
    "previousResult": "PASS",
    "currentResult": "FAIL",
    "expectedResult": "PASS",
    "changed": true,
    "matched": false,
    "verificationResult": "FAIL"
  },

  "executionResults": [
    {
      "resultKey": "API1_RESPONSE",
      "resultName": "API1返却結果チェック",
      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",
      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },
    {
      "resultKey": "API1_MEMBER_STATUS",
      "resultName": "会員状態チェック",
      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",
      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },
    {
      "resultKey": "API2_RESPONSE",
      "resultName": "API2返却結果チェック",
      "previousResult": "PASS",
      "currentResult": "FAIL",
      "expectedResult": "PASS",
      "changed": true,
      "matched": false,
      "verificationResult": "FAIL"
    },
    {
      "resultKey": "API1_API2_CONSISTENCY",
      "resultName": "API間整合性チェック",
      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",
      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    }
  ]
}
```

这里：

```text
数组顺序
    表示Java实际产出顺序

resultKey
    表示结果身份

resultName
    表示客户看到的名称
```

# 三、Expected和Previous都只按Key定位

Expected：

```json
{
  "batchExpectedResult": "PASS",

  "expectedResults": {
    "API1_RESPONSE": "PASS",
    "API1_MEMBER_STATUS": "PASS",
    "API2_RESPONSE": "PASS",
    "API1_API2_CONSISTENCY": "PASS"
  }
}
```

Previous：

```json
{
  "results": {
    "API1_RESPONSE": "PASS",
    "API1_MEMBER_STATUS": "PASS",
    "API2_RESPONSE": "PASS",
    "API1_API2_CONSISTENCY": "PASS"
  }
}
```

Current是数组，但Framework执行时可以同时建立索引：

```java
Map<String, ExecutionResult> currentResultIndex;
```

比较时：

```java
String key = currentResult.getResultKey();

String previous =
    previousResults.get(key);

String expected =
    expectedResults.get(key);
```

因此比较完全不依赖顺序。

# 四、数组顺序只用于报告展示

例如Java：

```java
collector.add(
    checkApi1Response(api1Response)
);

collector.add(
    checkMemberStatus(api1Response)
);

collector.add(
    checkApi2Response(api2Response)
);

collector.add(
    checkApiConsistency(api1Response, api2Response)
);
```

`collector`内部使用：

```java
List<ExecutionResult> results =
        new ArrayList<>();
```

`ArrayList`保持追加顺序，Jackson输出JSON时也按List顺序输出。

所以Report自然显示：

```text
API1 Response
API1 Member Status
API2 Response
API1与API2整合Check
```

不需要额外排序。

# 五、什么时候才需要`sequence`

只有这些情况才可能需要：

```text
多个Check并行执行
多个线程同时写结果
结果分散在多个文件后重新合并
需要恢复设计上的固定显示顺序
实际完成顺序和业务顺序不同
```

例如并行：

```text
Check A先启动，后完成
Check B后启动，先完成
```

这时数组追加顺序可能不稳定，才需要一个：

```text
displayOrder
```

但你的当前设计是：

```text
一个Scenario
一次Java Batch
按照业务顺序同步调用API和Check
```

所以不需要提前增加。

# 六、需要注意重复执行的情况

如果同一个Check只执行一次：

```text
API1_MEMBER_STATUS
```

直接使用稳定Key即可。

如果循环中同一个检查执行多次，例如针对3个会员：

```text
API1_MEMBER_STATUS
```

不能重复追加相同Key，否则Previous和Expected无法唯一定位。

这时有两种处理方式。

## 推荐：Java内部汇总为一个结果

```json
{
  "resultKey": "API1_MEMBER_STATUS",
  "currentResult": "FAIL",
  "details": {
    "checkedCount": 3,
    "failedCount": 1,
    "failedMembers": [
      "M003"
    ]
  }
}
```

## 确实需要逐件结果时

使用业务实例Key：

```text
API1_MEMBER_STATUS:M001
API1_MEMBER_STATUS:M002
API1_MEMBER_STATUS:M003
```

不过当前项目优先采用Java内部汇总，避免大量动态Key。

# 七、最终冻结建议

```text
1. 删除sequence。
2. executionResults使用List保持Java实际产出顺序。
3. resultKey负责Previous、Current、Expected定位。
4. resultName只负责报告显示。
5. Framework启动时检查resultKey不得重复。
6. Diff和Expected比较只使用resultKey，不依赖数组位置。
7. 当前同步Batch不设计displayOrder。
8. 将来真正出现并行执行时，再增加displayOrder或executionTime。
```

最小结果对象可以是：

```java
public record ExecutionResult(
        String resultKey,
        String resultName,
        String previousResult,
        String currentResult,
        String expectedResult,
        boolean changed,
        boolean matched,
        String verificationResult,
        Object details
) {
}
```

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次没有新增文件正文。

设计修正：

- 删除sequence字段。
- Java List的追加顺序作为执行与报告顺序。
- resultKey作为唯一比较和定位键。
- 只有未来出现并行或结果合并需求时，才考虑displayOrder。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需按无sequence的ResultKey模型重写】
```

## 第 121 轮

### 你

每一个业务check 就是一个函数  这个函数进去就是对应一个key， 里面处理完了就把这个key对应的结果写出来即可，不需要每一条都写，如果太复杂的逻辑，那么就归纳一个更大的逻辑key来给出结果即可，不会出现很多list很多期待key。多线程执行的 只需要总结为一个大逻辑即可

### ChatGPT

对，这个模型更简单，也更符合你现在的Java Batch实现思路。

核心就是：

> **一个业务Check函数，对应一个固定Result Key；函数内部完成所有处理，最后只输出这个Key的一条结果。**

复杂逻辑、循环处理、多线程处理，都封装在函数内部，不向外展开成大量Check Key。

# 一、最终最小模型

```text
一个Check函数
=
一个Result Key
=
一个Expected Result
=
一个Current Result
=
一个Previous Result
```

例如：

```java
CheckResult checkMemberStatus(...);
```

固定对应：

```text
MEMBER_STATUS_CHECK
```

输出一条：

```json
{
  "resultKey": "MEMBER_STATUS_CHECK",
  "previousResult": "PASS",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "changed": false,
  "matched": true,
  "verificationResult": "PASS"
}
```

不需要把函数内部验证的每一个字段都变成一个Key。

---

# 二、Result Key最好固定在Check函数里

不建议Scenario调用时到处手写：

```java
checkMemberStatus("MEMBER_STATUS_CHECK", ...);
```

更推荐Check函数自己固定Key：

```java
public CheckResult checkMemberStatus(
        Api1Response currentResponse,
        Api1Response previousResponse) {

    final String resultKey =
            "MEMBER_STATUS_CHECK";

    boolean passed =
            validateMemberStatus(currentResponse);

    return CheckResult.of(
            resultKey,
            passed ? PASS : FAIL
    );
}
```

这样：

```text
函数和Key固定对应
```

不会发生调用方传错Key的问题。

也可以用类常量：

```java
public final class MemberStatusCheck {

    public static final String RESULT_KEY =
            "MEMBER_STATUS_CHECK";

    public CheckResult execute(
            Api1Response previous,
            Api1Response current) {

        boolean passed =
                validate(current);

        return CheckResult.of(
                RESULT_KEY,
                passed ? PASS : FAIL
        );
    }
}
```

---

# 三、Scenario代码只负责按顺序调用

```java
public ScenarioResult execute(
        ScenarioContext context) {

    ResultCollector results =
            new ResultCollector();

    Api1Response api1 =
            callApi1(context.input());

    results.add(
        api1ResponseCheck.execute(
            context.previousApi1(),
            api1
        )
    );

    results.add(
        memberStatusCheck.execute(
            context.previousApi1(),
            api1
        )
    );

    Api2Response api2 =
            callApi2(context.input(), api1);

    results.add(
        api2ResponseCheck.execute(
            context.previousApi2(),
            api2
        )
    );

    results.add(
        updateResultCheck.execute(
            context.previousApi2(),
            api2
        )
    );

    results.add(
        apiConsistencyCheck.execute(
            context.previousScenarioData(),
            api1,
            api2
        )
    );

    return results.build();
}
```

输出顺序自然就是：

```text
API1返回结果Check
API1业务Check
API2返回结果Check
API2业务Check
API1与API2业务Check
```

不需要`sequence`。

---

# 四、复杂业务逻辑只输出一个大Key

例如某个月度业务检查内部包括：

```text
检查10万条数据
检查重复ID
检查业务日期
检查金额合计
检查状态关系
检查父子数据关系
```

不需要输出：

```text
MONTHLY_DUPLICATE_CHECK
MONTHLY_DATE_CHECK
MONTHLY_TOTAL_CHECK
MONTHLY_STATUS_CHECK
MONTHLY_RELATION_CHECK
```

可以统一成：

```text
MONTHLY_BUSINESS_CHECK
```

Java内部：

```java
public CheckResult execute(
        MonthlyData previous,
        MonthlyData current) {

    ValidationSummary summary =
            executeInternalChecks(current);

    boolean passed =
            summary.duplicateCount() == 0
            && summary.invalidDateCount() == 0
            && summary.amountMatched()
            && summary.statusValid()
            && summary.relationValid();

    return CheckResult.builder()
            .resultKey(
                "MONTHLY_BUSINESS_CHECK"
            )
            .currentResult(
                passed ? PASS : FAIL
            )
            .details(summary)
            .build();
}
```

对外只是一条结果：

```json
{
  "resultKey": "MONTHLY_BUSINESS_CHECK",
  "previousResult": "PASS",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "changed": true,
  "matched": false,
  "verificationResult": "FAIL",
  "details": {
    "checkedCount": 100000,
    "duplicateCount": 0,
    "invalidDateCount": 3,
    "amountMatched": true,
    "statusValid": true,
    "relationValid": true,
    "message": "业务日期检查发现3件不符合数据"
  }
}
```

`details`只是调查信息，不是独立Result Key。

---

# 五、多线程也只输出一个结果

例如一个Check内部将10万条数据分成10个线程：

```java
public CheckResult execute(
        LargeDataSet data) {

    List<PartitionResult> partitions =
            parallelExecutor.execute(data);

    AggregatedResult aggregated =
            aggregate(partitions);

    return CheckResult.builder()
            .resultKey(
                "LARGE_DATA_BUSINESS_CHECK"
            )
            .currentResult(
                aggregated.passed()
                    ? PASS
                    : FAIL
            )
            .details(
                aggregated.toDetails()
            )
            .build();
}
```

线程内部可能有：

```text
线程1：PASS
线程2：PASS
线程3：FAIL
线程4：PASS
```

但外部Expected不用出现4个Key。

只定义：

```json
{
  "LARGE_DATA_BUSINESS_CHECK": "PASS"
}
```

最终输出：

```json
{
  "resultKey": "LARGE_DATA_BUSINESS_CHECK",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "verificationResult": "FAIL",
  "details": {
    "threadCount": 4,
    "checkedCount": 100000,
    "failedPartitionCount": 1,
    "violationCount": 15
  }
}
```

所以：

> 多线程是函数内部实现方式，不应该影响Expected结构和结果Key数量。

---

# 六、Expected JSON因此会非常简单

```json
{
  "batchExpectedResult": "PASS",

  "expectedResults": {
    "API1_RESPONSE_CHECK": "PASS",
    "MEMBER_STATUS_CHECK": "PASS",
    "API2_RESPONSE_CHECK": "PASS",
    "UPDATE_RESULT_CHECK": "PASS",
    "API1_API2_CONSISTENCY_CHECK": "PASS",
    "MONTHLY_BUSINESS_CHECK": "PASS"
  }
}
```

它只回答：

```text
这个Check期待得到什么结果
```

不描述：

```text
Check内部验证了几个字段
内部用了几个线程
状态允许哪些值
金额如何计算
哪一个Java方法实现
每个子逻辑的Expected
```

---

# 七、Previous也只保存相同粒度

```json
{
  "batchResult": "PASS",

  "results": {
    "API1_RESPONSE_CHECK": "PASS",
    "MEMBER_STATUS_CHECK": "PASS",
    "API2_RESPONSE_CHECK": "PASS",
    "UPDATE_RESULT_CHECK": "PASS",
    "API1_API2_CONSISTENCY_CHECK": "PASS",
    "MONTHLY_BUSINESS_CHECK": "PASS"
  }
}
```

本次Java返回：

```json
{
  "resultKey": "MONTHLY_BUSINESS_CHECK",
  "currentResult": "FAIL"
}
```

框架通过Key得到：

```text
Previous = PASS
Current  = FAIL
Expected = PASS
```

生成：

```json
{
  "resultKey": "MONTHLY_BUSINESS_CHECK",
  "previousResult": "PASS",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "changed": true,
  "matched": false,
  "verificationResult": "FAIL"
}
```

---

# 八、API返回值比较也是一个函数一个Key

例如：

```java
api1ResponseCheck.execute(...);
```

固定Key：

```text
API1_RESPONSE_CHECK
```

它内部可以统一验证：

```text
HTTP状态
Response存在
JSON解析
必填项目
类型
长度
固定值
返回项目结构
```

如果这些内容本来就应作为一个“API1返回结果整体检查”给客户查看，那么只输出一个Key：

```json
{
  "resultKey": "API1_RESPONSE_CHECK",
  "previousResult": "PASS",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "verificationResult": "FAIL",
  "details": {
    "httpStatus": 200,
    "missingFields": [
      "memberName"
    ],
    "typeErrors": [],
    "fixedValueErrors": []
  }
}
```

不需要为每个字段产生一个Expected Key。

完整API Response仍保存在：

```text
request.json
response.json
```

---

# 九、Result Key的粒度由客户可理解的业务单位决定

拆分标准不是：

```text
一个if语句一个Key
一个字段一个Key
一个线程一个Key
一个数组元素一个Key
```

而是：

> **一个客户或承认者能够独立判断、独立说明的业务验证单位，一个Key。**

例如：

```text
API1返回结果检查
会员状态检查
API2返回结果检查
更新结果检查
API1与API2整合检查
月度业务整合检查
```

这已经足够。

如果一个复杂Check失败后，客户只需要知道：

```text
月度业务整合检查失败
```

那么就只需要：

```text
MONTHLY_BUSINESS_CHECK
```

更详细的失败位置写到`details`。

---

# 十、最终Java接口可以非常简单

```java
public interface BusinessCheck {

    CheckResult execute(
        CheckContext context
    );
}
```

每个实现固定一个Key：

```java
public final class MemberStatusCheck
        implements BusinessCheck {

    private static final String RESULT_KEY =
            "MEMBER_STATUS_CHECK";

    @Override
    public CheckResult execute(
            CheckContext context) {

        boolean passed =
                performBusinessValidation(
                    context
                );

        return CheckResult.builder()
                .resultKey(RESULT_KEY)
                .resultName(
                    "会員状態チェック"
                )
                .currentResult(
                    passed ? PASS : FAIL
                )
                .details(
                    createDetails(context)
                )
                .build();
    }
}
```

Framework在`results.add()`时自动补充：

```text
Previous Result
Expected Result
Changed
Matched
Verification Result
```

业务Check本身只需要返回：

```text
Result Key
Current Result
Details
```

---

# 十一、建议冻结的最小CheckResult

业务函数返回：

```java
public record CurrentCheckResult(
        String resultKey,
        String resultName,
        Result currentResult,
        Object details
) {
}
```

框架合并Previous和Expected后输出：

```java
public record VerificationResult(
        String resultKey,
        String resultName,
        Result previousResult,
        Result currentResult,
        Result expectedResult,
        boolean changed,
        boolean matched,
        Result verificationResult,
        Object details
) {
}
```

职责非常明确：

```text
业务Check：
只产生本次实际结果

Framework：
查Previous
查Expected
进行结果对应
生成最终结果
```

---

# 十二、最终确认

你的设计可以固定为：

```text
1. 每个业务Check函数对应一个固定Result Key。
2. Check函数内部完成全部业务验证。
3. Check函数只输出一条Current Result。
4. 复杂业务逻辑归纳为一个更大的业务Key。
5. 子检查只作为details，不生成独立Expected Key。
6. 循环数据不产生大量动态Key。
7. 多线程只作为函数内部实现，最终汇总为一个Key。
8. API返回结果验证同样可以归纳成一个Key。
9. Expected JSON只保存Result Key对应的Expected Result。
10. Previous、Current、Expected通过Result Key对应。
11. 不需要sequence。
12. 不需要大量List、子Result和子Expected定义。
```

最终执行结构就是：

```text
Java Check函数
    ↓
固定Result Key
    ↓
产生Current Result
    ↓
Framework按Key取得Previous和Expected
    ↓
输出一条最终Verification Result
```

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更文件

本次没有新增文件正文。

本次确认并简化：

```text
- 一个Check函数对应一个Result Key。
- 复杂逻辑、多线程、循环处理均在函数内部汇总。
- 每个Check只输出一条Current Result。
- 子检查只进入details，不产生大量Expected Key。
- Framework根据Result Key补充Previous和Expected。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需按一函数一Key、一Key一结果模型重写】
```

## 第 122 轮

### 你

保证usecase里的一个业务多个check 比如 字段一致  类型一致  数字大小判断 等等 分别就对应一个key，并且这个key需要在期待和生成2方都要有
给我一个整体的期待json格式  batch总结过 按顺序的api以及逻辑的结果

### ChatGPT

这次可以把格式直接收敛成一个镜像模型：**Expected文件按Java计划执行顺序列出Key；生成结果按实际执行顺序输出相同Key。Batch总结单独放在顶部。**

### ChatGPT

对。现在可以正式固定成：

> **UseCase中的每一个独立业务Check函数，对应一个稳定`resultKey`。Expected与Java生成结果双方都必须存在这个Key。**

字段一致、类型一致、数字范围判断分别是三个Check函数，因此分别对应三个Key；但不需要把每个字段继续拆成Key。

---

# 一、整体Expected JSON格式

下面按照Java Batch的实际处理顺序排列：

```json
{
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "expectedVersion": "1.0.0",

  "batch": {
    "resultKey": "BATCH_RESULT",
    "resultName": "バッチ総合結果",
    "expectedResult": "PASS"
  },

  "results": [
    {
      "resultKey": "API01_RESPONSE_CHECK",
      "resultName": "API1返却結果チェック",
      "relatedApiSteps": [
        "STEP-001"
      ],
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API01_FIELD_CONSISTENCY_CHECK",
      "resultName": "API1項目整合性チェック",
      "relatedApiSteps": [
        "STEP-001"
      ],
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API01_TYPE_CHECK",
      "resultName": "API1データ型チェック",
      "relatedApiSteps": [
        "STEP-001"
      ],
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API01_NUMERIC_RANGE_CHECK",
      "resultName": "API1数値範囲チェック",
      "relatedApiSteps": [
        "STEP-001"
      ],
      "expectedResult": "PASS"
    },

    {
      "resultKey": "API02_RESPONSE_CHECK",
      "resultName": "API2返却結果チェック",
      "relatedApiSteps": [
        "STEP-002"
      ],
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API02_FIELD_CONSISTENCY_CHECK",
      "resultName": "API2項目整合性チェック",
      "relatedApiSteps": [
        "STEP-002"
      ],
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API02_TYPE_CHECK",
      "resultName": "API2データ型チェック",
      "relatedApiSteps": [
        "STEP-002"
      ],
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API02_NUMERIC_RANGE_CHECK",
      "resultName": "API2数値範囲チェック",
      "relatedApiSteps": [
        "STEP-002"
      ],
      "expectedResult": "PASS"
    },

    {
      "resultKey": "API01_API02_BUSINESS_CONSISTENCY_CHECK",
      "resultName": "API1・API2業務整合性チェック",
      "relatedApiSteps": [
        "STEP-001",
        "STEP-002"
      ],
      "expectedResult": "PASS"
    }
  ]
}
```

这里没有：

```text
sequence
ruleId
validatorRef
允许值定义
字段级Expected
Java方法名称
比较公式
```

只有：

```text
resultKey
resultName
relatedApiSteps
expectedResult
```

---

# 二、为什么使用数组

`results`使用数组，是为了按照Java Batch的业务执行顺序表示：

```text
API1调用
↓
API1返回值Check
↓
API1字段一致Check
↓
API1类型Check
↓
API1数字范围Check
↓
API2调用
↓
API2返回值Check
↓
API2各项Check
↓
API1与API2之间的业务Check
```

不需要`sequence`，因为JSON数组本身已经保持顺序。

但比较时绝对不能依赖数组位置，必须使用：

```text
resultKey
```

也就是说：

```text
数组顺序：负责显示和执行顺序
resultKey：负责Expected、Previous、Current定位
```

---

# 三、Java Check函数与Key的对应

## API1返回结果检查

```java
public final class Api01ResponseCheck {

    public static final String RESULT_KEY =
            "API01_RESPONSE_CHECK";

    public CurrentCheckResult execute(
            Api01Response response) {

        boolean passed =
                checkResponse(response);

        return CurrentCheckResult.of(
                RESULT_KEY,
                "API1返却結果チェック",
                passed ? PASS : FAIL
        );
    }
}
```

## API1字段一致检查

```java
public final class Api01FieldConsistencyCheck {

    public static final String RESULT_KEY =
            "API01_FIELD_CONSISTENCY_CHECK";

    public CurrentCheckResult execute(
            Api01Response response) {

        FieldCheckSummary summary =
                checkFields(response);

        return CurrentCheckResult.builder()
                .resultKey(RESULT_KEY)
                .resultName(
                    "API1項目整合性チェック"
                )
                .currentResult(
                    summary.passed()
                        ? PASS
                        : FAIL
                )
                .details(summary)
                .build();
    }
}
```

## API1类型检查

```java
public final class Api01TypeCheck {

    public static final String RESULT_KEY =
            "API01_TYPE_CHECK";

    public CurrentCheckResult execute(
            Api01Response response) {

        TypeCheckSummary summary =
                checkTypes(response);

        return CurrentCheckResult.builder()
                .resultKey(RESULT_KEY)
                .resultName(
                    "API1データ型チェック"
                )
                .currentResult(
                    summary.passed()
                        ? PASS
                        : FAIL
                )
                .details(summary)
                .build();
    }
}
```

## API1数字范围检查

```java
public final class Api01NumericRangeCheck {

    public static final String RESULT_KEY =
            "API01_NUMERIC_RANGE_CHECK";

    public CurrentCheckResult execute(
            Api01Response response) {

        NumericCheckSummary summary =
                checkNumericRanges(response);

        return CurrentCheckResult.builder()
                .resultKey(RESULT_KEY)
                .resultName(
                    "API1数値範囲チェック"
                )
                .currentResult(
                    summary.passed()
                        ? PASS
                        : FAIL
                )
                .details(summary)
                .build();
    }
}
```

所以粒度是：

```text
字段一致Check函数
    一个Key

类型一致Check函数
    一个Key

数字范围Check函数
    一个Key
```

不是：

```text
字段A一个Key
字段B一个Key
字段C一个Key
```

字段级结果放进`details`。

---

# 四、Java Batch调用顺序

```java
public ScenarioCurrentResult execute(
        ScenarioContext context) {

    ResultCollector collector =
            new ResultCollector(
                context.expectedResults()
            );

    Api01Response api01 =
            callApi01(
                context.input()
                    .getStep("STEP-001")
            );

    collector.add(
        api01ResponseCheck.execute(api01)
    );

    collector.add(
        api01FieldConsistencyCheck.execute(
            api01
        )
    );

    collector.add(
        api01TypeCheck.execute(api01)
    );

    collector.add(
        api01NumericRangeCheck.execute(
            api01
        )
    );

    Api02Response api02 =
            callApi02(
                context.input()
                    .getStep("STEP-002"),
                api01
            );

    collector.add(
        api02ResponseCheck.execute(api02)
    );

    collector.add(
        api02FieldConsistencyCheck.execute(
            api02
        )
    );

    collector.add(
        api02TypeCheck.execute(api02)
    );

    collector.add(
        api02NumericRangeCheck.execute(
            api02
        )
    );

    collector.add(
        api01Api02BusinessConsistencyCheck
            .execute(api01, api02)
    );

    return collector.build();
}
```

Java代码顺序、生成结果顺序和Report显示顺序完全相同。

---

# 五、Batch执行后生成的结果JSON

```json
{
  "runId": "RUN-20260724-001",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",

  "batch": {
    "resultKey": "BATCH_RESULT",
    "resultName": "バッチ総合結果",

    "previousResult": "PASS",
    "currentResult": "FAIL",
    "expectedResult": "PASS",

    "changed": true,
    "matched": false,
    "verificationResult": "FAIL"
  },

  "results": [
    {
      "resultKey": "API01_RESPONSE_CHECK",
      "resultName": "API1返却結果チェック",
      "relatedApiSteps": [
        "STEP-001"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "details": {
        "requestRef": "steps/STEP-001/request.json",
        "responseRef": "steps/STEP-001/response.json",
        "httpStatus": 200,
        "responseParsed": true
      }
    },
    {
      "resultKey": "API01_FIELD_CONSISTENCY_CHECK",
      "resultName": "API1項目整合性チェック",
      "relatedApiSteps": [
        "STEP-001"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "details": {
        "checkedFieldCount": 18,
        "missingFieldCount": 0,
        "unexpectedFieldCount": 0,
        "differenceCount": 0
      }
    },
    {
      "resultKey": "API01_TYPE_CHECK",
      "resultName": "API1データ型チェック",
      "relatedApiSteps": [
        "STEP-001"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "details": {
        "checkedFieldCount": 18,
        "typeErrorCount": 0
      }
    },
    {
      "resultKey": "API01_NUMERIC_RANGE_CHECK",
      "resultName": "API1数値範囲チェック",
      "relatedApiSteps": [
        "STEP-001"
      ],

      "previousResult": "PASS",
      "currentResult": "FAIL",
      "expectedResult": "PASS",

      "changed": true,
      "matched": false,
      "verificationResult": "FAIL",

      "details": {
        "checkedFieldCount": 4,
        "violationCount": 1,
        "violations": [
          {
            "field": "balance",
            "actualValue": -100,
            "message": "許容範囲外の値です。"
          }
        ]
      }
    },

    {
      "resultKey": "API02_RESPONSE_CHECK",
      "resultName": "API2返却結果チェック",
      "relatedApiSteps": [
        "STEP-002"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "details": {
        "requestRef": "steps/STEP-002/request.json",
        "responseRef": "steps/STEP-002/response.json",
        "httpStatus": 200,
        "responseParsed": true
      }
    },
    {
      "resultKey": "API02_FIELD_CONSISTENCY_CHECK",
      "resultName": "API2項目整合性チェック",
      "relatedApiSteps": [
        "STEP-002"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "details": {
        "checkedFieldCount": 12,
        "differenceCount": 0
      }
    },
    {
      "resultKey": "API02_TYPE_CHECK",
      "resultName": "API2データ型チェック",
      "relatedApiSteps": [
        "STEP-002"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "details": {
        "checkedFieldCount": 12,
        "typeErrorCount": 0
      }
    },
    {
      "resultKey": "API02_NUMERIC_RANGE_CHECK",
      "resultName": "API2数値範囲チェック",
      "relatedApiSteps": [
        "STEP-002"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "details": {
        "checkedFieldCount": 3,
        "violationCount": 0
      }
    },

    {
      "resultKey": "API01_API02_BUSINESS_CONSISTENCY_CHECK",
      "resultName": "API1・API2業務整合性チェック",
      "relatedApiSteps": [
        "STEP-001",
        "STEP-002"
      ],

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "details": {
        "checkedBusinessItemCount": 5,
        "violationCount": 0,
        "message": "API間の業務整合性が成立しています。"
      }
    }
  ]
}
```

---

# 六、Expected与生成结果的对应

|Expected中的Key|Java函数|生成结果中的Key|
|---|---|---|
|`API01_RESPONSE_CHECK`|`api01ResponseCheck.execute()`|`API01_RESPONSE_CHECK`|
|`API01_FIELD_CONSISTENCY_CHECK`|`api01FieldConsistencyCheck.execute()`|`API01_FIELD_CONSISTENCY_CHECK`|
|`API01_TYPE_CHECK`|`api01TypeCheck.execute()`|`API01_TYPE_CHECK`|
|`API01_NUMERIC_RANGE_CHECK`|`api01NumericRangeCheck.execute()`|`API01_NUMERIC_RANGE_CHECK`|
|`API02_RESPONSE_CHECK`|`api02ResponseCheck.execute()`|`API02_RESPONSE_CHECK`|
|`API01_API02_BUSINESS_CONSISTENCY_CHECK`|`api01Api02BusinessConsistencyCheck.execute()`|同一Key|

完整定位键是：

```text
UseCaseId
+
ScenarioId
+
ResultKey
```

例如：

```text
UC-E6-001
/
SC-001
/
API01_TYPE_CHECK
```

---

# 七、双方Key必须完全一致

运行前后必须执行Key整合检查。

## Java生成了Key，但Expected不存在

```text
Java：
API01_TYPE_CHECK

Expected：
不存在
```

结果：

```json
{
  "resultKey": "API01_TYPE_CHECK",
  "currentResult": "PASS",
  "expectedResult": "NOT_DEFINED",
  "verificationResult": "BLOCKED",
  "message": "期待結果が定義されていません。"
}
```

## Expected定义了Key，但Java没有生成

```text
Expected：
API02_TYPE_CHECK

Java：
没有执行
```

结果：

```json
{
  "resultKey": "API02_TYPE_CHECK",
  "currentResult": "NOT_PRODUCED",
  "expectedResult": "PASS",
  "verificationResult": "BLOCKED",
  "message": "実行結果が生成されていません。"
}
```

## Java生成重复Key

立即判定：

```text
FRAMEWORK_ERROR
DUPLICATE_RESULT_KEY
```

不得覆盖前一条结果。

---

# 八、Batch总结规则

Batch结果由所有Key的`verificationResult`汇总。

例如：

|Result Key|Verification Result|
|---|---|
|API01_RESPONSE_CHECK|PASS|
|API01_FIELD_CONSISTENCY_CHECK|PASS|
|API01_TYPE_CHECK|PASS|
|API01_NUMERIC_RANGE_CHECK|FAIL|
|API02_RESPONSE_CHECK|PASS|
|API02_FIELD_CONSISTENCY_CHECK|PASS|
|API02_TYPE_CHECK|PASS|
|API02_NUMERIC_RANGE_CHECK|PASS|
|API01_API02_BUSINESS_CONSISTENCY_CHECK|PASS|

因此：

```text
Batch Current Result = FAIL
Batch Expected Result = PASS
Batch Verification Result = FAIL
```

只要一个必要Key没有满足Expected，Batch总结就是失败。

---

# 九、最终格式冻结候选

Expected文件：

```text
Batch Expected Result
+
按Java计划执行顺序排列的Expected Result Key
```

生成结果：

```text
Batch总结
+
按Java实际执行顺序排列的Result
```

每一个结果最少包含：

```json
{
  "resultKey": "API01_TYPE_CHECK",
  "resultName": "API1データ型チェック",
  "previousResult": "PASS",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "changed": false,
  "matched": true,
  "verificationResult": "PASS"
}
```

失败或需要调查时增加：

```json
{
  "details": {
    "checkedFieldCount": 18,
    "violationCount": 1,
    "violations": []
  }
}
```

这样可以保证：

```text
一个Check函数
=
一个Result Key
=
一个Expected项目
=
一个Current结果
=
一个Previous结果
=
Report中的一行
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更文件

本次未新增文件正文。

本次正式明确：

```text
1. 一个独立Check函数对应一个Result Key。
2. 字段一致、类型一致、数字范围分别对应独立Key。
3. 不拆成字段级Key。
4. Expected与Java生成结果双方必须拥有相同Key。
5. Expected和Generated Result都按Java业务顺序排列。
6. 不使用sequence。
7. Batch结果位于文件顶部。
8. Java执行结果、Expected和Previous通过Result Key对应。
9. Key缺失、重复或未生成均由Framework检出。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入Expected与Generated Result镜像格式】
```

## 第 123 轮

### 你

api调用需要按项目值详细表示是否有变化  ，api之后的会根据每个项目进行各种逻辑判断时候就不需要具体项目值了 。 所以还是有区别的 api本身调用  和   业务调用

### ChatGPT

对，这里必须明确分成两种结果类型：**API返回比较结果要保留字段级变化；业务Check只保留一个Key对应的综合判定。** 两者不能再用完全相同的明细结构。

### ChatGPT

对，必须区分。

你现在定义的是两种性质完全不同的结果：

```text
1. API本身的调用／返回比较
2. API之后执行的业务Check
```

它们都对应一个`resultKey`，但输出明细不同。

# 一、两种结果类型

## 1. API返回比较

API返回比较需要：

- 保存完整Request、Response；
- 按返回项目显示前回值和本次值；
- 显示字段是否新增、删除、变化；
- 显示变化数量；
- 最后归纳成该API返回比较的一个结果。

也就是：

```text
一个API返回比较Key
+
多个字段变化明细
```

字段明细不是独立Expected Key。

例如：

```json
{
  "resultKey": "API01_RESPONSE_COMPARE",
  "resultType": "API_RESPONSE_COMPARE",
  "currentResult": "PASS",
  "expectedResult": "PASS",

  "itemChanges": [
    {
      "path": "$.memberId",
      "previousValue": "M001",
      "currentValue": "M001",
      "changed": false
    },
    {
      "path": "$.memberStatus",
      "previousValue": "ACTIVE",
      "currentValue": "SUSPENDED",
      "changed": true
    },
    {
      "path": "$.balance",
      "previousValue": 1000,
      "currentValue": 700,
      "changed": true
    }
  ]
}
```

这里：

```text
API01_RESPONSE_COMPARE
```

是Expected与结果对应的Key。

而：

```text
$.memberId
$.memberStatus
$.balance
```

只是API返回字段的变化明细，不是Expected Key。

---

## 2. 业务Check

业务Check内部可能检查很多字段、很多条件，也可能跨多个API。

但对外只输出：

```text
一个业务Check函数
=
一个Result Key
=
一个综合结果
```

例如：

```json
{
  "resultKey": "MEMBER_STATUS_BUSINESS_CHECK",
  "resultType": "BUSINESS_CHECK",

  "previousResult": "PASS",
  "currentResult": "PASS",
  "expectedResult": "PASS",

  "changed": false,
  "matched": true,
  "verificationResult": "PASS"
}
```

不必再打印：

```text
memberStatus前回值
memberStatus本次值
允许状态值
状态转换公式
```

这些都是Java函数内部的业务逻辑。

失败时可以输出简单调查信息：

```json
{
  "resultKey": "MEMBER_STATUS_BUSINESS_CHECK",
  "resultType": "BUSINESS_CHECK",

  "previousResult": "PASS",
  "currentResult": "FAIL",
  "expectedResult": "PASS",

  "changed": true,
  "matched": false,
  "verificationResult": "FAIL",

  "details": {
    "message": "会員状態が業務条件を満たしていません。",
    "violationCount": 1
  }
}
```

# 二、Expected JSON整体格式

Expected只定义：

- Batch期待结果；
- API返回比较期待结果；
- 各业务Check期待结果；
- 按Java执行顺序排列；
- Expected和生成结果使用相同`resultKey`。

```json
{
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "expectedVersion": "1.0.0",

  "batch": {
    "resultKey": "BATCH_RESULT",
    "expectedResult": "PASS"
  },

  "results": [
    {
      "resultKey": "API01_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "resultName": "API1返却値比較",
      "apiStepKey": "STEP-001",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API01_FIELD_CONSISTENCY_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1項目整合性チェック",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API01_TYPE_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1データ型チェック",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API01_NUMERIC_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1数値条件チェック",
      "expectedResult": "PASS"
    },

    {
      "resultKey": "API02_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "resultName": "API2返却値比較",
      "apiStepKey": "STEP-002",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API02_FIELD_CONSISTENCY_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API2項目整合性チェック",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API02_TYPE_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API2データ型チェック",
      "expectedResult": "PASS"
    },

    {
      "resultKey": "API01_API02_BUSINESS_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1・API2間業務整合性チェック",
      "expectedResult": "PASS"
    }
  ]
}
```

注意Expected中不保存API返回的详细字段值。

API字段的前回值、本次值和变化内容，是执行后生成的信息。

---

# 三、Batch执行后的完整结果格式

结果文件顶部放Batch总结，下面按Java实际执行顺序排列。

```json
{
  "runId": "RUN-20260724-001",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",

  "batch": {
    "resultKey": "BATCH_RESULT",

    "previousResult": "PASS",
    "currentResult": "FAIL",
    "expectedResult": "PASS",

    "changed": true,
    "matched": false,
    "verificationResult": "FAIL"
  },

  "results": [
    {
      "resultKey": "API01_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "resultName": "API1返却値比較",
      "apiStepKey": "STEP-001",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "requestRef": "steps/STEP-001/request.json",
      "responseRef": "steps/STEP-001/response.json",

      "changeSummary": {
        "checkedItemCount": 20,
        "unchangedCount": 17,
        "changedCount": 2,
        "addedCount": 1,
        "removedCount": 0
      },

      "itemChanges": [
        {
          "path": "$.memberId",
          "previousState": "PRESENT",
          "currentState": "PRESENT",
          "previousValue": "M001",
          "currentValue": "M001",
          "changeType": "UNCHANGED",
          "changed": false
        },
        {
          "path": "$.memberStatus",
          "previousState": "PRESENT",
          "currentState": "PRESENT",
          "previousValue": "ACTIVE",
          "currentValue": "SUSPENDED",
          "changeType": "VALUE_CHANGED",
          "changed": true
        },
        {
          "path": "$.balance",
          "previousState": "PRESENT",
          "currentState": "PRESENT",
          "previousValue": 1000,
          "currentValue": 700,
          "changeType": "VALUE_CHANGED",
          "changed": true
        },
        {
          "path": "$.newItem",
          "previousState": "MISSING",
          "currentState": "PRESENT",
          "currentValue": "A",
          "changeType": "ITEM_ADDED",
          "changed": true
        }
      ]
    },

    {
      "resultKey": "API01_FIELD_CONSISTENCY_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1項目整合性チェック",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },

    {
      "resultKey": "API01_TYPE_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1データ型チェック",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },

    {
      "resultKey": "API01_NUMERIC_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1数値条件チェック",

      "previousResult": "PASS",
      "currentResult": "FAIL",
      "expectedResult": "PASS",

      "changed": true,
      "matched": false,
      "verificationResult": "FAIL",

      "details": {
        "violationCount": 1,
        "message": "数値条件を満たさない項目があります。"
      }
    },

    {
      "resultKey": "API02_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "resultName": "API2返却値比較",
      "apiStepKey": "STEP-002",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "requestRef": "steps/STEP-002/request.json",
      "responseRef": "steps/STEP-002/response.json",

      "changeSummary": {
        "checkedItemCount": 12,
        "unchangedCount": 10,
        "changedCount": 2,
        "addedCount": 0,
        "removedCount": 0
      },

      "itemChanges": [
        {
          "path": "$.updateResult",
          "previousValue": "SUCCESS",
          "currentValue": "SUCCESS",
          "changeType": "UNCHANGED",
          "changed": false
        },
        {
          "path": "$.updatedAt",
          "previousValue": "2026-07-23T10:00:00+09:00",
          "currentValue": "2026-07-24T10:00:00+09:00",
          "changeType": "VALUE_CHANGED",
          "changed": true
        }
      ]
    },

    {
      "resultKey": "API02_FIELD_CONSISTENCY_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API2項目整合性チェック",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },

    {
      "resultKey": "API02_TYPE_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API2データ型チェック",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },

    {
      "resultKey": "API01_API02_BUSINESS_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1・API2間業務整合性チェック",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS",

      "details": {
        "message": "API間の業務整合性が成立しています。"
      }
    }
  ]
}
```

# 四、API返回比较中的“变化”和“成功”要分开

API字段发生变化，不一定代表失败。

例如：

```text
memberStatus:
Previous = ACTIVE
Current  = SUSPENDED
changed  = true
```

这只表示发生了变化。

API返回比较的Java函数可能判断：

```text
Response取得成功
结构正常
比较处理完成
```

因此：

```text
currentResult = PASS
```

随后业务Check再判断：

```text
ACTIVE → SUSPENDED是否符合业务条件
```

业务Check可能返回：

```text
currentResult = PASS
```

所以要区分：

```text
API_RESPONSE_COMPARE
    详细展示项目发生了什么变化

BUSINESS_CHECK
    判断这些值在业务上是否正确
```

不能因为字段发生变化，就直接把API返回比较判为FAIL。

---

# 五、Java实现也要分开

## API返回比较函数

```java
CurrentCheckResult compareApi01Response(
        Api01Response previous,
        Api01Response current) {

    ApiItemDiffSummary diff =
            apiResponseCompareService.compare(
                previous,
                current
            );

    return CurrentCheckResult.builder()
            .resultKey(
                "API01_RESPONSE_COMPARE"
            )
            .resultType(
                API_RESPONSE_COMPARE
            )
            .currentResult(PASS)
            .details(diff)
            .build();
}
```

它负责：

```text
遍历返回项目
记录Previous和Current
判断新增、删除、变化、未变化
生成itemChanges
```

## 业务Check函数

```java
CurrentCheckResult checkApi01NumericCondition(
        Api01Response response) {

    boolean passed =
            executeNumericBusinessLogic(
                response
            );

    return CurrentCheckResult.builder()
            .resultKey(
                "API01_NUMERIC_CHECK"
            )
            .resultType(
                BUSINESS_CHECK
            )
            .currentResult(
                passed ? PASS : FAIL
            )
            .build();
}
```

它只负责：

```text
业务上是否满足条件
```

不需要再次输出所有字段前回值和本次值。

---

# 六、Snapshot、Diff、Report也要分开表现

推荐运行输出：

```text
RUN-20260724-001/
├── input-used.json
├── expected-used.json
├── verification-result.json
│
├── steps/
│   ├── STEP-001/
│   │   ├── request.json
│   │   ├── response.json
│   │   └── response-diff.json
│   │
│   └── STEP-002/
│       ├── request.json
│       ├── response.json
│       └── response-diff.json
│
└── report.json
```

## `response-diff.json`

只用于API字段级变化：

```json
{
  "resultKey": "API01_RESPONSE_COMPARE",
  "itemChanges": []
}
```

## `verification-result.json`

包含：

```text
Batch总结
API返回比较结果
业务Check结果
跨API业务Check结果
```

## Report

API返回比较显示字段明细：

|字段|前回|今回|变化类型|
|---|---|---|---|
|memberId|M001|M001|无变化|
|memberStatus|ACTIVE|SUSPENDED|值变化|
|balance|1000|700|值变化|

业务Check只显示结果：

|业务Check|前回|今回|期待|验证|
|---|---|---|---|---|
|项目整合性Check|PASS|PASS|PASS|PASS|
|类型Check|PASS|PASS|PASS|PASS|
|数值条件Check|PASS|FAIL|PASS|FAIL|
|API间整合Check|PASS|PASS|PASS|PASS|

---

# 七、最终冻结候选

```text
API本身调用：
    一个API Response Compare Key
    保存字段级Previous／Current／Change
    保存完整Request／Response引用

API后的业务验证：
    一个函数对应一个Business Check Key
    只保存Previous Result／Current Result／Expected Result
    必要时保存简单details

跨API业务验证：
    一个函数对应一个Business Check Key
    不归属某一个单独API

Batch：
    汇总全部API Compare和Business Check结果
```

最关键的区别：

|类型|一个Key|字段级值明细|Expected内容|
|---|---:|---:|---|
|API返回比较|是|需要|Expected Result|
|API后业务Check|是|原则上不需要|Expected Result|
|跨API业务Check|是|原则上不需要|Expected Result|
|Batch总结|是|不需要|Expected Result|

所以最终不是一种统一结果强行处理全部内容，而是：

```text
统一Key定位
+
两种结果明细结构
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次未新增文件正文。

本次确认：

```text
1. API返回比较与业务Check采用不同明细结构。
2. API返回比较必须保留字段级Previous／Current／Change。
3. 字段变化明细不产生独立Expected Key。
4. API之后的业务Check只输出一个Key的综合结果。
5. 跨API业务Check同样只输出综合结果。
6. Expected仍然只按Result Key定义Expected Result。
7. Batch结果汇总两类结果。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入API返回比较与业务Check双结构模型】
```

## 第 124 轮

### 你

你说的对 那么每个字段的比较生产文件 和 主要的要分开。

### ChatGPT

对，应该正式拆成两类文件：

```text
主要验证结果文件
    面向客户、承认者查看Batch和各业务Check结论

API字段比较明细文件
    面向调查人员查看每个返回字段的前回值、今回值和变化内容
```

两者通过API返回比较的`resultKey`和文件引用关联。

# 1. 推荐输出结构

```text
RUN-20260724-001/
├── verification-result.json
├── expected-used.json
├── previous-result.json
│
└── steps/
    ├── STEP-001/
    │   ├── request.json
    │   ├── response.json
    │   └── response-field-diff.json
    │
    └── STEP-002/
        ├── request.json
        ├── response.json
        └── response-field-diff.json
```

职责如下：

|文件|职责|
|---|---|
|`verification-result.json`|Batch总结、API比较总结、业务Check结果|
|`response-field-diff.json`|该API每个返回字段的详细变化|
|`request.json`|本次API请求证据|
|`response.json`|本次API返回证据|
|`expected-used.json`|本次使用的Expected|
|`previous-result.json`|本次比较使用的前回结果|

# 2. 主要结果文件

`verification-result.json`不保存大量字段值，只保存总结和明细文件引用。

```json
{
  "runId": "RUN-20260724-001",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",

  "batch": {
    "resultKey": "BATCH_RESULT",
    "previousResult": "PASS",
    "currentResult": "FAIL",
    "expectedResult": "PASS",
    "changed": true,
    "matched": false,
    "verificationResult": "FAIL"
  },

  "results": [
    {
      "resultKey": "API01_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "resultName": "API1返却値比較",
      "apiStepKey": "STEP-001",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": true,
      "matched": true,
      "verificationResult": "PASS",

      "changeSummary": {
        "checkedItemCount": 20,
        "unchangedCount": 17,
        "changedCount": 2,
        "addedCount": 1,
        "removedCount": 0
      },

      "fieldDiffRef": "steps/STEP-001/response-field-diff.json",
      "requestRef": "steps/STEP-001/request.json",
      "responseRef": "steps/STEP-001/response.json"
    },

    {
      "resultKey": "API01_FIELD_CONSISTENCY_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1項目整合性チェック",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },

    {
      "resultKey": "API01_TYPE_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1データ型チェック",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": false,
      "matched": true,
      "verificationResult": "PASS"
    },

    {
      "resultKey": "API02_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "resultName": "API2返却値比較",
      "apiStepKey": "STEP-002",

      "previousResult": "PASS",
      "currentResult": "PASS",
      "expectedResult": "PASS",

      "changed": true,
      "matched": true,
      "verificationResult": "PASS",

      "changeSummary": {
        "checkedItemCount": 12,
        "unchangedCount": 11,
        "changedCount": 1,
        "addedCount": 0,
        "removedCount": 0
      },

      "fieldDiffRef": "steps/STEP-002/response-field-diff.json",
      "requestRef": "steps/STEP-002/request.json",
      "responseRef": "steps/STEP-002/response.json"
    },

    {
      "resultKey": "API01_API02_BUSINESS_CHECK",
      "resultType": "BUSINESS_CHECK",
      "resultName": "API1・API2間業務整合性チェック",

      "previousResult": "PASS",
      "currentResult": "FAIL",
      "expectedResult": "PASS",

      "changed": true,
      "matched": false,
      "verificationResult": "FAIL",

      "details": {
        "message": "API間の業務整合性条件を満たしていません。"
      }
    }
  ]
}
```

这里的顺序就是Java实际处理顺序：

```text
API1返回比较
API1业务Check
API2返回比较
API2业务Check
API1与API2业务Check
```

# 3. API字段比较明细文件

`steps/STEP-001/response-field-diff.json`专门保存字段级变化。

```json
{
  "resultKey": "API01_RESPONSE_COMPARE",
  "apiStepKey": "STEP-001",
  "apiName": "会員情報取得API",

  "summary": {
    "checkedItemCount": 20,
    "unchangedCount": 17,
    "changedCount": 2,
    "addedCount": 1,
    "removedCount": 0
  },

  "items": [
    {
      "path": "$.memberId",
      "previousState": "PRESENT",
      "currentState": "PRESENT",
      "previousValue": "M001",
      "currentValue": "M001",
      "changeType": "UNCHANGED",
      "changed": false
    },
    {
      "path": "$.memberStatus",
      "previousState": "PRESENT",
      "currentState": "PRESENT",
      "previousValue": "ACTIVE",
      "currentValue": "SUSPENDED",
      "changeType": "VALUE_CHANGED",
      "changed": true
    },
    {
      "path": "$.balance",
      "previousState": "PRESENT",
      "currentState": "PRESENT",
      "previousValue": 1000,
      "currentValue": 700,
      "changeType": "VALUE_CHANGED",
      "changed": true
    },
    {
      "path": "$.newItem",
      "previousState": "MISSING",
      "currentState": "PRESENT",
      "previousValue": null,
      "currentValue": "A",
      "changeType": "ITEM_ADDED",
      "changed": true
    }
  ]
}
```

字段通过`path`定位：

```text
$.memberId
$.memberStatus
$.balance
$.member.address.postalCode
$.members[0].memberId
```

这些字段路径只用于API返回内容调查，不属于Expected Key。

# 4. 两种Key不能混淆

## Result Key

用于Expected、Previous、Current的正式结果对应：

```text
API01_RESPONSE_COMPARE
API01_FIELD_CONSISTENCY_CHECK
API01_TYPE_CHECK
API01_NUMERIC_CHECK
API01_API02_BUSINESS_CHECK
```

## Field Path

用于API返回字段的详细比较：

```text
$.memberId
$.memberStatus
$.balance
```

对应关系：

```text
API01_RESPONSE_COMPARE
└── response-field-diff.json
    ├── $.memberId
    ├── $.memberStatus
    └── $.balance
```

也就是说：

> 一个API比较Result Key，可以关联很多字段变化，但这些字段不会各自产生Expected Key。

# 5. API字段变化不直接决定业务失败

例如：

```text
memberStatus
Previous = ACTIVE
Current  = SUSPENDED
changed  = true
```

API比较文件只负责记录：

```text
字段发生变化
```

然后Java业务Check再判断：

```text
ACTIVE → SUSPENDED是否符合当前业务流程
```

如果合法：

```json
{
  "resultKey": "MEMBER_STATUS_TRANSITION_CHECK",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "verificationResult": "PASS"
}
```

如果不合法：

```json
{
  "resultKey": "MEMBER_STATUS_TRANSITION_CHECK",
  "currentResult": "FAIL",
  "expectedResult": "PASS",
  "verificationResult": "FAIL"
}
```

所以：

```text
API字段比较
    回答“变没变、怎么变”

业务Check
    回答“这种变化在业务上对不对”
```

# 6. Expected JSON保持简单

Expected不保存字段级比较值：

```json
{
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",

  "batch": {
    "resultKey": "BATCH_RESULT",
    "expectedResult": "PASS"
  },

  "results": [
    {
      "resultKey": "API01_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API01_FIELD_CONSISTENCY_CHECK",
      "resultType": "BUSINESS_CHECK",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API01_TYPE_CHECK",
      "resultType": "BUSINESS_CHECK",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API02_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "API01_API02_BUSINESS_CHECK",
      "resultType": "BUSINESS_CHECK",
      "expectedResult": "PASS"
    }
  ]
}
```

API返回字段的前回值和今回值来自：

```text
Previous API Snapshot
Current API Response
```

不是来自Expected JSON。

# 7. 最终文件职责冻结候选

```text
verification-result.json
    Batch结果
    API比较总结
    业务Check结果
    Expected对应结果
    字段明细文件引用

response-field-diff.json
    每个API字段的Previous值
    每个API字段的Current值
    新增／删除／变化／未变化
    字段变化统计

request.json
    API实际请求

response.json
    API实际返回
```

最终形成：

```text
主要结果
    看“本次Batch是否符合预期”

字段比较文件
    看“具体哪个API字段发生了什么变化”

业务Check结果
    看“这些字段和变化是否符合Java业务规则”
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次没有新增文件正文。

确认的设计变化：

```text
1. API字段比较明细与主要验证结果分文件保存。
2. verification-result.json只保存API比较总结和fieldDiffRef。
3. 每个API Step生成独立response-field-diff.json。
4. Result Key负责正式结果对应。
5. Field Path负责API字段变化定位。
6. 字段变化不直接等同于业务失败。
7. 业务正确性由Java Business Check判断。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入主要结果与字段Diff分离模型】
```

## 第 125 轮

### 你

但是字段比较本身也是java端来做，比较的文件是比较一个字段写这个字段的前后变化，那它怎么知道之前的值呢 前回的数据 换句话说最初回应该不存在

### ChatGPT

对，字段比较虽然由Java完成，但Java必须先取得两份数据：

```text
前回API Response Snapshot
今回API Response
```

比较关系是：

```text
Previous Response Snapshot
          ↓
       Java比较
          ↑
Current API Response
```

所以“之前的值”不是来自Expected JSON，而是来自前一次保存并认可的API返回Snapshot。

# 1. 前回值从哪里来

以API1为例，Java执行时根据：

```text
UseCaseId
+
ScenarioId
+
API Step Key
```

查找前回Snapshot：

```text
UC-E6-001
/
SC-001
/
STEP-001
/
response.json
```

逻辑上类似：

```java
Optional<JsonNode> previousResponse =
        baselineRepository.findResponse(
                context.useCaseId(),
                context.scenarioId(),
                "STEP-001"
        );

JsonNode currentResponse =
        callApi01();

ApiFieldDiff diff =
        responseComparator.compare(
                previousResponse,
                currentResponse
        );
```

这里：

```text
Expected JSON
    不参与字段前后值比较

Previous Snapshot
    提供前回字段值

Current Response
    提供本次字段值
```

---

# 2. 最初回确实不存在前回值

第一次执行时：

```text
Previous Snapshot = 不存在
Current Response   = 存在
```

因此不能伪造：

```text
previousValue = null
changed = true
```

因为`null`可能本来就是合法业务值，不能代表“前回不存在”。

第一次应该明确表示：

```text
comparisonState = INITIAL
baselineState   = NOT_FOUND
```

例如API比较摘要：

```json
{
  "resultKey": "API01_RESPONSE_COMPARE",
  "resultType": "API_RESPONSE_COMPARE",

  "currentResult": "PASS",
  "expectedResult": "PASS",
  "verificationResult": "PASS",

  "baselineState": "NOT_FOUND",
  "comparisonState": "INITIAL",

  "changeSummary": {
    "checkedItemCount": 20,
    "unchangedCount": 0,
    "changedCount": 0,
    "addedCount": 0,
    "removedCount": 0,
    "initialItemCount": 20
  },

  "fieldDiffRef": "steps/STEP-001/response-field-diff.json"
}
```

这里的`currentResult = PASS`表示：

> API调用成功，Response取得成功，Java成功生成了初回Snapshot。

不是说“与前回一致”。

---

# 3. 初次字段文件怎么写

第一次的`response-field-diff.json`：

```json
{
  "resultKey": "API01_RESPONSE_COMPARE",
  "apiStepKey": "STEP-001",

  "baselineState": "NOT_FOUND",
  "comparisonState": "INITIAL",

  "items": [
    {
      "path": "$.memberId",
      "previousState": "NOT_AVAILABLE",
      "currentState": "PRESENT",
      "currentValue": "M001",
      "changeType": "INITIAL_VALUE"
    },
    {
      "path": "$.memberStatus",
      "previousState": "NOT_AVAILABLE",
      "currentState": "PRESENT",
      "currentValue": "ACTIVE",
      "changeType": "INITIAL_VALUE"
    },
    {
      "path": "$.balance",
      "previousState": "NOT_AVAILABLE",
      "currentState": "PRESENT",
      "currentValue": 1000,
      "changeType": "INITIAL_VALUE"
    }
  ]
}
```

第一次不要输出：

```json
{
  "previousValue": null,
  "changed": true
}
```

正确表达是：

```text
previousState = NOT_AVAILABLE
changeType    = INITIAL_VALUE
```

---

# 4. 第一次执行后如何变成前回值

第一次执行完成后，本次Response成为Baseline候选：

```text
第一次执行
Current Response
      ↓
Initial Snapshot
      ↓
确认／承认
      ↓
Approved Baseline
```

推荐流程：

```text
RUN-001执行
    ↓
生成Current Snapshot
    ↓
生成Baseline Candidate
    ↓
承认者确认
    ↓
设为Approved Baseline
    ↓
RUN-002使用它作为Previous
```

第一次执行目录：

```text
RUN-001/
├── verification-result.json
├── steps/
│   └── STEP-001/
│       ├── request.json
│       ├── response.json
│       └── response-field-diff.json
└── baseline-candidate/
    └── STEP-001/
        └── response.json
```

批准后，逻辑上的Baseline变为：

```text
baseline/
└── UC-E6-001/
    └── SC-001/
        └── STEP-001/
            └── response.json
```

这里是逻辑候选结构，正式路径仍需跟冻结后的Repository Structure统一。

---

# 5. 第二次执行开始正常比较

第二次执行：

```text
Previous = 第一次批准的Response
Current  = 第二次取得的Response
```

例如：

```json
{
  "resultKey": "API01_RESPONSE_COMPARE",
  "baselineState": "FOUND",
  "comparisonState": "COMPARED",

  "changeSummary": {
    "checkedItemCount": 20,
    "unchangedCount": 18,
    "changedCount": 2,
    "addedCount": 0,
    "removedCount": 0,
    "initialItemCount": 0
  }
}
```

字段明细：

```json
{
  "path": "$.memberStatus",
  "previousState": "PRESENT",
  "currentState": "PRESENT",
  "previousValue": "ACTIVE",
  "currentValue": "SUSPENDED",
  "changeType": "VALUE_CHANGED",
  "changed": true
}
```

---

# 6. 第一回没有Baseline，不应该判FAIL

第一回不存在前回数据是正常状态，不是异常。

建议规则：

|情况|Comparison State|处理结果|
|---|---|---|
|前回Snapshot存在|`COMPARED`|正常生成变化明细|
|最初回无Snapshot|`INITIAL`|生成初回字段快照|
|本来应该有却读取失败|`BASELINE_ERROR`|ERROR或BLOCKED|
|Baseline文件损坏|`BASELINE_ERROR`|ERROR或BLOCKED|

关键区别：

```text
第一次不存在
    正常的INITIAL状态

以前存在但这次找不到
    运用或数据异常
```

Java需要知道这是不是首次执行，可以通过Baseline管理记录判断，不能简单地把“文件不存在”全部视为初次。

---

# 7. Batch结果如何处理最初回

例如第一次所有API和业务Check都成功：

```json
{
  "batch": {
    "resultKey": "BATCH_RESULT",
    "currentResult": "PASS",
    "expectedResult": "PASS",
    "matched": true,
    "verificationResult": "PASS",
    "baselineState": "INITIAL"
  }
}
```

业务Check仍然正常执行：

```json
{
  "resultKey": "API01_TYPE_CHECK",
  "resultType": "BUSINESS_CHECK",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "verificationResult": "PASS"
}
```

也就是说：

```text
API字段前后比较
    第一次没有前回值，标记INITIAL

Java业务Check
    不需要等待Baseline，照常判断PASS／FAIL

Batch
    可以正常得到最终结果
```

---

# 8. Previous Result和Previous Value也要区别

## API字段比较

保存的是：

```text
previousValue
currentValue
changeType
```

来源：

```text
前回Response Snapshot ↔ 今回Response
```

## 业务Check比较

保存的是：

```text
previousResult
currentResult
expectedResult
```

来源：

```text
前回Check Result ↔ 今回Check Result ↔ Expected Result
```

第一次时，业务Check结果也没有`previousResult`：

```json
{
  "resultKey": "API01_TYPE_CHECK",
  "previousResultState": "NOT_AVAILABLE",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "matched": true,
  "verificationResult": "PASS"
}
```

这里仍然能比较：

```text
Current ↔ Expected
```

只是不能比较：

```text
Previous ↔ Current
```

所以第一次：

```text
changed = 不适用
```

最好不要硬写`false`，可以省略或写：

```json
{
  "changed": null,
  "changeState": "NOT_COMPARABLE"
}
```

---

# 9. 完整生命周期

```mermaid
flowchart TD
    A[Batch启动] --> B{Approved Baseline存在?}

    B -- 否: 最初回 --> C[调用API取得Current Response]
    C --> D[生成Initial Field Snapshot]
    D --> E[执行业务Check]
    E --> F[生成Batch结果]
    F --> G[生成Baseline Candidate]
    G --> H[承认后成为Approved Baseline]

    B -- 是 --> I[读取Previous Response Snapshot]
    I --> J[调用API取得Current Response]
    J --> K[Java执行字段级Diff]
    K --> L[执行业务Check]
    L --> M[生成Batch结果]
    M --> N[本次结果承认后更新Baseline]
```

# 10. 最终规则

```text
1. API字段前回值来自Approved Previous Response Snapshot。
2. Expected JSON不保存字段前回值。
3. 最初回没有Previous Snapshot是正常状态。
4. 最初回使用INITIAL／NOT_FOUND明确表示。
5. 最初回字段使用INITIAL_VALUE，不使用previousValue=null冒充前回值。
6. 最初回仍然正常执行业务Check。
7. Current与Expected仍可比较并决定验证结果。
8. Previous不存在时，不执行Previous与Current变化判断。
9. 第一次Current Snapshot经确认后成为下一次Previous Baseline。
10. 后续每次由Java读取Baseline并逐字段比较。
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次未新增文件正文。

本次确认：

```text
1. 字段前回值来自Approved API Response Snapshot。
2. 最初回没有前回值，使用INITIAL状态。
3. 最初回不执行Previous／Current差异判定。
4. 最初回Current Snapshot作为Baseline Candidate。
5. 承认后用于下一次字段比较。
6. API字段Baseline与业务Check Result Baseline分别管理。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入Initial Baseline与字段Diff生命周期】
```

## 第 126 轮

### 你

我觉得这样太麻烦，比如说第一天执行的时候，设置一个初回执行Flg，这样就可以，第一次执行设为true，执行之后设为false，从那之后如果没找到前回的文件都属于异常。
当然不可能人每天都来承认，所有优先看baseline里有没有前回文件，没有的时候，就把前回的执行结果当成baseline

### ChatGPT

你这个方案更实用：**Baseline不需要人工承认，而是系统自动维护“前一次有效执行的实际Response”。** 初回Flg只负责允许第一次没有前回文件。

### ChatGPT

对，这样更简单，也符合“每日自动执行”的实际运用。

核心原则改成：

> **Baseline就是前一次完整执行产生的实际API Response，不需要人工承认。**

# 一、Baseline取得顺序

每次Batch启动时按下面顺序处理：

```text
1. 优先读取Baseline文件
2. Baseline不存在时，检查initialExecutionFlg
3. initialExecutionFlg = true
   → 允许初回执行
   → 不做前后字段比较
4. initialExecutionFlg = false
   → 查找前一次完整执行的Response
5. 前一次Response存在
   → 自动恢复为Baseline并继续比较
6. 前一次Response也不存在
   → 判定异常，停止执行
```

这样既简单，又避免因为Baseline文件偶然丢失就完全无法恢复。

---

# 二、初回执行

初回控制信息：

```json
{
  "initialExecutionFlg": true
}
```

初回执行流程：

```text
initialExecutionFlg = true
        ↓
Baseline不存在，允许执行
        ↓
调用API并保存Current Response
        ↓
不执行Previous与Current字段比较
        ↓
正常执行业务Check
        ↓
将Current Response自动保存为Baseline
        ↓
initialExecutionFlg更新为false
```

初回字段比较结果只需要表示：

```json
{
  "resultKey": "API01_RESPONSE_COMPARE",
  "comparisonStatus": "INITIAL",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "verificationResult": "PASS",
  "fieldDiffRef": "steps/STEP-001/response-field-diff.json"
}
```

字段文件可以保存本次初始值：

```json
{
  "resultKey": "API01_RESPONSE_COMPARE",
  "comparisonStatus": "INITIAL",
  "items": [
    {
      "path": "$.memberId",
      "currentValue": "M001"
    },
    {
      "path": "$.memberStatus",
      "currentValue": "ACTIVE"
    },
    {
      "path": "$.balance",
      "currentValue": 1000
    }
  ]
}
```

不需要输出虚假的：

```json
{
  "previousValue": null,
  "changed": true
}
```

因为初回没有Previous，不属于“变化”。

---

# 三、第二次以后

第二次以后：

```json
{
  "initialExecutionFlg": false
}
```

Java处理：

```text
读取Baseline Response
        ↓
调用API取得Current Response
        ↓
Java逐字段比较
        ↓
生成response-field-diff.json
        ↓
执行业务Check
        ↓
生成verification-result.json
        ↓
将本次完整Response更新为下一次Baseline
```

例如：

```json
{
  "path": "$.memberStatus",
  "previousValue": "ACTIVE",
  "currentValue": "SUSPENDED",
  "changeType": "VALUE_CHANGED",
  "changed": true
}
```

---

# 四、Baseline文件不存在时的自动恢复

当：

```text
initialExecutionFlg = false
Baseline文件不存在
```

不立即判错，先查最近一次完整执行结果。

```text
Baseline不存在
        ↓
查找最近一次Completed Run
        ↓
找到STEP-001/response.json
        ↓
复制或读取为本次Baseline
        ↓
继续执行字段比较
```

例如逻辑：

```java
Optional<JsonNode> baseline =
        baselineRepository.find(
                useCaseId,
                scenarioId,
                stepKey
        );

if (baseline.isEmpty()
        && !initialExecutionFlg) {

    baseline =
        runHistoryRepository
            .findLatestCompletedResponse(
                useCaseId,
                scenarioId,
                stepKey
            );

    baseline.ifPresent(response ->
        baselineRepository.restore(
            useCaseId,
            scenarioId,
            stepKey,
            response
        )
    );
}
```

最后：

```java
if (baseline.isEmpty()
        && !initialExecutionFlg) {

    throw new BaselineNotFoundException(
        useCaseId,
        scenarioId,
        stepKey
    );
}
```

---

# 五、什么执行结果可以成为下一次Baseline

不需要要求整个Batch验证为PASS。

因为Baseline的含义是：

> 前一次实际执行结果。

即使某个业务Check是FAIL，本次实际Response仍然可以作为下一次的前回值。

但是必须满足：

```text
API调用完成
Response取得成功
Response可以正常保存
本次Run完整结束
```

以下情况不能更新Baseline：

```text
API通信ERROR
Response解析失败
Batch中断
文件写入失败
本次Run为BLOCKED
```

因此推荐：

|本次状态|更新Baseline|
|---|---|
|业务验证PASS|更新|
|业务验证FAIL，但Response完整|更新|
|API调用ERROR|不更新|
|Batch中途异常终止|不更新|
|Response文件损坏|不更新|

这可以避免把不完整数据覆盖成Baseline。

---

# 六、Baseline更新时点

不要在API调用完成后立刻覆盖原Baseline。

应该：

```text
读取旧Baseline
        ↓
执行全部API和Check
        ↓
写入本次Run结果
        ↓
确认本次Response文件完整
        ↓
最后更新Baseline
```

并采用临时文件替换：

```text
baseline-response.tmp
        ↓ 写入完成
baseline-response.json
```

避免Batch运行到一半时覆盖旧Baseline。

---

# 七、最终最简状态

实际上只需要三个状态：

```text
INITIAL
    初回执行，没有前回值

COMPARED
    找到Baseline，完成前回与今回比较

ERROR
    非初回，但Baseline和前回执行结果都找不到
```

不需要人工承认状态，也不需要Baseline Candidate等复杂流程。

---

# 八、完整运行判断

```java
Optional<ResponseSnapshot> previous =
        baselineRepository.find(context);

if (previous.isEmpty()
        && !context.initialExecutionFlg()) {

    previous =
        runHistoryRepository
            .findLatestCompletedResponse(context);
}

if (previous.isEmpty()
        && !context.initialExecutionFlg()) {

    throw new BaselineNotFoundException();
}

ApiResponse current = callApi();

ApiFieldDiff fieldDiff;

if (context.initialExecutionFlg()) {

    fieldDiff =
        ApiFieldDiff.initial(current);

} else {

    fieldDiff =
        comparator.compare(
            previous.orElseThrow(),
            current
        );
}

List<CurrentCheckResult> checkResults =
        executeBusinessChecks(current);

writeRunResult(
        current,
        fieldDiff,
        checkResults
);

if (current.isComplete()) {

    baselineRepository.replace(current);
    executionState.setInitialExecutionFlg(false);
}
```

---

# 九、最终规则

```text
1. 初回执行Flg为true时，允许Baseline不存在。
2. 初回执行不做前后字段变化判断。
3. 初回执行完成后，Current Response自动成为Baseline。
4. 初回执行完成后，Flg自动更新为false。
5. 第二次以后优先读取Baseline文件。
6. Baseline不存在时，自动读取最近一次完整执行Response恢复Baseline。
7. Baseline和前回完整执行结果都不存在时判定ERROR。
8. 不需要人工每日承认。
9. 业务Check为FAIL时，只要Response完整，仍可更新Baseline。
10. API调用ERROR或Run不完整时，不更新Baseline。
11. Baseline在Batch全部输出完成后统一更新。
12. API字段Diff和主要验证结果继续分文件保存。
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次没有新增文件正文。

本次设计确认：

```text
- 删除人工Baseline承认流程。
- 使用initialExecutionFlg控制初回执行。
- 初回执行后自动生成Baseline并关闭Flg。
- 第二次以后优先使用Baseline。
- Baseline缺失时自动从最近完整Run恢复。
- 两边都不存在时判定ERROR。
- 完整Response无论业务PASS或FAIL都可成为下一次Baseline。
- 不完整或异常Run不得更新Baseline。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需按自动Baseline更新与初回Flg模型重写】
```

## 第 127 轮

### 你

如何找到前回对比文件呢  不是按日期

### ChatGPT

对，**不能按日期去找“前回”**。日期只能用于显示和审计，不能作为定位依据。

正确做法是使用一个固定的“运行状态指针”，明确记录上一次完整执行的`runId`。

# 一、定位单位

前回执行结果必须先按固定业务身份隔离：

```text
environmentId
+
useCaseId
+
scenarioId
+
inputSetId
```

例如：

```text
test
/
UC-E6-001
/
SC-001
/
INPUT-001
```

为什么需要`inputSetId`：

同一个Scenario如果使用不同输入数据执行，不能拿另一套输入的API Response作为前回比较对象。

如果系统保证一个Scenario永远只有一套输入，则可以暂时省略`inputSetId`。

---

# 二、设置一个固定状态文件

例如逻辑上设置：

```text
execution-state/
└── test/
    └── UC-E6-001/
        └── SC-001/
            └── INPUT-001/
                └── execution-state.json
```

内容：

```json
{
  "initialExecutionFlg": false,
  "latestCompletedRunId": "RUN-7f36a8c1",
  "baselineRunId": "RUN-7f36a8c1"
}
```

字段职责：

|字段|说明|
|---|---|
|`initialExecutionFlg`|是否允许无前回数据执行|
|`latestCompletedRunId`|最近一次完整执行的Run ID|
|`baselineRunId`|当前Baseline来源的Run ID|

在当前简化设计中，`latestCompletedRunId`和`baselineRunId`通常相同。

甚至可以进一步简化成：

```json
{
  "initialExecutionFlg": false,
  "previousRunId": "RUN-7f36a8c1"
}
```

我更推荐这个最小版本。

---

# 三、Baseline使用固定路径

系统平时不需要查找历史目录。

Baseline始终放在固定位置：

```text
baseline/
└── test/
    └── UC-E6-001/
        └── SC-001/
            └── INPUT-001/
                ├── verification-result.json
                └── steps/
                    ├── STEP-001/
                    │   └── response.json
                    └── STEP-002/
                        └── response.json
```

Java每次直接读取：

```text
baseline/test/UC-E6-001/SC-001/INPUT-001/
```

这里保存的永远是：

> 上一次完整执行产生的实际结果。

因此正常情况下根本不存在“如何找前一天目录”的问题。

---

# 四、运行历史使用Run ID保存

每次执行保存在：

```text
runs/
└── RUN-7f36a8c1/
    ├── run-meta.json
    ├── verification-result.json
    └── steps/
        ├── STEP-001/
        │   ├── request.json
        │   ├── response.json
        │   └── response-field-diff.json
        └── STEP-002/
            └── ...
```

`run-meta.json`中保存业务身份：

```json
{
  "runId": "RUN-7f36a8c1",
  "environmentId": "test",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "inputSetId": "INPUT-001",
  "runStatus": "COMPLETED"
}
```

注意：

```text
runId负责唯一定位执行结果
日期只作为run-meta中的执行时间
```

---

# 五、启动时的查找顺序

## 第一步：读取固定Baseline

Java直接检查：

```text
baseline/
test/
UC-E6-001/
SC-001/
INPUT-001/
```

存在：

```text
直接作为Previous使用
```

不需要扫描历史执行。

---

## 第二步：Baseline不存在时读取状态指针

读取：

```json
{
  "initialExecutionFlg": false,
  "previousRunId": "RUN-7f36a8c1"
}
```

然后准确定位：

```text
runs/RUN-7f36a8c1/
```

从该Run恢复：

```text
STEP-001/response.json
STEP-002/response.json
verification-result.json
```

不需要：

```text
查找昨天
按文件时间排序
找名称最大的目录
遍历所有Run
```

---

## 第三步：仍然找不到时判断初回Flg

### `initialExecutionFlg = true`

允许初次执行：

```text
Previous不存在
不执行字段前后比较
正常执行API和业务Check
执行完成后生成Baseline
Flg改为false
```

### `initialExecutionFlg = false`

说明系统原本已经执行过，但：

```text
Baseline不存在
previousRunId指向的Run也不存在
```

此时判定：

```text
BASELINE_NOT_FOUND
```

属于运行资料异常。

---

# 六、Java伪代码

```java
BaselineContext loadPrevious(
        ExecutionIdentity identity,
        ExecutionState state) {

    Optional<BaselineContext> baseline =
            baselineRepository.find(identity);

    if (baseline.isPresent()) {
        return baseline.get();
    }

    if (state.previousRunId() != null) {

        Optional<BaselineContext> previousRun =
                runRepository.loadAsBaseline(
                        state.previousRunId(),
                        identity
                );

        if (previousRun.isPresent()) {
            baselineRepository.restore(
                    identity,
                    previousRun.get()
            );

            return previousRun.get();
        }
    }

    if (state.initialExecutionFlg()) {
        return BaselineContext.initial();
    }

    throw new BaselineNotFoundException(
            identity
    );
}
```

这里完全没有日期判断。

---

# 七、执行完成后的更新

本次Run完整结束后：

```text
1. 保存本次Run目录
2. 确认所有必要Response写入成功
3. 将本次结果复制到固定Baseline路径
4. 更新execution-state.json中的previousRunId
5. 初回时将initialExecutionFlg改为false
```

例如本次Run：

```text
RUN-c91452ab
```

更新后：

```json
{
  "initialExecutionFlg": false,
  "previousRunId": "RUN-c91452ab"
}
```

下次执行就准确读取：

```text
runs/RUN-c91452ab/
```

或者正常情况下直接读取已经更新好的固定Baseline。

---

# 八、不能只使用“最近完成Run”的原因

假设存在：

```text
UC-E6-001 / SC-001 / INPUT-001
UC-E6-001 / SC-001 / INPUT-002
UC-E6-002 / SC-001 / INPUT-001
```

如果只找全系统“最近一次Run”，很容易找到错误对象。

所以状态指针必须绑定业务身份：

```text
environmentId
useCaseId
scenarioId
inputSetId
```

例如：

```json
{
  "environmentId": "test",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "inputSetId": "INPUT-001",
  "previousRunId": "RUN-c91452ab"
}
```

---

# 九、最终建议冻结

```text
正常取得Previous：
    固定Baseline路径

Baseline缺失后的恢复：
    execution-state.json中的previousRunId

禁止：
    按日期查找
    按目录名称排序
    按文件更新时间查找
    扫描后猜测最近Run

初回：
    initialExecutionFlg = true

非初回且Baseline、previousRunId均无效：
    ERROR
```

最简单的定位关系是：

```text
Execution Identity
    environmentId
    useCaseId
    scenarioId
    inputSetId

        ↓

execution-state.json
    previousRunId

        ↓

runs/{previousRunId}
```

而日常运行优先使用：

```text
baseline/{Execution Identity}
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次没有新增文件正文。

本次确认：

```text
1. 前回结果不按日期查找。
2. 正常运行直接读取固定Baseline路径。
3. Baseline丢失时，通过execution-state.json中的previousRunId恢复。
4. previousRunId精确定位历史Run。
5. 执行身份由Environment＋UseCase＋Scenario＋InputSet构成。
6. 日期只用于审计，不参与定位。
7. 禁止通过目录排序或更新时间猜测前回Run。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入Previous Run指针与Baseline定位规则】
```

## 第 128 轮

### 你

那baseline的文件 什么时候复制过去？

### ChatGPT

**Baseline在整个Batch执行结束、所有必要输出文件都成功写完之后，统一复制过去。**

不是：

```text
API1完成后马上更新Baseline
API2完成后马上更新Baseline
某个Check完成后更新Baseline
```

而是：

```text
整个Batch完成
→ 确认本次执行资料完整
→ 再统一替换Baseline
```

# 一、准确的更新时间点

完整顺序应当是：

```text
1. 读取旧Baseline
2. 调用API1
3. 保存API1 Request／Response
4. 执行API1相关Check
5. 调用API2
6. 保存API2 Request／Response
7. 执行API2相关Check
8. 执行跨API业务Check
9. 生成字段Diff文件
10. 生成主要verification-result.json
11. 确认本次Run资料完整
12. 将本次Run复制为新的Baseline
13. 更新previousRunId
14. 初回时将initialExecutionFlg改为false
15. Batch结束
```

因此Baseline更新属于：

```text
Batch Finalize处理
```

---

# 二、为什么不能每个API结束后复制

假设：

```text
API1成功
API2调用失败
```

如果API1完成后已经更新了Baseline，就会产生：

```text
STEP-001来自本次Run
STEP-002仍然来自前一次Run
```

这样Baseline就不是同一次Batch的完整快照。

所以必须保证：

> Baseline中的所有API Response和业务结果，都来自同一个完整Run。

因此一次替换的是整个Baseline目录，而不是逐个API覆盖。

---

# 三、什么情况下更新Baseline

## 可以更新

只要本次Batch执行资料完整，即使业务验证结果是FAIL，也可以更新：

|执行情况|更新Baseline|
|---|---:|
|所有API调用成功，所有Response完整，业务Check全部PASS|是|
|所有API调用成功，Response完整，但某个业务Check为FAIL|是|
|字段与前回发生变化|是|
|Expected验证结果为FAIL，但运行资料完整|是|

因为Baseline表示：

```text
前一次完整执行的实际结果
```

它不是“前一次正确结果”。

---

## 不可以更新

|执行情况|更新Baseline|
|---|---:|
|某个必要API调用ERROR|否|
|Response无法解析|否|
|Response文件写入失败|否|
|Batch中途异常终止|否|
|主要结果文件未生成|否|
|部分API结果缺失|否|

此时继续保留旧Baseline。

---

# 四、初回执行

初回启动：

```json
{
  "initialExecutionFlg": true
}
```

运行时没有Baseline：

```text
不做前回字段比较
正常执行API和业务Check
```

第一次完整执行结束后：

```text
本次Run
↓
复制为Baseline
↓
更新previousRunId
↓
initialExecutionFlg = false
```

注意顺序必须是：

```text
先成功生成Baseline
再把initialExecutionFlg改为false
```

不能先关闭Flg，否则Baseline复制失败后，下次运行会被当成非初回，但又没有Baseline。

---

# 五、第二次以后

第二次启动时：

```text
读取固定Baseline
↓
作为Previous
↓
执行本次API
↓
Java进行字段比较
↓
生成本次Run结果
↓
本次Run完整后替换Baseline
```

也就是说：

```text
RUN-001完整完成
    → Baseline = RUN-001

RUN-002启动
    → Previous使用RUN-001
    → RUN-002完整完成
    → Baseline替换为RUN-002

RUN-003启动
    → Previous使用RUN-002
```

---

# 六、Baseline应该复制哪些文件

字段前后比较需要前回Response，业务Check前后结果需要前回验证结果。

所以Baseline最少保存：

```text
baseline/
├── baseline-meta.json
├── verification-result.json
└── steps/
    ├── STEP-001/
    │   └── response.json
    ├── STEP-002/
    │   └── response.json
    └── STEP-003/
        └── response.json
```

`baseline-meta.json`：

```json
{
  "sourceRunId": "RUN-c91452ab",
  "environmentId": "test",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "inputSetId": "INPUT-001",
  "executionCompleted": true
}
```

其中：

```text
response.json
    用于字段Previous Value比较

verification-result.json
    用于业务Check的Previous Result比较

sourceRunId
    说明Baseline来自哪一次Run
```

Request原则上不需要复制进Baseline，因为字段比较主要使用前回Response。历史Run目录仍完整保存Request用于审计。

---

# 七、替换Baseline的安全顺序

不要直接覆盖旧Baseline。

推荐：

```text
1. 创建baseline.tmp
2. 将本次Run需要的文件复制到baseline.tmp
3. 校验文件数量和必要文件
4. 写入baseline-meta.json
5. 原子替换baseline
6. 更新execution-state.json
```

逻辑示例：

```text
baseline.tmp/
    ↓ 写入并检查完成

旧baseline/
    ↓ 保留到新Baseline准备完成

baseline.tmp
    ↓ 原子Rename

baseline/
```

这样即使复制过程中程序异常，旧Baseline仍然存在。

---

# 八、状态文件最后更新

Baseline替换成功后，再更新：

```json
{
  "initialExecutionFlg": false,
  "previousRunId": "RUN-c91452ab"
}
```

更新顺序必须是：

```text
保存完整Run
→ 替换Baseline
→ 更新previousRunId
→ 更新initialExecutionFlg
```

原因是如果程序中途崩溃：

## Baseline已更新，状态文件还未更新

问题不大，因为下次启动优先读取固定Baseline。

## 状态文件已更新，Baseline还没更新

问题很大，状态指向新Run，但Baseline仍然不完整。

所以状态指针必须最后更新。

---

# 九、Java处理位置

可以在Scenario执行结束后的Framework中统一处理：

```java
ScenarioExecutionResult result =
        scenario.execute(context);

runResultWriter.write(
        context.runId(),
        result
);

if (result.isExecutionComplete()) {

    baselineManager.replaceFromRun(
            context.executionIdentity(),
            context.runId()
    );

    executionStateManager.update(
            context.executionIdentity(),
            context.runId(),
            false
    );
}
```

这里关键不是：

```java
result.getVerificationResult() == PASS
```

而是：

```java
result.isExecutionComplete()
```

即：

```text
所有必要API已执行
所有必要Response已保存
结果文件生成成功
Batch没有异常中断
```

---

# 十、最终冻结规则

```text
1. Baseline在Batch Finalize阶段更新。
2. 不在单个API调用结束时更新。
3. 不进行部分Step的Baseline替换。
4. Baseline必须来自同一个完整Run。
5. 业务Check为FAIL不影响Baseline更新。
6. API ERROR、文件缺失或Batch中断时不更新。
7. 初回完整执行后自动创建Baseline。
8. Baseline更新成功后才关闭initialExecutionFlg。
9. Baseline更新成功后才更新previousRunId。
10. 更新采用临时目录＋原子替换。
```

一句话就是：

> **本次Run完整落盘后，把本次Run整体复制为下次执行使用的Baseline。**

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次未新增文件正文。

本次确认：

```text
1. Baseline在整个Batch完成后统一更新。
2. 禁止按API单独更新Baseline。
3. Baseline必须来自同一个完整Run。
4. Verification FAIL但执行完整时仍更新Baseline。
5. API ERROR或Run不完整时保留旧Baseline。
6. Baseline采用临时目录和原子替换。
7. previousRunId与initialExecutionFlg最后更新。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入Batch Finalize阶段的Baseline更新规则】
```

## 第 129 轮

### 你

expected对比  api对比 业务对比  初回执行  baseline复制  都讨论了 我觉得可以了。
但是input.json你说了 batch执行开始就通过request加载进去了 ，那么单独按业务做一个分支也不对。
其实input.json里面按照api单位  来子boject定义输入值  比如 request的入力在顶层，那么内部的api那么就是一个数组，按照api的顺序，定义他们需要的初期值，当然前面api返回值不需要指定

### ChatGPT

对，这里应该把`input.json`收敛成“**按API顺序提供初期输入值**”，而不是再做业务分支定义或参数映射规则。前序API的返回值由Java直接放入Context，后续API需要时从Context取，不在`input.json`重复指定。

### ChatGPT

对，`input.json`应该重新定义为：

> **一次Batch执行的外部初期输入，以及按执行顺序排列的各API初期输入值。**

它不负责定义：

```text
业务分支
前后API字段映射
Expected
Baseline
比较规则
业务判断规则
```

前面API的返回值由Java放入运行时Context，后面的API直接从Context取得。

---

# 一、推荐的整体 `input.json`

```json
{
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "environmentId": "test",
  "inputSetId": "INPUT-001",

  "request": {
    "memberId": "M000001",
    "businessDate": "2026-07-24",
    "operatorId": "USER001"
  },

  "apis": [
    {
      "stepKey": "STEP-001",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "NORMAL"
      }
    },
    {
      "stepKey": "STEP-002",
      "apiId": "API-002",
      "initialValues": {
        "updateType": "STATUS_UPDATE"
      }
    },
    {
      "stepKey": "STEP-003",
      "apiId": "API-003",
      "initialValues": {
        "registerMode": "NORMAL"
      }
    }
  ]
}
```

这里分为两部分。

## 顶层 `request`

表示Batch启动时从外部传入的共通输入：

```json
{
  "memberId": "M000001",
  "businessDate": "2026-07-24",
  "operatorId": "USER001"
}
```

这些值可能被多个API使用。

## `apis`

按照实际API调用顺序，定义每次API调用需要额外提供的初期值。

```text
数组第1个：API1
数组第2个：API2
数组第3个：API3
```

不需要额外的`sequence`。

---

# 二、前一个API返回值不写入Input JSON

例如API1返回：

```json
{
  "memberId": "M000001",
  "memberStatus": "ACTIVE",
  "balance": 1000
}
```

API2需要：

```json
{
  "memberId": "M000001",
  "beforeStatus": "ACTIVE",
  "updateType": "STATUS_UPDATE"
}
```

`input.json`中只定义：

```json
{
  "stepKey": "STEP-002",
  "apiId": "API-002",
  "initialValues": {
    "updateType": "STATUS_UPDATE"
  }
}
```

下面两个值不用写：

```text
memberId
beforeStatus
```

因为Java已经从API1 Response取得：

```java
Api01Response api01Response =
        callApi01(api01Request);

context.putResponse(
        "STEP-001",
        api01Response
);
```

API2构造Request时：

```java
Api01Response api01Response =
        context.getResponse(
                "STEP-001",
                Api01Response.class
        );

ApiInput api02Input =
        input.getApi("STEP-002");

Api02Request api02Request =
        new Api02Request(
                api01Response.getMemberId(),
                api01Response.getMemberStatus(),
                api02Input.getString("updateType")
        );
```

实际API2 Request由三部分组成：

```text
顶层request中的共通初期值
+
STEP-002的initialValues
+
前序API Response
```

但具体怎么组合，由Java代码实现，不在JSON中定义映射规则。

---

# 三、`stepKey`与`apiId`的区别

建议两个都保留。

```json
{
  "stepKey": "STEP-002",
  "apiId": "API-002"
}
```

## `apiId`

表示调用的是哪个API：

```text
API-002
```

## `stepKey`

表示这个Scenario中的第几次API调用实例：

```text
STEP-002
```

因为同一个API可能在一个Scenario中调用两次：

```json
{
  "apis": [
    {
      "stepKey": "STEP-001",
      "apiId": "API-001"
    },
    {
      "stepKey": "STEP-003",
      "apiId": "API-001"
    }
  ]
}
```

所以不能只依靠`apiId`定位输入和输出文件。

---

# 四、Java如何读取Input JSON

Java可以同时保留：

```text
List
    保持API执行顺序

Map
    根据stepKey快速定位
```

例如：

```java
public final class ScenarioInput {

    private BatchRequest request;

    private List<ApiInput> apis;

    public ApiInput getApi(
            String stepKey) {

        return apis.stream()
                .filter(api ->
                        api.stepKey()
                                .equals(stepKey)
                )
                .findFirst()
                .orElseThrow(() ->
                        new InputNotFoundException(
                                stepKey
                        )
                );
    }
}
```

Scenario代码：

```java
public ScenarioResult execute(
        ScenarioContext context) {

    ScenarioInput input =
            context.input();

    ApiInput api01Input =
            input.getApi("STEP-001");

    Api01Request api01Request =
            buildApi01Request(
                    input.getRequest(),
                    api01Input
            );

    Api01Response api01Response =
            callApi01(api01Request);

    context.putResponse(
            "STEP-001",
            api01Response
    );

    ApiInput api02Input =
            input.getApi("STEP-002");

    Api02Request api02Request =
            buildApi02Request(
                    input.getRequest(),
                    api02Input,
                    api01Response
            );

    Api02Response api02Response =
            callApi02(api02Request);

    context.putResponse(
            "STEP-002",
            api02Response
    );

    return executeChecks(context);
}
```

---

# 五、不需要在Input JSON里定义业务分支

不建议：

```json
{
  "branches": {
    "memberStatus": {
      "ACTIVE": "STEP-002",
      "SUSPENDED": "STEP-003"
    }
  }
}
```

因为这又会把业务逻辑外部化。

应该由Java决定：

```java
if (api01Response.isActive()) {
    executeApi02(context);
} else {
    executeApi03(context);
}
```

对应的Input文件只需要为可能执行的API准备初期输入。

例如：

```json
{
  "apis": [
    {
      "stepKey": "STEP-001",
      "apiId": "API-001",
      "initialValues": {}
    },
    {
      "stepKey": "STEP-002",
      "apiId": "API-002",
      "initialValues": {
        "updateType": "NORMAL"
      }
    },
    {
      "stepKey": "STEP-003",
      "apiId": "API-003",
      "initialValues": {
        "suspendReason": "STATUS_ERROR"
      }
    }
  ]
}
```

Java根据API1结果决定执行STEP-002还是STEP-003。

不过更简单的做法是：

> 一个Scenario对应一条已经确定的API执行路径。

那么`SC-001`只写它实际需要执行的API：

```text
STEP-001 → STEP-002
```

另一个分支作为`SC-002`：

```text
STEP-001 → STEP-003
```

这样Input JSON里不需要准备未执行API的输入。

这更符合当前UseCase／Scenario设计。

---

# 六、Input JSON不应包含初回Flg

`initialExecutionFlg`不建议放在`input.json`。

因为它不是业务输入，而是运行状态。

应该放在：

```text
execution-state.json
```

例如：

```json
{
  "initialExecutionFlg": false,
  "previousRunId": "RUN-c91452ab"
}
```

职责分离：

|文件|职责|
|---|---|
|`input.json`|Batch和各API的初期输入|
|`expected.json`|每个Result Key的期待结果|
|`execution-state.json`|初回Flg、Previous Run指针|
|`baseline/`|前回完整执行结果|
|`verification-result.json`|本次主要验证结果|
|`response-field-diff.json`|API字段前后变化|

---

# 七、Input JSON与Expected JSON不需要镜像

两者定位对象不同。

## Input JSON

按API调用实例定位：

```text
UseCaseId
+
ScenarioId
+
StepKey
```

例如：

```text
UC-E6-001 / SC-001 / STEP-002
```

## Expected JSON

按验证结果定位：

```text
UseCaseId
+
ScenarioId
+
ResultKey
```

例如：

```text
UC-E6-001 / SC-001 / API02_TYPE_CHECK
```

因此：

```text
Input的Key：stepKey
Expected的Key：resultKey
```

不能强行使用同一种结构。

---

# 八、最终完整Input JSON候选

```json
{
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "environmentId": "test",
  "inputSetId": "INPUT-001",

  "request": {
    "memberId": "M000001",
    "businessDate": "2026-07-24",
    "operatorId": "USER001"
  },

  "apis": [
    {
      "stepKey": "STEP-001",
      "apiId": "API-001",
      "apiName": "会員情報取得API",
      "initialValues": {
        "searchType": "NORMAL"
      }
    },
    {
      "stepKey": "STEP-002",
      "apiId": "API-002",
      "apiName": "会員状態更新API",
      "initialValues": {
        "updateType": "STATUS_UPDATE",
        "updateReason": "DAILY_EXECUTION"
      }
    },
    {
      "stepKey": "STEP-003",
      "apiId": "API-003",
      "apiName": "更新結果照会API",
      "initialValues": {
        "detailRequired": true
      }
    }
  ]
}
```

不过正式运行用JSON中，`apiName`可以省略，因为`apiId`已经能查到名称。

最小版本是：

```json
{
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "environmentId": "test",
  "inputSetId": "INPUT-001",

  "request": {
    "memberId": "M000001",
    "businessDate": "2026-07-24"
  },

  "apis": [
    {
      "stepKey": "STEP-001",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "NORMAL"
      }
    },
    {
      "stepKey": "STEP-002",
      "apiId": "API-002",
      "initialValues": {
        "updateType": "STATUS_UPDATE"
      }
    },
    {
      "stepKey": "STEP-003",
      "apiId": "API-003",
      "initialValues": {}
    }
  ]
}
```

# 九、最终冻结候选

```text
1. Input JSON只定义执行初期输入。
2. 顶层request保存Batch入口和共通输入。
3. apis数组按照实际API执行顺序排列。
4. 每个API使用stepKey唯一定位调用实例。
5. apiId表示实际调用的API。
6. initialValues只保存外部需要指定的初期值。
7. 前序API Response不写入Input JSON。
8. 前序API Response由Java保存到ScenarioContext。
9. 后续API Request由Java组合顶层request、initialValues和前序Response。
10. 业务分支、字段映射和业务规则不写入Input JSON。
11. 一个Scenario原则上对应一条确定的API执行路径。
12. initialExecutionFlg属于execution-state，不属于Input。
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次未新增文件正文。

本次确认：

```text
1. Input JSON改为顶层request＋按顺序排列的apis数组。
2. 每个API只定义外部初期值。
3. 前序API返回值由Java Context管理。
4. 后续API输入不在JSON中重复指定前序Response值。
5. Input不定义业务分支和字段映射规则。
6. Input使用stepKey定位，Expected使用resultKey定位。
7. initialExecutionFlg继续保存在execution-state。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入Input JSON的API顺序型结构】
```

## 第 130 轮

### 你

还有 context的设计 也应该根据usecase里的scenario来 ，不需要全部统一一个id

### ChatGPT

对。**Context不应该设计成全系统统一的一套Context ID目录。**

更合理的是：

> **一个UseCase下面的每个Scenario，根据自身API调用顺序和业务处理内容，拥有自己的ScenarioContext。**

统一的只是Context的基本使用方式，不统一Context里面的全部数据项。

# 一、Context的定位

Context的运行边界应当是：

```text
一次Run
+
一个UseCase
+
一个Scenario
```

例如：

```text
RUN-001
UC-E6-001
SC-001
```

Java启动Scenario时创建：

```java
ScenarioContext context =
        new ScenarioContext(
                runId,
                useCaseId,
                scenarioId,
                input
        );
```

Scenario执行结束后，该Context生命周期结束。

不需要再定义：

```text
CONTEXT-001
CONTEXT-002
CONTEXT-003
```

这样的全局Context ID。

---

# 二、Context不是Master数据

Context是Java运行时对象，用于保存当前Scenario执行过程中产生的数据：

```text
Batch初期Input
API1 Request
API1 Response
API2 Request
API2 Response
各Check当前结果
Expected
Baseline
执行状态
```

这些内容都是本次执行期间的数据，不需要作为全系统统一Master项目管理。

例如`SC-001`：

```text
ScenarioContext
├── batchInput
├── STEP-001
│   ├── initialValues
│   ├── request
│   └── response
├── STEP-002
│   ├── initialValues
│   ├── request
│   └── response
├── expectedResults
├── previousResults
└── currentCheckResults
```

而另一个`SC-002`可以完全不同：

```text
ScenarioContext
├── batchInput
├── STEP-001 response
├── STEP-003 response
└── cancellationCheckResult
```

不要求两个Scenario拥有相同Context字段。

---

# 三、统一的是框架结构

Framework只提供最基本的共同能力：

```java
public class ScenarioContext {

    private final String runId;
    private final String useCaseId;
    private final String scenarioId;

    private final ScenarioInput input;

    private final Map<String, Object> requests;
    private final Map<String, Object> responses;
    private final Map<String, CurrentCheckResult> checkResults;

    private final ExpectedContext expected;
    private final BaselineContext baseline;
}
```

统一的是这些操作：

```java
context.getInput();
context.putRequest(stepKey, request);
context.getRequest(stepKey, RequestClass.class);
context.putResponse(stepKey, response);
context.getResponse(stepKey, ResponseClass.class);
context.putCheckResult(resultKey, result);
context.getExpected(resultKey);
```

但里面具体有什么：

```text
STEP-001
STEP-002
API01_RESPONSE_COMPARE
MEMBER_STATUS_CHECK
```

由当前Scenario决定。

---

# 四、Scenario代码自己决定保存哪些数据

例如`SC-001`：

```java
public ScenarioResult execute(
        ScenarioContext context) {

    ApiInput api01Input =
            context.getInput()
                    .getApi("STEP-001");

    Api01Request api01Request =
            buildApi01Request(
                    context.getInput()
                            .getRequest(),
                    api01Input
            );

    context.putRequest(
            "STEP-001",
            api01Request
    );

    Api01Response api01Response =
            callApi01(api01Request);

    context.putResponse(
            "STEP-001",
            api01Response
    );

    context.putCheckResult(
            api01ResponseCompare.execute(
                    context.getBaseline()
                            .getResponse("STEP-001"),
                    api01Response
            )
    );

    ApiInput api02Input =
            context.getInput()
                    .getApi("STEP-002");

    Api02Request api02Request =
            buildApi02Request(
                    api02Input,
                    api01Response
            );

    context.putRequest(
            "STEP-002",
            api02Request
    );

    Api02Response api02Response =
            callApi02(api02Request);

    context.putResponse(
            "STEP-002",
            api02Response
    );

    context.putCheckResult(
            api01Api02BusinessCheck.execute(
                    api01Response,
                    api02Response
            )
    );

    return buildResult(context);
}
```

这里Context只是保存Scenario执行中需要共享的数据。

---

# 五、Context内部使用现有Key即可

Context不需要再增加一套Context专用ID。

## API数据定位

直接使用：

```text
stepKey
```

例如：

```text
STEP-001
STEP-002
```

```java
context.getResponse(
        "STEP-001",
        Api01Response.class
);
```

## Check结果定位

直接使用：

```text
resultKey
```

例如：

```text
API01_RESPONSE_COMPARE
API01_TYPE_CHECK
API01_API02_BUSINESS_CHECK
```

```java
context.getCheckResult(
        "API01_TYPE_CHECK"
);
```

因此不需要再出现：

```text
CONTEXT_API01_RESPONSE
CONTEXT_MEMBER_STATUS
CONTEXT_API02_RESULT
```

这会重复制造Key。

---

# 六、Context与Input、Expected、Baseline的关系

```text
Input JSON
    ↓ 加载
ScenarioContext.input

Expected JSON
    ↓ 加载
ScenarioContext.expected

Baseline
    ↓ 加载
ScenarioContext.baseline

API执行结果
    ↓ Scenario运行中写入
ScenarioContext.requests / responses

业务Check结果
    ↓ Scenario运行中写入
ScenarioContext.checkResults
```

完整流程：

```text
创建ScenarioContext
        ↓
加载Input
        ↓
加载Expected
        ↓
加载Baseline
        ↓
执行API1并保存Response
        ↓
执行API1 Check并保存Result
        ↓
执行API2并保存Response
        ↓
执行跨API Check并保存Result
        ↓
输出文件
        ↓
Context销毁
```

---

# 七、是否需要Context JSON

正常情况下不需要把完整Java Context直接输出成一个巨大的`context.json`。

因为正式证据已经分别保存：

```text
input-used.json
expected-used.json
verification-result.json

steps/STEP-001/request.json
steps/STEP-001/response.json
steps/STEP-001/response-field-diff.json
```

如果需要调查，可以只生成一个轻量的Context摘要：

```json
{
  "runId": "RUN-001",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "executedSteps": [
    "STEP-001",
    "STEP-002"
  ],
  "generatedResultKeys": [
    "API01_RESPONSE_COMPARE",
    "API01_TYPE_CHECK",
    "API02_RESPONSE_COMPARE",
    "API01_API02_BUSINESS_CHECK"
  ]
}
```

但这不是必须文件。

---

# 八、对`Context_Master`的修正

原来的`Context_Master.md`如果准备定义：

```text
全系统所有Context ID
全部Context项目
统一Context字段目录
```

这个方向需要重做。

新的职责应该只保留：

```text
1. ScenarioContext的生命周期
2. Input、Expected、Baseline的装载方式
3. StepKey保存Request／Response的规则
4. ResultKey保存Check结果的规则
5. Context中数据覆盖禁止规则
6. 类型安全取得规则
7. Scenario结束后的释放规则
8. 并行执行时Context实例隔离规则
```

具体Context内容由：

```text
UseCase
└── Scenario
    └── Java Scenario实现
```

自己决定。

---

# 九、最终确定

```text
1. 一个Scenario执行实例对应一个ScenarioContext。
2. Context不使用全系统统一Context ID。
3. Context内容根据UseCase中的Scenario决定。
4. Framework只统一Context接口和生命周期。
5. API Request／Response使用stepKey定位。
6. Check Result使用resultKey定位。
7. 不新增Context专用数据Key。
8. 不建立全系统Context字段清单。
9. 不同Scenario可以拥有完全不同的Context内容。
10. 每个Run的Context独立，不能相互共享或覆盖。
```

最终关系可以固定为：

```text
UseCase
└── Scenario
    ├── Input JSON
    ├── Expected JSON
    ├── ScenarioContext
    │   ├── Step Request／Response
    │   ├── Baseline
    │   └── Check Result
    └── Output
```

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次未新增文件正文。

本次确认：

```text
1. Context改为Scenario单位的运行时对象。
2. 删除全系统统一Context ID的方向。
3. API数据直接使用stepKey定位。
4. Check结果直接使用resultKey定位。
5. Context_Master只定义共通生命周期和操作规则。
6. 具体Context内容由各Scenario自行决定。
7. Context_Master.md与Context_Master設計書.md继续标记为需要重做。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入Scenario单位Context模型】
```

## 第 131 轮

### 你

一个ScenarioContext如果里面有相同的api的request和response 我觉得也应该加上区分code

### ChatGPT

对。一个Scenario里可能多次调用同一个API，所以仅靠`apiId`无法区分Request和Response。

但不需要再新增一套复杂ID。可以把之前的`stepKey`正式明确为：

```text
apiCallCode
```

它表示：

> 同一个Scenario中的一次具体API调用实例。

## 1. 两个Code职责不同

```text
apiId
    表示调用哪个API

apiCallCode
    表示这个Scenario中的哪一次调用
```

例如同一个`API-001`调用两次：

```json
{
  "apis": [
    {
      "apiCallCode": "CALL-001",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "BEFORE_UPDATE"
      }
    },
    {
      "apiCallCode": "CALL-002",
      "apiId": "API-002",
      "initialValues": {
        "updateType": "NORMAL"
      }
    },
    {
      "apiCallCode": "CALL-003",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "AFTER_UPDATE"
      }
    }
  ]
}
```

这里：

```text
CALL-001 → 第一次调用API-001
CALL-002 → 调用API-002
CALL-003 → 第二次调用API-001
```

`apiId`可以重复，但`apiCallCode`在当前Scenario内不能重复。

# 2. ScenarioContext按`apiCallCode`保存

Context不应该这样保存：

```java
Map<String, Object> responsesByApiId;
```

因为相同API会覆盖。

应该改成：

```java
Map<String, ApiExchange> apiExchanges;
```

其中：

```java
public record ApiExchange(
        String apiCallCode,
        String apiId,
        Object request,
        Object response
) {
}
```

写入：

```java
context.putApiExchange(
        "CALL-001",
        "API-001",
        api01BeforeRequest,
        api01BeforeResponse
);

context.putApiExchange(
        "CALL-003",
        "API-001",
        api01AfterRequest,
        api01AfterResponse
);
```

取得：

```java
Api01Response before =
        context.getResponse(
                "CALL-001",
                Api01Response.class
        );

Api01Response after =
        context.getResponse(
                "CALL-003",
                Api01Response.class
        );
```

这样即使两个Response都是同一个Java类型，也不会混淆。

# 3. Context结构

```text
ScenarioContext
├── input
├── expected
├── baseline
├── apiExchanges
│   ├── CALL-001
│   │   ├── apiId = API-001
│   │   ├── request
│   │   └── response
│   ├── CALL-002
│   │   ├── apiId = API-002
│   │   ├── request
│   │   └── response
│   └── CALL-003
│       ├── apiId = API-001
│       ├── request
│       └── response
└── checkResults
```

不再单独维护：

```text
requests Map
responses Map
```

建议直接统一为：

```text
apiCallCode → ApiExchange
```

因为Request和Response本来就是同一次API调用的一组数据。

# 4. 输出文件也按`apiCallCode`区分

```text
RUN-001/
├── verification-result.json
└── api-calls/
    ├── CALL-001/
    │   ├── api-meta.json
    │   ├── request.json
    │   ├── response.json
    │   └── response-field-diff.json
    ├── CALL-002/
    │   ├── api-meta.json
    │   ├── request.json
    │   ├── response.json
    │   └── response-field-diff.json
    └── CALL-003/
        ├── api-meta.json
        ├── request.json
        ├── response.json
        └── response-field-diff.json
```

`api-meta.json`：

```json
{
  "apiCallCode": "CALL-003",
  "apiId": "API-001",
  "apiName": "会員情報取得API"
}
```

这样文件路径也不会因为相同API被覆盖。

# 5. Baseline也必须按`apiCallCode`

```text
baseline/
├── verification-result.json
└── api-calls/
    ├── CALL-001/
    │   └── response.json
    ├── CALL-002/
    │   └── response.json
    └── CALL-003/
        └── response.json
```

字段比较时：

```java
JsonNode previous =
        baseline.getResponse("CALL-003");

JsonNode current =
        context.getResponse("CALL-003");

ApiFieldDiff diff =
        comparator.compare(previous, current);
```

比较的是：

```text
前回CALL-003
↔
今回CALL-003
```

而不是模糊地比较：

```text
前回API-001
↔
今回API-001
```

# 6. API比较Result Key也对应调用实例

例如：

```text
CALL-001_RESPONSE_COMPARE
CALL-002_RESPONSE_COMPARE
CALL-003_RESPONSE_COMPARE
```

Expected：

```json
{
  "results": [
    {
      "resultKey": "CALL-001_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "apiCallCode": "CALL-001",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "CALL-002_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "apiCallCode": "CALL-002",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "CALL-003_RESPONSE_COMPARE",
      "resultType": "API_RESPONSE_COMPARE",
      "apiCallCode": "CALL-003",
      "expectedResult": "PASS"
    }
  ]
}
```

但业务Check仍然使用独立业务Key：

```text
BEFORE_AFTER_MEMBER_STATUS_CHECK
```

例如：

```java
Api01Response before =
        context.getResponse(
                "CALL-001",
                Api01Response.class
        );

Api01Response after =
        context.getResponse(
                "CALL-003",
                Api01Response.class
        );

CheckResult result =
        memberStatusTransitionCheck.execute(
                before,
                after
        );
```

输出：

```json
{
  "resultKey": "BEFORE_AFTER_MEMBER_STATUS_CHECK",
  "resultType": "BUSINESS_CHECK",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "verificationResult": "PASS"
}
```

# 7. `apiCallCode`的唯一范围

不需要全系统唯一。

只需保证：

```text
同一个UseCase
+
同一个Scenario
```

内部唯一。

完整定位为：

```text
UseCaseId
+
ScenarioId
+
apiCallCode
```

例如：

```text
UC-E6-001 / SC-001 / CALL-003
```

其他Scenario可以再次使用：

```text
CALL-001
CALL-002
```

不会冲突，因为Scenario不同。

# 8. 最终确定

```text
1. apiId标识API定义，可以重复。
2. apiCallCode标识Scenario中的一次API调用，不能重复。
3. 原来的stepKey正式统一为apiCallCode，不再同时保留两个相同职责的字段。
4. ScenarioContext按apiCallCode保存ApiExchange。
5. ApiExchange统一包含apiId、Request、Response。
6. Input JSON按apiCallCode排列API调用。
7. Output和Baseline目录按apiCallCode保存。
8. API字段Diff比较相同apiCallCode的前回与今回Response。
9. API Response Compare Result Key应能明确对应apiCallCode。
10. 业务Check继续使用独立resultKey。
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

```text
本次未新增文件正文。

设计修正：
- 将stepKey正式统一为apiCallCode。
- apiId标识API，apiCallCode标识Scenario内调用实例。
- ScenarioContext改为apiCallCode → ApiExchange。
- Request、Response、Diff和Baseline全部按apiCallCode定位。
- 相同API在同一Scenario内可以安全调用多次。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入apiCallCode与ApiExchange模型】
```

## 第 132 轮

### 你

每个api的reqeust和response的项目呢  不也是ScenarioContext里定义吗 还是说不需要定义

### ChatGPT

不需要把每个API的Request／Response项目，再在`ScenarioContext`里重新定义一遍。

应该分成三层：

```text
API Request／Response项目定义
    由各API的Java DTO或API Schema负责

ScenarioContext
    按apiCallCode保存完整的Request／Response对象

Scenario专用业务数据
    只有跨API处理需要的派生值，才单独定义
```

# 1. API项目应该定义在哪里

例如API1的Request和Response：

```java
public record MemberSearchRequest(
        String memberId,
        String searchType,
        LocalDate businessDate
) {
}
```

```java
public record MemberSearchResponse(
        String memberId,
        String memberName,
        String memberStatus,
        BigDecimal balance
) {
}
```

字段定义属于：

```text
MemberSearchRequest
MemberSearchResponse
```

不是属于`ScenarioContext`。

这样API自己的字段只定义一次。

---

# 2. ScenarioContext只保存对象

```java
public final class ScenarioContext {

    private final String runId;
    private final String useCaseId;
    private final String scenarioId;

    private final ScenarioInput input;

    private final Map<String, ApiExchange<?, ?>> apiExchanges;
    private final Map<String, CurrentCheckResult> checkResults;

    private final ExpectedContext expected;
    private final BaselineContext baseline;
}
```

`ApiExchange`：

```java
public record ApiExchange<REQ, RES>(
        String apiCallCode,
        String apiId,
        REQ request,
        RES response
) {
}
```

保存：

```java
context.putApiExchange(
        new ApiExchange<>(
                "CALL-001",
                "API-001",
                memberSearchRequest,
                memberSearchResponse
        )
);
```

取得：

```java
MemberSearchResponse response =
        context.getResponse(
                "CALL-001",
                MemberSearchResponse.class
        );
```

Context只知道：

```text
CALL-001下面保存了一个Request和一个Response
```

不需要自己再声明：

```text
memberId
memberName
memberStatus
balance
```

---

# 3. 不应该在Context里重复定义API字段

不推荐：

```java
public class ScenarioContext {

    private String api01RequestMemberId;
    private String api01RequestSearchType;

    private String api01ResponseMemberId;
    private String api01ResponseMemberName;
    private String api01ResponseMemberStatus;
    private BigDecimal api01ResponseBalance;

    private String api02RequestMemberId;
    private String api02ResponseResult;
}
```

问题是：

- API字段修改时，DTO和Context都要修改；
- 同一个API调用两次时，字段命名越来越复杂；
- Scenario不同，Context类会无限膨胀；
- 容易把API原始数据和业务派生数据混在一起。

所以Context应该保存整个对象：

```java
context.getRequest("CALL-001", MemberSearchRequest.class);
context.getResponse("CALL-001", MemberSearchResponse.class);
```

---

# 4. 同一个API调用两次也没有问题

例如：

```text
CALL-001：更新前查询
CALL-002：执行更新
CALL-003：更新后查询
```

其中`CALL-001`和`CALL-003`调用的是相同API。

```java
MemberSearchResponse before =
        context.getResponse(
                "CALL-001",
                MemberSearchResponse.class
        );

MemberSearchResponse after =
        context.getResponse(
                "CALL-003",
                MemberSearchResponse.class
        );
```

业务Check：

```java
CurrentCheckResult result =
        memberStatusTransitionCheck.execute(
                before,
                after
        );
```

不会因为Response类型相同而混淆，因为实际定位使用：

```text
apiCallCode
```

---

# 5. Input如何生成API Request对象

Input JSON：

```json
{
  "request": {
    "memberId": "M000001",
    "businessDate": "2026-07-24"
  },
  "apis": [
    {
      "apiCallCode": "CALL-001",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "BEFORE_UPDATE"
      }
    },
    {
      "apiCallCode": "CALL-002",
      "apiId": "API-002",
      "initialValues": {
        "updateType": "NORMAL"
      }
    },
    {
      "apiCallCode": "CALL-003",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "AFTER_UPDATE"
      }
    }
  ]
}
```

Java生成`CALL-001` Request：

```java
MemberSearchRequest request =
        new MemberSearchRequest(
                input.request().memberId(),
                input.getApi("CALL-001")
                        .getString("searchType"),
                input.request().businessDate()
        );
```

调用后保存：

```java
MemberSearchResponse response =
        memberApi.search(request);

context.putApiExchange(
        "CALL-001",
        "API-001",
        request,
        response
);
```

---

# 6. 后续API使用前序Response

例如`CALL-002`需要API1返回的`memberStatus`：

```java
MemberSearchResponse api1 =
        context.getResponse(
                "CALL-001",
                MemberSearchResponse.class
        );

ApiInput api2Input =
        input.getApi("CALL-002");

MemberUpdateRequest request =
        new MemberUpdateRequest(
                api1.memberId(),
                api1.memberStatus(),
                api2Input.getString("updateType")
        );
```

这里：

```text
memberId
memberStatus
```

仍然属于`MemberSearchResponse`。

ScenarioContext只是保存并提供这个对象。

---

# 7. 什么内容需要在Scenario Context中额外定义

只有API Request／Response之外的Scenario运行数据，才有必要单独定义。

例如：

```text
本次处理对象件数
多个API结果计算出的总金额
业务分支判断结果
中间计算结果
并行处理汇总结果
```

可以放到Scenario专用业务数据对象：

```java
public final class MemberUpdateScenarioData {

    private BigDecimal calculatedAmount;
    private int processedCount;
    private String selectedBusinessPath;
}
```

Context中保存：

```java
private final MemberUpdateScenarioData scenarioData;
```

不过如果这些值只在一个Check函数内部使用，也没必要放进Context，直接在函数内部处理即可。

判断标准：

```text
多个后续处理需要共同使用
    放入ScenarioContext的scenarioData

只在当前函数内部使用
    保留在函数局部变量
```

---

# 8. API字段比较如何取得字段

字段比较Java函数读取：

```java
JsonNode previousResponse =
        baseline.getResponseJson(
                "CALL-001"
        );

JsonNode currentResponse =
        context.getResponseJson(
                "CALL-001"
        );
```

然后递归比较所有字段：

```java
ApiFieldDiff diff =
        responseComparator.compare(
                previousResponse,
                currentResponse
        );
```

字段比较不要求ScenarioContext提前列出所有字段。

因为字段信息已经存在于：

```text
Response DTO
或
序列化后的Response JSON
```

推荐：

```text
API调用和业务处理：
    使用强类型Response DTO

通用字段Diff：
    将Response DTO转成JsonNode后递归比较
```

这样兼顾类型安全和通用字段比较。

---

# 9. API字段定义与Schema

每个API最好有独立定义：

```text
API-001
├── MemberSearchRequest.java
├── MemberSearchResponse.java
└── API设计书／Schema

API-002
├── MemberUpdateRequest.java
├── MemberUpdateResponse.java
└── API设计书／Schema
```

它们负责：

- 字段名称；
- 数据类型；
- 嵌套结构；
- 是否允许为空；
- Request和Response结构；
- JSON序列化规则。

ScenarioContext不承担这些职责。

---

# 10. 最终关系

```text
ScenarioContext
│
├── input
│
├── apiExchanges
│   ├── CALL-001
│   │   ├── MemberSearchRequest
│   │   └── MemberSearchResponse
│   │
│   ├── CALL-002
│   │   ├── MemberUpdateRequest
│   │   └── MemberUpdateResponse
│   │
│   └── CALL-003
│       ├── MemberSearchRequest
│       └── MemberSearchResponse
│
├── checkResults
├── expected
├── baseline
└── scenarioData（仅必要时）
```

结论是：

```text
1. Request／Response每个项目必须定义。
2. 但定义在API DTO／API Schema中。
3. ScenarioContext不重复定义每个项目。
4. ScenarioContext按apiCallCode保存完整Request／Response对象。
5. 同一个API调用多次，通过apiCallCode区分。
6. 跨API使用时，从Context取得对应Response对象。
7. 只有Scenario独有的中间业务数据，才放入scenarioData。
8. 通用字段Diff通过Response JSON递归比较，不依赖Context字段清单。
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次未新增文件正文。

本次确认：

```text
- API Request／Response项目定义放在API DTO或API Schema中。
- ScenarioContext不重复定义API字段。
- ScenarioContext按apiCallCode保存完整ApiExchange。
- ApiExchange包含apiId、Request对象和Response对象。
- Scenario专用派生数据仅在必要时定义scenarioData。
- 通用字段Diff基于序列化后的Response JSON执行。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入API DTO、ApiExchange与ScenarioContext职责边界】
```

## 第 133 轮

### 你

那么返回项目的diff json里的变量前后不一样 变量名就是java里的定义的Response吗

### ChatGPT

对，但更准确地说：

> `diff.json`里的字段名，应该使用**API实际Response JSON中的项目名**，而不是直接使用Java类里的成员变量名。

Java的Response DTO只是业务处理时使用的强类型对象。

# 1. 推荐关系

例如API实际返回：

```json
{
  "member_id": "M001",
  "member_status": "ACTIVE",
  "balance": 1000
}
```

Java DTO：

```java
public record MemberResponse(
        @JsonProperty("member_id")
        String memberId,

        @JsonProperty("member_status")
        String memberStatus,

        BigDecimal balance
) {
}
```

这里存在两套名称：

|用途|名称|
|---|---|
|API实际JSON项目名|`member_id`|
|Java变量名|`memberId`|
|API实际JSON项目名|`member_status`|
|Java变量名|`memberStatus`|

`diff.json`应该写：

```json
{
  "path": "$.member_status",
  "previousValue": "ACTIVE",
  "currentValue": "SUSPENDED",
  "changeType": "VALUE_CHANGED"
}
```

而不是：

```json
{
  "path": "$.memberStatus"
}
```

因为字段Diff的目的，是说明：

> 实际API返回报文中的哪个项目发生了变化。

---

# 2. 字段Diff使用什么数据比较

最好同时保存两种Response形态：

```text
原始Response JSON
    用于证据保存和字段Diff

Java Response DTO
    用于后续API构造和业务逻辑判断
```

`ScenarioContext`中的一次API调用可以这样保存：

```java
public record ApiExchange<REQ, RES>(
        String apiCallCode,
        String apiId,
        REQ requestObject,
        JsonNode requestJson,
        JsonNode responseJson,
        RES responseObject
) {
}
```

例如：

```java
ApiExchange<MemberRequest, MemberResponse> exchange =
        new ApiExchange<>(
                "CALL-001",
                "API-001",
                requestObject,
                requestJson,
                responseJson,
                responseObject
        );
```

职责：

|数据|用途|
|---|---|
|`requestObject`|Java业务处理|
|`requestJson`|实际Request证据|
|`responseJson`|字段Diff、实际Response证据|
|`responseObject`|后续API和业务Check|

---

# 3. 字段比较流程

```java
JsonNode previousResponseJson =
        baseline.getResponseJson(
                "CALL-001"
        );

JsonNode currentResponseJson =
        context.getResponseJson(
                "CALL-001"
        );

ApiFieldDiff diff =
        responseComparator.compare(
                previousResponseJson,
                currentResponseJson
        );
```

比较器递归读取JSON字段名：

```text
member_id
member_status
balance
address.postal_code
members[0].member_id
```

生成：

```json
{
  "apiCallCode": "CALL-001",
  "items": [
    {
      "path": "$.member_id",
      "previousValue": "M001",
      "currentValue": "M001",
      "changeType": "UNCHANGED"
    },
    {
      "path": "$.member_status",
      "previousValue": "ACTIVE",
      "currentValue": "SUSPENDED",
      "changeType": "VALUE_CHANGED"
    }
  ]
}
```

因此Diff比较不依赖Java反射读取DTO变量名，而是直接比较实际JSON。

---

# 4. 为什么不能直接使用Java变量名

假设API项目没有变化，只是Java开发人员重构：

之前：

```java
String memberStatus;
```

之后：

```java
@JsonProperty("member_status")
String status;
```

API实际返回仍然是：

```json
{
  "member_status": "ACTIVE"
}
```

如果Diff使用Java变量名，就会错误地认为：

```text
memberStatus被删除
status被新增
```

但实际上API完全没有变化。

如果Diff使用实际Response JSON：

```text
$.member_status
```

就不会出现误判。

所以必须遵守：

```text
Java变量重命名
    不应该造成API字段变化

API JSON项目名变化
    才应该被判定为字段变化
```

---

# 5. 如果API项目名真的发生变化

前回Response：

```json
{
  "member_status": "ACTIVE"
}
```

本次Response：

```json
{
  "status": "ACTIVE"
}
```

默认比较结果应该是两条：

```json
{
  "items": [
    {
      "path": "$.member_status",
      "previousValue": "ACTIVE",
      "currentState": "MISSING",
      "changeType": "ITEM_REMOVED"
    },
    {
      "path": "$.status",
      "previousState": "MISSING",
      "currentValue": "ACTIVE",
      "changeType": "ITEM_ADDED"
    }
  ]
}
```

Java无法仅根据值相同就判断：

```text
member_status
```

和：

```text
status
```

是同一个业务项目。

因为也可能是旧字段删除、新字段新增，只是值碰巧相同。

---

# 6. 已知是改名时怎么处理

如果客户明确说明：

```text
member_status → status
```

属于同一个项目改名，可以在Compare Policy中定义明确映射：

```json
{
  "fieldMappings": [
    {
      "previousPath": "$.member_status",
      "currentPath": "$.status"
    }
  ]
}
```

比较结果可以写：

```json
{
  "previousPath": "$.member_status",
  "currentPath": "$.status",
  "previousValue": "ACTIVE",
  "currentValue": "ACTIVE",
  "changeType": "PATH_RENAMED",
  "valueChanged": false
}
```

但这必须是显式定义。

不能让Java根据字段值自动猜测字段改名。

---

# 7. Response DTO字段名与API项目名的关系

建议API DTO明确使用映射：

```java
public record MemberResponse(
        @JsonProperty("member_id")
        String memberId,

        @JsonProperty("member_status")
        String memberStatus
) {
}
```

这样：

```text
responseJson
    保持API原始项目名

responseObject
    使用Java标准命名

字段Diff
    使用responseJson

业务Check
    使用responseObject
```

业务Check：

```java
MemberResponse response =
        context.getResponse(
                "CALL-001",
                MemberResponse.class
        );

if ("ACTIVE".equals(
        response.memberStatus())) {
    // 业务判断
}
```

字段Diff：

```json
{
  "path": "$.member_status"
}
```

二者不冲突。

---

# 8. 最终确定

```text
1. diff.json的字段路径使用实际API Response JSON项目名。
2. 不直接使用Java DTO成员变量名。
3. Java DTO负责强类型业务处理。
4. 原始Response JSON负责证据保存和字段比较。
5. Java变量改名不会产生API字段Diff。
6. API JSON项目名变化时，默认判定为旧字段删除＋新字段新增。
7. 已确认的字段改名，通过Compare Policy显式映射。
8. 不允许Java根据值相同自动猜测字段对应关系。
```

最终模型是：

```text
ApiExchange
├── requestObject
├── requestJson
├── responseJson      ← 字段Diff使用
└── responseObject    ← 业务逻辑使用
```

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【需要重做】
    ├── Verification_Master.md【需要重做】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【需要重做】
    │   ├── Verification_Master設計書.md【需要重做】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【需要重做】
        ├── Verification_Master_Example.md【需要重做】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次未新增文件正文。

本次确认：

```text
- Diff字段名采用API实际Response JSON项目名。
- Java DTO字段名只用于Java业务代码。
- ScenarioContext的ApiExchange同时保存Response JSON和Response DTO。
- 字段Diff读取Response JSON。
- 业务Check读取Response DTO。
- API字段改名默认表现为删除＋新增。
- 明确的改名关系通过Compare Policy映射。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【未完成／需纳入Response JSON与Response DTO的职责分离】
```

## 第 134 轮

### 你

好的。按照目前的设计 Context_Master  Verification_Master  Verification_Policy_Master Compare_Policy_Master 这些master的第一还需要吗
各个usecase和它的scenario来详细定义。那么master是写什么内容呢

### ChatGPT

现在可以把原则收紧：**Master只保留跨UseCase／Scenario复用、并且需要通过Code引用的内容。** 运行时对象和单个Scenario专用定义，不应再做成Master。

### ChatGPT

对。按照现在已经收敛的设计，这4个Master不应该全部继续保留。

最终判断是：

|文件|是否继续作为Master|结论|
|---|---:|---|
|`Context_Master.md`|否|Context是Scenario运行时对象，不是Master数据|
|`Verification_Master.md`|否|具体Check与Result Key由各Scenario定义，不需要全局登记|
|`Verification_Policy_Master.md`|是|保存所有Scenario共通的验证判定规则|
|`Compare_Policy_Master.md`|是|保存API Response字段Diff的共通比较规则|

因此，真正需要保留的业务规则Master主要是：

```text
Verification_Policy_Master.md
Compare_Policy_Master.md
```

而Context和Verification的“共通结构”仍然需要设计书，但不应该继续叫Master。

---

# 一、什么内容才应该叫Master

一个内容适合作为Master，需要同时满足：

```text
1. 被多个UseCase或Scenario共通使用
2. 内容相对稳定
3. 可以通过Code进行引用
4. 需要集中维护和统一变更
```

例如：

```text
VP-DEFAULT
CP-JSON-DEFAULT
```

多个Scenario都可以引用它们，所以适合作为Master。

相反，下面这些不适合作为Master：

```text
SC-001里调用哪些API
CALL-001保存什么Response
MEMBER_STATUS_CHECK使用什么Java函数
SC-001有哪些Result Key
SC-002需要哪些Context数据
```

因为它们只属于某一个Scenario。

---

# 二、`Context_Master.md`不再需要

## 原来可能想做的内容

以前的`Context_Master.md`可能准备统一登记：

```text
Context ID
Context项目
Context变量名称
Context数据来源
Context保存位置
```

现在这个方向已经不成立。

因为当前设计是：

```text
一个Scenario执行实例
    对应一个ScenarioContext
```

Context中的内容由当前Scenario决定。

例如：

```text
UC-E6-001
└── SC-001
    └── ScenarioContext
        ├── CALL-001 Request／Response
        ├── CALL-002 Request／Response
        ├── Expected
        ├── Baseline
        └── Check Results
```

另一个Scenario可能是：

```text
UC-E6-001
└── SC-002
    └── ScenarioContext
        ├── CALL-001 Request／Response
        ├── CALL-003 Request／Response
        └── Cancel Check Results
```

它们没有必要拥有同一套Context项目。

## 应该怎么处理

根目录的：

```text
Context_Master.md
```

建议取消。

但是共通的Context框架规则仍然需要设计书，例如：

```text
design/ScenarioContext共通設計書.md
```

这个设计书只写：

- 一个Scenario一个Context实例；
- Context生命周期；
- `apiCallCode`定位Request／Response；
- `resultKey`定位Check Result；
- Input、Expected、Baseline如何装载；
- 并行Run之间如何隔离；
- API DTO与Response JSON如何保存；
- Context何时释放；
- 同一个Key禁止重复写入。

它不是Master，只是Framework共通设计。

---

# 三、`Verification_Master.md`不再需要

## 为什么不需要

现在已经确定：

```text
一个Java Check函数
=
一个Result Key
=
一个Expected项目
=
一个Current项目
```

具体有哪些Check，完全由Scenario决定。

例如`SC-001`：

```text
CALL-001_RESPONSE_COMPARE
CALL-001_TYPE_CHECK
CALL-002_RESPONSE_COMPARE
MEMBER_STATUS_BUSINESS_CHECK
```

`SC-002`可能是：

```text
CALL-001_RESPONSE_COMPARE
CALL-003_RESPONSE_COMPARE
CANCEL_RESULT_CHECK
```

如果再用一个全局`Verification_Master.md`登记所有Result Key，就会出现重复维护：

```text
Scenario定义一次
Expected定义一次
Verification Master再定义一次
Java常量再定义一次
```

这反而增加不一致风险。

## Result Key应该在哪里定义

正式定义源建议是Java Check函数：

```java
public final class MemberStatusBusinessCheck {

    public static final String RESULT_KEY =
            "MEMBER_STATUS_BUSINESS_CHECK";

    public CheckResult execute(...) {
        ...
    }
}
```

Scenario设计书中说明这个Check会被执行。

Expected JSON中使用相同Key：

```json
{
  "resultKey": "MEMBER_STATUS_BUSINESS_CHECK",
  "expectedResult": "PASS"
}
```

不需要再登记到全局Verification Master。

## 应该怎么处理

根目录的：

```text
Verification_Master.md
```

建议取消。

但验证结果的共通结构仍然需要设计书，例如：

```text
design/VerificationResult共通設計書.md
```

内容包括：

- Result Key定位原则；
- `API_RESPONSE_COMPARE`与`BUSINESS_CHECK`两类结果；
- Expected／Current／Previous关系；
- 主结果文件格式；
- Field Diff文件引用；
- Result Key重复、缺失、未生成时的处理；
- Batch结果汇总方式；
- 输出顺序规则。

这也是Framework设计，不是Master。

---

# 四、`Verification_Policy_Master.md`需要保留

这个Master保存所有Scenario共通的“验证判定规则”。

它不登记具体的Result Key，也不登记具体业务字段。

## 应该保存的内容

例如：

|Policy Code|规则内容|
|---|---|
|`VP-DEFAULT`|默认验证规则|
|`VP-INITIAL`|初回执行规则|
|`VP-STRICT`|严格验证规则|
|`VP-COMPATIBLE`|兼容性验证规则|

## `VP-DEFAULT`可以定义

```text
Current Result与Expected Result一致
    → Verification Result = PASS

Current Result与Expected Result不一致
    → Verification Result = FAIL

Expected Result不存在
    → BLOCKED

Java未生成Expected中的Result Key
    → BLOCKED

Java生成未定义的Result Key
    → BLOCKED

Result Key重复
    → ERROR
```

还可以包括：

### 初回执行规则

```text
initialExecutionFlg = true
Baseline不存在
    → 允许执行

初回不进行Previous／Current字段变化比较

初回完整执行后
    → 自动生成Baseline
    → initialExecutionFlg改为false
```

### Baseline规则

```text
优先读取固定Baseline

Baseline不存在
    → 根据previousRunId恢复

非初回并且两者均不存在
    → ERROR

完整Run结束后
    → 更新Baseline

执行中断或Response不完整
    → 不更新Baseline
```

### Batch汇总规则

```text
任一Result为ERROR
    → Batch ERROR

无ERROR但存在BLOCKED
    → Batch BLOCKED

无ERROR／BLOCKED但存在FAIL
    → Batch FAIL

全部PASS
    → Batch PASS
```

这些规则是所有Scenario共通的，所以应该保留为Master。

---

# 五、`Compare_Policy_Master.md`需要保留

这个Master专门保存API Response字段级Diff规则。

因为我们已经确定：

```text
API字段比较
和
业务Check
```

是两种不同性质的验证。

因此Compare Policy独立保留是合理的。

## 应该保存的内容

例如：

|Policy Code|用途|
|---|---|
|`CP-JSON-DEFAULT`|默认JSON字段比较|
|`CP-IGNORE-DYNAMIC`|忽略动态日期、时间、UUID|
|`CP-NUMERIC-TOLERANCE`|允许数值误差|
|`CP-ARRAY-BY-KEY`|数组按业务Key对应|
|`CP-STRICT-ORDER`|数组严格按顺序比较|

## 默认比较规则

```text
Previous Response JSON
↔
Current Response JSON
```

字段名采用实际API JSON项目名：

```text
$.member_id
$.member_status
$.members[0].member_id
```

变化类型：

```text
UNCHANGED
VALUE_CHANGED
TYPE_CHANGED
ITEM_ADDED
ITEM_REMOVED
```

## null与不存在必须分开

```text
{
  "memberStatus": null
}
```

和：

```text
{}
```

不能视为相同。

即：

```text
PRESENT_NULL
MISSING
```

是不同状态。

## 数组比较规则

数组是Compare Policy最需要统一的部分。

例如：

```json
{
  "members": [
    {
      "memberId": "M001",
      "status": "ACTIVE"
    },
    {
      "memberId": "M002",
      "status": "STOPPED"
    }
  ]
}
```

可以定义：

```text
CP-ARRAY-BY-MEMBER-ID
    arrayPath = $.members
    matchKey  = memberId
```

这样数组顺序改变时，不会错误地把所有元素都判为变化。

---

# 六、各Scenario详细定义什么

每个UseCase下面的Scenario负责定义实际执行内容。

例如：

```text
UseCase UC-E6-001
└── Scenario SC-001
```

Scenario应定义：

## 1. API执行顺序

```text
CALL-001 → API-001
CALL-002 → API-002
CALL-003 → API-001
```

## 2. Input

```json
{
  "request": {
    "memberId": "M001"
  },
  "apis": [
    {
      "apiCallCode": "CALL-001",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "BEFORE"
      }
    },
    {
      "apiCallCode": "CALL-002",
      "apiId": "API-002",
      "initialValues": {
        "updateType": "NORMAL"
      }
    },
    {
      "apiCallCode": "CALL-003",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "AFTER"
      }
    }
  ]
}
```

## 3. ScenarioContext中使用的数据

不需要列每个API字段，只需要定义：

```text
CALL-001
    MemberSearchRequest
    MemberSearchResponse

CALL-002
    MemberUpdateRequest
    MemberUpdateResponse

CALL-003
    MemberSearchRequest
    MemberSearchResponse
```

以及必要的Scenario专用派生数据。

## 4. Check执行顺序

```text
CALL-001_RESPONSE_COMPARE
CALL-001_TYPE_CHECK
CALL-002_RESPONSE_COMPARE
CALL-003_RESPONSE_COMPARE
MEMBER_STATUS_TRANSITION_CHECK
```

## 5. Expected

```json
{
  "results": [
    {
      "resultKey": "CALL-001_RESPONSE_COMPARE",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "CALL-001_TYPE_CHECK",
      "expectedResult": "PASS"
    },
    {
      "resultKey": "MEMBER_STATUS_TRANSITION_CHECK",
      "expectedResult": "PASS"
    }
  ]
}
```

## 6. 使用哪个Policy

Scenario只引用Master中的Policy Code：

```json
{
  "verificationPolicyCode": "VP-DEFAULT",
  "defaultComparePolicyCode": "CP-JSON-DEFAULT"
}
```

特定API调用需要不同规则时：

```json
{
  "apiCallCode": "CALL-003",
  "comparePolicyCode": "CP-IGNORE-DYNAMIC"
}
```

因此关系是：

```text
Scenario
    定义做什么

Verification Policy Master
    定义结果如何判定

Compare Policy Master
    定义字段如何比较
```

---

# 七、最终职责边界

|内容|定义位置|
|---|---|
|UseCase清单|`UseCase_Master.md`|
|Scenario清单和所属UseCase|`Scenario_Master.md`|
|API调用顺序|各Scenario|
|API初期输入|各Scenario的`input.json`|
|API Request／Response字段|API DTO／API Schema|
|Context实际保存内容|各Scenario Java实现|
|ScenarioContext共通接口|共通设计书|
|具体Result Key|Java Check函数＋Scenario设计|
|Expected Result|各Scenario的`expected.json`|
|验证判定共通规则|`Verification_Policy_Master.md`|
|API字段比较共通规则|`Compare_Policy_Master.md`|
|字段Diff结果|每次Run生成的`response-field-diff.json`|
|Baseline|每次完整Run结束后自动更新|

---

# 八、推荐的最终调整

建议正式调整为：

```text
删除Master属性：
    Context_Master.md
    Verification_Master.md

保留Master：
    Verification_Policy_Master.md
    Compare_Policy_Master.md

保留但改成普通设计书：
    Context_Master設計書.md
        → ScenarioContext共通設計書.md

    Verification_Master設計書.md
        → VerificationResult共通設計書.md
```

目前目录已经冻结，因此这两个删除和两个重命名，在你正式确认之前不直接修改。

---

# 当前 `system/02_master/` 完整文件结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【待确认】
    ├── Verification_Master.md【待确认】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【待确认】
    │   ├── Verification_Master設計書.md【待确认】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【未完成】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【待确认】
        ├── Verification_Master_Example.md【待确认】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【需要重做】
```

## 本次新增或变更

本次没有新增文件正文。

本次提出的结构调整：

```text
1. Context_Master.md建议删除。
2. Verification_Master.md建议删除。
3. Verification_Policy_Master.md继续保留。
4. Compare_Policy_Master.md继续保留。
5. Context共通内容改为ScenarioContext共通设计书。
6. Verification共通内容改为VerificationResult共通设计书。
7. 具体Context、Result Key、Expected全部由各Scenario定义。
```

以上调整目前标记为`待确认`，尚未作为冻结目录变更。

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【需要重做】

重写时需要明确加入：
- 什么内容可以称为Master；
- Master与Scenario详细定义的边界；
- Policy Master的继承与覆盖规则；
- 运行时对象不得登记为Master的规则。
```

## 第 135 轮

### 你

Compare_Policy_Master.md 有啥用  开发的时候java写具体业务逻辑和比较 不是按照这个来的吧

### ChatGPT

你说得对。按照目前已经确定的实现方式，**Java开发具体业务逻辑和比较时，并不应该依赖`Compare_Policy_Master.md`。**

所以，`Compare_Policy_Master.md`现在基本没有必要继续作为Master保留。

# 一、现在实际存在两类比较

## 1. API Response字段Diff

这是Framework的通用Java比较器：

```java
responseDiffComparator.compare(
    previousResponseJson,
    currentResponseJson
);
```

它负责固定行为：

```text
字段相同
字段值变化
字段新增
字段删除
字段类型变化
null与字段不存在的区别
嵌套Object递归比较
Array比较
```

这些应当由Java公共组件实现和测试，不需要每天读取一个Master决定怎么比较。

例如：

```java
public final class JsonResponseDiffComparator {

    public ResponseDiff compare(
            JsonNode previous,
            JsonNode current) {
        // Java通用字段Diff实现
    }
}
```

---

## 2. 业务比较

业务比较完全由各Scenario中的Java Check函数实现：

```java
public CheckResult checkMemberStatus(
        MemberResponse before,
        MemberResponse after) {

    boolean passed =
            "ACTIVE".equals(before.memberStatus())
            && "SUSPENDED".equals(after.memberStatus());

    return result(passed);
}
```

它不应该读取：

```text
Compare_Policy_Master
```

来决定业务逻辑。

因为业务条件应当明确地写在Java代码和Scenario设计中。

---

# 二、原来Compare Policy可能想解决什么

原来考虑`Compare_Policy_Master.md`，主要是为了外部配置这些特殊规则：

```text
忽略日期字段
忽略执行时间
数值允许误差
数组按某个业务Key匹配
字符串Trim后比较
大小写忽略
字段改名前后映射
```

例如：

```text
$.updatedAt → 忽略变化
$.amount → 允许误差0.01
$.members → 按memberId匹配
```

但这里有一个关键判断：

> 这些规则是否需要由运用人员在不修改Java、不重新发布的情况下调整？

如果不需要，那么就没有必要做Master。

---

# 三、按照当前系统，建议删除Compare Policy Master

目前设计是：

```text
API字段Diff共通逻辑
    Java Framework实现

API个别特殊处理
    各Scenario或各API的Java代码实现

业务判断逻辑
    Java Check函数实现
```

因此：

```text
Compare_Policy_Master.md
```

会造成重复定义：

```text
Java写一次
Scenario设计写一次
Compare Policy Master再写一次
```

而且可能发生：

```text
Master写的是一种规则
Java实际实现的是另一种规则
```

最终Java才是真正运行的内容，Master反而容易变成无人维护的文档。

所以建议：

```text
Compare_Policy_Master.md
    删除

Compare_Policy_Master_Example.md
    删除

Compare_Policy_Master設計書.md
    不再作为Master设计书
```

---

# 四、共通Diff规则仍然需要设计书

删除Master不等于不设计字段Diff。

建议把：

```text
design/Compare_Policy_Master設計書.md
```

改为普通设计书：

```text
design/APIレスポンスDiff共通設計書.md
```

它只说明Java Framework怎么工作，不提供可运行的Master数据。

内容包括：

- Previous Response JSON与Current Response JSON的取得；
- 使用实际JSON项目名比较；
- `VALUE_CHANGED`、`ITEM_ADDED`、`ITEM_REMOVED`等变化类型；
- `null`和字段不存在的区别；
- Object递归比较；
- Array默认比较方式；
- Diff JSON输出格式；
- 初回执行时不执行前后比较；
- Baseline取得方式；
- Diff文件和主要结果文件分离；
- 比较异常时的处理。

这是一份**实现设计书**，不是Master。

---

# 五、个别API的特殊比较怎么办

例如某个API的：

```text
updatedAt
requestId
processingTime
```

每次必然不同，需要忽略。

可以直接在该API调用的Java比较函数中定义：

```java
private static final Set<String> IGNORE_PATHS =
        Set.of(
            "$.updatedAt",
            "$.requestId",
            "$.processingTime"
        );
```

调用：

```java
ResponseDiff diff =
        responseDiffComparator.compare(
                previous,
                current,
                IGNORE_PATHS
        );
```

或者Scenario中明确调用专用比较器：

```java
memberSearchResponseComparator.compare(
        previous,
        current
);
```

这些内容应当归属于：

```text
具体API
或
具体Scenario
```

而不是全局Master。

---

# 六、多个Scenario共用特殊规则怎么办

多个Scenario需要忽略相同字段时，可以复用Java类：

```java
public final class CommonDynamicFieldPolicy {

    public static final Set<String> COMMON_IGNORE_PATHS =
            Set.of(
                "$.requestId",
                "$.executionTimestamp"
            );
}
```

或者复用比较器：

```java
commonApiResponseComparator.compare(
        previous,
        current
);
```

Java公共类已经能够实现复用，不一定非要建立Master。

---

# 七、什么时候才需要Compare Policy Master

只有下面情况成立时，才值得保留：

```text
运用人员需要修改比较规则
并且
不允许修改Java
并且
不需要重新Build和发布
```

例如运用人员需要通过配置马上增加：

```text
忽略$.updatedAt
```

那才需要外部配置文件。

但即便如此，也更像：

```text
Scenario专用compare-config.json
```

而不是全系统的Master。

例如：

```json
{
  "apiCallCode": "CALL-001",
  "ignorePaths": [
    "$.updatedAt",
    "$.requestId"
  ]
}
```

按照我们目前追求的简单实现，这一层暂时也没有必要加入。

---

# 八、最终建议

现在可以正式调整为：

|原文件|处理建议|
|---|---|
|`Compare_Policy_Master.md`|删除|
|`Compare_Policy_Master_Example.md`|删除|
|`Compare_Policy_Master設計書.md`|改为`APIレスポンスDiff共通設計書.md`|

最终职责：

```text
API Response字段Diff
    Java Framework共通比较器

API个别忽略和特殊比较
    API或Scenario Java代码

业务比较
    Scenario Java Check函数

Diff输出格式
    APIレスポンスDiff共通設計書

不再需要
    Compare Policy Master
```

结论就是：

> **Compare Policy不应该成为Java业务实现的驱动Master。当前设计下应删除Master，只保留API Response Diff的Java共通设计。**

---

# 当前 `system/02_master/` 完整文件结构与状态

以下仍是当前冻结结构，删除和重命名尚未正式执行：

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【待确认】
    ├── Verification_Master.md【待确认】
    ├── Verification_Policy_Master.md【需要重做】
    ├── Compare_Policy_Master.md【待确认】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【待确认】
    │   ├── Verification_Master設計書.md【待确认】
    │   ├── Verification_Policy_Master設計書.md【需要重做】
    │   └── Compare_Policy_Master設計書.md【待确认】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【待确认】
        ├── Verification_Master_Example.md【待确认】
        ├── Verification_Policy_Master_Example.md【需要重做】
        └── Compare_Policy_Master_Example.md【待确认】
```

## 本次新增或变更

本次没有新增文件正文。

本次结构调整建议：

```text
1. Compare_Policy_Master.md建议删除。
2. Compare_Policy_Master_Example.md建议删除。
3. Compare_Policy_Master設計書.md建议改名为APIレスポンスDiff共通設計書.md。
4. API字段Diff规则由Java Framework实现。
5. API个别特殊比较由API或Scenario Java实现。
6. 业务比较继续由各Java Check函数实现。
7. 当前变更尚未冻结，相关文件状态改为待确认。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【需要重做】

重写时应明确规定：
- Java实现规则不能重复登记为Master；
- 运行时比较逻辑不属于Master；
- 只有需要跨Scenario集中维护并由Code引用的数据才允许成为Master。
```

## 第 136 轮

### 你

Verification_Policy_Master設計書.md  里面是来说明初回那些规则的吗 初回确实是共通  但是还是不是很清楚这个文件存在的意义

### ChatGPT

你的疑问是对的。

`Verification_Policy_Master設計書.md`原本的定位应该是：

> 说明`Verification_Policy_Master.md`这个Master有哪些项目、Policy Code怎么定义、Scenario如何引用、覆盖优先级是什么。

它并不是专门写“初回执行规则”的文件。

但按照现在的实现方式，**这个Master及其设计书都没有足够的存在意义**。

# 一、初回执行不是Master数据

初回执行规则目前已经确定为固定Framework逻辑：

```text
initialExecutionFlg = true
    → 允许Baseline不存在
    → 不做Previous／Current字段Diff
    → 本次完整执行后生成Baseline
    → 将initialExecutionFlg更新为false

initialExecutionFlg = false
    → 优先读取Baseline
    → Baseline不存在时按previousRunId恢复
    → 两者都不存在时ERROR
```

这些规则：

- 不是由Scenario选择；
- 不是由运用人员修改；
- 不是通过Policy Code切换；
- 不是每个UseCase都不一样；
- 最终直接由Java Framework实现。

所以它应该写在：

```text
初回実行・Baseline管理共通設計
```

或者并入：

```text
RunContext／ExecutionState共通設計
```

而不是写成Master。

---

# 二、什么情况下才需要Verification Policy Master

只有系统支持多套验证模式时，才需要Master。

例如：

```text
VP-STRICT
    Current必须与Expected完全一致

VP-WARNING
    不一致只输出WARNING，不判FAIL

VP-NO-PREVIOUS-COMPARE
    不比较Previous，只比较Expected

VP-MONITORING
    API字段变化只记录，不影响Batch结果
```

然后Scenario引用：

```json
{
  "verificationPolicyCode": "VP-STRICT"
}
```

Java在运行时读取：

```java
VerificationPolicy policy =
        verificationPolicyRepository.load(
                "VP-STRICT"
        );
```

这种情况下：

```text
Verification_Policy_Master.md
```

才有意义，因为它真的驱动运行行为。

但当前设计不是这样。

当前设计是：

```text
Expected比较方式固定
Result Key检查方式固定
初回规则固定
Baseline规则固定
Batch汇总方式固定
```

Java不需要从Master加载这些规则。

因此做一个Policy Master，只会变成对Java实现的重复说明。

---

# 三、当前所谓“Verification Policy”实际包含什么

我们之前讨论的内容大致有：

## 1. Expected判定

```text
Current = Expected
    → PASS

Current ≠ Expected
    → FAIL
```

## 2. Result Key完整性

```text
Expected有，但Java未生成
    → BLOCKED

Java生成，但Expected未定义
    → BLOCKED

Result Key重复
    → ERROR
```

## 3. 初回执行

```text
初回无Baseline
    → 允许执行
```

## 4. Baseline管理

```text
完整Run结束后更新Baseline
异常Run不更新Baseline
```

## 5. Batch汇总

```text
存在ERROR → Batch ERROR
存在BLOCKED → Batch BLOCKED
存在FAIL → Batch FAIL
全部正常 → Batch PASS
```

这些全部都是：

> **验证Framework的固定行为。**

它们应该进入普通共通设计书，而不是Master。

---

# 四、正确的文件定位

建议删除：

```text
Verification_Policy_Master.md
Verification_Policy_Master_Example.md
```

将：

```text
design/Verification_Policy_Master設計書.md
```

改为普通设计书，例如：

```text
design/検証判定共通設計書.md
```

这份设计书说明Java Framework的固定规则。

## `検証判定共通設計書.md`应包含

```text
1. Current／Expected判定规则
2. Previous／Current变化显示规则
3. Result Key完整性检查
4. API Response Compare与Business Check的区别
5. 初回执行处理
6. Baseline取得与更新
7. Batch最终结果汇总
8. PASS／FAIL／BLOCKED／ERROR定义
9. 结果文件输出结构
10. 异常时是否继续后续API
```

它是：

```text
Java实现规格
```

不是：

```text
运行时Master数据
```

---

# 五、与其他设计书的边界

为了避免再次重复，推荐这样划分。

## `ScenarioContext共通設計書.md`

负责：

```text
Context生命周期
apiCallCode
ApiExchange
Request／Response DTO
Response JSON
Expected装载
Baseline装载
Result保存
```

## `APIレスポンスDiff共通設計書.md`

负责：

```text
Previous Response JSON与Current Response JSON比较
字段路径
新增／删除／值变化／类型变化
Diff JSON输出
```

## `検証判定共通設計書.md`

负责：

```text
Current与Expected如何判定
Result Key不一致如何处理
Batch结果如何汇总
初回时验证结果如何处理
```

## `Baseline管理共通設計書.md`
也可以并入RunContext设计书，负责：

```text
initialExecutionFlg
previousRunId
Baseline固定路径
Baseline恢复
Baseline复制时点
异常Run不更新Baseline
```

这样每份设计书职责明确，不需要Policy Master。

---

# 六、最终结论

`Verification_Policy_Master設計書.md`不是单纯说明初回执行规则。

它本来应该说明：

```text
Verification Policy Master如何建立和引用
```

但当前系统没有多套可选择Policy，Java也不会读取Policy Master，所以：

> **`Verification_Policy_Master.md`不需要，`Verification_Policy_Master設計書.md`也不应该继续作为Master设计书存在。**

应该调整为：

```text
删除：
    Verification_Policy_Master.md
    Verification_Policy_Master_Example.md

改名：
    Verification_Policy_Master設計書.md
        ↓
    検証判定共通設計書.md
```

初回执行规则只是其中一部分，也可以进一步放到：

```text
Baseline／ExecutionState共通設計
```

最核心的判断标准是：

```text
规则由JSON／Master驱动Java
    → 需要Master

规则直接固定实现于Java Framework
    → 只需要共通设计书，不需要Master
```

当前属于后者。

---

# 当前 `system/02_master/` 完整文件结构与状态

以下是当前冻结结构，尚未执行删除或改名：

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【待确认】
    ├── Verification_Master.md【待确认】
    ├── Verification_Policy_Master.md【待确认】
    ├── Compare_Policy_Master.md【待确认】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【待确认】
    │   ├── Verification_Master設計書.md【待确认】
    │   ├── Verification_Policy_Master設計書.md【待确认】
    │   └── Compare_Policy_Master設計書.md【待确认】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【待确认】
        ├── Verification_Master_Example.md【待确认】
        ├── Verification_Policy_Master_Example.md【待确认】
        └── Compare_Policy_Master_Example.md【待确认】
```

## 本次新增或变更

本次未新增文件正文。

本次结构判断：

```text
1. Verification_Policy_Master.md建议删除。
2. Verification_Policy_Master_Example.md建议删除。
3. Verification_Policy_Master設計書.md建议改为検証判定共通設計書.md。
4. 初回执行属于Framework固定规则，不属于Master数据。
5. Baseline管理规则可以放入RunContext／ExecutionState共通设计。
6. 当前调整尚未正式冻结。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【需要重做】

需要重新明确：
- Master必须实际被Java或配置引用；
- 固定Framework行为不得伪装成Master；
- 单纯说明Java实现规则的文件属于共通设计书。
```

## 第 137 轮

### 你

按照今天我们对话内容 设计书还需要增加和删除什么

### ChatGPT

今天的讨论已经足够把设计书结构重新收敛。我会按“必须独立成册、可以合并、应删除”三类整理，避免再次把Java固定逻辑误做成Master。

### ChatGPT

按照今天已经确定的实现方式，设计书应当做一次明显收敛：

> **Master只管理真正需要集中维护的定义；Input、Context、Expected、Diff、Baseline等属于执行设计，移动到各自设计目录，不再伪装成Master。**

# 一、结论：需要删除、改造、新增哪些设计书

## 1. 从 `02_master/design/` 删除的4份设计书

|当前文件|处理|
|---|---|
|`Context_Master設計書.md`|删除Master属性，内容迁移到`05_run_context/ScenarioContext設計書.md`|
|`Verification_Master設計書.md`|删除Master属性，内容并入`06_verification_assets/検証結果・Expected設計書.md`|
|`Verification_Policy_Master設計書.md`|删除Master属性，判定规则并入`検証結果・Expected設計書.md`|
|`Compare_Policy_Master設計書.md`|删除Master属性，改为`06_verification_assets/APIレスポンスDiff設計書.md`|

这4份不是完全不要内容，而是：

```text
不再作为Master设计书
↓
移动并改造成普通Java执行设计书
```

---

# 二、需要新增的设计书

今天讨论后，真正需要新增或重新独立整理的是5份。

## 1. `04_usecase_design/Scenario入力データ設計書.md`

负责`input.json`：

- 顶层`request`；
- `apis`数组；
- API调用顺序；
- `apiCallCode`；
- `apiId`；
- `initialValues`；
- 前序API Response不写入Input；
- 后续Request由Java组合Input与前序Response；
- Input不定义业务分支；
- 一个Scenario原则上对应一条确定执行路径。

示例结构：

```json
{
  "request": {
    "memberId": "M001"
  },
  "apis": [
    {
      "apiCallCode": "CALL-001",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "BEFORE"
      }
    }
  ]
}
```

---

## 2. `05_run_context/ScenarioContext設計書.md`

负责运行中的ScenarioContext：

- 一个Scenario执行实例对应一个Context；
- 不使用全系统统一Context ID；
- `apiCallCode`区分同一API的多次调用；
- `ApiExchange`结构；
- Request DTO；
- Response DTO；
- Request JSON；
- Response JSON；
- `resultKey`保存Check结果；
- 不同Run的Context隔离；
- Context生命周期；
- Context结束后的释放。

核心模型：

```text
ScenarioContext
├── input
├── baseline
├── expected
├── apiExchanges
│   ├── CALL-001
│   │   ├── requestObject
│   │   ├── requestJson
│   │   ├── responseObject
│   │   └── responseJson
│   └── CALL-002
└── checkResults
```

---

## 3. `05_run_context/ExecutionState・Baseline管理設計書.md`

负责：

- `initialExecutionFlg`；
- `previousRunId`；
- 固定Baseline路径；
- 初回执行；
- 非初回Baseline缺失；
- 从`previousRunId`恢复Baseline；
- Baseline复制时点；
- Batch完整结束后统一更新；
- API Error或Run不完整时不更新；
- 临时目录与原子替换；
- Baseline更新后才更新状态文件。

核心顺序：

```text
读取旧Baseline
→ 执行Scenario
→ 写完本次Run
→ 检查Run完整性
→ 替换Baseline
→ 更新previousRunId
→ 初回Flg设为false
```

初回规则只写在这里，不需要Verification Policy Master。

---

## 4. `06_verification_assets/検証結果・Expected設計書.md`

这份由原来的：

```text
Verification_Master設計書
+
Verification_Policy_Master設計書
```

合并而来。

负责：

- `expected.json`结构；
- `verification-result.json`结构；
- 一个Java Check函数对应一个`resultKey`；
- API比较和业务Check两种结果类型；
- Current与Expected比较；
- Previous与Current变化显示；
- Result Key重复；
- Expected Key未生成；
- Java生成未知Key；
- PASS／FAIL／BLOCKED／ERROR；
- Batch汇总；
- Java输出顺序；
- Batch结果最后计算、文件顶部显示；
- 字段Diff文件引用。

不需要拆成两本，因为：

```text
Expected结构
验证结果结构
验证判定规则
```

三者高度相关，拆开反而重复。

---

## 5. `06_verification_assets/APIレスポンスDiff設計書.md`

由原来的：

```text
Compare_Policy_Master設計書.md
```

改造而来。

负责Java通用字段Diff：

- Previous Response JSON；
- Current Response JSON；
- 使用API实际JSON字段名；
- 不使用Java DTO变量名；
- Object递归比较；
- Array比较；
- `null`和字段不存在的区别；
- 字段新增；
- 字段删除；
- 值变化；
- 类型变化；
- `response-field-diff.json`结构；
- 初回时不进行前后比较；
- Diff文件与主要验证结果文件分离。

它说明Java怎么实现，不提供运行时Policy Master。

---

# 三、不需要单独增加的设计书

为了避免再次过度拆分，以下内容不需要独立成册。

## 1. 不单独建立 `ApiExchange設計書`

并入：

```text
ScenarioContext設計書.md
```

因为`ApiExchange`就是Context内部结构。

## 2. 不单独建立 `Expected設計書`

并入：

```text
検証結果・Expected設計書.md
```

Expected和Current Result通过`resultKey`对应，分开容易重复。

## 3. 不单独建立 `初回実行設計書`

并入：

```text
ExecutionState・Baseline管理設計書.md
```

初回Flg的主要作用就是控制Baseline不存在时的处理。

## 4. 不单独建立 `Verification Policy設計書`

固定判定规则直接并入：

```text
検証結果・Expected設計書.md
```

Java不会读取Policy Master，就不需要Policy设计书。

## 5. 不单独建立 `Compare Policy設計書`

字段Diff共通规则直接写入：

```text
APIレスポンスDiff設計書.md
```

API个别特殊比较由API或Scenario Java实现。

---

# 四、API Request／Response项目定义放在哪里

不增加Context字段定义书。

API字段继续由：

```text
03_api_design/
└── 各API設計書
```

以及Java DTO定义。

例如：

```text
MemberSearchRequest
MemberSearchResponse
MemberUpdateRequest
MemberUpdateResponse
```

负责：

- JSON字段名；
- Java字段名；
- 类型；
- 必填；
- 长度；
- 嵌套结构；
- 序列化规则。

ScenarioContext只保存对象，不重复声明字段。

---

# 五、整理后的设计书职责关系

```text
03_api_design/
└── 各API設計書
    └── Request／Response项目定义

04_usecase_design/
├── 各UseCase・Scenario設計書
└── Scenario入力データ設計書
    └── input.json

05_run_context/
├── ScenarioContext設計書
│   └── apiCallCode・ApiExchange・DTO・JSON
└── ExecutionState・Baseline管理設計書
    └── 初回Flg・previousRunId・Baseline更新

06_verification_assets/
├── 検証結果・Expected設計書
│   └── resultKey・Expected・Current・Batch判定
└── APIレスポンスDiff設計書
    └── 字段级Previous／Current Diff

07_report/
└── Report設計書
    └── 展示主要结果与Diff引用
```

---

# 六、`02_master`最终应该保留什么设计书

`02_master/design/`只保留真正的Master设计书：

```text
Master共通設計書.md
Business_Master設計書.md
Environment_Master設計書.md
API_Master設計書.md
UseCase_Master設計書.md
Scenario_Master設計書.md
API・UseCase・Scenario対応表設計書.md
```

以下4份不再属于`02_master/design/`：

```text
Context_Master設計書.md
Verification_Master設計書.md
Verification_Policy_Master設計書.md
Compare_Policy_Master設計書.md
```

---

# 七、与设计书联动删除的Master文件

既然Java不会读取这些Master，根目录对应文件也应删除：

```text
Context_Master.md
Verification_Master.md
Verification_Policy_Master.md
Compare_Policy_Master.md
```

对应Example也删除：

```text
Context_Master_Example.md
Verification_Master_Example.md
Verification_Policy_Master_Example.md
Compare_Policy_Master_Example.md
```

删除原因分别是：

|文件|原因|
|---|---|
|Context Master|Context由每个Scenario运行时创建|
|Verification Master|Result Key由Scenario和Java Check定义|
|Verification Policy Master|判定规则固定在Java Framework|
|Compare Policy Master|Diff逻辑固定在Java或API专用比较器|

---

# 八、今天讨论后建议的变更总数

## 删除Master及Example

```text
4个Master
4个Example
```

## 从`02_master/design`移除

```text
4份Master设计书
```

## 新增普通设计书

```text
5份
```

分别是：

```text
Scenario入力データ設計書.md
ScenarioContext設計書.md
ExecutionState・Baseline管理設計書.md
検証結果・Expected設計書.md
APIレスポンスDiff設計書.md
```

其中并不是净增加5本，因为4份旧Master设计书的内容被重组到了新设计书里。

真正净新增的主题主要只有两个：

```text
Scenario入力データ設計
ExecutionState・Baseline管理設計
```

其他三份主要是原有内容的重新定位和合并。

---

# 当前 `system/02_master/` 完整文件结构与状态

以下是当前冻结结构。今天讨论出的删除、迁移和改名尚未正式应用，因此相关文件统一标为`待确认`。

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【待确认】
    ├── Verification_Master.md【待确认】
    ├── Verification_Policy_Master.md【待确认】
    ├── Compare_Policy_Master.md【待确认】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【待确认】
    │   ├── Verification_Master設計書.md【待确认】
    │   ├── Verification_Policy_Master設計書.md【待确认】
    │   └── Compare_Policy_Master設計書.md【待确认】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【待确认】
        ├── Verification_Master_Example.md【待确认】
        ├── Verification_Policy_Master_Example.md【待确认】
        └── Compare_Policy_Master_Example.md【待确认】
```

# 本次新增或变更

本次没有生成文件正文。

本次整理出的结构变更候选：

```text
删除：
- Context_Master.md
- Verification_Master.md
- Verification_Policy_Master.md
- Compare_Policy_Master.md
- 上述4个Example
- 上述4个Master设计书名称与定位

新增／迁移：
- 04_usecase_design/Scenario入力データ設計書.md
- 05_run_context/ScenarioContext設計書.md
- 05_run_context/ExecutionState・Baseline管理設計書.md
- 06_verification_assets/検証結果・Expected設計書.md
- 06_verification_assets/APIレスポンスDiff設計書.md
```

# 下一份计划文件

下一步首先应该重写：

```text
system/02_master/design/Master共通設計書.md
【需要重做】
```

这份必须先明确：

```text
什么是Master
什么不是Master
Java固定实现不得重复做成Master
Scenario专用定义不得进入全局Master
Master与各设计目录之间的职责边界
```

完成它以后，才能正式删除上述4组Master文件并冻结新的目录结构。

## 第 138 轮

### 你

总结一下 我们开始17点之后讨论的内容

### ChatGPT

下面总结我们今天17点以后围绕API验证Batch讨论并基本确认的设计内容。

# 一、整体执行模型

最终收敛为：

```text
一个UseCase
└── 多个Scenario

一个Scenario
└── 一次同步Java Batch执行
```

每个Scenario由Java按照确定顺序：

```text
读取Input
→ 加载Expected
→ 加载Baseline
→ 调用API
→ 保存Request／Response
→ 生成API字段Diff
→ 执行业务Check
→ 生成主要验证结果
→ Batch结束时更新Baseline
```

结果顺序直接使用Java执行顺序，不增加`sequence`或`displayOrder`。

Batch汇总结果最后计算，但在结果文件顶部显示。

---

# 二、API调用验证和业务验证必须分开

我们明确了两类验证不是一回事。

## 1. API本身的Response比较

负责回答：

```text
API返回的每个项目有没有变化
前回值是什么
本次值是什么
字段新增、删除、类型变化还是值变化
```

需要生成字段级Diff明细。

例如：

```json
{
  "path": "$.member_status",
  "previousValue": "ACTIVE",
  "currentValue": "SUSPENDED",
  "changeType": "VALUE_CHANGED"
}
```

## 2. API之后的业务Check

负责回答：

```text
这些返回值在业务上是否正确
跨API的数据是否整合
数值、状态、件数是否符合业务条件
```

业务逻辑全部由Java函数实现。

一个独立业务Check：

```text
一个Java函数
=
一个resultKey
=
一个Expected项目
=
一个Current结果
```

业务Check不需要再详细输出所有字段前后值，只需要一个综合结果，失败时附加简要`details`。

---

# 三、主要结果文件与字段Diff文件分开

最终决定不把大量字段Diff塞进主要结果文件。

## 主要文件

```text
verification-result.json
```

保存：

- Batch总结；
- API Response比较总结；
- 业务Check结果；
- Expected对比结果；
- 字段Diff文件引用。

例如：

```json
{
  "resultKey": "CALL-001_RESPONSE_COMPARE",
  "resultType": "API_RESPONSE_COMPARE",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "verificationResult": "PASS",
  "fieldDiffRef": "api-calls/CALL-001/response-field-diff.json"
}
```

## 字段明细文件

每个API调用单独生成：

```text
api-calls/CALL-001/response-field-diff.json
api-calls/CALL-002/response-field-diff.json
```

保存每个Response字段的：

```text
previousValue
currentValue
changeType
```

---

# 四、Diff字段名使用API实际JSON项目名

字段Diff不使用Java DTO成员变量名，而使用API实际Response JSON中的项目名。

例如API实际返回：

```json
{
  "member_status": "ACTIVE"
}
```

Java DTO可以是：

```java
@JsonProperty("member_status")
String memberStatus;
```

Diff仍然写：

```text
$.member_status
```

不写：

```text
$.memberStatus
```

这样Java变量改名不会被误判为API字段变化。

最终职责：

```text
Response JSON
    用于证据保存和字段Diff

Response DTO
    用于后续API构造和业务判断
```

---

# 五、Result Key和字段Path的区别

## Result Key

用于正式对应：

```text
Expected
Previous Result
Current Result
Report
```

例如：

```text
CALL-001_RESPONSE_COMPARE
MEMBER_STATUS_BUSINESS_CHECK
```

## Field Path

只用于API字段变化定位：

```text
$.member_id
$.member_status
$.members[0].member_id
```

一个API比较`resultKey`下面可以有很多字段Path，但字段Path不生成独立Expected Key。

---

# 六、Expected设计

Expected只保存：

```text
这个Java Check预期是PASS还是FAIL
```

不保存：

- 具体业务规则；
- 字段允许值；
- 业务公式；
- API字段的前回值；
- API字段的期待值；
- Java判断逻辑。

例如：

```json
{
  "resultKey": "MEMBER_STATUS_BUSINESS_CHECK",
  "expectedResult": "PASS"
}
```

业务规则仍由Java实现。

Expected和Java生成结果通过`resultKey`对应。

---

# 七、Input JSON设计

我们重新确认了`input.json`的作用：

> 保存本次Scenario执行所需的外部初期输入值。

它不负责定义：

- 业务分支；
- 前后API字段映射；
- Expected；
- Baseline；
- 比较规则；
- 业务判断规则。

推荐结构：

```json
{
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-001",
  "environmentId": "test",
  "inputSetId": "INPUT-001",

  "request": {
    "memberId": "M001",
    "businessDate": "2026-07-24"
  },

  "apis": [
    {
      "apiCallCode": "CALL-001",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "BEFORE"
      }
    },
    {
      "apiCallCode": "CALL-002",
      "apiId": "API-002",
      "initialValues": {
        "updateType": "NORMAL"
      }
    }
  ]
}
```

## 顶层`request`

保存Batch入口或多个API共用的初期输入。

## `apis`

按照API实际执行顺序排列。

每个API只写它需要外部指定的初期值。

前面API返回的值不重复写入`input.json`，由Java从ScenarioContext取得。

---

# 八、一个Scenario原则上对应一条确定路径

不建议在`input.json`中写业务分支，例如：

```text
ACTIVE走API2
SUSPENDED走API3
```

业务分支由Java处理。

更推荐：

```text
SC-001：CALL-001 → CALL-002
SC-002：CALL-001 → CALL-003
```

即一个Scenario对应一条明确的API调用路径。

---

# 九、ScenarioContext设计

Context不再使用全系统统一的`Context ID`。

最终原则：

```text
一次Scenario执行
=
一个ScenarioContext实例
```

Context内容根据当前UseCase中的Scenario决定。

不同Scenario可以有不同的API调用和业务数据。

Framework只统一：

- Context生命周期；
- Input装载；
- Expected装载；
- Baseline装载；
- Request／Response保存；
- Check Result保存；
- Run之间的实例隔离。

---

# 十、相同API多次调用的区分

同一个Scenario可能多次调用同一个API，所以仅使用`apiId`不够。

我们将原来的`stepKey`正式收敛为：

```text
apiCallCode
```

职责：

```text
apiId
    表示调用哪个API

apiCallCode
    表示当前Scenario中的哪一次具体调用
```

例如：

```text
CALL-001 → API-001 更新前查询
CALL-002 → API-002 执行更新
CALL-003 → API-001 更新后查询
```

`apiId`可以重复。

`apiCallCode`在同一个Scenario内必须唯一。

完整定位范围：

```text
UseCaseId
+
ScenarioId
+
apiCallCode
```

---

# 十一、ApiExchange设计

ScenarioContext不需要逐字段定义每个API的Request和Response项目。

API字段定义属于：

```text
Request DTO
Response DTO
API Schema
API设计书
```

ScenarioContext只按`apiCallCode`保存完整调用对象：

```text
apiCallCode → ApiExchange
```

例如：

```java
public record ApiExchange<REQ, RES>(
    String apiCallCode,
    String apiId,
    REQ requestObject,
    JsonNode requestJson,
    RES responseObject,
    JsonNode responseJson
) {
}
```

职责：

|内容|用途|
|---|---|
|`requestObject`|Java处理|
|`requestJson`|实际请求证据|
|`responseObject`|后续API和业务Check|
|`responseJson`|字段Diff和实际Response证据|

Context不重复声明：

```text
memberId
memberStatus
balance
```

这些字段只在API DTO和Schema中定义一次。

---

# 十二、初回执行设计

使用简单的：

```json
{
  "initialExecutionFlg": true
}
```

初回：

```text
Baseline可以不存在
不做Previous／Current字段Diff
正常调用API
正常执行业务Check
完整执行后生成Baseline
最后把initialExecutionFlg改为false
```

第二次以后：

```text
initialExecutionFlg = false
```

Baseline不存在就属于异常，但先允许通过`previousRunId`恢复。

---

# 十三、前回结果不按日期定位

我们明确：

> 前回不能通过日期、目录名或文件更新时间查找。

正常优先读取固定Baseline路径。

Baseline缺失时读取执行状态文件：

```json
{
  "initialExecutionFlg": false,
  "previousRunId": "RUN-c91452ab"
}
```

然后准确读取：

```text
runs/RUN-c91452ab/
```

禁止：

```text
查找昨天目录
按时间排序
找最新文件
扫描全部Run猜测前回
```

日期只用于审计和显示，不参与定位。

---

# 十四、Baseline复制时点

Baseline不能在单个API执行结束后更新。

必须：

```text
整个Scenario Batch完整执行
→ 所有Request／Response落盘
→ Diff文件生成
→ verification-result.json生成
→ 检查Run完整
→ 统一替换Baseline
```

原因是避免出现：

```text
CALL-001来自本次Run
CALL-002仍来自上一次Run
```

Baseline必须全部来自同一个完整Run。

---

# 十五、哪些结果可以更新Baseline

Baseline表示：

> 前一次完整执行的实际结果。

因此：

|本次情况|更新Baseline|
|---|---:|
|业务Check全部PASS|是|
|业务Check有FAIL，但API Response完整|是|
|Expected验证为FAIL，但Run完整|是|
|字段发生变化|是|
|API调用ERROR|否|
|Response解析失败|否|
|Batch中断|否|
|输出文件不完整|否|

Baseline不是“前一次正确结果”，而是“前一次完整实际结果”。

更新顺序：

```text
保存完整Run
→ 替换Baseline
→ 更新previousRunId
→ 初回Flg改为false
```

状态文件最后更新。

---

# 十六、Master是否继续保留的结论

我们重新确定了Master的判断标准。

只有满足以下条件才应该作为Master：

```text
多个UseCase／Scenario共用
内容需要集中维护
通过Code或配置引用
运行时确实会读取
```

按照当前Java固定实现方式，以下4个不再适合作为Master：

```text
Context_Master
Verification_Master
Verification_Policy_Master
Compare_Policy_Master
```

原因：

|原Master|为什么不需要|
|---|---|
|Context Master|Context由每个Scenario运行时创建|
|Verification Master|Result Key由Java Check和Scenario定义|
|Verification Policy Master|判定规则固定在Java Framework|
|Compare Policy Master|字段Diff由Java比较器实现|

---

# 十七、原Master设计书如何处理

不代表设计内容全部不要，而是取消Master属性并重新归类。

建议删除或迁移：

```text
Context_Master設計書.md
Verification_Master設計書.md
Verification_Policy_Master設計書.md
Compare_Policy_Master設計書.md
```

重组为普通执行设计书。

---

# 十八、今天讨论后需要的5份普通设计书

## 1. `Scenario入力データ設計書.md`

位置候选：

```text
04_usecase_design/
```

负责`input.json`：

- 顶层request；
- apis数组；
- apiCallCode；
- apiId；
- initialValues；
- API执行顺序；
- 前序Response不写入Input；
- Input不定义分支和映射。

## 2. `ScenarioContext設計書.md`

位置候选：

```text
05_run_context/
```

负责：

- ScenarioContext生命周期；
- ApiExchange；
- apiCallCode；
- Request／Response DTO；
- Request／Response JSON；
- Expected和Baseline装载；
- Check Result保存；
- 并行Run隔离。

## 3. `ExecutionState・Baseline管理設計書.md`

位置候选：

```text
05_run_context/
```

负责：

- initialExecutionFlg；
- previousRunId；
- Baseline读取；
- Baseline恢复；
- 初回执行；
- Baseline替换时点；
- 完整Run判断；
- 原子更新。

## 4. `検証結果・Expected設計書.md`

位置候选：

```text
06_verification_assets/
```

由原：

```text
Verification_Master設計
+
Verification_Policy_Master設計
```

合并而来。

负责：

- resultKey；
- expected.json；
- verification-result.json；
- API Compare和Business Check；
- Current／Expected判定；
- Result Key完整性；
- Batch汇总；
- PASS／FAIL／BLOCKED／ERROR。

## 5. `APIレスポンスDiff設計書.md`

位置候选：

```text
06_verification_assets/
```

由原Compare Policy设计改造。

负责：

- Previous／Current Response JSON；
- 实际API字段名；
- 字段新增、删除、类型变化、值变化；
- null和字段不存在；
- response-field-diff.json；
- 初回不执行字段前后Diff。

---

# 十九、不需要继续细分的设计书

为了避免设计书再次膨胀，以下不独立成册：

```text
ApiExchange設計書
Expected单独設計書
初回実行設計書
Verification Policy設計書
Compare Policy設計書
```

分别并入：

```text
ApiExchange
    → ScenarioContext設計書

Expected
    → 検証結果・Expected設計書

初回／Baseline
    → ExecutionState・Baseline管理設計書

验证Policy
    → 検証結果・Expected設計書

字段比较Policy
    → APIレスポンスDiff設計書
```

---

# 二十、17点以后讨论的最终核心模型

```text
UseCase
└── Scenario
    ├── input.json
    │   ├── request
    │   └── apis[apiCallCode, apiId, initialValues]
    │
    ├── ScenarioContext
    │   ├── ApiExchange by apiCallCode
    │   ├── Expected
    │   ├── Baseline
    │   └── Check Results by resultKey
    │
    ├── Java执行
    │   ├── API调用
    │   ├── Response字段Diff
    │   └── 业务Check
    │
    └── Output
        ├── verification-result.json
        ├── api-calls/{apiCallCode}/request.json
        ├── api-calls/{apiCallCode}/response.json
        └── api-calls/{apiCallCode}/response-field-diff.json
```

一句话总结：

> **每个Scenario由Java明确实现API顺序和业务逻辑；Input只提供初期值；Context只保存本次运行对象；Expected只定义结果期待；API字段Diff和业务Check分开；前回由固定Baseline和previousRunId定位；全部固定Java行为不再伪装成Master。**

---

# 当前 `system/02_master/` 完整文件结构与状态

以下仍是当前冻结目录。今天提出的删除、迁移和改名尚未正式冻结，因此相关文件标记为`待确认`。

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    ├── Context_Master.md【待确认】
    ├── Verification_Master.md【待确认】
    ├── Verification_Policy_Master.md【待确认】
    ├── Compare_Policy_Master.md【待确认】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   ├── API・UseCase・Scenario対応表設計書.md【需要重做】
    │   ├── Context_Master設計書.md【待确认】
    │   ├── Verification_Master設計書.md【待确认】
    │   ├── Verification_Policy_Master設計書.md【待确认】
    │   └── Compare_Policy_Master設計書.md【待确认】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        ├── API_UseCase_Scenario対応表_Example.md【需要重做】
        ├── Context_Master_Example.md【待确认】
        ├── Verification_Master_Example.md【待确认】
        ├── Verification_Policy_Master_Example.md【待确认】
        └── Compare_Policy_Master_Example.md【待确认】
```

# 本次新增或变更

本次没有生成文件正文。

今天17点以后确认或提出的结构调整：

```text
建议删除Master：
- Context_Master.md
- Verification_Master.md
- Verification_Policy_Master.md
- Compare_Policy_Master.md

建议删除对应Example：
- Context_Master_Example.md
- Verification_Master_Example.md
- Verification_Policy_Master_Example.md
- Compare_Policy_Master_Example.md

建议取消Master设计书：
- Context_Master設計書.md
- Verification_Master設計書.md
- Verification_Policy_Master設計書.md
- Compare_Policy_Master設計書.md

建议新增／重组：
- 04_usecase_design/Scenario入力データ設計書.md
- 05_run_context/ScenarioContext設計書.md
- 05_run_context/ExecutionState・Baseline管理設計書.md
- 06_verification_assets/検証結果・Expected設計書.md
- 06_verification_assets/APIレスポンスDiff設計書.md
```

以上目录调整目前仍为`待确认`，尚未纳入冻结结构。

# 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【需要重做】
```

该文件重写时必须先明确：

```text
Master的成立条件
Java固定逻辑不得登记成Master
Scenario专用定义不得进入全局Master
Master与普通设计书的职责边界
```

## 第 139 轮

### 你

总结内容我确认了，目录调整目前仍为待确认，按照建议执行

### ChatGPT

确认。目录调整从“待确认”改为**正式采用**，后续不再按原来的4类Master继续设计。

本次是**目录与设计职责正式变更**，并不表示相关设计书正文已经完成。

# 一、正式删除的文件

从`system/02_master/`删除：

```text
Context_Master.md
Verification_Master.md
Verification_Policy_Master.md
Compare_Policy_Master.md
```

从`system/02_master/design/`删除：

```text
Context_Master設計書.md
Verification_Master設計書.md
Verification_Policy_Master設計書.md
Compare_Policy_Master設計書.md
```

从`system/02_master/examples/`删除：

```text
Context_Master_Example.md
Verification_Master_Example.md
Verification_Policy_Master_Example.md
Compare_Policy_Master_Example.md
```

删除理由正式确定为：

```text
Context
    是Scenario单位的运行时对象，不是Master

Verification
    由Scenario与Java Check函数定义，不是全局Master

Verification Policy
    是Java Framework固定判定逻辑，不是运行时Master

Compare Policy
    是Java通用Diff实现或API个别Java逻辑，不是运行时Master
```

# 二、正式新增的普通设计书

## `04_usecase_design/`

```text
Scenario入力データ設計書.md【未完成】
```

负责：

```text
input.json
顶层request
apis数组
apiCallCode
apiId
initialValues
API执行顺序
前序API Response的使用方式
```

## `05_run_context/`

```text
ScenarioContext設計書.md【未完成】
ExecutionState・Baseline管理設計書.md【未完成】
```

分别负责：

```text
ScenarioContext設計書
    Scenario单位Context
    apiCallCode
    ApiExchange
    Request／Response DTO
    Request／Response JSON
    Result保存
```

```text
ExecutionState・Baseline管理設計書
    initialExecutionFlg
    previousRunId
    初回执行
    Baseline读取
    Baseline恢复
    Baseline复制和替换
```

## `06_verification_assets/`

```text
検証結果・Expected設計書.md【未完成】
APIレスポンスDiff設計書.md【未完成】
```

分别负责：

```text
検証結果・Expected設計書
    expected.json
    verification-result.json
    resultKey
    Current／Expected
    Previous／Current
    Batch汇总
```

```text
APIレスポンスDiff設計書
    Response JSON字段比较
    previousValue
    currentValue
    changeType
    response-field-diff.json
```

# 三、调整后的设计职责结构

```text
03_api_design/
└── 各API設計書
    ├── Request项目
    ├── Response项目
    ├── JSON字段名
    ├── Java DTO
    └── 类型、长度、必填等

04_usecase_design/
├── 各UseCase設計書
├── 各Scenario設計書
└── Scenario入力データ設計書.md
    └── input.json

05_run_context/
├── ScenarioContext設計書.md
│   └── Context、apiCallCode、ApiExchange
└── ExecutionState・Baseline管理設計書.md
    └── 初回Flg、previousRunId、Baseline

06_verification_assets/
├── 検証結果・Expected設計書.md
│   └── Expected、Result Key、主要结果
└── APIレスポンスDiff設計書.md
    └── API字段级前后比较

07_report/
└── Report設計書
    └── Batch结果、Check结果、Diff引用
```

# 四、调整后的 `system/02_master/` 完整结构

下面是从本次开始采用的新结构。

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【已给出内容】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【已给出内容】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   └── API・UseCase・Scenario対応表設計書.md【需要重做】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【已给出内容】
        ├── Scenario_Master_Example.md【需要重做】
        └── API_UseCase_Scenario対応表_Example.md【需要重做】
```

# 五、本次新增或变更文件

## 从冻结目录删除

```text
system/02_master/Context_Master.md
system/02_master/Verification_Master.md
system/02_master/Verification_Policy_Master.md
system/02_master/Compare_Policy_Master.md

system/02_master/design/Context_Master設計書.md
system/02_master/design/Verification_Master設計書.md
system/02_master/design/Verification_Policy_Master設計書.md
system/02_master/design/Compare_Policy_Master設計書.md

system/02_master/examples/Context_Master_Example.md
system/02_master/examples/Verification_Master_Example.md
system/02_master/examples/Verification_Policy_Master_Example.md
system/02_master/examples/Compare_Policy_Master_Example.md
```

## 新增为普通设计书

```text
system/04_usecase_design/Scenario入力データ設計書.md【未完成】

system/05_run_context/ScenarioContext設計書.md【未完成】
system/05_run_context/ExecutionState・Baseline管理設計書.md【未完成】

system/06_verification_assets/検証結果・Expected設計書.md【未完成】
system/06_verification_assets/APIレスポンスDiff設計書.md【未完成】
```

# 六、正式冻结的设计原则

```text
1. Master必须是多个UseCase／Scenario共同引用的数据。
2. Java固定实现逻辑不得重复做成Master。
3. Scenario专用定义不得进入全局Master。
4. Context是运行时对象，不是Master。
5. Result Key由Java Check与Scenario定义，不做全局登记。
6. Expected由各Scenario管理。
7. API字段Diff由Java共通Comparator实现。
8. 业务比较由Scenario Java Check实现。
9. 初回与Baseline属于执行状态管理。
10. 普通设计书与Master设计书必须明确分开。
```

# 七、下一份计划文件

下一份首先重写：

```text
system/02_master/design/Master共通設計書.md
【需要重做】
```

这份将以本次正式调整后的结构为基础，明确：

```text
Master成立条件
Master禁止收录的内容
Master与Scenario设计的边界
Master与Java固定实现的边界
Master之间的引用规则
文件命名、Code和Reference规则
```

本次调整已经正式采用，后续目录说明不再显示已删除的12个旧文件。

## 第 140 轮

### 你

UseCase_Master和Scenario_Master設計書需要重新制作吗

### ChatGPT

需要，但程度不同。

## 结论

|设计书|是否需要重新制作|原因|
|---|---|---|
|`UseCase_Master設計書.md`|需要修订，不一定全部推翻|UseCase本身的定位基本没变，但必须删除旧的Context／Verification／Policy Master依赖，并重新明确UseCase与Scenario的职责边界|
|`Scenario_Master設計書.md`|需要完整重做|今天确认的Scenario定义已经发生根本变化：API执行路径、`apiCallCode`、Input、Context、Expected、Check顺序都以Scenario为单位|

由于当前状态分类中没有“部分修改”，两份暂时都应标记为：

```text
【需要重做】
```

但实际工作量不同。

# 一、`UseCase_Master設計書.md`为什么需要修订

UseCase的基本职责仍然成立：

```text
一个UseCase
    表示一项完整业务目的

一个UseCase
    可以包含多个Scenario
```

所以旧设计书中以下内容通常可以保留：

- UseCase ID；
- UseCase名称；
- 业务目的；
- 对应Business；
- 前提条件；
- 适用环境；
- 所属Scenario一览；
- 有效／无效状态。

但是需要删除或修改旧内容。

## 需要删除的内容

如果旧设计中包含下面引用，需要删除：

```text
Context Master Code
Verification Master Code
Verification Policy Code
Compare Policy Code
```

因为这些Master已经正式取消。

## 需要重新明确的内容

UseCase只负责定义：

```text
这个业务验证要达到什么目的
包含哪些Scenario
这些Scenario共同覆盖什么业务范围
```

UseCase不负责定义：

```text
API调用顺序
API初期输入
apiCallCode
Context内容
Expected Result Key
字段Diff
Java业务Check函数
Baseline处理
```

这些全部下沉到Scenario设计或共通执行设计书。

## 修订后的UseCase关系

```text
UseCase Master
└── UC-E6-001
    ├── 业务目的
    ├── 业务范围
    ├── 对应Business
    └── Scenario清单
        ├── SC-001
        ├── SC-002
        └── SC-003
```

所以`UseCase_Master設計書.md`是**职责收缩和引用关系修正**，不是完全从零推翻。

---

# 二、`Scenario_Master設計書.md`为什么必须完整重做

Scenario的定义今天已经发生了根本变化。

旧设计可能只是：

```text
Scenario ID
Scenario名称
正常／异常
对应API
```

这已经不够。

现在Scenario成为整个Java执行设计的核心单位：

```text
一个Scenario
=
一条确定的业务执行路径
=
一次同步Java Batch执行
```

## 新的Scenario必须定义

### 1. 所属UseCase

```text
useCaseId
scenarioId
```

### 2. Scenario业务目的

例如：

```text
更新前取得会员状态
执行状态更新
更新后再次取得
验证状态迁移结果
```

### 3. API调用顺序

```text
CALL-001 → API-001
CALL-002 → API-002
CALL-003 → API-001
```

同一API可以多次调用。

### 4. `apiCallCode`

```text
apiId
    表示哪个API

apiCallCode
    表示当前Scenario中的哪一次调用
```

### 5. Input文件引用

Scenario需要对应：

```text
input.json
```

其中包含：

```text
顶层request
apis数组
每个API的initialValues
```

### 6. ScenarioContext范围

需要说明当前Scenario会保存哪些调用对象：

```text
CALL-001
    Request DTO
    Response DTO
    Request JSON
    Response JSON

CALL-002
    Request DTO
    Response DTO
    Request JSON
    Response JSON
```

但不需要在Scenario Master中逐字段定义API项目。

### 7. Check执行顺序

例如：

```text
CALL-001_RESPONSE_COMPARE
CALL-001_TYPE_CHECK
CALL-002_RESPONSE_COMPARE
MEMBER_STATUS_TRANSITION_CHECK
```

### 8. Expected引用

Scenario需要明确关联哪一个：

```text
expected.json
```

Expected中的正式对应单位是：

```text
resultKey
```

### 9. Baseline比较单位

API Response字段比较按：

```text
UseCaseId
+
ScenarioId
+
apiCallCode
```

定位前回与本次Response。

### 10. 输出文件

```text
verification-result.json
api-calls/{apiCallCode}/request.json
api-calls/{apiCallCode}/response.json
api-calls/{apiCallCode}/response-field-diff.json
```

这些变化已经超过“局部修改”，因此`Scenario_Master設計書.md`必须完整重做。

---

# 三、Scenario Master本体也需要重做

不仅设计书需要重做：

```text
Scenario_Master設計書.md
```

对应的：

```text
Scenario_Master.md
Scenario_Master_Example.md
```

也必须同步重做。

新的`Scenario_Master.md`不应该塞入全部执行细节，只登记Scenario的概要和引用关系。

推荐项目：

|项目|说明|
|---|---|
|`scenarioId`|Scenario唯一标识|
|`useCaseId`|所属UseCase|
|`scenarioName`|Scenario名称|
|`scenarioType`|正常、异常、境界等|
|`executionClass`|Java Scenario执行类|
|`inputRef`|Input文件引用|
|`expectedRef`|Expected文件引用|
|`status`|有效／无效|
|`description`|业务路径概要|

API调用明细、Context内容、Result Key清单不全部写进Master，放到各Scenario设计书。

---

# 四、UseCase Master本体是否需要重做

`UseCase_Master.md`目前内容已经给出，但需要检查是否包含已经删除的旧Master引用。

判断规则：

## 不包含旧引用

如果当前只包含：

```text
UseCase ID
业务名称
业务目的
Business ID
Scenario清单
状态
```

则只需小幅修订，可以继续使用。

## 包含旧引用

如果包含：

```text
Context Master
Verification Master
Policy Master
Compare Policy Master
```

则需要重做对应列和引用关系。

由于今天已正式删除这4类Master，在完成检查前，建议把`UseCase_Master.md`也从：

```text
【已给出内容】
```

调整为：

```text
【需要重做】
```

这样不会误把旧结构当成当前有效版本。

---

# 五、推荐制作顺序

应按以下顺序处理：

```text
1. Master共通設計書.md
2. UseCase_Master設計書.md
3. Scenario_Master設計書.md
4. UseCase_Master.md
5. Scenario_Master.md
6. API_UseCase_Scenario対応表設計書.md
7. API_UseCase_Scenario対応表.md
8. 对应Example
```

原因是必须先冻结：

```text
什么属于Master
UseCase负责什么
Scenario负责什么
详细执行设计放在哪里
```

然后才能正确制作Master本体。

---

# 当前 `system/02_master/` 完整结构与状态

根据今天正式采用的新模型，`UseCase_Master`相关内容也需要重新核对，因此状态更新如下：

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【待确认】
    ├── UseCase_Master.md【需要重做】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【待确认】
    │   ├── UseCase_Master設計書.md【需要重做】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   └── API・UseCase・Scenario対応表設計書.md【需要重做】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【待确认】
        ├── UseCase_Master_Example.md【需要重做】
        ├── Scenario_Master_Example.md【需要重做】
        └── API_UseCase_Scenario対応表_Example.md【需要重做】
```

# 本次新增或变更

本次没有新增文件正文。

状态调整：

```text
UseCase_Master.md
    已给出内容 → 需要重做

UseCase_Master設計書.md
    已给出内容 → 需要重做

UseCase_Master_Example.md
    已给出内容 → 需要重做
```

理由：

```text
需要删除旧Context／Verification／Policy引用
需要重新明确UseCase与Scenario的职责边界
需要适配Scenario单位Input、Context、Expected和API执行设计
```

`Scenario_Master.md`、`Scenario_Master設計書.md`和Example继续保持：

```text
【需要重做】
```

# 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【需要重做】
```

完成后紧接着处理：

```text
system/02_master/design/UseCase_Master設計書.md
system/02_master/design/Scenario_Master設計書.md
```

其中`Scenario_Master設計書.md`是完整重做，`UseCase_Master設計書.md`是基于旧内容进行职责收缩和结构修订。

## 第 141 轮

### 你

API_Master設計書.md呢

### ChatGPT

`API_Master設計書.md`也需要重新制作，但原因和`Scenario_Master設計書.md`不同。

## 结论

|文件|处理|
|---|---|
|`API_Master設計書.md`|需要重做|
|`E6_API_Master.md`|需要重做|
|`E6_API_Master_Example.md`|需要重做|

它不需要承载Scenario执行细节，而要重新收敛成：

> **全系统API定义目录，负责说明“有哪些API、每个API的固定技术属性和详细设计引用”。**

# 一、API Master应该定义什么

一个API只登记一次。

例如：

```text
API-001：会員情報取得API
API-002：会員状態更新API
API-003：更新結果照会API
```

推荐项目：

|项目|说明|
|---|---|
|`apiId`|API固定标识|
|`apiName`|API名称|
|`systemId`|所属系统|
|`method`|GET、POST等|
|`endpointId`或路径引用|API端点|
|`requestDto`|Request DTO类|
|`responseDto`|Response DTO类|
|`apiDesignRef`|详细API设计书引用|
|`enabled`|是否有效|
|`description`|API概要|

例如：

```markdown
| apiId | apiName | method | requestDto | responseDto | apiDesignRef |
|---|---|---|---|---|---|
| API-001 | 会員情報取得API | POST | MemberSearchRequest | MemberSearchResponse | 03_api_design/API-001設計書.md |
| API-002 | 会員状態更新API | POST | MemberUpdateRequest | MemberUpdateResponse | 03_api_design/API-002設計書.md |
```

# 二、API Master不应该定义什么

下面内容全部不属于API Master：

```text
apiCallCode
Scenario中的API调用顺序
CALL-001／CALL-002
input.json中的initialValues
前序API Response如何传给后续API
ScenarioContext内容
Expected
resultKey
业务Check
Baseline
字段Diff结果
```

原因是：

```text
API-001
```

是固定API定义。

而：

```text
CALL-001
CALL-003
```

是某个Scenario中的调用实例。

同一个API可以在不同Scenario中多次调用：

```text
SC-001 / CALL-001 → API-001
SC-001 / CALL-003 → API-001
SC-002 / CALL-002 → API-001
```

因此必须区分：

```text
API Master
    管理apiId

Scenario设计
    管理apiCallCode
```

# 三、Request／Response项目是否放在API Master

不应该把每个字段全部塞进API Master。

API Master只引用：

```text
Request DTO
Response DTO
API详细设计书
```

字段详细定义放在：

```text
03_api_design/
└── API-001設計書.md
```

里面定义：

- Request项目；
- Response项目；
- JSON项目名；
- Java变量名；
- 数据类型；
- 必填；
- 长度；
- 固定值；
- 属性值；
- 嵌套结构；
- 数组结构。

例如：

```text
API Master
└── API-001
    ├── requestDto = MemberSearchRequest
    ├── responseDto = MemberSearchResponse
    └── apiDesignRef = API-001設計書.md
```

# 四、为什么需要重做

原来的API Master设计如果包含以下内容，就已经不符合今天的设计：

```text
Scenario顺序
Context ID
Verification ID
Compare Policy
Expected定义
UseCase专用输入
```

今天已经明确：

```text
API定义
    是全局固定定义

API调用实例
    是Scenario专用定义

API返回字段Diff
    是运行时Java输出

API业务判断
    是Scenario Java Check
```

所以`API_Master設計書.md`需要重新明确边界。

# 五、API Master与其他设计书的关系

```text
API_Master
    定义系统有哪些API
        ↓

API详细设计书
    定义Request／Response字段
        ↓

Scenario设计书
    定义本Scenario如何调用API
        ↓

Scenario入力データ設計書
    定义该次调用需要的初期输入
        ↓

ScenarioContext設計書
    保存本次Request／Response对象
        ↓

APIレスポンスDiff設計書
    比较前回与今回Response JSON
```

职责表：

|内容|定义位置|
|---|---|
|API固定标识|API Master|
|HTTP Method、端点|API Master／API详细设计|
|Request／Response字段|API详细设计和DTO|
|Scenario内调用实例|Scenario设计|
|`apiCallCode`|Scenario设计|
|API调用顺序|Scenario设计|
|初期输入值|`input.json`|
|前序API值传递|Scenario Java实现|
|Response字段Diff|Java Comparator|
|业务Check|Scenario Java函数|

# 六、重做程度

`API_Master設計書.md`不是完全推翻API这个概念，而是重新收敛职责。

但因为状态分类没有“部分修订”，应统一标记：

```text
【需要重做】
```

同时：

```text
E6_API_Master.md
E6_API_Master_Example.md
```

也应从原来的`待确认`更新为：

```text
【需要重做】
```

暂时不修改`E6_API_Master.md`这个文件名。是否统一改名为`API_Master.md`，属于目录命名调整，需要另行确认。

# 当前 `system/02_master/` 完整结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【需要重做】
    ├── UseCase_Master.md【需要重做】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【需要重做】
    │   ├── UseCase_Master設計書.md【需要重做】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   └── API・UseCase・Scenario対応表設計書.md【需要重做】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【需要重做】
        ├── UseCase_Master_Example.md【需要重做】
        ├── Scenario_Master_Example.md【需要重做】
        └── API_UseCase_Scenario対応表_Example.md【需要重做】
```

# 本次新增或变更

本次未新增文件正文。

状态变更：

```text
E6_API_Master.md
    待确认 → 需要重做

API_Master設計書.md
    待确认 → 需要重做

E6_API_Master_Example.md
    待确认 → 需要重做
```

本次确认的职责：

```text
API Master
    只登记API固定定义和详细设计引用

Scenario
    定义apiCallCode、调用顺序和调用实例

API详细设计
    定义Request／Response项目

Java
    实现调用、数据传递、字段Diff和业务Check
```

# 下一份计划文件

仍然先制作：

```text
system/02_master/design/Master共通設計書.md
【需要重做】
```

之后推荐顺序调整为：

```text
1. API_Master設計書.md
2. UseCase_Master設計書.md
3. Scenario_Master設計書.md
4. API・UseCase・Scenario対応表設計書.md
```

因为必须先固定“API是什么”，再定义UseCase和Scenario如何引用及调用这些API。

## 第 142 轮

### 你

Business_Master.md  和 Environment_Master.md【呢

### ChatGPT

这两个不需要因为今天的设计变化而完整重做。

## 结论

|文件|处理|
|---|---|
|`Business_Master.md`|继续保留，核心职责不变|
|`Business_Master設計書.md`|继续保留，做一次整合性检查即可|
|`Business_Master_Example.md`|继续保留|
|`Environment_Master.md`|继续保留，核心职责不变|
|`Environment_Master設計書.md`|继续保留，做一次整合性检查即可|
|`Environment_Master_Example.md`|继续保留|

当前内容状态继续维持：

```text
【已给出内容】
```

但在最终冻结前，要检查是否还残留已经删除的旧Master引用。

# 一、Business Master为什么继续需要

`Business_Master.md`管理的是业务层面的稳定定义，例如：

```text
Business ID
业务名称
业务目的
业务范围
业务概要
对应UseCase
有效状态
```

关系是：

```text
Business
└── UseCase
    └── Scenario
```

例如：

```text
BUS-E6-001 会員情報更新業務
└── UC-E6-001 会員状態更新検証
    ├── SC-001 正常更新
    └── SC-002 更新対象なし
```

今天讨论的这些内容：

```text
input.json
ScenarioContext
apiCallCode
Expected
Response Diff
Baseline
initialExecutionFlg
```

全部在Business层以下，不会改变Business Master本身的存在意义。

## Business Master不应包含

需要确认当前文件里没有下列内容：

```text
API调用顺序
apiCallCode
Context项目
Result Key
Expected结果
Compare Policy
Baseline路径
初回执行Flg
```

这些不属于Business Master。

## Business Master应当只回答

```text
这是哪个业务
业务边界是什么
包含哪些UseCase
这个业务为什么需要验证
```

因此它继续保留是合理的。

---

# 二、Environment Master为什么继续需要

`Environment_Master.md`管理的是环境固定定义，例如：

```text
environmentId
环境名称
环境类型
API Base URL
连接设定引用
超时设定
认证方式引用
有效状态
```

例如：

```text
ENV-LOCAL
ENV-STAGING
ENV-PROD
```

Java Batch执行时，可以根据：

```text
environmentId
```

取得对应环境的API连接信息。

这是真正会被多个UseCase和Scenario共同引用的固定数据，因此符合Master条件。

## Environment Master不应包含

以下内容不属于环境Master：

```text
initialExecutionFlg
previousRunId
Baseline状态
当前Run ID
上一次执行结果
ScenarioContext
Expected
API Response
```

这些都是运行状态，应放在：

```text
ExecutionState・Baseline管理
```

而不是Environment Master。

## Environment Master应当只回答

```text
本次在哪个环境执行
这个环境连接哪个系统
API连接地址是什么
认证、超时等共通设定是什么
```

---

# 三、两者与新设计的关系

```text
Business_Master
    定义业务分类和业务边界

Environment_Master
    定义执行目标环境

UseCase_Master
    定义一个业务验证目的

Scenario_Master
    定义具体执行路径

各Scenario设计
    定义API调用、Input、Expected和Java Check

ExecutionState
    管理初回Flg、previousRunId和Baseline
```

所以：

```text
Business Master
Environment Master
```

仍然是有效的Master。

而之前删除的：

```text
Context Master
Verification Master
Verification Policy Master
Compare Policy Master
```

属于运行时或Java固定实现，不满足Master条件。

---

# 四、需要检查但不需要重做的地方

## `Business_Master.md`

检查是否存在：

```text
Context Master引用
Verification Master引用
Policy Master引用
具体Scenario执行细节
```

有的话删除对应列或说明即可。

## `Environment_Master.md`

检查是否把下面内容混进去了：

```text
初回执行Flg
Baseline文件位置
previousRunId
每次Run状态
```

有的话迁移到`ExecutionState・Baseline管理設計書.md`。

只要没有这些旧内容，就不需要重做。

---

# 五、最终判断

```text
Business_Master.md
    保留
    不需要完整重做
    最终冻结前进行整合性检查

Environment_Master.md
    保留
    不需要完整重做
    最终冻结前进行整合性检查
```

设计书和Example同样保持有效：

```text
Business_Master設計書.md【已给出内容】
Environment_Master設計書.md【已给出内容】

Business_Master_Example.md【已给出内容】
Environment_Master_Example.md【已给出内容】
```

# 当前 `system/02_master/` 完整结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【需要重做】
    ├── UseCase_Master.md【需要重做】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【需要重做】
    │   ├── UseCase_Master設計書.md【需要重做】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   └── API・UseCase・Scenario対応表設計書.md【需要重做】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【需要重做】
        ├── UseCase_Master_Example.md【需要重做】
        ├── Scenario_Master_Example.md【需要重做】
        └── API_UseCase_Scenario対応表_Example.md【需要重做】
```

# 本次新增或变更

本次没有新增文件正文，也没有修改文件状态。

正式确认：

```text
Business_Master.md
Business_Master設計書.md
Business_Master_Example.md
    继续保留为【已给出内容】

Environment_Master.md
Environment_Master設計書.md
Environment_Master_Example.md
    继续保留为【已给出内容】
```

最终冻结前仅进行旧Master引用和职责边界检查。

# 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【需要重做】
```

之后按照顺序重新制作：

```text
1. API_Master設計書.md
2. UseCase_Master設計書.md
3. Scenario_Master設計書.md
4. API・UseCase・Scenario対応表設計書.md
```

## 第 143 轮

### 你

api返回项目 比较时 确实有一些项目 不需要比较 所以 json里有项目增加 减少  json的项目值变化 该怎么做  一些特别的位数 不为空等倒是业务来check 可是json里值变化 但是是忽略项目 这个怎么比较啊
本来就是属于忽略那一类 是不是让它直接返回true 但是也得让java知道哪些是直接不必的呢

### ChatGPT

这里不要简单地把忽略字段“偷偷返回 true”。更稳妥的是：**Java明确知道哪些JSON Path属于忽略对象，并在Diff里标记为`IGNORED`，但不计入有效变化。**

### ChatGPT

对，这类“天然会变化、业务上不关心”的Response项目，Java必须提前知道哪些字段需要忽略。

但不建议忽略后直接悄悄返回`true`。正确做法是：

> **检测到变化，但把该变化标记为`IGNORED`，不计入有效变化，也不影响验证结果。**

# 一、比较结果分成三种

对于每一个JSON字段：

```text
正常比较且一致
正常比较且发生变化
命中忽略规则
```

例如：

```json
{
  "path": "$.updatedAt",
  "previousValue": "2026-07-24T10:00:00+09:00",
  "currentValue": "2026-07-25T10:00:00+09:00",
  "detectedChangeType": "VALUE_CHANGED",
  "comparisonStatus": "IGNORED",
  "effectiveChanged": false,
  "ignoreReason": "実行日時のため比較対象外"
}
```

这里真实情况是：

```text
值确实变化了
```

但最终判定是：

```text
有效变化 = false
```

不能简单写：

```json
{
  "changed": false
}
```

因为这样会让调查人员误以为前后值相同。

---

# 二、需要两种忽略方式

“忽略字段”最好分成两类。

## 1. 完全忽略字段

例如：

```text
requestId
updatedAt
executionTimestamp
traceId
```

规则：

```text
字段值变化     → 忽略
字段新增       → 忽略
字段删除       → 忽略
字段类型变化   → 忽略
```

可以叫：

```text
IGNORE_FIELD
```

例如：

```java
private static final Set<String> IGNORE_FIELD_PATHS =
        Set.of(
                "$.requestId",
                "$.updatedAt",
                "$.traceId"
        );
```

---

## 2. 只忽略值变化

有些字段本身必须存在，但内容每天都不同。

例如：

```text
processingTime
sequenceNumber
```

此时可以：

```text
字段不存在       → 仍然算变化
字段类型变化     → 仍然算变化
字段值变化       → 忽略
```

可以叫：

```text
IGNORE_VALUE
```

例如：

```java
private static final Set<String> IGNORE_VALUE_PATHS =
        Set.of(
                "$.processingTime",
                "$.sequenceNumber"
        );
```

两者区别：

|模式|字段删除|类型变化|值变化|
|---|---:|---:|---:|
|`IGNORE_FIELD`|忽略|忽略|忽略|
|`IGNORE_VALUE`|检测|检测|忽略|

这已经足够，不需要再增加很多复杂Policy类型。

# 三、Java在哪里知道忽略项目

这些字段不放在：

```text
input.json
expected.json
Environment Master
Compare Policy Master
```

而是由API比较Java实现持有。

例如API专用比较定义：

```java
public final class MemberSearchResponseCompareDefinition {

    public static final Set<String> IGNORE_FIELD_PATHS =
            Set.of(
                    "$.requestId",
                    "$.updatedAt"
            );

    public static final Set<String> IGNORE_VALUE_PATHS =
            Set.of(
                    "$.processingTime"
            );

    private MemberSearchResponseCompareDefinition() {
    }
}
```

Java调用：

```java
ResponseFieldDiff diff =
        responseDiffComparator.compare(
                previousResponseJson,
                currentResponseJson,
                MemberSearchResponseCompareDefinition
                        .IGNORE_FIELD_PATHS,
                MemberSearchResponseCompareDefinition
                        .IGNORE_VALUE_PATHS
        );
```

所以Java确实明确知道：

```text
哪些字段正常比较
哪些字段完全忽略
哪些字段只忽略值变化
```

---

# 四、同一个API在不同Scenario中规则不同怎么办

默认规则可以按`apiId`定义。

例如：

```text
API-001
    默认忽略updatedAt和requestId
```

如果某个Scenario中的某次调用有特殊要求，则按`apiCallCode`覆盖。

例如：

```java
ResponseCompareDefinition compareDefinition =
        switch (apiCallCode) {
            case "CALL-001" ->
                    MemberSearchBeforeCompareDefinition.INSTANCE;

            case "CALL-003" ->
                    MemberSearchAfterCompareDefinition.INSTANCE;

            default ->
                    MemberSearchDefaultCompareDefinition.INSTANCE;
        };
```

原则：

```text
通常相同
    按API复用比较定义

某次调用特殊
    按Scenario中的apiCallCode使用专用定义
```

仍然不需要建立全局`Compare_Policy_Master`。

---

# 五、Diff JSON怎么输出

例如前回：

```json
{
  "memberId": "M001",
  "memberStatus": "ACTIVE",
  "updatedAt": "2026-07-24T10:00:00+09:00"
}
```

今回：

```json
{
  "memberId": "M001",
  "memberStatus": "SUSPENDED",
  "updatedAt": "2026-07-25T10:00:00+09:00"
}
```

`response-field-diff.json`：

```json
{
  "apiCallCode": "CALL-001",
  "apiId": "API-001",

  "summary": {
    "checkedItemCount": 3,
    "unchangedCount": 1,
    "effectiveChangedCount": 1,
    "ignoredCount": 1
  },

  "items": [
    {
      "path": "$.memberId",
      "previousValue": "M001",
      "currentValue": "M001",
      "detectedChangeType": "UNCHANGED",
      "comparisonStatus": "COMPARED",
      "effectiveChanged": false
    },
    {
      "path": "$.memberStatus",
      "previousValue": "ACTIVE",
      "currentValue": "SUSPENDED",
      "detectedChangeType": "VALUE_CHANGED",
      "comparisonStatus": "COMPARED",
      "effectiveChanged": true
    },
    {
      "path": "$.updatedAt",
      "previousValue": "2026-07-24T10:00:00+09:00",
      "currentValue": "2026-07-25T10:00:00+09:00",
      "detectedChangeType": "VALUE_CHANGED",
      "comparisonStatus": "IGNORED",
      "ignoreMode": "IGNORE_FIELD",
      "effectiveChanged": false,
      "ignoreReason": "実行日時のため比較対象外"
    }
  ]
}
```

这样报告中既能看见：

```text
updatedAt实际发生变化
```

也能明确知道：

```text
这是预定忽略项目，不属于有效差异
```

---

# 六、增加、减少怎么处理

例如忽略字段`requestId`前回不存在，本次新增：

```json
{
  "path": "$.requestId",
  "previousState": "MISSING",
  "currentState": "PRESENT",
  "currentValue": "REQ-999",
  "detectedChangeType": "ITEM_ADDED",
  "comparisonStatus": "IGNORED",
  "ignoreMode": "IGNORE_FIELD",
  "effectiveChanged": false
}
```

如果是普通字段新增：

```json
{
  "path": "$.newBusinessField",
  "previousState": "MISSING",
  "currentState": "PRESENT",
  "currentValue": "A",
  "detectedChangeType": "ITEM_ADDED",
  "comparisonStatus": "COMPARED",
  "effectiveChanged": true
}
```

删除也是同样逻辑。

因此判断顺序应该是：

```text
先识别字段Path
→ 检查是否命中忽略定义
→ 再决定变化是否属于有效变化
```

---

# 七、数组中的忽略字段

例如：

```json
{
  "members": [
    {
      "memberId": "M001",
      "updatedAt": "2026-07-25T10:00:00+09:00"
    }
  ]
}
```

忽略规则可以支持通配形式：

```java
"$.members[*].updatedAt"
```

实际Diff路径仍然输出：

```text
$.members[0].updatedAt
```

Java比较器在匹配忽略规则时，将：

```text
$.members[0].updatedAt
```

匹配到：

```text
$.members[*].updatedAt
```

---

# 八、与业务Check的边界

你说的这些：

```text
必填
不为空
长度
位数
固定值
允许值
数值范围
业务状态转换
```

仍然由Java业务Check负责。

例如：

```java
checkRequiredFields(response);
checkFieldLength(response);
checkMemberStatus(response);
```

而字段Diff只负责：

```text
前回和今回结构是否变化
字段是否增加或减少
字段值是否发生变化
该变化是否属于忽略项目
```

所以两者明确分开：

|处理|负责内容|
|---|---|
|Response Diff|前后变化与忽略判定|
|Business Check|字段内容是否符合业务规则|

---

# 九、API Response比较的主要结果

忽略字段变化不应该影响主要验证结果。

例如：

```json
{
  "resultKey": "CALL-001_RESPONSE_COMPARE",
  "resultType": "API_RESPONSE_COMPARE",
  "currentResult": "PASS",
  "expectedResult": "PASS",
  "verificationResult": "PASS",

  "changeSummary": {
    "effectiveChangedCount": 0,
    "ignoredCount": 2
  },

  "fieldDiffRef": "api-calls/CALL-001/response-field-diff.json"
}
```

如果有普通字段变化：

```json
{
  "changeSummary": {
    "effectiveChangedCount": 1,
    "ignoredCount": 2
  }
}
```

但“字段发生变化”本身仍然不一定等于业务FAIL。

业务是否正确，继续由后面的Business Check判断。

---

# 十、最终确定

```text
1. Java必须明确持有忽略字段定义。
2. 忽略字段不放入Expected或Input。
3. 不需要恢复Compare Policy Master。
4. API默认忽略规则可以由API专用Java定义复用。
5. Scenario特殊规则通过apiCallCode使用专用比较定义。
6. 忽略字段仍然记录前回值和今回值。
7. Diff中使用comparisonStatus = IGNORED。
8. 忽略变化的effectiveChanged = false。
9. 普通字段增加、删除和值变化的effectiveChanged = true。
10. 业务必填、长度、位数和允许值继续由Business Check处理。
```

最核心的结构是：

```text
实际变化：
    detectedChangeType = VALUE_CHANGED

比较处理：
    comparisonStatus = IGNORED

最终有效差异：
    effectiveChanged = false
```

不是简单地直接返回`true`，而是：

> **Java检测到变化，但根据明确的忽略定义，将它排除在有效Diff之外。**

# 当前 `system/02_master/` 完整结构与状态

```text
system/
└── 02_master/
    ├── README.md【需要重做】
    ├── Business_Master.md【已给出内容】
    ├── Environment_Master.md【已给出内容】
    ├── E6_API_Master.md【需要重做】
    ├── UseCase_Master.md【需要重做】
    ├── Scenario_Master.md【需要重做】
    ├── API_UseCase_Scenario対応表.md【需要重做】
    │
    ├── design/
    │   ├── Master共通設計書.md【需要重做】
    │   ├── Business_Master設計書.md【已给出内容】
    │   ├── Environment_Master設計書.md【已给出内容】
    │   ├── API_Master設計書.md【需要重做】
    │   ├── UseCase_Master設計書.md【需要重做】
    │   ├── Scenario_Master設計書.md【需要重做】
    │   └── API・UseCase・Scenario対応表設計書.md【需要重做】
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md【需要重做】
    │   └── Master_ID・Reference記述ガイド.md【需要重做】
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md【需要重做】
    │   └── Master整合性Checklist.md【需要重做】
    │
    └── examples/
        ├── Business_Master_Example.md【已给出内容】
        ├── Environment_Master_Example.md【已给出内容】
        ├── E6_API_Master_Example.md【需要重做】
        ├── UseCase_Master_Example.md【需要重做】
        ├── Scenario_Master_Example.md【需要重做】
        └── API_UseCase_Scenario対応表_Example.md【需要重做】
```

## 本次新增或变更

本次未新增文件正文。

本次确认：

```text
- Response Diff支持IGNORE_FIELD和IGNORE_VALUE。
- 忽略规则由Java API比较定义持有。
- 相同API默认复用；特殊调用按apiCallCode覆盖。
- 忽略项目仍输出到Diff文件。
- 忽略变化不计入effectiveChangedCount。
- 不恢复Compare_Policy_Master。
```

## 下一份计划文件

```text
system/02_master/design/Master共通設計書.md
【需要重做】
```

同时该规则应写入后续普通设计书：

```text
system/06_verification_assets/APIレスポンスDiff設計書.md
【未完成】
```
