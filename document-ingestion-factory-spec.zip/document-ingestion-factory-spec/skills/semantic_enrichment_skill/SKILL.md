# Semantic Enrichment Skill

## 目的

normalized.json に対して、AI による意味補足を行う。

## 入力

- normalized.json
- assets images

## 出力

- enriched.normalized.json

## AI が担当すること

1. Sheet summary の生成
2. Table description の生成
3. Table row summary の生成
4. Flow diagram description の生成
5. Business entity の抽出
6. Relation 候補の抽出

## AI が担当しないこと

1. source_location の作成
2. row / col の計算
3. table 構造の決定
4. ファイルパス管理
5. ID 生成
