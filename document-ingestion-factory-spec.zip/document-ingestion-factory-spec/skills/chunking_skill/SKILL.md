# Semantic Chunking Skill

## 目的

normalized.json から、向量化に適した chunks.jsonl を生成する。

## 入力

- normalized.json

## 出力

- chunks.jsonl

## 基本方針

1. 固定長だけで分割しない
2. 文書構造に基づいて分割する
3. table は table_summary / table_group / table_row に分ける
4. image / flow_diagram は description / asset_path を含める
5. heading は後続 block と結合する
6. comment は対象 cell / row / block に結合する
7. metadata を必ず付与する

## chunk metadata 必須項目

- document_id
- file_name
- document_type
- business_domain
- unit_id
- unit_name
- content_unit_id
- content_unit_type
- source_location
- language
