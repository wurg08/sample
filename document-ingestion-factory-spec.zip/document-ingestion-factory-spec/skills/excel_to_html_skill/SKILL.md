# Excel to HTML Skill

## 目的

Excel ファイルを Normalize HTML 処理に適した HTML 形式へ変換する。

## 入力

- .xlsx
- .xlsm
- .xls

## 出力

- index.html
- assets/
- conversion_report.json

## 変換方式

1. Google Sheets HTML export
2. Microsoft Excel Save as HTML
3. LibreOffice Headless

## 方針

HTML は直接向量化しない。HTML は normalized.json 生成のための中間成果物とする。
