# Vector Ingestion Skill

## 目的

chunks.jsonl を embedding 化し、vector DB に入庫する。

## 入力

- chunks.jsonl
- quality_report.json

## 出力

- ingestion_report.json

## 対応 Vector Store

- PostgreSQL + pgvector
- Chroma
- Milvus
