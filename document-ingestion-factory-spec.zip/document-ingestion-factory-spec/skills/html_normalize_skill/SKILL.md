# HTML Normalize Skill

## 目的

Excel / Google Sheets / LibreOffice / Microsoft Excel から生成された HTML を、AI とプログラムが理解できる normalized.json に変換する。

## 入力

- index.html
- assets/
- source Excel file optional

## 出力

- normalized.json
- document.md
- normalize_log.json

## 基本方針

1. HTML を直接 Markdown 化しない
2. 必ず normalized.json を先に生成する
3. Heading / Paragraph / Table / Image / Flow Diagram / Comment を content_unit として抽出する
4. Table は columns / rows / cells に構造化する
5. Cell には text / value / formula / comment / style / source_location を保持する
6. Image / Flow Diagram は asset として管理する
7. 色、取消線、太字などは style_semantics に変換する
8. すべての content_unit に source_location をできるだけ付与する

## 禁止事項

- HTML 全文をそのまま content に入れない
- table を Markdown 文字列だけにしない
- 画像を path だけで終わらせない
- chunk をこの Skill 内で生成しない
