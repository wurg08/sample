# Document Ingestion Orchestrator Skill

## 目的

この Skill は、文書を RAG / 向量検索 / 設計書生成 / コード生成に利用できる状態へ変換するための全体フローを制御する。

## 対象入力

- Excel
- HTML
- PDF
- PPTX
- Markdown
- Text

## 出力

- normalized.json
- document.md
- chunks.jsonl
- quality_report.json
- ingestion_report.json
- retrieval_eval_report.json

## 基本方針

1. 入力ファイル形式に応じて適切な変換 Skill を呼び出す
2. すべての文書は normalized.json に統一する
3. normalized.json から document.md を生成する
4. normalized.json から chunks.jsonl を生成する
5. quality gate を通過したものだけ向量化・入庫する
6. 各処理結果は audit に記録する
7. 失敗時は次工程へ進まず failure report を出力する

## 標準呼び出し順序

1. detect_input_type
2. convert_to_html_or_text
3. normalize
4. semantic_enrichment
5. normalize_quality_check
6. chunking
7. chunk_quality_check
8. vector_ingestion
9. retrieval_evaluation
