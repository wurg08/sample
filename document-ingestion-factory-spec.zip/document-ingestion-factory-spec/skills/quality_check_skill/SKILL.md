# Quality Check Skill

## 目的

normalized.json、document.md、chunks.jsonl の品質をチェックし、入庫可能か判定する。

## 入力

- normalized.json
- document.md optional
- chunks.jsonl optional

## 出力

- quality_report.json
- decision: passed / passed_with_warnings / failed / human_review_required

## チェック項目

1. schema validation
2. text coverage
3. source_location coverage
4. table header detection rate
5. image description coverage
6. content_unit count
7. chunk count
8. metadata completeness
9. duplicate chunk detection
10. empty chunk detection
