CREATE INDEX IF NOT EXISTS idx_documents_type
ON documents(document_type);

CREATE INDEX IF NOT EXISTS idx_documents_domain
ON documents(business_domain);

CREATE INDEX IF NOT EXISTS idx_chunks_document_id
ON chunks(document_id);

CREATE INDEX IF NOT EXISTS idx_chunks_metadata
ON chunks USING GIN(metadata);

CREATE INDEX IF NOT EXISTS idx_chunks_content_fulltext
ON chunks USING GIN(to_tsvector('simple', content));

CREATE INDEX IF NOT EXISTS idx_chunk_embeddings_vector
ON chunk_embeddings
USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);
