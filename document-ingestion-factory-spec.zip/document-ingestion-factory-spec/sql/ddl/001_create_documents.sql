CREATE TABLE IF NOT EXISTS documents (
    document_id TEXT PRIMARY KEY,
    document_key TEXT,
    title TEXT,
    file_name TEXT NOT NULL,
    source_type TEXT NOT NULL,
    document_type TEXT,
    business_domain TEXT,
    system_name TEXT,
    module_name TEXT,
    language TEXT,
    version TEXT,
    normalized_json JSONB,
    quality_score NUMERIC,
    status TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
