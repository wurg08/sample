CREATE TABLE IF NOT EXISTS document_relations (
    relation_id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL,
    from_content_unit_id TEXT,
    to_content_unit_id TEXT,
    relation_type TEXT,
    relation_detail JSONB,
    confidence NUMERIC,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(document_id)
);
