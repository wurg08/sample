CREATE TABLE IF NOT EXISTS content_units (
    content_unit_id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL,
    unit_id TEXT,
    unit_name TEXT,
    unit_index INTEGER,
    type TEXT NOT NULL,
    subtype TEXT,
    title TEXT,
    text_content TEXT,
    normalized_text TEXT,
    source_location JSONB,
    style JSONB,
    semantics JSONB,
    raw_content JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(document_id)
);
