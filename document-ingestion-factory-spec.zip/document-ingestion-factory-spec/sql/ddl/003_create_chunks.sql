CREATE TABLE IF NOT EXISTS chunks (
    chunk_id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL,
    content_unit_id TEXT,
    chunk_type TEXT,
    content TEXT NOT NULL,
    metadata JSONB,
    token_count INTEGER,
    quality_score NUMERIC,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(document_id)
);
