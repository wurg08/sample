# SPEC: document-ingestion-factory v1.0

## 0. Project Name

document-ingestion-factory

## 1. Goal

Build an industrial document ingestion factory that converts Excel / HTML / PDF / PPTX / Markdown / Text into `normalized.json`, then exports `document.md`, `chunks.jsonl`, and `quality_report.json`, and later ingests valid chunks into PostgreSQL + pgvector.

First MVP scope:

```text
HTML
  -> normalized.json
  -> document.md
  -> quality_report.json
  -> chunks.jsonl
```

## 2. Core Principles

1. Do not embed raw HTML directly.
2. Always generate `normalized.json` first.
3. Tables must be structured as columns / rows / cells.
4. Images must be managed as assets.
5. Each content unit must have a stable ID.
6. Each chunk must have metadata.
7. Preserve source references as much as possible.
8. If quality score is below 80, ingestion must be blocked.
9. Programs handle structure; AI handles semantic enrichment.
10. Semantic enrichment must not calculate row/column/source-location.

## 3. MVP Acceptance Criteria

MVP is complete only if:

1. `python -m src.main run-pipeline --html samples/html/sample.html --output work/sample` can execute.
2. It generates `work/sample/normalized.json`.
3. It generates `work/sample/document.md`.
4. It generates `work/sample/quality_report.json`.
5. It generates `work/sample/chunks.jsonl`.
6. `normalized.json` passes `schemas/normalized.schema.json` validation.
7. `chunks.jsonl` contains at least:
   - 1 table summary chunk
   - 2 table row chunks
8. `document.md` contains:
   - 注文管理 詳細設計書
   - 画面項目一覧
   - 注文ID
   - 顧客名
9. `quality_report.json` has `overall_score >= 80`.
10. All pytest tests pass.

## 4. Required Python Modules

Implement these first:

- `src/normalizers/html_loader.py`
- `src/normalizers/html_cleaner.py`
- `src/normalizers/style_extractor.py`
- `src/normalizers/style_semantics_mapper.py`
- `src/normalizers/table_extractor.py`
- `src/normalizers/image_extractor.py`
- `src/normalizers/paragraph_extractor.py`
- `src/normalizers/heading_detector.py`
- `src/normalizers/normalized_builder.py`
- `src/validators/normalized_validator.py`
- `src/exporters/markdown_exporter.py`
- `src/quality/normalize_quality_checker.py`
- `src/chunking/table_chunker.py`
- `src/chunking/diagram_chunker.py`
- `src/chunking/paragraph_chunker.py`
- `src/chunking/semantic_chunker.py`
- `src/chunking/chunk_writer.py`
- `src/main.py`

## 5. normalized.json Top-Level Structure

```json
{
  "schema_version": "1.0.0",
  "document": {},
  "source_files": [],
  "structure": {},
  "content_units": [],
  "assets": [],
  "relations": [],
  "global_semantics": {},
  "chunking_policy": {},
  "quality": {},
  "audit": {}
}
```

## 6. content_unit Types

Supported types:

- heading
- paragraph
- table
- image
- flow_diagram
- chart
- formula
- comment
- sql
- code
- api_definition
- db_definition
- screen_definition
- test_case
- unknown

Each content unit must include:

- `content_unit_id`
- `type`
- `unit_id`
- `order`

## 7. Chunk Format

Each line in `chunks.jsonl` must be one JSON object with:

- `chunk_id`
- `document_id`
- `content_unit_id`
- `chunk_type`
- `content`
- `metadata`
- `quality`

## 8. Prohibited Implementations

Do not:

1. Write raw HTML as a chunk.
2. Convert tables only to Markdown without keeping columns / rows / cells.
3. Ignore `source_files`.
4. Ignore `quality_report`.
5. Generate chunks without metadata.
6. Skip schema validation.
7. Allow failed quality to ingest.

## 9. Future Extensions

After MVP:

1. LibreOffice Excel -> HTML conversion.
2. openpyxl extraction of formulas, comments, sheet names, and cell addresses.
3. AI semantic enrichment.
4. Flow diagram OCR.
5. Real embedding and pgvector ingestion.
6. Hybrid search.
7. Retrieval evaluation.
8. Web UI for human review.
9. `document.json` for frontend preview.
10. PDF / PPTX normalizers.
