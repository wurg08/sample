# normalized.json Design

`normalized.json` is the internal industrial intermediate model.

It is used by:

- validators
- markdown exporter
- semantic enrichment
- chunk generator
- quality checker
- vector ingestion

It is not intended as a frontend display JSON. A later `document.json` can be generated for UI preview.
