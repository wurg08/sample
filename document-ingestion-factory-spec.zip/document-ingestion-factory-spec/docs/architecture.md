# Architecture

```text
Input Layer
  -> Converter Layer
  -> Normalize Layer
  -> Semantic Layer
  -> Export Layer
  -> Chunk Layer
  -> Vector Layer
  -> Retrieval Layer
  -> Agent / Skills Layer
```

MVP focuses on:

```text
HTML -> Normalize Layer -> Export Layer -> Chunk Layer -> Quality Gate
```
