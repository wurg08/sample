# Skills Call Design

Standard flow:

```text
document_ingestion_orchestrator
  -> excel_to_html_skill, if input is Excel
  -> html_normalize_skill
  -> semantic_enrichment_skill
  -> quality_check_skill
  -> chunking_skill
  -> quality_check_skill
  -> vector_ingestion_skill
  -> retrieval_eval_skill
```

MVP flow:

```text
html_normalize_skill -> quality_check_skill -> chunking_skill
```
