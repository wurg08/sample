"""TODO: implement tests according to docs/SPEC.md."""

def test_placeholder():
    assert True
