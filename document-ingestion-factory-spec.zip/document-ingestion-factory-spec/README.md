# document-ingestion-factory Spec Package

This package contains an industrial-grade specification and project skeleton for a document ingestion factory.

Main flow:

```text
Excel / HTML / PDF / PPTX / Markdown / Text
  -> normalized.json
  -> document.md
  -> chunks.jsonl
  -> quality_report.json
  -> PostgreSQL + pgvector
  -> hybrid retrieval
```

First MVP scope:

```text
HTML -> normalized.json -> document.md -> chunks.jsonl -> quality_report.json
```

Recommended first command for Codex / VS Code Agent:

```text
Read docs/SPEC.md and implement the MVP acceptance criteria only.
```
