---
title: 注文状態更新API設計書（Example）
document_id: EX-API-902-DESIGN
version: 1.0.0-draft.3
status: DRAFT
document_type: API Detail Design Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 注文状態更新API設計書（Example）

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 注文状態更新API設計書（Example） |
| 文書ID | `EX-API-902-DESIGN` |
| API ID | `API-902` |
| 対象システム | `EXAMPLE` |
| 文書種別 | API詳細設計書記入例 |
| 版数 | `1.0.0-draft.3` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Example Design Team |
| レビュー責任 | API Owner / Verification Lead / Java Lead / Operations Owner |
| 承認責任 | Example System Owner |

本書のAPI、Endpoint、DTO、Field、Codeおよび業務値はすべて架空である。正式E6 API、正式Master、Java実装またはRuntime設定へコピーしてはならない。

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更区分 | 承認状態 |
|---|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | 更新系APIのRequest、Response、排他、Timeoutおよび冪等性を含む900番台記入例を新規作成 | NEW | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | SC-E6-903詳細設計、Input、ExpectedとのTimeout契約照合状態を反映 | UPDATE | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | Framework横断再走査によりProvider Error時のVerificationを`NOT_EVALUATED`とExecution／Reason Codeへ分離 | UPDATE | DRAFT |

## 3. 目的

本書は、注文IDを指定して注文状態を一回更新する架空APIについて、API固定契約、Request生成、楽観的排他、Response、Error、Contract Check、Compare Definition、Timeout後の安全境界およびJava責務の記入粒度を示す。

Exampleとして特に次を明示する。

1. 更新対象、目標状態および期待VersionのSourceを分離する。
2. HTTP 2xxだけで業務更新成功と判定しない。
3. Timeout時に更新結果を推測せず`UNKNOWN`として扱う。
4. 更新APIを読取APIと同じRetry Policyで自動再送しない。
5. API固定契約とScenario固有の状態遷移Expectedを分離する。

## 4. 適用範囲

### 4.1 対象

- `API-902`のMethod、Endpoint PathおよびDTO
- Request Header、Path ParameterおよびRequest Body
- 楽観的排他に使用する`expectedVersion`
- Success／Error Response契約
- API共通Contract CheckおよびBusiness Check候補
- API既定Compare Definition
- Timeout、Retry、Idempotency、Security、MaskおよびEvidence
- `SC-E6-901`の`CALL-002`からの参照例

### 4.2 対象外

| 対象外 | 正式な定義先 |
|---|---|
| Environment別Scheme、Host、Port | Environment設定 |
| Credential、Token実値 | Secret Provider |
| 更新前後の許可状態遷移 | Scenario設計、Business Rule、Java Check |
| API呼出順序、分岐、Skip | Scenario詳細設計 |
| Scenario Input実値 | Scenario Input JSON |
| Scenario固有Expected | Scenario Expected JSON、Java Check |
| Timeout後の個別Recovery実行 | Recovery Procedure、運用設計 |
| Runtime結果、Evidence実体 | Runtime Artifact |

## 5. 根拠資料

| Source ID | 資料名 | Reference | 確認状態 |
|---|---|---|---|
| API902-SRC-001 | E6 API Master記入例 | `system/02_master/examples/E6_API_Master_Example.md` | CONFIRMED |
| API902-SRC-002 | API・UseCase・Scenario対応表記入例 | `system/02_master/examples/API_UseCase_Scenario対応表_Example.md` | CONFIRMED |
| API902-SRC-003 | API設計書Template | `system/03_api_design/API設計書_Template.md` | CONFIRMED |
| API902-SRC-004 | SC-E6-901 Scenario設計書Example | `system/04_usecase_design/examples/scenario/SC-E6-901設計書_Example.md` | CONFIRMED |
| API902-SRC-005 | 架空Provider OpenAPI | `EXAMPLE://order-api/openapi` | EXAMPLE ONLY |

## 6. API Master整合

| apiId | apiName | systemId | method | endpointPath | requestDto | responseDto | enabled |
|---|---|---|---|---|---|---|:---:|
| API-902 | 注文状態更新API | EXAMPLE | PATCH | `/api/v1/orders/{orderId}/status` | `OrderStatusUpdateRequest` | `OrderStatusUpdateResponse` | true |

### 6.1 整合性判定

| Check | 判定 | 根拠 |
|---|:---:|---|
| API ID | PASS | `API-902`で一致する。 |
| Method | PASS | `PATCH`で一致する。 |
| Endpoint Path | PASS | Hostを含まない相対Pathで一致する。 |
| Request DTO | PASS | `OrderStatusUpdateRequest`で一致する。 |
| Response DTO | PASS | `OrderStatusUpdateResponse`で一致する。 |
| Example分離 | PASS | 900番台かつ`examples/`配下である。 |

本判定はExample文書間の整合だけを示し、正式APIの存在または実行可能性を示さない。

## 7. API概要

| 項目 | 内容 |
|---|---|
| API ID | `API-902` |
| API名称 | 注文状態更新API |
| Provider System | `EXAMPLE` |
| Method | `PATCH` |
| Endpoint Path | `/api/v1/orders/{orderId}/status` |
| Request DTO | `OrderStatusUpdateRequest` |
| Success Response | `OrderStatusUpdateResponse` |
| 認証 | Bearer Token（Example。実値記載禁止） |
| 副作用 | 注文状態およびVersionを更新する。 |
| 排他 | `expectedVersion`による楽観的排他 |
| 自動Retry | 0回 |

## 8. 処理概要

### 8.1 正常処理

1. Environment ContextからBase URLを解決する。
2. Scenario Request Builderが`orderId`、`targetStatus`および`expectedVersion`を明示的に組み立てる。
3. API Clientが認証、Correlation IDおよびIdempotency Keyを設定する。
4. 送信前Request ValidationとMask済Evidence生成を完了する。
5. Providerへ`PATCH` Requestを一回送信する。
6. HTTP StatusとResponse Bodyを受領する。
7. Bodyを`OrderStatusUpdateResponse`へDeserializeする。
8. Contract Checkを実行し、Scenario固有の状態遷移Checkへ引き渡す。

### 8.2 処理Flow

```mermaid
flowchart TD
    A["Input・前段Response解決"]
    B["Request生成・Validation"]
    C["PATCHを一回送信"]
    D["Response Deserialize"]
    E["Contract Check"]
    U["結果UNKNOWN・Recovery引渡し"]
    X["Error記録"]

    A -->|PASS| B -->|PASS| C
    A -->|非PASS| X
    B -->|非PASS| X
    C -->|Response受信| D --> E
    C -->|Timeout| U
    C -->|通信Error| X
```

## 9. Endpoint設計

| 項目 | 設計 |
|---|---|
| Method | `PATCH` |
| Relative Path | `/api/v1/orders/{orderId}/status` |
| Content-Type | `application/json` |
| Accept | `application/json` |
| Scheme／Host／Port | Environment設定から取得 |
| Query String | なし |
| Fragment | 使用禁止 |

### 9.1 URL組立

```text
resolvedBaseUrl + "/api/v1/orders/" + encodePathSegment(orderId) + "/status"
```

Base URLの末尾SlashとPath先頭SlashはClient共通部品が正規化する。注文IDをEncodeせず文字列連結してはならない。

## 10. Request Header／Path／Query

### 10.1 Header

| Header | 必須 | Source | Validation | Evidence |
|---|:---:|---|---|---|
| `Authorization` | Yes | Secret Provider | `Bearer ` Prefixを持つ。 | 全Mask |
| `Accept` | Yes | API Client固定値 | `application/json` | 記録可 |
| `Content-Type` | Yes | API Client固定値 | `application/json` | 記録可 |
| `X-Correlation-Id` | Yes | Run Context | 空でないUUID形式 | 記録可 |
| `Idempotency-Key` | Yes | Run＋Call Context | Run内でCALL-002に一意 | Hash後保存 |

`Idempotency-Key`はProviderの重複排除能力を説明するExampleであり、自動Retry許可を意味しない。

### 10.2 Path Parameter

| Parameter | 型 | 必須 | Null | 長さ | Pattern | Source |
|---|---|:---:|:---:|---|---|---|
| `orderId` | String | Yes | No | 1～32 | `^[A-Z0-9-]+$` | CALL-001 Responseの検証済み`orderId` |

### 10.3 Query Parameter

なし。排他Version、目標状態または実行制御をQueryへ追加してはならない。

## 11. Request Body

### 11.1 Request DTO

| 項目 | 内容 |
|---|---|
| DTO | `OrderStatusUpdateRequest` |
| Java FQCN | `com.example.e6.api.order.dto.OrderStatusUpdateRequest` |
| Root Type | Object |
| Unknown Field | 送信禁止 |

### 11.2 Request項目定義

| JSONPath | Java型 | 必須 | Null | 制約 | Source |
|---|---|:---:|:---:|---|---|
| `$.targetStatus` | String | Yes | No | `PROCESSING`,`SHIPPED`,`CANCELLED` | Input `targetStateRef`の解決結果 |
| `$.expectedVersion` | Long | Yes | No | 1以上 | CALL-001 Response `orderVersion` |
| `$.changeReasonCode` | String | Yes | No | 固定値`VERIFICATION` | Request Builder |

### 11.3 Request項目規則

- CALL-001 Response全体をRequestへSerializeしない。
- `expectedVersion`をScenario Inputの固定値で上書きしない。
- `targetStatus`は承認済みReferenceから解決し、自由入力文字列を許可しない。
- `changeReasonCode`はAPI固定契約としてBuilderが設定する。
- Null Fieldまたは未定義Fieldを送信しない。

### 11.4 Request JSON Sample

```json
{
  "targetStatus": "SHIPPED",
  "expectedVersion": 3,
  "changeReasonCode": "VERIFICATION"
}
```

Sample値は架空値であり、実行データまたはExpectedとして利用してはならない。

## 12. Request生成責務

| Field／責務 | Source | Owner | 禁止事項 |
|---|---|---|---|
| Base URL | Environment Resolver | API Client | Host直書き |
| `orderId` | CALL-001検証済みResponse | Scenario Request Builder | Inputとの暗黙優先順位 |
| `targetStatus` | Input `targetStateRef` | Scenario Request Builder | 任意文字列 |
| `expectedVersion` | CALL-001 `orderVersion` | Scenario Request Builder | 古い固定Version |
| `changeReasonCode` | API固定値 | Request Builder | Scenarioごとの自由変更 |
| Header | Context／Secret Provider | Client Interceptor | Secret Log出力 |

## 13. Request Validation

| Rule ID | 対象 | 条件 | 不成立時 |
|---|---|---|---|
| API902-REQ-001 | `orderId` | CALL-001でContract確認済み、Nullでない。 | API未呼出、`BLOCKED` |
| API902-REQ-002 | `targetStatus` | 許可Enumかつ開始状態と異なる。 | API未呼出、`FAIL` |
| API902-REQ-003 | `expectedVersion` | 1以上でCALL-001値と一致する。 | API未呼出、`FAIL` |
| API902-REQ-004 | `changeReasonCode` | `VERIFICATION`である。 | API未呼出、`ERROR` |
| API902-REQ-005 | Correlation ID | UUID形式かつRun内一貫。 | API未呼出、`ERROR` |
| API902-REQ-006 | Idempotency Key | CALL-002に対して一意。 | API未呼出、`BLOCKED` |
| API902-REQ-007 | Authorization | Secret Providerから解決済み。 | API未呼出、`BLOCKED` |

## 14. Response Header

| Header | 必須 | Check | 取扱い |
|---|:---:|---|---|
| `Content-Type` | Yes | `application/json`互換 | Contract Check |
| `X-Correlation-Id` | Yes | Request値と一致 | Contract Check |
| `Date` | No | 存在時にHTTP-date形式 | Diffは`IGNORE_VALUE` |

## 15. HTTP Status

| Status | 意味 | Body | Verification取扱い |
|---:|---|---|---|
| 200 | 更新成功 | `OrderStatusUpdateResponse` | Success Contractへ進む。 |
| 400 | Request不正 | `ApiErrorResponse` | Error Contractを確認する。 |
| 401 | 認証不正 | `ApiErrorResponse` | 原則FAIL。 |
| 404 | 対象注文不存在 | `ApiErrorResponse` | 自動で正常扱いしない。 |
| 409 | Version競合 | `ApiErrorResponse` | 更新不成立として専用判定する。 |
| 422 | 状態遷移不許可 | `ApiErrorResponse` | Business Errorとして専用判定する。 |
| 500 | Provider内部Error | `ApiErrorResponse` | Execution `INCOMPLETE`、Verification `NOT_EVALUATED`、Provider Error Reason Code。 |

Responseを受信していないTimeoutへ架空のHTTP Statusを設定してはならない。

## 16. Success Response

### 16.1 Response DTO

| 項目 | 内容 |
|---|---|
| DTO | `OrderStatusUpdateResponse` |
| Java FQCN | `com.example.e6.api.order.dto.OrderStatusUpdateResponse` |
| Root Type | Object |
| Unknown Field | 記録後Contract Error。黙って破棄しない。 |

### 16.2 Response項目定義

| JSONPath | Java型 | 必須 | Null | 制約 | Check分類 |
|---|---|:---:|:---:|---|---|
| `$.orderId` | String | Yes | No | Request Pathと一致 | EXISTS／TYPE／INPUT_MATCH |
| `$.previousStatus` | String | Yes | No | 定義済み注文状態 | TYPE／ENUM |
| `$.currentStatus` | String | Yes | No | Request `targetStatus`と一致 | TYPE／ENUM／INPUT_MATCH |
| `$.orderVersion` | Long | Yes | No | Request `expectedVersion`より大きい | TYPE／RANGE |
| `$.updateResult` | String | Yes | No | 固定値`UPDATED` | TYPE／FIXED_VALUE |
| `$.updatedAt` | String | Yes | No | RFC 3339 Date-Time | TYPE／FORMAT |

### 16.3 Array設計

本APIのSuccess ResponseにArrayは存在しない。未定義Arrayを追加した場合はUnknown FieldとしてContract Errorにする。

### 16.4 Success Response JSON Sample

```json
{
  "orderId": "ORD-EX-0001",
  "previousStatus": "PROCESSING",
  "currentStatus": "SHIPPED",
  "orderVersion": 4,
  "updateResult": "UPDATED",
  "updatedAt": "2026-07-27T10:20:30+09:00"
}
```

## 17. Error Response

### 17.1 Error Schema

| JSONPath | 型 | 必須 | Null | 制約 |
|---|---|:---:|:---:|---|
| `$.errorCode` | String | Yes | No | 定義済みCode |
| `$.message` | String | Yes | No | 1～200、機密値を含まない。 |
| `$.correlationId` | String | Yes | No | Request Correlation IDと一致 |
| `$.occurredAt` | String | Yes | No | RFC 3339 Date-Time |

### 17.2 Error Code

| HTTP Status | errorCode | 意味 |
|---:|---|---|
| 400 | `ORDER_UPDATE_REQUEST_INVALID` | 更新Request不正 |
| 401 | `AUTHENTICATION_FAILED` | 認証失敗 |
| 404 | `ORDER_NOT_FOUND` | 対象注文不存在 |
| 409 | `ORDER_VERSION_CONFLICT` | 楽観的排他競合 |
| 422 | `ORDER_STATUS_TRANSITION_NOT_ALLOWED` | 状態遷移不許可 |
| 500 | `ORDER_API_INTERNAL_ERROR` | Provider内部Error |

### 17.3 Error Response JSON Sample

```json
{
  "errorCode": "ORDER_VERSION_CONFLICT",
  "message": "The order version has changed.",
  "correlationId": "00000000-0000-4000-8000-000000000001",
  "occurredAt": "2026-07-27T10:20:30+09:00"
}
```

## 18. Business／Contract Check設計要求

| Check ID | 種別 | 条件 | 失敗時 |
|---|---|---|---|
| API902-CHK-001 | REQUEST_CONTRACT | 全必須Request Fieldが型、Null、Enum、Rangeを満たす。 | API未呼出 |
| API902-CHK-002 | RESPONSE_CONTRACT | 200時にSuccess Response全必須Fieldが存在する。 | FAIL |
| API902-CHK-003 | FIXED_VALUE | `updateResult=UPDATED`である。 | FAIL |
| API902-CHK-004 | INPUT_MATCH | Response `orderId`がPath `orderId`と一致する。 | FAIL |
| API902-CHK-005 | INPUT_MATCH | `currentStatus`がRequest `targetStatus`と一致する。 | FAIL |
| API902-CHK-006 | BUSINESS | Response VersionがRequest Versionより大きい。 | FAIL |
| API902-CHK-007 | ERROR_CONTRACT | Error時にStatusと`errorCode`が定義済み組合せである。 | FAIL |

### 18.1 標準観点

RequestとResponseについて`EXISTS`、`TYPE`、`NULL`、`LENGTH`、`FORMAT`、`ENUM`、`FIXED_VALUE`、`RANGE`および相関Checkを独立Resultとして保持する。

## 19. API既定Compare Definition要求

| JSONPath | Mode | 理由 | Contract／Business Check |
|---|---|---|---|
| `$.orderId` | `EXACT` | 更新対象Identity | 実行する。 |
| `$.previousStatus` | `EXACT` | 更新前状態 | 実行する。 |
| `$.currentStatus` | `EXACT` | 更新後状態 | 実行する。 |
| `$.orderVersion` | `EXACT` | Version変化 | 実行する。 |
| `$.updateResult` | `EXACT` | 固定値 | 実行する。 |
| `$.updatedAt` | `IGNORE_VALUE` | 実行時刻で変化する。 | 存在、型、Null、Formatは実行する。 |

`IGNORE_VALUE`はChange判定だけに作用し、ContractまたはBusiness Checkを免除しない。

### 19.1 Mode

| Mode | 意味 |
|---|---|
| `EXACT` | 正規化後の値を完全一致比較する。 |
| `IGNORE_VALUE` | Field値の差をChange判定から除外する。 |

### 19.2 Scenario固有上書き

更新前後の許可状態遷移およびVersion増加条件はScenario専用Java Checkで評価する。API既定Compare Definitionを変更して状態遷移を表現してはならない。

## 20. DTO／Java実装

| Component | Example FQCN | 責務 |
|---|---|---|
| Request DTO | `com.example.e6.api.order.dto.OrderStatusUpdateRequest` | 更新要求保持 |
| Response DTO | `com.example.e6.api.order.dto.OrderStatusUpdateResponse` | 更新結果保持 |
| Error DTO | `com.example.e6.api.common.dto.ApiErrorResponse` | Error Body保持 |
| API Client | `com.example.e6.api.order.OrderStatusUpdateApiClient` | HTTP呼出 |
| Validator | `com.example.e6.api.order.OrderStatusUpdateContractValidator` | API固定契約Check |

### 20.1 Java実装原則

- DTOは型付きClassとする。
- Request BuilderとAPI Clientを分離する。
- API Client内部で自動Retryしない。
- Timeout時にSuccess／Failure Response DTOを生成しない。
- Scenario固有ExpectedをAPI Clientへ埋め込まない。
- Java Class名はExampleであり、正式Source Root確定には使用しない。

## 21. Security／Mask

| 対象 | 保存 | Mask |
|---|:---:|---|
| Authorization Header | No | 全体を`***` |
| Idempotency Key | 条件付き | Hash化 |
| `orderId` | Yes | 末尾4桁以外をMask |
| Request／Response Body | 条件付き | Field別Mask後 |
| Error Message | Yes | Secret／個人情報検査後 |

## 22. Timeout／Retry／Idempotency要求

| 項目 | 設計 |
|---|---|
| Connect Timeout | Example設定Referenceから取得。秒数を本書へ固定しない。 |
| Read Timeout | Example設定Referenceから取得。秒数を本書へ固定しない。 |
| 自動Retry | 0回 |
| Timeout時更新結果 | `UNKNOWN` |
| Timeout後通常Flow | CALL-003を実行せずRecoveryへ引き渡す。 |
| Idempotency Key | CALL-002送信前に一意に生成しEvidenceへHash保存する。 |
| 再送判断 | Provider状態確認、Business Owner承認およびRecovery Procedureに従う。 |

Idempotency Keyが存在しても、Providerの保証範囲と再送条件が確認できない状態で自動再送してはならない。

## 23. Logging／Evidence

| Artifact | 必須 | 内容 |
|---|:---:|---|
| Request Meta | Yes | Method、Mask済Path、Header名、開始時刻 |
| Mask済Request Body | Yes | 送信したDTO、Hash |
| Response Meta | Response受信時 | Status、Header、終了時刻、Duration |
| Mask済Response Body | Response受信時 | SuccessまたはError Body |
| Contract Result | Yes | Rule ID、結果、Evidence Reference |
| Transport Error | 発生時 | Error分類、Stack Trace Reference |
| Recovery Reference | Timeout時 | 状態確認と判断の引渡し先 |

## 24. Scenario連携

| scenarioId | apiCallCode | 目的 | 前提 | Timeout後 |
|---|---|---|---|---|
| SC-E6-901 | CALL-002 | 注文状態変更 | CALL-001と事前CheckがPASS | 結果UNKNOWN、CALL-003 Skip |
| SC-E6-903 | CALL-002 | Timeout経路の更新試行 | Timeout Harness成立 | Recovery引渡し |

SC-E6-903の詳細設計、InputおよびExpectedは静的Exampleとして作成済みである。ただし、Java、Environment、Timeout Harness、Recoveryおよび承認Gateがないため実行可能にはならない。

## 25. Traceability

```text
API-902
├─ API Master Example
├─ API-902 Detail Design Example
├─ OrderStatusUpdateRequest／Response
├─ OrderStatusUpdateApiClient
└─ SC-E6-901
   └─ CALL-002
```

## 26. Validation

| Rule ID | 確認内容 | 期待 |
|---|---|---|
| API902-V001 | Front Matterと文書情報が一致する。 | PASS |
| API902-V002 | API Master Exampleの固定項目と一致する。 | PASS |
| API902-V003 | 900番台かつ`examples/`に配置される。 | PASS |
| API902-V004 | Request FieldのSourceとOwnerが一意である。 | PASS |
| API902-V005 | Success／Error Contractが機械判定可能である。 | PASS |
| API902-V006 | Timeout結果を`UNKNOWN`として扱う。 | PASS |
| API902-V007 | 自動Retryが0回である。 | PASS |
| API902-V008 | Scenario固有状態遷移をAPI固定契約へ混入していない。 | PASS |

## 27. API単体Test観点

### 27.1 Request

- 正常なPath、目標状態およびVersion
- Null、空文字、未定義Enum、Version 0
- CALL-001との`orderId／orderVersion`不一致
- Authorization、Correlation ID、Idempotency Key未解決
- Unknown Field混入

### 27.2 Response

- 全必須Field正常
- Field不足、Null、型違反、未定義Enum
- `updateResult`固定値違反
- RequestとResponseの注文ID／目標状態不一致
- Version非増加
- StatusとError Code不整合

### 27.3 Diff／Transport

- `updatedAt`だけの変化はChange対象外
- `updatedAt`の不存在またはFormat不正はContract FAIL
- Timeout時にHTTP Statusを生成しない
- Timeout後のRetry 0回とCALL-003未実行

## 28. Review Checklist

### 28.1 契約

- [ ] Method、Path、DTOがAPI Master Exampleと一致する。
- [ ] Request／Response Field、StatusおよびError Codeが一意である。
- [ ] 楽観的排他と固定値を確認できる。

### 28.2 Java

- [ ] DTO、Builder、Client、Validatorの責務が分離される。
- [ ] Timeout時に結果を推測しない。
- [ ] Client内部の自動Retryが無効である。

### 28.3 Security

- [ ] Credential実値が存在しない。
- [ ] Mask対象、Idempotency KeyおよびEvidence保存可否が明示される。

### 28.4 変更影響

- [ ] Request／Response Field変更時のScenario Mapping影響を追跡できる。
- [ ] IdempotencyまたはTimeout契約変更時にRecovery影響を確認できる。

## 29. 完了条件

1. Example内のAPI Master、ScenarioおよびAPI設計が整合する。
2. Request、Response、Error、排他、TimeoutおよびCheckの記入例が揃う。
3. Example値が正式MasterおよびRuntimeから分離される。
4. `document_id`がRepository内で一意である。
5. Markdown構造Validationを通過する。

## 30. Release Blocker

本書はExampleであり正式Release対象外である。さらに、Java Client、DTO、Provider、Environment、Secret、Test DataおよびRecovery実体を持たないためRuntimeへ投入できない。

## 31. Open Issues

| Issue ID | 内容 | 影響 | Owner | 状態 |
|---|---|---|---|---|
| API902-OI-001 | Java Example未実装 | DTO、Client、ValidatorをBuild照合できない。 | Example Java Team | OPEN |
| API902-OI-002 | ProviderのIdempotency保証は架空 | 自動再送可否を確定できない。 | Example API Owner | OPEN |
| API902-OI-003 | Timeout／Recovery実体未作成 | 更新結果確認と再送判断を実行できない。 | Example Operations Team | OPEN |

## 32. 禁止事項

- 本Exampleを正式E6 API仕様として引用する。
- `API-902`を正式API Masterへ登録する。
- Sample値、Token、Hostまたは時刻を実行値として利用する。
- CALL-001 Response全体をRequestへ動的Mergeする。
- HTTP 200だけでScenario PASSと判定する。
- Timeoutを未更新と解釈する。
- Idempotency Keyだけを根拠に自動Retryする。
- `IGNORE_VALUE`でContractまたはBusiness Checkを免除する。

## 33. 次工程

1. SC-E6-901／903 Input、ExpectedおよびScenario設計とAPI-902契約をJava実装時に双方向照合する。
2. Java ExampleのSource Root確定後、DTO、Client、BuilderおよびValidatorを実装する。
3. Timeout Harness、Idempotency保証、Recovery ProcedureおよびEvidence Schemaを具体化する。
