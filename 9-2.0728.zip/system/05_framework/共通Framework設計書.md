---
title: 共通Framework設計書
document_id: E6-API-VAL-COMMON-FRAMEWORK-DESIGN
version: 1.0.0-draft.8
status: DRAFT
document_type: Common Framework Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# 共通Framework設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 共通Framework設計書 |
| 文書ID | `E6-API-VAL-COMMON-FRAMEWORK-DESIGN` |
| 対象 | E6 API Verification Platformの共通Runtime Component、Port、契約およびLifecycle |
| 配置 | `system/05_framework/` |
| 文書種別 | Framework論理設計書 |
| 版数 | `1.0.0-draft.8` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | System Architecture / Runtime Team |
| レビュー責任 | System Architect / Runtime Lead / Verification Lead / Security Lead / Operation Lead |
| 承認責任 | System Owner |

## 2. 目的

本書は、E6 API Verification Platformの共通Frameworkについて、次を定義する。

1. 論理Componentと依存方向
2. Component間Portおよび受渡し契約
3. Run受付から終了までの完全なLifecycle
4. Definition Load、PreflightおよびExecution Plan生成
5. Scenario、API Call、VerificationおよびResult集約の制御
6. Artifact公開、Baseline更新、ReportおよびRecoveryとの境界
7. Fail Closed、Idempotency、Concurrency、TimeoutおよびCancellation原則
8. Java実装時に維持すべき論理境界と拡張点

本書はJava Source Root、Package名、Module構成または個別製品を確定しない。HTTP、Storage、Lock、Secret、AuditおよびDeploymentのCapability契約は`環境・Runtime構成設計書.md`を正本とする。

## 3. 上位入力と責務境界

| Reference | 本書で使用する決定 |
|---|---|
| `system/01_repository/Repository_Structure.md` | `05_framework`責務、Repository／Runtime分離、Recovery非正本 |
| `system/05_framework/Framework設計入力・決定事項一覧.md` | `FW-IN-*`、`FW-DEC-*`、`FW-OI-*` |
| `system/05_framework/システム設計書.md` | System Boundary、12論理Component、11 Step Lifecycle |
| `system/05_framework/共通Identity・Resultモデル設計書.md` | Static／Runtime Identity、Execution Identity、四結果軸、集約 |
| `system/05_framework/ScenarioContext設計書.md` | Scenario内Context、`apiCallCode`、DTO／JSON併存 |
| `system/05_framework/ExecutionState・Baseline管理設計書.md` | Previous非推測、Complete判定、Versioned Baseline／State条件更新 |
| `system/05_framework/ファイル入出力設計書.md` | Run Create-Only、Baseline／Report CAS Pointer、State CAS、Pinned Read |
| `system/05_framework/環境・Runtime構成設計書.md` | Runtime Profile、External Config／Secret、Provider Capability、Deployment Gate |
| `system/06_verification_assets/検証結果・Expected設計書.md` | ExpectedとCheck Resultの責務 |
| `system/06_verification_assets/APIレスポンスDiff設計書.md` | Field Diffの責務 |
| `system/07_report/Report設計書.md` | 公開済みArtifactからのReport生成 |

本書は次の詳細を正本化しない。

| 詳細 | 正本 |
|---|---|
| Master／設計／Java Classの具体的連携項目 | `Framework・業務定義連携設計書.md` |
| Artifact、Evidence、Manifest、Mask | `Snapshot・Evidence設計書.md` |
| Path、Atomic Write、Storage Adapter | `ファイル入出力設計書.md` |
| Error Taxonomy、Log、Recovery Handoff | `ログ・例外・Recovery設計書.md` |
| Endpoint、Secret、Deployment、Runtime製品 | `環境・Runtime構成設計書.md` |

## 4. 設計原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `CF-P001` | Java First | 実行順序、分岐、Mappingおよび個別Check登録は型付きJavaで実装する。外部式言語を実行しない。 |
| `CF-P002` | Port／Adapter | CoreはScheduler、HTTP、File System、DB、Report形式へ直接依存しない。 |
| `CF-P003` | Plan Before Execute | 外部API呼出前にDefinition、Reference、Registryおよび環境制約を解決し、不変Execution Planを確定する。 |
| `CF-P004` | Fail Closed | 必須定義、Class、Schema、Secret Referenceまたは契約不整合を推測・自動補完しない。 |
| `CF-P005` | Explicit Lifecycle | Run、Batch、UseCase、Scenario、API CallおよびCheckの開始・終了を明示する。 |
| `CF-P006` | Four-axis Result | Execution、Verification、Change、Recoveryを単一PASS／FAILへ圧縮しない。 |
| `CF-P007` | Immutable Final | Finalize後のResult、Execution Planおよび公開Artifactを変更しない。 |
| `CF-P008` | No Hidden Retry | Retryは明示的Policyと安全性根拠がある場合だけ行い、更新API Timeoutは自動Retryしない。 |
| `CF-P009` | Complete Before Publish | 必須Artifact、Mask、HashおよびManifest検証完了前に公開またはBaseline更新しない。 |
| `CF-P010` | No Reverse Mutation | Report、Adapterおよび個別CheckはExecution StateまたはBaselineを変更しない。 |
| `CF-P011` | Deterministic Aggregate | 同じChild Result集合から同じParent Resultを導出する。 |
| `CF-P012` | Observable Failure | Skip、Not Reached、Not Evaluated、Timeout、Cancellationおよび欠落を成功として隠さない。 |

## 5. 論理構成

```mermaid
flowchart TD
    A["Trigger Adapter"] --> B["Run Orchestrator"]
    B --> C["Definition・Plan"]
    C --> D["Scenario Runtime"]
    D --> E["API Access"]
    D --> F["Verification"]
    E --> G["Artifact・State"]
    F --> G
    G --> H["Report・Recovery"]
```

### 5.1 Core Component

| Component ID | Component | 主責務 | 禁止責務 |
|---|---|---|---|
| `CF-CMP-001` | Run Request Adapter | CLI、Scheduler等を共通`RunRequest`へ変換する。 | Definition解決、Scenario実行 |
| `CF-CMP-002` | Run Orchestrator | Run全体の状態遷移、順序、Lock、終了処理を統括する。 | API固有Mapping、個別判定 |
| `CF-CMP-003` | Definition Loader | Version／Hash付きSource Definitionを読込み、`DefinitionSourceSet`を生成する。 | 不足定義の生成、Master更新 |
| `CF-CMP-004` | Preflight Validator | Reference、Schema、Registry、環境、安全制約を検証する。 | Errorの自動降格 |
| `CF-CMP-005` | Execution Planner | 検証済み`DefinitionBundle`から不変Execution Planを生成する。 | API呼出、Runtime Result生成 |
| `CF-CMP-006` | Definition Resolver／Registry | Source DefinitionのID／ReferenceとRegistry Keyを一意に解決し、Definition Graphを構築する。 | Classpath全走査による曖昧選択 |
| `CF-CMP-007` | Scenario Dispatcher | UseCase／Scenarioの順序、分岐、停止、Skipを制御する。 | Orchestrator、State更新 |
| `CF-CMP-008` | API Access Coordinator | Request構築、認証適用、HTTP呼出、Response正規化を統括する。 | Expected判定、暗黙Retry |
| `CF-CMP-009` | Verification Coordinator | Contract、Expected、Business Check、Diffを実行・集約する。 | Scenario順序変更、State更新 |
| `CF-CMP-010` | Result Aggregator | Child Resultから四軸Parent Resultを決定的に導出する。 | 原Result上書き、表示都合の丸め |
| `CF-CMP-011` | Artifact Publisher | 一時Artifactの完全性を検証し、`runId`単位でCreate-Only公開する。 | Baseline採否の独断 |
| `CF-CMP-012` | State／Baseline Coordinator | Complete条件に基づきVersioned Baseline PointerとStateを条件更新する。 | 不完全Run採用、日時によるPrevious推測 |
| `CF-CMP-013` | Report Coordinator | 公開済みArtifactからReport生成を要求する。 | 実行中Object参照、結果変更 |
| `CF-CMP-014` | Recovery Coordinator | `UNKNOWN_OUTCOME`等を明示的Recoveryへ引き渡す。 | 通常実行の暗黙再開 |

`システム設計書.md`の12論理Componentを、本書では契約単位へ分割して14 Componentとして詳細化する。System Boundaryまたは責務は変更しない。

### 5.2 Trace Validation責務

Trace Validationを第15 Componentまたは専用Masterとして追加せず、既存ComponentのCommit Gateへ分担する。

| Gate | Owner Component | 責務 |
|---|---|---|
| `TRACE-STATIC` | Definition Loader／Preflight Validator | Master、設計、Input／ExpectedおよびSchemaのReference Graphを検証する。 |
| `TRACE-BUILD` | Definition Resolver／Registry／Preflight Validator | Registry Descriptor、Class、DTO、CapabilityおよびBuild Identityを双方向検証する。 |
| `TRACE-SEAL` | Execution Planner／Run Orchestrator | Execution Identity、Definition Bundle、Registry SnapshotおよびArtifact Requirementを固定する。 |
| `TRACE-RUNTIME` | Result Aggregator／Artifact Publisher | Result、Diff、Core Artifact、ManifestのIdentity、Owner、HashおよびSource Referenceを検証する。 |
| `TRACE-REPORT` | Report Coordinator | Report行からResult、Diff、Manifest Entryへの逆引きを検証する。 |

Component間で受け渡す`TraceValidationResult`はGate、Rule ID、Status、Source Key、Target Key、Failure Codeおよび安全なEvidence Referenceを持つ論理Contractとする。これはMaster、Runtime ArtifactまたはReportの代替正本ではない。

## 6. Port分類と依存規則

### 6.1 Port分類

| Port群 | 代表Port | Direction | 内容 |
|---|---|---|---|
| Trigger | `RunRequestPort` | Inbound | 起動要求受付 |
| Definition | `DefinitionLoadPort`、`RegistryResolvePort` | Outbound | 静的定義と実装解決 |
| Execution | `ScenarioExecutionPort`、`ApiCallPort` | Inbound／Outbound | Scenarioと外部API実行 |
| Verification | `CheckExecutionPort`、`DiffPort` | Outbound | Checkと比較 |
| Persistence | `ArtifactStorePort`、`ExecutionStatePort`、`LockPort` | Outbound | Artifact、State、Lock |
| Cross-cutting | `ClockPort`、`IdGeneratorPort`、`SecretProviderPort` | Outbound | 時刻、ID、Secret |
| Output | `ReportPort`、`RecoveryHandoffPort`、`NotificationPort` | Outbound | Report、Recovery、通知 |

### 6.2 依存規則

```text
Adapter
  → Application Orchestrator
    → Domain／Framework Contract
      → Outbound Port
        ← Infrastructure Adapter
```

1. Core Contractは具体的Scheduler、HTTP Library、Storage、DBまたはJSON Library型を公開しない。
2. Infrastructure ExceptionをCore外へ漏らさず、分類済みFramework Failureへ変換する。
3. 個別Scenarioは`ScenarioExecutionPort`に適合し、Artifact、Baseline、Report Adapterを直接呼ばない。
4. API Executorは`ApiCallSpec`と`ScenarioContext`の必要Viewだけを受け取る。
5. Check実装はRead OnlyのActual／Expected／Metadataだけを受け取る。
6. Port呼出順序はOrchestratorだけが統括し、Adapterが次Stepを決定しない。

## 7. 共通契約モデル

### 7.1 `RunRequest`

| 項目 | 必須 | 内容 |
|---|---:|---|
| `requestId` | Yes | 受付要求の追跡ID。`runId`とは別。 |
| `environmentId` | Yes | 実行対象Environment |
| `selection` | Yes | UseCase／Scenario／Input Set選択 |
| `executionMode` | Yes | 許可された実行Mode |
| `requestedBy` | Yes | 起動主体Reference |
| `requestedAt` | Yes | 受付時刻 |
| `definitionVersionConstraint` | Yes | 使用DefinitionのVersion条件 |
| `options` | No | 承認済み共通Option。任意式を許可しない。 |

同一`requestId`の重複受付は新しい実行を暗黙生成しない。重複時の返却規則はTrigger Adapterと運用設計で定義する。

### 7.2 `DefinitionBundle`

`DefinitionBundle`は、`DefinitionSourceSet`の読込、Reference／Registry解決およびPreflight Validationが完了した後に固定する検証済み成果物である。次をVersion、HashおよびSource Reference付きで保持する。

- 5 Master
- API／UseCase／Scenario設計
- Scenario Input／Expected
- JSON Schema
- Verification／Diff定義
- Environmentの非Secret設定
- Registry Manifest

Bundleは固定後Read Onlyとし、実行中にSource Definitionを再読込しない。Hot Reloadを禁止する。

### 7.3 `ExecutionPlan`

| 項目 | 内容 |
|---|---|
| `planId` | Plan実体Identity |
| `runId` | 対象Run |
| `executionIdentity` | Baseline／Previous比較Slot |
| `definitionSnapshot` | Version／Hash一覧 |
| `orderedScenarios` | 実行順序と依存 |
| `apiCallSpecs` | `apiId`、`apiCallCode`、Executor、Builder、Timeout、Retry可否 |
| `checkSpecs` | `resultKey`、Check種別、Expected、Severity規則 |
| `artifactRequirements` | 必須ArtifactとSchema Version |
| `baselineReference` | 明示的に解決したPrevious／Baseline |
| `environmentConstraints` | 実行可否、更新API制限、Data Lease等 |

Execution PlanはPreflight成功後にSealし、Scenario実行中に変更しない。分岐結果はPlanを書き換えず、Plan内のBranch定義に対する実行記録として保存する。

### 7.4 `ApiCallSpec`と`ApiExchange`

| Contract | 主な内容 |
|---|---|
| `ApiCallSpec` | `apiId`、`apiCallCode`、Method、Endpoint Reference、Builder Key、Executor Key、Timeout、Retry Classification |
| `ApiRequestEnvelope` | Mask前RequestのRuntime表現、Header、Body、Metadata |
| `ApiExchange` | Request Reference、Response／Failure、Timing、Attempt、`apiCallExecutionId` |

Secretを含むEnvelopeはRuntime Memory内だけで扱い、Artifactへ渡す前にMaskする。Transport ErrorとHTTP Error Responseを同一Failureへ丸めない。

### 7.5 `CheckSpec`と`CheckResult`

各Checkは安定した`resultKey`を持ち、少なくとも次を返す。

- `checkExecutionId`
- `resultKey`
- 対象Identity
- 四結果軸の該当値
- `reasonCode`
- Severity
- Expected／Actualの安全なEvidence Reference
- Check実装Version

`IGNORE_VALUE`は同一型の値変化をDiff Itemとして残し、`comparisonStatus=IGNORED`、`effectiveChanged=false`とする。比較未実施を表す`NOT_COMPARED`へ変換しない。追加、削除、型変化はEffective Diffとし、存在、型、Null、空文字、構造および子項目Checkも独立して実行する。

## 8. Definition LoadとPreflight

### 8.1 処理順序

```mermaid
flowchart TD
    A["Load Source Set"] --> B["Resolve Graph・Registry"]
    B --> C["Schema・Hash・Reference"]
    C --> D["Environment・Safety"]
    D --> E["Freeze Bundle"]
    E --> F["Build Plan"]
    F --> G["Seal Plan"]
```

### 8.2 必須Validation

| Validation | Error時 |
|---|---|
| Master／設計／Input／ExpectedのReference完全性 | `REJECTED` |
| Document／Schema Version互換性 | `REJECTED` |
| Hash一致 | `REJECTED` |
| Scenario Class、Executor、Builder、Checkの一意解決 | `REJECTED` |
| Scenario Masterの`scenarioId + executionClass`とScenario Registry Descriptorの完全一致 | `REJECTED` |
| Registry DescriptorからDefinitionへの逆Trace | `REJECTED` |
| `apiCallCode`、`resultKey`のScope内一意性 | `REJECTED` |
| Environment実行許可、更新API制限 | `REJECTED` |
| Secret Referenceの存在と参照権限 | `REJECTED`。Secret値はPreflight結果へ出力しない。 |
| Baseline Identity一致 | 比較を要求する場合は`REJECTED`、任意比較は明示的`NOT_COMPARED` |
| Artifact必須一覧とSchema解決 | `REJECTED` |

Preflight ErrorはWarningへ自動降格しない。任意項目は設計時点で任意と定義されていなければならない。

## 9. Run Lifecycle

### 9.1 Run Phase遷移

`RunPhase`はOrchestratorの進行状態であり、`ExecutionStatus`ではない。Phase名から四結果軸を逆算せず、各軸はResult Aggregatorが独立して確定する。

```mermaid
stateDiagram-v2
    [*] --> ACCEPTED
    ACCEPTED --> PREFLIGHT
    PREFLIGHT --> EXECUTING: valid
    PREFLIGHT --> FINALIZING: rejected
    EXECUTING --> FINALIZING: terminal outcome
    FINALIZING --> PUBLISHED: evidence package valid
    FINALIZING --> FINISHED: publish failed
    PUBLISHED --> REPORTING
    REPORTING --> FINISHED
    FINISHED --> [*]
```

| 区分 | Canonical値 |
|---|---|
| `RunPhase` | `ACCEPTED / PREFLIGHT / EXECUTING / FINALIZING / PUBLISHED / REPORTING / FINISHED` |
| Execution Status | `NOT_STARTED / RUNNING / COMPLETED / INCOMPLETE / REJECTED / UNKNOWN_OUTCOME` |
| Recovery Status | `NOT_REQUIRED / REQUIRED / IN_PROGRESS / RESOLVED` |

`PUBLISHED`は安全なArtifact Packageが公開されたことだけを表す。Executionが`INCOMPLETE`、`REJECTED`または`UNKNOWN_OUTCOME`でも、当該終端Outcomeに必須のEvidenceが揃えばPackageを公開できる。

### 9.2 Lifecycle契約

| Step | Owner | Input | Output／Commit Point | Failure処理 |
|---:|---|---|---|---|
| 1 | Adapter／Orchestrator | `RunRequest` | `runId`、受付記録 | 重複・不正要求を拒否 |
| 2 | Loader／Resolver | Request、Version条件 | `DefinitionSourceSet`、解決済みDefinition Graph | API呼出前停止 |
| 3 | Preflight／Planner | Definition Graph、Registry、Schema、Environment | 固定`DefinitionBundle`、Sealed `ExecutionPlan` | `REJECTED` |
| 4 | Orchestrator／Lock Port | Execution Identity | Lock Lease | 待機または拒否 |
| 5 | Dispatcher | Plan、Input、Baseline Reference | 初期`ScenarioContext` | `INCOMPLETE` |
| 6 | Scenario／API／Verification | Context、Call／Check Spec | Child Result、Masked Evidence候補 | Failure分類、必要時停止 |
| 7 | Aggregator | 全Child Result | 四軸Parent Result | 欠落Childを正常集約しない |
| 8 | Publisher | Result、Artifact候補 | 終端Outcome別Complete Manifest、公開Run | 隔離し、旧公開物を維持 |
| 9 | State Coordinator | 公開Run、Complete判定 | State／Baseline Pointer | 旧値維持、Recovery記録 |
| 10 | Report Coordinator | 公開Run | Report Artifact | Execution Resultと分離 |
| 11 | Orchestrator | 最終状態 | Lock解放、通知 | Cleanup Failureを記録 |

Lock取得後の全終了経路で解放を試行する。Lease消失時は新しい副作用を開始せず、現在のAPI呼出結果に応じて`INCOMPLETE`または`UNKNOWN_OUTCOME`へ分類する。

## 10. Scenario実行契約

### 10.1 Scenario Interfaceの論理責務

```text
ScenarioExecution
  input : ScenarioExecutionCommand
  output: ScenarioExecutionResult
```

`ScenarioExecutionCommand`はExecution Planの当該Scenario View、Read Only Input、Context Accessおよび許可済みFramework Serviceだけを含む。

個別Scenarioは次を実行できる。

- Planに定義された`apiCallCode`の呼出
- 明示的Mappingによる後続Request構築
- Planに定義されたBranch選択
- Check実行要求
- 明示的`SKIP`、停止および失敗通知

個別Scenarioは次を実行してはならない。

- Master、Expected、PlanまたはBaselineの書換え
- 任意Class名／Script／式の動的実行
- 未登録APIの呼出
- ResultまたはArtifactの直接公開
- 通常経路外のBaseline更新
- Timeoutした更新APIの独自Retry

### 10.2 Branchと到達性

| 状態 | 意味 |
|---|---|
| `RUN` | Plan上のStepを実行した。 |
| `SKIP` | 条件評価の結果、明示的に実行対象外となった。 |
| `NOT_REACHED` | 前段停止またはFailureにより到達しなかった。 |

`SKIP`と`NOT_REACHED`を成功実行として集約しない。Branch評価に必要な値が欠落した場合は既定Branchへ推測せずFailureとする。

## 11. API Access契約

### 11.1 標準Pipeline

```text
ApiCallSpec解決
→ Request Builder
→ Request Contract確認
→ Secret／Auth適用
→ Transport実行
→ Response捕捉
→ DTO／JSON正規化
→ Mask
→ ApiExchange確定
```

### 11.2 Retry分類

| 分類 | Default |
|---|---|
| 更新APIでResponse未確認のTimeout／Connection切断 | Retry禁止、`UNKNOWN_OUTCOME` |
| 明示的に副作用なしと確認済みの参照API | 承認済みRetry Policyがある場合だけ可能 |
| HTTP 4xx／5xx | Default Retryなし |
| Request Build／Schema／認証設定Error | Retryなし |
| Rate Limit | API契約、上限、待機条件が明示された場合だけ可能 |

Retryを行う場合もAttemptを同一`apiCallExecutionId`の上書きにせず、Attempt履歴を保持する。Recoveryによる再実行は新しいRunおよび実行時Identityを発行する。

## 12. Verification契約

### 12.1 Check種別

| Check群 | 例 |
|---|---|
| Transport／Status | Timeout分類、HTTP Status |
| Contract | Field存在、型、Null、空文字、長さ、桁数、構造 |
| Expected | 固定値、Enum、Range、属性条件 |
| Business | Java実装された業務Check |
| Change | Field追加、削除、型変化、値変化 |
| Completeness | 必須Check実施、Result欠落 |

### 12.2 実行規則

1. Checkは副作用を持たない。
2. 一つのCheck Failureにより他の独立Checkを暗黙停止しない。
3. Actual未取得時は`PASS`ではなく`NOT_EVALUATED`とReasonを返す。
4. Previous／Baseline不在時は`UNCHANGED`ではなく`NOT_COMPARED`とReasonを返す。
5. Check ExceptionはVerification `FAIL`へ単純変換せず、Framework FailureとしてExecution軸への影響を分類する。
6. Result欠落はCompleteness Failureとし、Parentを正常完了へ集約しない。

## 13. Result集約

Result Aggregatorは`共通Identity・Resultモデル設計書.md`の正式Priorityを使用する。

```text
Child Result収集
→ Identity／件数／必須Result検証
→ 各軸の独立集約
→ Reason／Severity集約
→ Parent Result Finalize
→ Immutable化
```

禁止事項：

- Verification `FAIL`をExecution `INCOMPLETE`へ自動変換する。
- Execution `COMPLETED`をVerification `PASS`と見なす。
- Child欠落を空集合の成功として扱う。
- Summaryだけを保存し四軸Resultを捨てる。
- Severityで原Statusを書き換える。

## 14. Artifact、State、Report境界

### 14.1 Commit Point

| Commit Point | 条件 | 失敗時 |
|---|---|---|
| Plan Seal | Preflight全項目成功 | API未呼出のまま`REJECTED` |
| Result Finalize | 必須Child ResultとIdentity整合 | `INCOMPLETE` |
| Artifact Publish | 終端Outcome別の必須Artifact、Mask、Hash、Schema、Manifestおよび完全性検証成功 | 一時領域隔離、旧公開物維持 |
| State Update | 公開Runと更新条件成立 | 旧State維持 |
| Baseline Update | 候補条件、承認規則、Generation検証およびPointer CAS成立 | 旧Baseline維持 |
| Report Publish | 公開Artifactのみ参照し、Generation／Pointerを条件更新 | Report Failureを別記録 |

### 14.2 Baseline候補

Verification `FAIL`でもExecution `COMPLETED`かつArtifact Completeなら候補になり得る。ただし候補と自動採用は別であり、`ExecutionState・Baseline管理設計書.md`の条件を満たさなければ更新しない。

Artifact Completeは「当該終端Outcomeに必要なEvidence一式が完全」を意味する。Execution `COMPLETED`とは別条件であり、`INCOMPLETE`や`UNKNOWN_OUTCOME`のEvidence PackageがCompleteでもBaseline候補にはしない。

### 14.3 Trace Commit Gate

| Commit Point | 必須Trace Gate | Trace Failure時 |
|---|---|---|
| Plan Seal | `TRACE-STATIC / TRACE-BUILD / TRACE-SEAL` | Seal禁止、API呼出0件 |
| Result Finalize | Sealed Planと`resultKey`／`apiCallCode`の一致 | Resultを`INCOMPLETE`として安全に確定 |
| Artifact Publish | `TRACE-RUNTIME` | Publish禁止またはQuarantine |
| Report Publish | `TRACE-REPORT` | Report `INCOMPLETE`または公開禁止 |

後段のTrace Failureで過去の実行事実を`REJECTED`へ変更しない。各Failureは発生したCommit Pointの状態とReasonへ保持する。

## 15. Concurrency、Lock、Cancellation

### 15.1 Concurrency

- 異なるExecution Identityは環境許容量の範囲で並列実行可能とする。
- 同一Execution IdentityはLock Policyに従う。
- 並列ScenarioがContextの同一Keyへ競合Writeしてはならない。
- Result集約順は並列完了順に依存しない。
- Artifact PathおよびIdentityはRun間で衝突しない。

### 15.2 Lock

本書では`LockPort`契約だけを確定し、File／DB／分散Lock製品を固定しない。

最低契約：

- Acquire
- Lease／Owner確認
- Renewまたは有効期限確認
- Release
- Stale Lock識別

同一Execution Identityの二重実行を許可する運用Modeが必要な場合も、Baseline更新権限を別途排他する。

### 15.3 Cancellation

| 状況 | 処理 |
|---|---|
| API呼出前 | 新しい副作用を開始せず安全停止 |
| 参照API呼出中 | Client能力の範囲でCancelし、結果を明示 |
| 更新API呼出中／直後 | 成否不明なら`UNKNOWN_OUTCOME` |
| Artifact公開中 | Atomic契約に従い旧版または新版の一方だけを有効化 |
| Baseline更新中 | Pointer切替結果を検証し、曖昧ならRecovery |

## 16. Error、Timeout、Recovery境界

| Failure分類 | Execution | Recovery | Framework処理 |
|---|---|---|---|
| Preflight Error | `REJECTED` | 原則`NOT_REQUIRED` | API呼出禁止 |
| Request Build Error | `INCOMPLETE` | 条件により`REQUIRED` | 当該Call未送信を記録 |
| HTTP Error Response | 実行契約に従う | 通常`NOT_REQUIRED` | ResponseをVerification対象にできる |
| 参照API Timeout | `INCOMPLETE`または定義済み分類 | 条件による | 暗黙Retryなし |
| 更新API Timeout | `UNKNOWN_OUTCOME` | `REQUIRED` | 後続副作用停止 |
| Check実装Exception | `INCOMPLETE` | 条件による | `PASS/FAIL`へ丸めない |
| Artifact Publish Failure | `INCOMPLETE` | 条件による | Baseline更新禁止 |
| State／Baseline更新の成否不明 | `INCOMPLETE` | `REQUIRED` | 旧／新Pointerを照合 |

Recoveryは元Runを上書きしない。再確認、補償、再実行または手動解決はすべて元RunとのRelationを保持する新しい記録とする。

## 17. Security境界

1. Credential値をDefinition、Plan、Result、Log、ArtifactまたはReportへ保存しない。
2. Secret ProviderはReferenceから実行時に値を供給し、利用ScopeをAPI Callへ限定する。
3. Request／Response／Exceptionは永続化前にMaskする。
4. Mask失敗時はArtifact公開を禁止する。
5. Path、File名、Header名等の外部入力をそのままStorage Keyへ使用しない。
6. 任意Class名、Script、SpEL、JavaScriptまたはShellをDefinitionから実行しない。
7. Trigger、実行、Baseline更新および承認権限を分離可能にする。
8. PRODおよび更新APIはEnvironment制約と運用承認の双方を満たすまで実行しない。

## 18. Observability

最低限、次のIdentityをStructured Log、MetricおよびTraceへ関連付ける。

- `requestId`
- `runId`
- `batchExecutionId`
- `useCaseExecutionId`
- `scenarioExecutionId`
- `apiCallExecutionId`
- `checkExecutionId`
- `artifactId`
- `environmentId`

Logの有無をResultの代用にしない。ResultとArtifactが正本であり、Logは診断Evidenceである。

主要Metric候補：

- Run受付／完了／拒否／不完全／Unknown Outcome件数
- Preflight Failure分類
- API Call時間、Timeout、HTTP Status分類
- Verification Failure／Change件数
- Artifact Publish／State Update Failure
- Lock競合／Lease消失
- Recovery Required未解決件数

## 19. 拡張点

| 拡張点 | 登録単位 | 制約 |
|---|---|---|
| Scenario | `scenarioId`／Registry Key | Master・設計・Java Trace必須 |
| API Executor | API種別／Executor Key | Transport責務だけを持つ |
| Request Builder | Builder Key | 未定義値を推測しない |
| Check | Check Type／Result Key Pattern | 副作用禁止、Reason必須 |
| Diff Strategy | Compare Type | 外部式を実行しない |
| Artifact Store | Storage Port | Atomic Publish契約を満たす |
| Lock | Lock Port | Owner／Lease／Releaseを保証 |
| Report | Report Port | 公開済みArtifactだけを読む |

Plugin登録は起動時またはBuild時に確定し、Run実行中の動的差替えを禁止する。同一Keyの複数実装はPreflight Errorとする。

## 20. Java実装境界

### 20.1 確定する論理境界

- Inbound／Outbound Port分離
- Immutable Command／Result
- Registryによる一意解決
- Scenario、API Access、Verification、Persistenceの責務分離
- Infrastructure ExceptionのFramework Failure変換
- Finalize後のResult変更禁止
- Test DoubleをPort単位で差替え可能にすること

### 20.2 本書で確定しない事項

- Repository内Java Source Root
- Package名
- Maven／Gradle Module
- Spring Boot採用範囲
- HTTP Client製品
- JSON Library
- File／DB／Object Storage
- Scheduler／Container／Tomcat構成

これらはEnvironment／Runtime構成設計と実装準備Reviewで承認後、同一Change SetでRepository Structure、Build、Testおよび運用文書へ反映する。

## 21. Testability

| Test Level | 確認対象 |
|---|---|
| Contract Test | Port入出力、未知Status、Reason必須、Immutable性 |
| Component Test | Loader、Preflight、Planner、Dispatcher、Aggregator |
| Adapter Test | HTTP、Storage、Lock、Secret、Report |
| Failure Injection | Timeout、Cancel、Lease消失、Publish失敗、Pointer曖昧 |
| Determinism Test | Child順序を変えても同一集約結果 |
| Security Test | Secret非出力、Mask失敗時Publish拒否、Path Traversal |
| Recovery Test | Unknown Outcome、元Run不変、新Identity発行 |
| End-to-End Test | Run RequestからReport／Recoveryまで |

正式Businessが0件の間は900番台Exampleまたは専用Fixtureを使用し、Exampleを正式Masterへ登録しない。

## 22. Framework Validation

| Validation ID | 確認内容 | Status |
|---|---|---|
| `CF-VAL-001` | API呼出前にPlan SealとPreflightが完了する。 | `DESIGNED` |
| `CF-VAL-002` | 全PortのOwner、Input、Output、Failure責務が一意である。 | `DESIGNED` |
| `CF-VAL-003` | 四軸ResultがLifecycle全体で保持される。 | `DESIGNED` |
| `CF-VAL-004` | 更新API Timeoutが自動Retryされない。 | `DESIGNED` |
| `CF-VAL-005` | Artifact Complete前にBaseline更新されない。 | `DESIGNED` |
| `CF-VAL-006` | ReportからState／Baselineを変更できない。 | `DESIGNED` |
| `CF-VAL-007` | 同一Registry Keyの曖昧解決を拒否する。 | `DESIGNED` |
| `CF-VAL-008` | Package、Source Root、製品を未承認のまま固定していない。 | `PASSED` |
| `CF-VAL-009` | Recoveryを元Runの上書きとして扱わない。 | `DESIGNED` |
| `CF-VAL-010` | Recovery文書をNormative Referenceにしていない。 | `PASSED` |
| `CF-VAL-011` | Environment MasterとRuntime Deployment Profileが分離される。 | `DESIGNED` |
| `CF-VAL-012` | Runtime Provider Capability不足時にAPI呼出前停止となる。 | `DESIGNED` |
| `CF-VAL-013` | Static／Build／Seal／Runtime／ReportのTrace GateとOwnerが一意である。 | `DESIGNED` |
| `CF-VAL-014` | Scenario Class宣言を反射実行せず、Registry管理済みInstanceだけを使用する。 | `DESIGNED` |
| `CF-VAL-015` | Runtime／Report Trace FailureがSource Runの四結果軸を書き換えない。 | `DESIGNED` |

`DESIGNED`は設計上定義済みであり、Java Testまたは運用試験済みを意味しない。

## 23. Open Issue

| Issue ID | 論点 | 暫定制約 | 決定先 |
|---|---|---|---|
| `CF-OI-001` | Java Source Root、Package、Module | 論理Componentだけを使用する。Environment Draftは製品非依存Profileを維持する。 | 実装準備Architecture Review |
| `CF-OI-002` | UUID Version、Prefix、最大長 | Opaque、一意、非再利用を維持する。 | Schema／Runtime設計 |
| `CF-OI-003` | Lock製品、Lease時間、待機戦略 | Profile別Lock／FencingとStorage条件は定義済み。製品と実値を待つ。 | Runtime／Infrastructure Review |
| `CF-OI-004` | HTTP Client、Pool、TLS、Proxy | 必須Capabilityと安全境界は定義済み。Port外へ製品型を漏らさない。 | Runtime／Infrastructure Review |
| `CF-OI-005` | 参照API Retry条件 | Default Retryなし。安全性確認を必須とする。 | API設計／Runtime設計 |
| `CF-OI-006` | Manifest Schema実体、必須Artifact Profile | Snapshot／File I/O DraftのComplete／Integrity契約を維持する。 | 第8バッチ／正式Review |
| `CF-OI-007` | Cancellation実装能力 | Dispatch-aware CapabilityとTimeout Matrixを使用し、更新APIの成否不明を`UNKNOWN_OUTCOME`とする。具体的Client製品と値を待つ。 | Runtime／NFR Review |
| `CF-OI-008` | Report再生成Identity | 元Run Resultを変更しない。 | Report／Identity整合Review |
| `CF-OI-009` | PROD更新APIの承認Interface | Environmentだけで許可しない。 | Environment／Operation設計 |

## 24. Review Checklist

- [ ] Componentごとの主責務と禁止責務が分離されている。
- [ ] Execution PlanがAPI呼出前に検証・Sealされる。
- [ ] Definition不足を推測または自動生成していない。
- [ ] Java Firstを外部Policy式へ戻していない。
- [ ] `apiId`、`apiCallCode`、`apiCallExecutionId`を混同していない。
- [ ] `resultKey`とCheck実行順序を混同していない。
- [ ] `SKIP`と`NOT_REACHED`を区別している。
- [ ] Verification FailureとExecution Failureを区別している。
- [ ] `IGNORE_VALUE`が存在・型・Null・構造Checkを無効化していない。
- [ ] 更新API Timeoutを自動Retryしていない。
- [ ] Artifact Complete前にState／Baselineを更新していない。
- [ ] Reportが実行中ObjectまたはState更新Portへ依存していない。
- [ ] Secret、任意式、Path入力の安全境界がある。
- [ ] 未決Package、Source Root、StorageおよびDeploymentを固定していない。
- [ ] ExampleまたはRecoveryを現行正本として使用していない。

## 25. 次工程への引渡し

本書完成後、次を順次作成する。

1. `Framework・業務定義連携設計書.md`
2. `Snapshot・Evidence設計書.md`
3. `ファイル入出力設計書.md`
4. `ログ・例外・Recovery設計書.md`
5. `環境・Runtime構成設計書.md`

Java実装は上記設計、現行16 Schema、Java Source Root／Package決定および重大Review指摘解消後に開始する。Schema正文完成はJava Writer／Reader／Generatorまたは5段階Trace Gateの実装完了を意味しない。

## 26. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | System設計、Identity／Result設計および現行Context／Baseline設計に基づき、Component、Port、Lifecycle、Fail Closed、Retry、Artifact／State境界を新規定義 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | Definition Source Set、Validated Bundle、Sealed Planの生成境界を明確化し、`IGNORE_VALUE`を現行Diff契約へ統一 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | 横断ReviewによりRun Phaseと四結果軸を分離し、終端Outcome別Artifact完全性とBaseline候補条件を明確化 | DRAFT |
| `1.0.0-draft.4` | 2026-07-28 | File I/O設計に合わせ、Run Create-Only、Baseline／Report Generation＋CAS Pointer、State CAS、Pinned ReadおよびFencing条件を同期 | DRAFT |
| `1.0.0-draft.5` | 2026-07-28 | Log／Recovery設計に合わせ、Failure Record、Dispatch State、Retry Eligibility、CancellationおよびImmutable Recovery Caseの境界を同期 | DRAFT |
| `1.0.0-draft.6` | 2026-07-28 | Environment／Runtime設計に合わせ、Target Environment／Runtime Profile、External Config／Secret、Capability Probe、Health、DeploymentおよびResource境界を同期 | DRAFT |
| `1.0.0-draft.7` | 2026-07-28 | 第9バッチとして既存Componentへの5段階Trace Validation責務、Registry BindingおよびCommit Gateを追加 | DRAFT |
| `1.0.0-draft.8` | 2026-07-28 | 第9バッチ第2段階の現行16 Schemaを実装入力へ反映し、Schema正文とJava／5段階Trace Gate実装完了の状態を分離 | DRAFT |
