---
title: Framework・業務定義連携設計書
document_id: E6-API-VAL-FRAMEWORK-DEFINITION-INTEGRATION-DESIGN
version: 1.0.0-draft.4
status: DRAFT
document_type: Framework and Business Definition Integration Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Framework・業務定義連携設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Framework・業務定義連携設計書 |
| 文書ID | `E6-API-VAL-FRAMEWORK-DEFINITION-INTEGRATION-DESIGN` |
| 対象 | Master、詳細設計、Scenario静的資産、Java RegistryおよびExecution Plan間の連携 |
| 配置 | `system/05_framework/` |
| 版数 | `1.0.0-draft.4` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | Framework Architecture Team |
| レビュー責任 | System Architect / Runtime Lead / Business Analysis Lead / Verification Lead |
| 承認責任 | System Owner |

## 2. 目的

本書は、E6 API Verification Platformが業務定義と実装を推測なく一意に接続するため、次を定義する。

1. 5 Master、03／04詳細設計、Scenario Input／ExpectedおよびJava Registryの責務
2. Definitionの装載順序、Reference解決、整合性検証およびBundle固定
3. Scenario、API Executor、Request Builder、Check実装のRegistry契約
4. `businessId`からResult／Evidenceまでの双方向Trace
5. 未登録、重複、無効、版不整合およびReference断裂時のFail Closed
6. Definition変更をJava、Schema、TestおよびTraceへ波及させる変更統制

本書は業務Flow、API項目、Scenario個別ロジックまたはJava Packageを定義する文書ではない。

## 3. 上位入力

| Reference | 本書で使用する決定 |
|---|---|
| `system/01_repository/Repository_Structure.md` | 5 Master、Java First、Scenario Input／Expected、Example／Recovery分離 |
| `system/02_master/README.md` | Master責務と登録Gate |
| `system/03_api_design/API設計書_Template.md` | API契約、DTO、Executor、BuilderおよびCompare要求 |
| `system/04_usecase_design/UseCase設計書_Template.md` | UseCase、Scenario、呼出順序、分岐およびMapping |
| `system/04_usecase_design/Scenario入力データ設計書.md` | Input構造、`inputSetId`、`apiCallCode`および禁止事項 |
| `system/05_framework/共通Identity・Resultモデル設計書.md` | Static／Runtime Identity、`resultKey`および四結果軸 |
| `system/05_framework/共通Framework設計書.md` | Loader、Resolver、Registry、PreflightおよびSealed Plan |
| `system/06_verification_assets/検証結果・Expected設計書.md` | ExpectedとCheck Resultの責務 |
| `system/06_verification_assets/APIレスポンスDiff設計書.md` | Compare DefinitionとDiff Resultの責務 |

## 4. 適用範囲

### 4.1 対象

- 5 Masterの読込、構文解析、列契約およびID解決
- API／UseCase／Scenario詳細設計のReference解決
- Scenario Input／Expected JSONとSchemaの整合
- Java Scenario、Executor、Builder、CheckおよびCompare実装のRegistry解決
- Environment外部設定Referenceの存在確認
- Definition Snapshot、HashおよびVersion Compatibility
- Execution Planへ渡す型付きDefinition Graph
- MasterからArtifactまでの双方向Trace

### 4.2 対象外

| 対象外 | 正式な管理先 |
|---|---|
| As-Is業務事実 | `business/` |
| API Request／Response項目 | `system/03_api_design/` |
| 個別Scenarioの順序、分岐、Mapping | `system/04_usecase_design/`およびJava Scenario |
| Check Algorithm | Java Check実装および`system/06_verification_assets/` |
| Runtime Artifactの物理Path | `ファイル入出力設計書.md` |
| Java Source Root／Package／Module | Environment／Runtime構成設計と実装準備Review |
| Credential実値 | Secret Provider |

## 5. 設計原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `FDI-P001` | One Authority per Fact | 同じ事実を複数成果物で独立管理しない。 |
| `FDI-P002` | Five Masters Only | RuntimeがMasterとして扱うのはBusiness、Environment、API、UseCase、Scenarioだけとする。 |
| `FDI-P003` | Java First | 順序、分岐、Mapping、Check登録およびCompare Definitionを外部式から実行しない。 |
| `FDI-P004` | Explicit Reference | File名、表示名、行順またはClass名推測でReferenceを補完しない。 |
| `FDI-P005` | Resolve Before Execute | 全ReferenceとRegistryをAPI呼出前に解決する。 |
| `FDI-P006` | Exact Cardinality | 必須Referenceは一件だけ解決し、0件または複数件をErrorとする。 |
| `FDI-P007` | Enabled Is Not Sufficient | `enabled=true`だけで実行可能と判定しない。全Gate成立を要求する。 |
| `FDI-P008` | Immutable Bundle | 検証済みDefinition BundleをRun中に差し替えない。 |
| `FDI-P009` | Trace Both Ways | Definitionから実装／Resultへ、Resultから根拠Definitionへ追跡可能にする。 |
| `FDI-P010` | No Executable Data | Markdown／JSONへScript、Class生成指示または任意式を埋め込まない。 |
| `FDI-P011` | Example Isolation | 900番台Exampleを正式Execution Planへ混入させない。 |
| `FDI-P012` | Recovery Non-Normative | `recovery/`を現行Definition Sourceにしない。 |

## 6. Definition Layerと正本

| Layer | 正本 | 保持する事実 | 保持してはならない事実 |
|---|---|---|---|
| Business Fact | `business/` | 現行Flow、分岐、前提、業務根拠 | To-Be実行Class |
| Master | 5 Master | Stable ID、名称、関係、Reference、Enabled | 詳細Field、実行Algorithm |
| Detail Design | 03／04 | API契約、Scenario順序、Mapping、Check要求 | Credential実値、Runtime結果 |
| Static Asset | Input／Expected JSON | 初期値、期待値、対象Check Data | 分岐式、秘密情報、Baseline |
| Java Registry | Build Artifact | 実装Key、型、対応ID、Capability | Master事実の独自複製 |
| Runtime Plan | Sealed `ExecutionPlan` | 解決済みSnapshotと実行順序 | 未解決Reference、可変定義 |
| Runtime Result | Result／Evidence | 実行実体、四軸結果、Definition Reference | Master更新 |

## 7. 5 Master連携契約

### 7.1 Business Master

| 項目 | 契約 |
|---|---|
| Identity | `businessId` |
| 根拠 | `businessAnalysisRef` |
| 被参照元 | UseCase Masterの`businessIds` |
| 実行時用途 | Coverage、Report分類、Trace |
| 実行ロジック | 保持しない |

正式Businessが0件の場合、正式UseCase／Scenario Execution Planを生成してはならない。

### 7.2 Environment Master

| 項目 | 契約 |
|---|---|
| Identity | `environmentId` |
| 外部参照 | `baseUrlRef`、`authProfileRef` |
| 被参照元 | UseCase Masterの`applicableEnvironmentIds`、Run Request |
| Runtime解決 | Config Provider／Secret Provider |
| 禁止 | URL、Token、Password、Credential実値のMaster保存 |

`enabled=true`はEnvironment定義の有効性を示すだけで、PROD実行または更新API実行を自動許可しない。

### 7.3 API Master

| 項目 | 契約 |
|---|---|
| Identity | `apiId` |
| 詳細設計 | `apiDesignRef` |
| 実装 | `requestDto`、`responseDto`およびAPI設計で指定するRegistry Key |
| 被参照元 | Scenario詳細設計の各`apiCallCode` |
| 一意性 | `apiId`はAPI定義、`apiCallCode`はScenario内呼出位置 |

同じ`apiId`を一つのScenarioで複数回呼び出す場合、異なる`apiCallCode`を必須とする。

### 7.4 UseCase Master

| 項目 | 契約 |
|---|---|
| Identity | `useCaseId` |
| 親関係 | `businessIds` |
| 子関係 | `scenarioIds` |
| 環境 | `applicableEnvironmentIds` |
| 詳細設計 | `useCaseDesignRef` |

`businessIds`、`scenarioIds`および詳細設計内一覧は集合として双方向一致しなければならない。

### 7.5 Scenario Master

| 項目 | 契約 |
|---|---|
| Identity | `scenarioId` |
| 親 | `useCaseId` |
| Java実装 | `executionClass`をRegistryで一意解決 |
| Static Asset | `inputRef`、`expectedRef` |
| 詳細設計 | `scenarioDesignRef` |

Classの存在だけでは実行可能としない。Master、詳細設計、Input、Expected、Registry、EnvironmentおよびSchemaの全Gateを満たす必要がある。

## 8. 対応表の位置付け

`API_UseCase_Scenario対応表.md`は、5 MasterとScenario詳細設計から生成できるTrace Viewであり、第6のMasterではない。

| 規則 | 内容 |
|---|---|
| 生成元 | UseCase Master、Scenario Master、API Master、Scenario詳細設計 |
| Identity | `scenarioId + apiCallCode` |
| 更新 | 生成元と同一Change Setで再生成 |
| Runtime | Preflight整合確認に利用可能だが、単独で実行定義を補完しない |
| 不一致 | 手修正で吸収せず、生成元を是正して再生成 |

`callSequence`は表示および整合確認用であり、Java Scenario実装を置き換える実行Scriptではない。

## 9. 詳細設計連携

### 9.1 API設計

API設計書は最低限、次をAPI MasterおよびJavaへ追跡可能にする。

- Method、Endpoint Reference、Request／Response DTO
- Header、Path、Query、BodyのField契約
- HTTP StatusとResponse Schema
- Sensitive FieldとMask方式
- Timeout、Retry、Idempotency分類
- Executor Key、Builder KeyおよびDTO Class
- API既定Contract CheckとCompare Definition要求

Scenario固有の呼出順序、分岐、初期値およびExpectedをAPI設計へ保持してはならない。

### 9.2 UseCase設計

UseCase設計書はBusiness、Scenario Coverage、前提、事後条件およびEnvironment適用範囲を保持する。UseCase Masterとの集合差分を許可しない。

### 9.3 Scenario詳細設計

Scenario詳細設計は最低限、次を保持する。

| 項目 | 内容 |
|---|---|
| `scenarioId` | Scenario Masterと一致 |
| `apiCallCode` | Scenario内一意 |
| `apiId` | API Masterで解決 |
| `callSequence` | Trace用の安定した順序 |
| `executeCondition` | Java分岐へのTrace。外部式として実行しない |
| Mapping | Source／Target／変換責務／Java Method Reference |
| Builder／Executor | Registry Key |
| Check | `resultKey`、Check Type、Java Check Key、Expected Reference |
| 到達性 | `RUN / SKIP / NOT_REACHED`の判定責務 |

## 10. Scenario Input／Expected連携

### 10.1 Input

Inputは`scenarioId`、`useCaseId`、`environmentId`、`inputSetId`およびScenarioが要求する初期値を保持する。

Inputに次を含めてはならない。

- 実行可能な分岐式またはMapping式
- Java Class名の任意指定
- Expected、BaselineまたはPrevious
- Secret実値
- Scenario詳細設計に存在しない`apiCallCode`

### 10.2 Expected

Expectedは`environmentId + useCaseId + scenarioId + inputSetId`に対応し、Status、Contract、BusinessおよびChange Checkの期待を表現する。現行契約では独立した`expectedSetId`を使用せず、Expected内容改訂は`expectedVersion`で追跡する。

`IGNORE_VALUE`は値差分だけを対象外にし、存在、型、Null、形式、Object／Array構造および子項目Checkを無効にしない。

### 10.3 Asset Cardinality

| Reference | Cardinality | 0件時 | 複数件時 |
|---|---:|---|---|
| `scenarioId → inputRef` | 1 | `DEFINITION_REFERENCE_MISSING` | `DEFINITION_REFERENCE_AMBIGUOUS` |
| `scenarioId → expectedRef` | 1 | `DEFINITION_REFERENCE_MISSING` | `DEFINITION_REFERENCE_AMBIGUOUS` |
| `inputRef → inputSetId` | 1 | `INPUT_SET_MISSING` | 複数Root ObjectはSchema Error |
| `expectedRef → inputSetId` | 1 | `EXPECTED_INPUT_SET_MISSING` | Input側との不一致時Error |
| 選択InputとExpected | 1:1 | `EXPECTED_NOT_MATCHED` | `environmentId / useCaseId / scenarioId / inputSetId`不一致時Error |

複数Input／Expected Assetを許可する場合も、Run Requestが選択する`inputSetId`と両Referenceを一意に解決しなければならない。複数Assetの物理命名が承認されるまでは、現行FileへArrayまたは独自Set Containerを追加しない。

## 11. Java Registry契約

### 11.1 Registry分類

| Registry | Key | 対応対象 | 必須Capability |
|---|---|---|---|
| Scenario Registry | `scenarioId` | `executionClass` | Planに従うScenario実行 |
| API Executor Registry | Executor Key | API Call | Transport実行、Response正規化 |
| Request Builder Registry | Builder Key | `apiCallCode` | 型付きDTO／JSON構築 |
| Check Registry | Check Key | `resultKey` | 副作用なしのCheck実行 |
| Compare Registry | Compare Key | Field／Object比較 | Change Result生成 |
| Mapper Registry | Mapper Key | Source→Target Mapping | 型変換と欠落検出 |

### 11.2 Registry Descriptor

各登録は次のDescriptorを提供する。

| 項目 | 必須 | 内容 |
|---|---|---|
| `registryType` | Yes | Scenario／Executor／Builder／Check／Compare／Mapper |
| `registryKey` | Yes | Scope内一意な安定Key |
| `implementationType` | Yes | Build内で解決した型 |
| `supportedDefinitionVersion` | Yes | 互換Version範囲 |
| `supportedSchemaVersion` | 条件付 | 入出力Schema互換範囲 |
| `capabilities` | Yes | Read／Update、Retry Safe等 |
| `buildIdentity` | Yes | Build／Commit／Artifact Reference |
| `bindingRefs` | Yes | 対応する`scenarioId`、`apiId`、`apiCallCode`または`resultKey`。Registry種別ごとの許可Scopeだけを保持 |
| `enabled` | Yes | Build内登録状態 |

### 11.3 解決規則

1. Definitionが明示したKeyだけを解決する。
2. Classpath走査結果から名称が近いClassを選ばない。
3. 同一Keyの0件、複数件、無効登録およびVersion非互換を拒否する。
4. Registry DescriptorとAPI／Scenario設計のCapabilityを照合する。
5. Run開始後にRegistryを追加、削除または差し替えない。
6. 外部Definitionから任意の完全修飾Class名を受け取って反射実行しない。

### 11.4 Master／設計とRegistryのBinding契約

RegistryはMasterの複製ではなく、Build内実装を静的Definitionへ接続するAllowlistである。Bindingは次の一致条件をすべて満たさなければならない。

| Registry | Definition側Source | Join Key | 必須一致 |
|---|---|---|---|
| Scenario | Scenario Master | `scenarioId` | Descriptorが一件だけ存在し、`implementationType`が`executionClass`と完全一致する。 |
| API Executor | API設計／Scenario詳細設計 | Executor Key | `apiId`、HTTP CapabilityおよびRead／Update分類が一致する。 |
| Request Builder | API設計／Scenario詳細設計 | Builder Key | `apiCallCode`、`apiId`および`requestDto`互換性が一致する。 |
| Check | Scenario詳細設計／Expected | Check Key＋`resultKey` | `resultKey`がExpected、設計、Registryの三者で一件ずつ対応する。 |
| Compare | API設計／Scenario詳細設計 | Compare Key | API既定Scopeまたは`scenarioId + apiCallCode` Override Scopeが一致する。 |
| Mapper | Scenario詳細設計 | Mapper Key | Source Call、Target Call、Field型および変換Capabilityが一致する。 |

`Scenario_Master.executionClass`はBuild Trace用の宣言Referenceであり、Instantiation命令ではない。Runtimeはこの値を反射実行せず、`scenarioId`で解決済みScenario Registry Descriptorを取得し、その`implementationType`との完全一致を検証した後にRegistry管理済みInstanceだけを使用する。

Registry SnapshotはDescriptor本体、Binding Edge、Build Identityおよび互換性判定を固定する。Class名が存在してもRegistryに登録されていない場合、Registry Keyが一致してもBinding Scopeが異なる場合、またはDescriptorからDefinitionへ逆引きできない場合はすべて`REGISTRY_RESOLUTION_ERROR`とする。

## 12. Definition装載順序

```mermaid
flowchart TD
    A["Repository・Build識別"] --> B["5 Master装載"]
    B --> C["03／04設計解決"]
    C --> D["Input・Expected・Schema検証"]
    D --> E["Java Registry解決"]
    E --> F["Environment・安全制約検証"]
    F --> G["Definition Graph固定"]
    G --> H["Execution Plan生成・Seal"]
```

順序を入れ替えて不足定義を後から補完してはならない。外部API呼出はStep H完了後だけ許可する。

## 13. Definition Bundle

### 13.1 構造

| 項目 | 内容 |
|---|---|
| `bundleId` | Bundle実体の一意ID |
| `bundleVersion` | Bundle契約Version |
| `createdAt` | 生成時刻。Identityには使用しない |
| `sourceRevision` | Repository Revision／Release Artifact |
| `masterSnapshots` | 5 MasterのVersion、Hash、件数 |
| `designSnapshots` | 解決した03／04文書のID、Version、Hash |
| `assetSnapshots` | Input／Expected／SchemaのVersion、Hash |
| `registrySnapshot` | Registry DescriptorとBuild Identity |
| `referenceGraph` | ID、Reference、Cardinality、解決状態 |
| `validationResults` | Preflight検証結果 |
| `bundleHash` | 正規化Bundle全体Hash |

### 13.2 不変条件

- Bundle内の全Referenceは`RESOLVED_EXACTLY_ONE`である。
- `enabled=true`の実行対象に無効な親、子、API、EnvironmentまたはRegistryがない。
- 同じStatic IDが複数Sourceで競合しない。
- Exampleと正式定義を同一Bundleへ混在させない。
- Source Revision、Build IdentityおよびSchema Versionを記録する。
- Bundle Hash確定後は内容を変更しない。

### 13.3 SchemaとSemantic Validator

`definition-bundle.schema.json`は、Bundle Identity、Definition Profile、5 Master Snapshot、設計／Asset Snapshot、Registry Snapshot、Reference Edge、Validation ResultおよびHashの構造を検証する。

次は単一JSON SchemaではなくDefinition Bundle Builder／Semantic Validatorが検証する。

1. `masterSnapshots`に5 Master Typeが各一件だけ存在する。
2. Document／Asset／Descriptor／EdgeのStable KeyがScope内一意である。
3. `definitionProfile=FORMAL`と900番台Exampleが混在しない。
4. `scenarioId + executionClass`とRegistry `implementationType`が完全一致する。
5. Source Revision、各Content Hash、Registry Snapshot HashおよびBundle Hashが実Byteと一致する。
6. 全必須Referenceが実Sourceへ一件だけ解決する。

## 14. Reference Graph

### 14.1 必須Edge

| From | To | Cardinality |
|---|---|---:|
| UseCase | Business | 1..N |
| UseCase | Environment | 1..N |
| UseCase | Scenario | 1..N |
| Scenario | UseCase | 1 |
| Scenario | Scenario詳細設計 | 1 |
| Scenario | Input | 1 |
| Scenario | Expected | 1 |
| Scenario | Scenario Registry | 1 |
| Scenario API Call | API | 1 |
| API | API詳細設計 | 1 |
| API Call | Builder／Executor | 各1 |
| Check Spec | Check Registry | 1 |
| Input／Expected／Result | JSON Schema | 各1 |

### 14.2 循環と孤立

- UseCaseとScenarioの双方向Referenceは整合確認用であり、装載の無限循環を起こしてはならない。
- Business、API、UseCase、Scenarioの有効レコードが孤立している場合はCoverage Errorとする。
- 無効レコードは正式Traceには残せるがExecution Planへ含めない。
- 無効親を参照する有効子を許可しない。

## 15. 双方向Trace

### 15.1 Forward Trace

```text
businessId
→ useCaseId
→ scenarioId
→ inputSetId
→ expectedRef / expectedVersion
→ apiCallCode / apiId
→ Registry Key / implementationType
→ resultKey
→ checkExecutionId / artifactId
```

### 15.2 Reverse Trace

ResultまたはEvidenceから最低限、次へ逆引きできること。

- `runId`とExecution Identity
- `businessId`、`useCaseId`、`scenarioId`
- `apiCallCode`、`apiId`、`resultKey`
- Definition Bundle ID／Hash
- Source Document ID／Version／Hash
- Registry Descriptor／Build Identity
- Input Set ID、Expected Reference／Content VersionおよびSchema Version

### 15.3 Trace Matrix

| Trace ID | Source | Target | 一致Key | Gate |
|---|---|---|---|---|
| `FDI-TRC-001` | Business Master | 業務分析 | `businessAnalysisRef` | 登録根拠存在 |
| `FDI-TRC-002` | UseCase Master | UseCase設計 | `useCaseId` | 双方向一致 |
| `FDI-TRC-003` | Scenario Master | Scenario設計 | `scenarioId` | 双方向一致 |
| `FDI-TRC-004` | Scenario Master | Input／Expected | `scenarioId`＋Ref | Schema一致 |
| `FDI-TRC-005` | Scenario設計 | API Master | `apiCallCode`＋`apiId` | API有効 |
| `FDI-TRC-006` | API Master | API設計／DTO | `apiId`＋Class | 契約一致 |
| `FDI-TRC-007` | 設計 | Java Registry | Registry Key | 一意・互換 |
| `FDI-TRC-008` | Check Spec | Result | `resultKey` | 欠落なし |
| `FDI-TRC-009` | Result | Evidence | Execution ID | Hash／Manifest |
| `FDI-TRC-010` | Scenario Master | Scenario Registry | `scenarioId`＋`executionClass` | Descriptor／Class完全一致 |
| `FDI-TRC-011` | Definition Bundle | Run Meta | `bundleId`＋`bundleHash` | Seal済みBundle一致 |
| `FDI-TRC-012` | Run Meta | Artifact Manifest | `runId`＋Execution Identity＋Bundle | 三者一致 |
| `FDI-TRC-013` | Scenario設計 | Scenario Execution | `scenarioId`＋`apiCallCode` | Plan Call集合一致 |
| `FDI-TRC-014` | API Call設計 | API Call Meta／Diff | `runId`＋`apiCallCode`＋`apiId` | 実行・比較Identity一致 |
| `FDI-TRC-015` | Expected／Check Registry | Verification Result | `scenarioId`＋`inputSetId`＋`resultKey` | 必須Check双方向一致 |
| `FDI-TRC-016` | Artifact Manifest | Core Artifact | `artifactId`＋`relativePath`＋`contentHash` | Entryと実体一致 |
| `FDI-TRC-017` | Report Item | Result／Diff／Artifact | Source ID＋Relative Reference | Sourceへ逆引き可能 |
| `FDI-TRC-018` | Runtime Result | Master／設計／Registry | Execution Identity＋Bundle Snapshot | 過去Snapshotへ逆引き可能 |

## 16. Preflight Validation

| Validation ID | 確認内容 | Failure Code |
|---|---|---|
| `FDI-VAL-001` | 5 MasterだけがMasterとして装載される。 | `UNSUPPORTED_MASTER_TYPE` |
| `FDI-VAL-002` | ID、Referenceおよび固定列が有効である。 | `DEFINITION_CONTRACT_ERROR` |
| `FDI-VAL-003` | 必須Referenceが一意に解決する。 | `DEFINITION_REFERENCE_ERROR` |
| `FDI-VAL-004` | 親子ReferenceとEnabled状態が整合する。 | `DEFINITION_RELATION_ERROR` |
| `FDI-VAL-005` | 03／04設計とMasterが一致する。 | `DESIGN_MASTER_MISMATCH` |
| `FDI-VAL-006` | Input／ExpectedがScenarioおよびSchemaと一致する。 | `SCENARIO_ASSET_MISMATCH` |
| `FDI-VAL-007` | `apiCallCode`、`inputSetId`および`resultKey`がScope内一意である。 | `DEFINITION_ID_DUPLICATE` |
| `FDI-VAL-008` | Registry Keyが一件だけ解決しVersion互換である。 | `REGISTRY_RESOLUTION_ERROR` |
| `FDI-VAL-009` | DTO／JSON Field契約とMask定義が完全である。 | `API_CONTRACT_INCOMPLETE` |
| `FDI-VAL-010` | Environment、Config、Auth Referenceおよび実行制約が解決する。 | `ENVIRONMENT_RESOLUTION_ERROR` |
| `FDI-VAL-011` | Example／Recoveryが正式Bundleに混入していない。 | `NON_PRODUCTION_DEFINITION_MIXED` |
| `FDI-VAL-012` | Source Revision、Version、HashおよびBundle Hashが確定する。 | `DEFINITION_INTEGRITY_ERROR` |
| `FDI-VAL-013` | Scenario Registryの`scenarioId`、`executionClass`および`implementationType`が完全一致する。 | `REGISTRY_BINDING_MISMATCH` |
| `FDI-VAL-014` | Registry Descriptorから対応Definitionへ一意に逆引きできる。 | `REGISTRY_REVERSE_TRACE_MISSING` |
| `FDI-VAL-015` | Run MetaとManifestの`runId`、Execution Identity、`bundleId`および`bundleHash`が一致する。 | `RUNTIME_TRACE_MISMATCH` |
| `FDI-VAL-016` | Result／Diff／API Call MetaのIdentityがSealed Plan内Callへ解決する。 | `RUNTIME_ARTIFACT_ORPHAN` |
| `FDI-VAL-017` | Manifest EntryのID、Path、HashおよびOwnerがArtifact実体と一致する。 | `ARTIFACT_TRACE_MISMATCH` |
| `FDI-VAL-018` | Report全明細がResult、DiffまたはManifest Entryへ逆引きできる。 | `REPORT_REVERSE_TRACE_MISSING` |

`FDI-VAL-001～014`の一件でもErrorの場合、Execution Statusを`REJECTED`とし、外部API呼出を0件にする。`FDI-VAL-015～017`は実行後の公開GateとしてPackage公開を拒否またはQuarantineし、過去の実行事実を`REJECTED`へ書き換えない。`FDI-VAL-018`はReport公開Gateであり、Source Runの四結果軸を変更しない。

### 16.1 段階別Validation Gate

後段は前段の成功を前提とする。必要な入力またはSchema Coverageが欠ける場合、推測で`PASS`にせず`BLOCKED`または`NOT_EXECUTED`とする。

| Gate | 実行時点 | 主入力 | 主出力 | Failure時 |
|---|---|---|---|---|
| `TRACE-STATIC` | Build前／CI | 5 Master、03／04設計、Input／Expected、現行16 Schema | Static Reference Graph | Release Block |
| `TRACE-BUILD` | Build／Startup | Static Graph、Registry Descriptor、Build Identity | Registry Binding Graph | 起動／Release Block |
| `TRACE-SEAL` | Run Preflight | Definition Bundle、Environment、Run Request | Sealed Trace Projection | API呼出0件、`REJECTED` |
| `TRACE-RUNTIME` | Artifact Finalize | Run Meta、Result、Diff、Manifest、Core Artifact | Runtime Trace Validation Result | Publish禁止／Quarantine |
| `TRACE-REPORT` | Report Finalize | Published Package、Report Set | Reverse Trace Validation Result | Report `INCOMPLETE`または公開禁止 |

### 16.2 Trace Projection

Trace Validationは専用の第6 MasterまたはRepository Registryを作らず、各正本から次のProjectionを導出する。

| Projection | 必須Key |
|---|---|
| Static Definition | `businessId`、`environmentId`、`useCaseId`、`scenarioId`、`inputSetId`、`apiCallCode`、`apiId`、`resultKey` |
| Build Binding | `registryType`、`registryKey`、`implementationType`、`bindingRefs`、`buildIdentity` |
| Run Seal | `runId`、Execution Identity、`bundleId`、`bundleHash`、Registry Snapshot Reference |
| Artifact | `artifactId`、Owner Execution ID、`relativePath`、`contentHash`、Definition Reference |
| Report Source | `runId`、`resultId`／`apiCallCode`／`artifactId`、Source Relative Reference |

ProjectionはValidator内部の不変入力またはValidation Resultとして扱い、Master事実を独自に更新しない。Display Name、Array Index、Report行番号またはFile名類似をJoin Keyに使用してはならない。

### 16.3 現行Coverage

| Gate | 現行設計Coverage | 現在状態 |
|---|---|---|
| `TRACE-STATIC` | Master／設計／Input／Expectedの規則と現行16 Schemaを定義済み。正式E6レコードは0件。 | `DESIGNED / FORMAL_DATA_BLOCKED` |
| `TRACE-BUILD` | Descriptor、BindingおよびFail Closed契約を定義済み。Java Source Root／Package／Build Artifact未確定。 | `DESIGNED / IMPLEMENTATION_BLOCKED` |
| `TRACE-SEAL` | Bundle ID／Hash、Registry Snapshot、Execution IdentityおよびBundle Schema正文・機械Validation済み。Java Builder／正式Data未実装。 | `DESIGNED / IMPLEMENTATION_BLOCKED` |
| `TRACE-RUNTIME` | Run Meta、Scenario Execution、API Meta、Result、DiffおよびManifest Schema正文・機械Validation済み。Java Writer／Readerと実Artifact Test未実施。 | `DESIGNED / IMPLEMENTATION_BLOCKED` |
| `TRACE-REPORT` | Batch Resultと4 Report Schema、Source Result／Diff／Manifestへの逆引き規則を定義済み。Generator／Publisher未実装。 | `DESIGNED / IMPLEMENTATION_BLOCKED` |

この表の`DESIGNED`または`PARTIAL`を実装済み、Contract Test済み、正式Review済みまたはRelease可能と読み替えてはならない。

## 17. Enabledと実行可能性

実行可能性は次の論理積で判定する。

```text
Master Enabled
AND Parent／Child Enabled整合
AND Detail Design Complete
AND Input／Expected Valid
AND Registry Resolved Exactly Once
AND Schema Compatible
AND Environment Allowed
AND Security／Operation Gate Approved
AND Definition Bundle Sealed
```

`enabled=false`は明示的対象外であり、Reference不正や未完成を隠すために使用しない。無効化理由、Ownerおよび再有効化条件を変更履歴へ残す。

## 18. Error処理

| Error分類 | 例 | Execution | Verification | Recovery |
|---|---|---|---|---|
| Parse／Schema | Markdown列不足、JSON不正 | `REJECTED` | `NOT_EVALUATED` | `NOT_REQUIRED` |
| Reference | ID未登録、複数解決 | `REJECTED` | `NOT_EVALUATED` | `NOT_REQUIRED` |
| Registry | Class未登録、Key重複、版非互換 | `REJECTED` | `NOT_EVALUATED` | `NOT_REQUIRED` |
| Environment | Config／Auth Reference未解決 | `REJECTED` | `NOT_EVALUATED` | 条件により`REQUIRED` |
| Integrity | Hash不一致、Source Revision混在 | `REJECTED` | `NOT_EVALUATED` | `REQUIRED` |
| Runtime Drift | Seal後にDefinition／Buildが変化 | `INCOMPLETE` | `NOT_EVALUATED` | `REQUIRED` |

Definition ErrorをVerification `FAIL`へ変換してはならない。業務結果不一致ではなく実行前提不成立である。

## 19. 変更統制

### 19.1 変更影響

| 変更 | 必須影響確認 |
|---|---|
| Business Master | UseCase Coverage、Report分類 |
| Environment Master | Config／Auth、実行許可、安全Gate |
| API Master／設計 | DTO、Executor、Builder、Scenario呼出、Contract Test |
| UseCase Master／設計 | Business、Scenario集合、Environment |
| Scenario Master／設計 | Input、Expected、Java Scenario、対応表、E2E Test |
| Input | Schema、Builder、Test Data |
| Expected | Check Registry、Result Schema、Verification Test |
| Registry | Build Identity、Compatibility、Component Test |
| Schema | DTO、Serializer、Migration、Backward Compatibility |

### 19.2 同一Change Set

ID、Reference、Field契約またはRegistry Keyを変更するときは、影響するMaster、設計、Java、Schema、TestおよびTrace Viewを同一Change Setで更新する。途中状態を正式Releaseとして公開しない。

### 19.3 互換性

- Breaking ChangeはDefinition／SchemaのMajor Versionを更新する。
- Bundleは一つの互換Version集合だけで構成する。
- Run中に新Versionへ切り替えない。
- 過去Runは当時のBundle ID／Hashで再現可能なTraceを保持する。

## 20. Security

1. Definitionから任意Class、Script、Shell、SpELまたはJavaScriptを実行しない。
2. RegistryはBuild済みAllowlistとして扱い、外部入力で動的拡張しない。
3. Path ReferenceはRepository Root配下の許可領域へ正規化し、Traversalを拒否する。
4. Config／AuthはReferenceだけを保持し、Secret実値をBundle、LogまたはArtifactへ含めない。
5. Sensitive Field定義がないAPIは有効化しない。
6. Definition Hash不一致をWarningへ降格しない。
7. PRODおよび更新APIはEnvironment、Operation ApprovalおよびData Leaseを別々に確認する。

## 21. Test設計

| Test Level | 確認内容 |
|---|---|
| Parser Test | 5 Master固定列、Markdown／JSON構文、未知列 |
| Reference Test | 0件、1件、複数件、循環、孤立、無効親 |
| Registry Contract Test | Key重複、未登録、Version非互換、Capability不足 |
| Asset Contract Test | Scenario／Set ID、Schema、Secret混入、未知`apiCallCode` |
| Trace Test | Forward／Reverse Trace、対応表再生成 |
| Determinism Test | 同一Source／Buildから同一Bundle Hash |
| Drift Test | Seal後のSource／Build差替え拒否 |
| Security Test | Path Traversal、任意Class、Script、Secret |
| End-to-End Test | MasterからSealed Plan、ResultからDefinition逆引き |

正式Businessが0件の間は、900番台Exampleを専用Test Profileで使用し、正式Bundleと混在させない。

## 22. Validation状態

| Validation ID | 内容 | Status |
|---|---|---|
| `FDI-DOC-V001` | 5 Masterの責務とReference方向を定義した。 | `DESIGNED` |
| `FDI-DOC-V002` | 対応表を第6 Masterではなく生成Trace Viewとした。 | `DESIGNED` |
| `FDI-DOC-V003` | Input／Expected／Java First境界を定義した。 | `DESIGNED` |
| `FDI-DOC-V004` | Registryの一意解決と動的実行禁止を定義した。 | `DESIGNED` |
| `FDI-DOC-V005` | Definition Bundleと装載順序を定義した。 | `DESIGNED` |
| `FDI-DOC-V006` | Forward／Reverse Traceを定義した。 | `DESIGNED` |
| `FDI-DOC-V007` | Example／Recoveryを正式Sourceにしていない。 | `PASSED` |
| `FDI-DOC-V008` | Java Source Root、Packageまたは製品を固定していない。 | `PASSED` |
| `FDI-DOC-V009` | Static／Build／Seal／Runtime／Reportの段階別Gateと入力不足時の`BLOCKED`を定義した。 | `DESIGNED` |
| `FDI-DOC-V010` | Scenario MasterのClass宣言とBuild内Registry Instance生成を分離した。 | `DESIGNED` |

`DESIGNED`は設計済みを示し、Java実装またはRuntime Test完了を意味しない。

## 23. Open Issue

| Issue ID | 論点 | 暫定制約 | 決定先 |
|---|---|---|---|
| `FDI-OI-001` | Registry Keyの正式命名規則 | Scenario Registryは`scenarioId`を使用する。他Registryは論理Keyを使用しPackage名を埋め込まない。 | Java実装設計 |
| `FDI-OI-002` | Definition Bundle Schema | `definition-bundle.schema.json`正文・機械Validation済み。BundleなしでPlanを生成せず、正式Role ReviewとJava Builder Contract Testを待つ。 | Architecture／Runtime Review |
| `FDI-OI-003` | Markdown Parser／AST製品 | Port外へ製品型を漏らさない。 | 実装準備Review |
| `FDI-OI-004` | Hash正規化方式 | Raw File Hashと論理Content Hashを区別する。 | Snapshot／File I/O設計 |
| `FDI-OI-005` | CI対応表自動生成 | 手修正を正本化しない。 | 第9バッチTrace Validation |
| `FDI-OI-006` | Multiple Input／Expected Asset配置 | `inputSetId`とScenario Masterの両Referenceで一意選択し、未採用の`expectedSetId`を追加しない。 | File I/O／Schema設計 |
| `FDI-OI-007` | PROD Approval／Data Lease Interface | Environment Enabledだけでは許可しない。 | Environment／Runtime・Operation設計 |
| `FDI-OI-008` | Run Meta／Scenario Execution／API Call MetaのTrace Schema | 3独立Schema正文・機械Validation済み。親子Identityと実Artifact一致はCross-Artifact Validator／Java Contract Testを待つ。 | `FW-OI-017`／Runtime Review |
| `FDI-OI-009` | Report Source ReferenceとReport JSON Schema | Batch Resultと4 Report Schema正文・機械Validation済み。Source ID＋Relative Reference＋Hashの逆引き実装を待つ。 | Report／Runtime Review |

## 24. Review Checklist

- [ ] 5 Master以外をMasterとして装載していない。
- [ ] 対応表を実行ロジックまたは第6 Masterとして扱っていない。
- [ ] Master、詳細設計、Input／Expected、Javaの正本責務が分離されている。
- [ ] ReferenceをFile名、表示名、順番または類似Classから推測していない。
- [ ] `apiId`、`apiCallCode`、`apiCallExecutionId`を区別している。
- [ ] `resultKey`がCheck順序に依存していない。
- [ ] Java Registryが0件／複数件／Version非互換を拒否する。
- [ ] `enabled=true`だけで実行可能としていない。
- [ ] ExampleまたはRecoveryが正式Bundleに混入していない。
- [ ] Definition ErrorをVerification Failureへ変換していない。
- [ ] BundleをAPI呼出前に検証しSealしている。
- [ ] Result／EvidenceからSourceとBuildへ逆引きできる。
- [ ] Secret、任意式、動的ClassおよびPath Traversalを拒否する。
- [ ] Source Root、Packageおよび製品を未承認のまま固定していない。

## 25. 次工程への引渡し

本書のDefinition Bundle、Asset Snapshot、Hash、MaskおよびTrace要件を入力として、次に`Snapshot・Evidence設計書.md`を作成する。

Java実装開始前に、次が必要である。

1. 本書とFramework中核3設計の横断Review
2. 現行16 JSON Schemaの正式ReviewとJava DTO／Writer／Reader Contract Test
3. Registry Key命名とJava Source Root／Packageの承認
4. 正式Business／API／UseCase／Scenarioの登録
5. Definition Bundle、Reference GraphおよびTraceの自動Validation

## 26. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | 5 Master、03／04設計、Input／Expected、Java Registry、Definition Bundleおよび双方向Traceの連携契約を新規定義 | DRAFT |
| `1.0.0-draft.2` | 2026-07-28 | Scenario Expected Schema契約に合わせ、`expectedSetId`を除去し、Input／Expectedの1:1 Identity、ReferenceおよびVersion追跡へ統一 | DRAFT |
| `1.0.0-draft.3` | 2026-07-28 | 第9バッチとしてMaster／Registry Binding、5段階Trace Gate、Runtime／Report逆引き、Schema未対象区間のFail Closedを具体化 | DRAFT |
| `1.0.0-draft.4` | 2026-07-28 | 第9バッチ第2段階のDefinition Bundle、Runtime Meta、Batch ResultおよびReport Schemaを反映し、Schema構造検証とSemantic／Java Contract Testの責務を分離 | DRAFT |
