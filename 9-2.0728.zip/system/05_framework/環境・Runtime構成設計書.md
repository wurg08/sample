---
title: 環境・Runtime構成設計書
document_id: E6-API-VAL-ENVIRONMENT-RUNTIME-DESIGN
version: 1.0.0-draft.1
status: DRAFT
document_type: Environment and Runtime Deployment Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# 環境・Runtime構成設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 環境・Runtime構成設計書 |
| 文書ID | `E6-API-VAL-ENVIRONMENT-RUNTIME-DESIGN` |
| 対象 | Environment解決、Runtime配置、外部Config、Secret、Network、Storage、Lock、Process、Deploymentおよび運用Handoff |
| 配置 | `system/05_framework/` |
| 文書種別 | Framework Environment・Runtime Deployment設計書 |
| 版数 | `1.0.0-draft.1` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | System Architecture / Runtime / Platform Team |
| レビュー責任 | System Architect / Runtime Lead / Infrastructure Lead / Security Lead / Operation Lead |
| 承認責任 | System Owner / Environment Owner |

## 2. 目的

本書は、E6 API Verification Platformを異なる実行先およびRuntime基盤で安全かつ再現可能に動作させるため、次を定義する。

1. Environment Masterが表す論理接続先とRuntime Deployment Profileの分離
2. 同一Release Artifactを環境別外部設定で実行する境界
3. Config、Secret、CertificateおよびCredentialの解決とSeal
4. Process、Container、Storage、Lock、NetworkおよびHTTP Clientの必須Capability
5. 起動、Preflight、Run、ShutdownおよびCrash RecoveryのRuntime Lifecycle
6. 最小権限、暗号化、監査およびProduction安全Gate
7. Capacity、Concurrency、Timeout、Retention、BackupおよびDisaster Recoveryの決定境界
8. Build、Release、Deployment、RollbackおよびConfiguration Driftの統制
9. Scheduler、Monitoring、AlertおよびOperation設計へのHandoff

本書は、未確認のServer名、IP Address、Absolute Path、Credential、Cloud Service、Container製品、Scheduler製品、Logging製品またはSecret Store製品を推測して確定しない。

## 3. 上位入力

| Reference | 本書で継承する契約 |
|---|---|
| `system/01_repository/Repository_Structure.md` | 凍結Repository構造、Runtime成果物のRepository外配置、未承認Directory追加禁止 |
| `system/02_master/Environment_Master.md` | 論理Environment ID、外部Config／Auth Reference、Production境界、`enabled` |
| `system/02_master/design/Environment_Master設計書.md` | Environment Master固定10項目、No Secret、No Runtime Tuning |
| `system/05_framework/Framework設計入力・決定事項一覧.md` | `FW-IN-*`、`FW-DEC-*`、`FW-OI-*`、未決事項 |
| `system/05_framework/システム設計書.md` | System Boundary、論理Component、外部Interface、Deployment論理単位 |
| `system/05_framework/共通Identity・Resultモデル設計書.md` | Execution Identity、四結果軸、Reason Code、集約規則 |
| `system/05_framework/共通Framework設計書.md` | Port／Adapter、Sealed Plan、Lifecycle、Fail Closed |
| `system/05_framework/Framework・業務定義連携設計書.md` | Environment解決、Definition Bundle、Java Registry、安全Gate |
| `system/05_framework/ScenarioContext設計書.md` | Run Isolation、Context非共有、API Call Identity |
| `system/05_framework/ExecutionState・Baseline管理設計書.md` | Identity Lock、Baseline／State整合、CAS |
| `system/05_framework/Snapshot・Evidence設計書.md` | 保存前Mask、Artifact Manifest、Protected Evidence |
| `system/05_framework/ファイル入出力設計書.md` | Logical／Physical分離、Storage Capability、Publication、Fencing |
| `system/05_framework/ログ・例外・Recovery設計書.md` | Diagnostic／Audit／Recovery分離、Dispatch State、Timeout、Recovery Case |
| `system/07_report/Report設計書.md` | Report Set、閲覧境界、Source Run不変 |

## 4. 適用範囲

### 4.1 対象

- Build EnvironmentとRuntime Environmentの信頼境界
- Local、共同検証および本番相当Runtimeの配置候補
- Release Artifact、Container ImageおよびDefinition Package
- External Configuration、Secret ProviderおよびCertificate Provider
- Runtime Data、Baseline、Execution State、ReportおよびAdapter Private Storage
- Lock／Lease／FencingとConcurrent Execution
- E6 APIへのDNS、Proxy、TLS、AuthenticationおよびHTTP接続
- Diagnostic、Audit、Metric、Trace、Recovery Adapter
- Process／Container Lifecycle、Health、ReadinessおよびGraceful Shutdown
- Deployment、Rollback、Backup、RestoreおよびDisaster Recovery
- Runtime Capability ProbeとRelease／Run Gate

### 4.2 対象外

| 対象外 | 正式な管理先 |
|---|---|
| 論理Environmentの固定10項目 | `Environment_Master.md` |
| API Path、Method、Field、API固有Timeout／Retry | API Master／API詳細設計 |
| UseCase／Scenario固有のEnvironment適用範囲 | UseCase／Scenario設計 |
| 実Credential、Token、Password、秘密鍵 | 承認済みSecret／Certificate Provider |
| Scheduler時刻、Calendar、日次Job順序 | Operation／Scheduler設計 |
| On-call、通知先、Recovery SLA、Runbook本文 | Operation設計 |
| Retention日数、Backup世代数、Capacity実値 | NFR／Security／Operation承認 |
| Java Source Root、Package、Module | 実装準備Architecture Review |
| 個別Infrastructure製品の構築手順 | Infrastructure／Deployment Runbook |

## 5. 基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `ERT-P001` | Two Axes | 論理接続先EnvironmentとRuntime Deployment Profileを別Identityとして管理する。 |
| `ERT-P002` | Immutable Release | 同一の承認済みRelease ArtifactまたはImageを環境別外部設定で実行する。 |
| `ERT-P003` | Externalized Configuration | URL、Timeout、Proxy、Storage、Sink等の可変値をCodeへHard Codingしない。 |
| `ERT-P004` | No Secret in Repository | Secret、Token、Password、秘密鍵および実証明書をRepository、Imageまたは通常Artifactへ保存しない。 |
| `ERT-P005` | Sealed Runtime Profile | Run開始前にRelease、Definition、Config、Provider Capabilityおよび安全Gateを固定する。 |
| `ERT-P006` | Least Privilege | Runtime User、Service Account、Storage、SecretおよびNetwork権限を最小化する。 |
| `ERT-P007` | Fail Closed | 未解決Config、未知Provider、Capability不足または承認不足では外部API呼出前に停止する。 |
| `ERT-P008` | Capability over Product | 製品名ではなく必要Capabilityを契約とし、Adapter Probeで証明する。 |
| `ERT-P009` | No Mutable Shared Memory | Run間でContext、Buffer、Writer、TemporaryまたはCredential Objectを共有しない。 |
| `ERT-P010` | Non-root Runtime | 共有／本番相当Runtimeは非root Identityで動作し、Application領域をRead Onlyとする。 |
| `ERT-P011` | Bounded Resource | Memory、Thread、Connection、Queue、File、Response、TimeoutおよびDisk使用量に上限を設ける。 |
| `ERT-P012` | Observable but Safe | Result、Diagnostic、Audit、Metric、Traceを追跡可能にし、機密情報をSignalへ含めない。 |
| `ERT-P013` | Reproducible Run | Release、Image Digest、Definition Hash、Config HashおよびProvider ProfileをRun単位で追跡する。 |
| `ERT-P014` | Original Run Immutable | Recovery、Restore、Report再生成またはDeployment RollbackでPublished Runを書き換えない。 |

## 6. 二つのEnvironment軸

### 6.1 論理Target Environment

Environment Masterの`environmentId`は「どのE6論理環境へ接続するか」を表す。

例：

- `ENV-LOCAL`
- `ENV-STAGING`
- `ENV-PROD`

これはServer、Container、Build AgentまたはDeployment Stageを表さない。

### 6.2 Runtime Deployment Profile

Runtime Deployment Profileは「Platformをどの実行基盤、Storage、LockおよびProvider能力で動かすか」を表す。本書のProfile名はArchitecture分類であり、第6 Masterではない。

| Profile ID | 用途 | 必須特性 | 正式Baseline |
|---|---|---|---|
| `RTP-LOCAL-ISOLATED` | 開発者／CIの隔離検証 | 単一Process、隔離Storage、Mock可 | Default不可 |
| `RTP-SHARED-SINGLE-NODE` | 共同検証／日次実行 | Linux相当、非root、永続Storage、外部Secret、Audit | Capabilityと承認次第 |
| `RTP-CONTAINER-SINGLE-INSTANCE` | Container化された日次Runtime | Immutable Image、Read Only Root、外部Data／Secret | Capabilityと承認次第 |
| `RTP-DISTRIBUTED` | 複数Node／Replica | 分散Lock、Fencing、CAS、Pinned Read、共有Audit | 本書では未選定 |

### 6.3 禁止される混用

- `BUILD`をEnvironment Masterへ登録しない。
- `ENV-STAGING`を「Docker Host名」の意味で使用しない。
- `RTP-*`をUseCaseの`applicableEnvironmentIds`へ設定しない。
- Runtime Profileの変更だけでBaseline Execution Identityを変更しない。
- `environmentId`だけからRuntime Storage、SecretまたはDeployment方式を推測しない。

## 7. Environment解決

```mermaid
flowchart TD
    A["Run Request"] --> B["Environment Master"]
    B --> C["External Config Reference"]
    B --> D["Auth Profile Reference"]
    C --> E["Runtime Deployment Profile"]
    D --> E
    E --> F["Capability Probe"]
    F --> G["Sealed Runtime Profile"]
    G --> H["Sealed Execution Plan"]
```

Environment解決は次をすべて満たす場合だけ成功とする。

1. `environmentId`がEnvironment Masterに一意に存在する。
2. `enabled=true`である。
3. UseCaseの`applicableEnvironmentIds`に含まれる。
4. `baseUrlRef`と`authProfileRef`が許可Providerで一意に解決する。
5. Runtime Deployment Profileが対象Environmentの安全区分を満たす。
6. Config Schema、Secret MetadataおよびCertificate状態が有効である。
7. Storage、Lock、HTTP、AuditおよびRecovery Capability Probeが成功する。
8. Production-like／Productionおよび更新APIに必要な承認が存在する。

`enabled=true`は必要条件であり、単独の実行許可ではない。

## 8. 論理Runtime構成

```mermaid
flowchart TD
    S["Scheduler／Operator"] --> R["Runtime Process"]
    R --> D["Definition Source"]
    R --> C["Config Provider"]
    R --> K["Secret／Certificate Provider"]
    R --> E["E6 API"]
    R --> A["Artifact／State Storage"]
    R --> O["Diagnostic／Audit／Metric"]
    R --> Q["Recovery Case Store"]
```

| 論理Node | 主責務 | 禁止責務 |
|---|---|---|
| Scheduler／Operator | Run Request、Trigger Identity、承認Reference | Result再判定、Baseline直接更新 |
| Runtime Process | Plan、Scenario、API、Verification、Publication | Secret永続化、LogからResult推測 |
| Definition Source | Version固定の定義提供 | Run中の無通知差替え |
| Config Provider | 非Secret設定解決 | Credential実値配布 |
| Secret／Certificate Provider | 短寿命またはReferenceベースSecret提供 | Repository／Artifact書込 |
| Artifact／State Storage | Create-Only、CAS、Pinned Read、Integrity | 四結果軸再判定 |
| Diagnostic／Audit／Metric | 安全なSignal受領 | Source Run改変 |
| Recovery Case Store | 別IdentityのCase／Action管理 | 元Run書換え |

## 9. BuildとRelease境界

### 9.1 Build Environment

Build EnvironmentはE6 Target Environmentではなく、次の責務だけを持つ。

- Java Compile、Unit／Contract／Security Test
- Dependency、LicenseおよびVulnerability Scan
- Executable ArtifactまたはContainer Image生成
- Definition／Schema Package組立
- SBOM、Build Provenance、Checksumおよび署名生成
- 承認済みArtifact RepositoryへのPublish

Build EnvironmentからE6 APIへ接続してはならない。

### 9.2 Release Unit

Release Unitは次を追跡可能にする。

| 項目 | 必須 |
|---|:---:|
| `releaseId` | Yes |
| Application Version | Yes |
| Source Revision | Yes |
| Build Timestamp | Yes |
| Artifact SHA-256／Image Digest | Yes |
| Definition Package Revision／Hash | Yes |
| Schema Set Version／Hash | Yes |
| Java Runtime Requirement | Yes |
| SBOM Reference | Yes |
| Signature／Provenance Reference | Shared／Production-likeでYes |
| Config Schema Version | Yes |

Release UnitへEnvironment固有URL、Credential、Secret、Baseline、Execution StateまたはRun Artifactを含めない。

### 9.3 Definition Package

Definition SourceをReleaseへ同梱する場合も外部Versioned Sourceとして提供する場合も、Run開始時に`sourceRevision`と`contentHash`を固定する。

Mutable Branch名、最新File、Directory更新時刻またはDeploy時の暗黙CopyをDefinition Revisionの正本にしない。

## 10. External Configuration

### 10.1 Config分類

| 分類 | 例 | Secret | Run中変更 |
|---|---|:---:|:---:|
| Identity／Target | `environmentId`、System Reference | No | No |
| Connectivity | Base URL、Proxy、TLS Profile | No | No |
| HTTP Control | Connect／Response／Call Timeout、Pool上限 | No | No |
| Runtime Control | Concurrency、Queue、Shutdown Grace | No | No |
| Storage | Logical Namespace、Capability Profile、Quota | Locatorは非公開 | No |
| Observability | Sink Profile、Level、Buffer上限 | Credentialは別Provider | No |
| Safety | Update API Gate、Approval Required、Rate Limit | No | No |
| Retention | Class、Policy Reference | No | No |
| Secret Reference | Auth／Certificate／Key Reference | 値はYes | Referenceだけ固定 |

### 10.2 Config Source優先順位

優先順位を実装が自由に変更してはならない。

```text
Approved Run Request Override
→ Environment-specific External Config
→ Runtime Deployment Profile
→ Release Default
```

ただし次はRun RequestでOverride禁止とする。

- `environmentId`と矛盾するBase URL
- TLS検証無効化
- Secret／Auth Profile
- Update API許可の緩和
- Mask／Secret Scan無効化
- Audit無効化
- Storage／Lock／Fencing Capabilityの緩和
- Retention短縮、Protected Evidence有効化
- Limitを無制限へ変更する値

Environment MasterはRuntime TuningのDefault Sourceではない。

### 10.3 Config Merge

1. 各SourceをSchema検証する。
2. 許可されたKeyだけMergeする。
3. Unknown Key、Duplicate Keyおよび型不一致を拒否する。
4. Override Allowlistと環境別上限を検証する。
5. Secret Referenceを値へ展開する前のSafe ConfigをCanonical化する。
6. `configHash`を計算する。
7. Secret値を含まないResolved Config SnapshotをSealする。

### 10.4 Config Trace

`run-meta.json`は少なくとも次をReferenceまたは安全なMetadataとして保持する。

- `environmentId`
- Runtime Deployment Profile ID／Version
- Release ID／Digest
- Definition Bundle Hash
- Config Schema Version
- Secretを除くCanonical Config Hash
- Storage／Lock／HTTP／Sink Capability Profile ID
- Timezone
- Approval Reference ID

Base URL実値、Proxy Credential、Token、Certificate本文、Secret Version値の機密部分またはPhysical Locatorを保存しない。

## 11. SecretとCertificate

### 11.1 原則

- SecretはReferenceから必要時に解決し、可能な限り短寿命とする。
- Secret ObjectをScenario Context、DTO Evidence、Log、MetricまたはReportへ渡さない。
- Secret Provider ClientはRuntime Identityに必要最小限のRead権限だけを与える。
- Environment間でCredentialを共用しない。
- Image、Release Package、Config Template、Command LineおよびProcess一覧へSecretを載せない。
- 共有／本番相当Runtimeでは平文Environment VariableによるSecret受渡しをDefaultにしない。
- Secret取得失敗時に古い値、空値または別Environmentの値へFallbackしない。

### 11.2 Secret Handle

Runtime Coreへ渡すのはSecret値ではなく、使用目的が限定されたHandleまたはAuth Providerである。

```java
public interface CredentialProvider {
    CredentialHandle resolve(AuthProfileReference reference, RunSecurityContext context);
}

public interface CertificateProvider {
    TlsMaterialHandle resolve(TlsProfileReference reference, RunSecurityContext context);
}
```

論理Interface例であり、Package、製品SDKまたはCredential形式を確定しない。

### 11.3 Rotation

- RotationでEnvironment IDを変更しない。
- 新Runは新Versionを使用し、実行中Runの差替え条件をProvider契約で明示する。
- 期限切れ、RevokedまたはVersion不一致をPreflightで拒否する。
- Rotation EventをAuditするがSecret値を記録しない。
- Certificate期限監視と更新責任はEnvironment Owner／Operationへ割り当てる。

### 11.4 Protected Evidence

Protected Raw EvidenceはDefault Disabledとする。有効化する場合も次を必須とする。

- Credential常時除去
- 通常Artifactとは別の暗号化Domain
- 明示ApprovalとPurpose
- Access Audit
- 短いRetention Policy
- 通常Runtime／Report Readerからの参照禁止

## 12. Runtime Identityと権限

| Role／Identity | 最小権限 | 禁止 |
|---|---|---|
| Build Identity | Source Read、Artifact Publish | E6 API、Runtime State、Production Secret |
| Deploy Identity | Release配置、Profile設定 | E6業務API呼出、Baseline内容変更 |
| Runtime Identity | Definition Read、Target API Call、Run Write | Deploy、過去Run改変、他Environment Secret |
| State／Baseline Writer | CAS／Pointer更新 | Report生成、任意Delete |
| Scheduler Identity | Run Request作成 | Secret Read、Result改変 |
| Recovery Operator | 承認済みCase Action | 元Run書換え、任意API再送 |
| Diagnostic Reader | Mask済みLog Read | Secret／Protected Evidence |
| Auditor | Audit／Evidence Read | Runtime Mutation |
| Backup／Restore Identity | 承認済みBackup／Restore | Primary Runtime API Call |

同一Service AccountへBuild、Deploy、Runtime、BackupおよびAdminを集約しない。

## 13. Network、DNS、Proxy、TLS

### 13.1 通信Domain

| From | To | 用途 | 原則 |
|---|---|---|---|
| Runtime | E6 API | Verification API Call | Allowlist、TLS、環境一致 |
| Runtime | Config Provider | 非Secret Config解決 | Read Only |
| Runtime | Secret／Certificate Provider | Auth Material解決 | 最小権限、暗号化 |
| Runtime | Artifact／State Storage | Run／State／Report | Private、条件Write |
| Runtime | Diagnostic／Audit／Recovery | Signal／Case | TLS、認証、Bounded |
| Build | Artifact Repository | Release Publish | 署名、Checksum |
| Operator | Runtime Control Plane | 起動／確認 | 認証、Audit |

Default Denyとし、用途不明のOutbound通信を許可しない。

### 13.2 Base URL

- Environment Masterの`baseUrlRef`から解決する。
- Scheme、Host、Port、Base Pathを構造化して検証する。
- User Info、Fragmentおよび未承認Queryを禁止する。
- DNS Rebinding、Private／Public境界およびAllowlistを確認する。
- RedirectはDefault禁止とし、必要時も同一許可境界で再検証する。
- Log、Failure MessageおよびReportへFull URLを出力しない。

### 13.3 TLS

- HTTPSをDefaultとする。
- Hostname VerificationとTrust Chain検証を無効化しない。
- 許可TLS Version／CipherはInfrastructure Security Policyを参照する。
- mTLSが必要な場合、Private KeyをSecret／Certificate Provider外へ永続化しない。
- Trust Store／Key StoreのVersionと期限を安全なMetadataとして追跡する。
- Certificate ErrorをRetryで回避しない。

### 13.4 Proxy

- Proxy利用有無、Host Reference、No Proxy RuleをExternal Configで管理する。
- Proxy CredentialはSecret Providerで解決する。
- No ProxyをWildcardで過度に拡張しない。
- Proxy経由後もTarget Host、TLSおよびEnvironment境界を検証する。

## 14. HTTP Client Capability

HTTP Client Adapterは次をCapability ProbeまたはContract Testで証明する。

| Capability | 必須契約 |
|---|---|
| Connect Timeout | DNS／Connection確立の上限 |
| Response Header Timeout | Header受信開始の上限 |
| Body Read Timeout | Body Stream進捗の上限 |
| Overall Call Deadline | Call全体の絶対期限 |
| Bounded Response | Byte、Depth、Itemの上限 |
| Dispatch State | `NOT_DISPATCHED / MAYBE_DISPATCHED / DISPATCHED`相当を判定可能 |
| Cancellation Signal | 要求と成立を区別 |
| Pool Bound | Environment／Target別Connection上限 |
| TLS／Proxy | Profile適用と検証結果 |
| Correlation | `apiCallExecutionId`、`attemptId` |

製品固有ExceptionはBoundaryでFailure Recordへ変換する。

更新APIが`MAYBE_DISPATCHED`または`DISPATCHED`の場合、Timeout、Cancelまたは接続断後の自動Retryを禁止する。

## 15. Runtime Storage Profile

### 15.1 必須Domain

| Domain | 必須Capability |
|---|---|
| Definition | Immutable／Version Pinning／Read Only |
| Run Publication | `runId` Create-Only／Package Seal／Read-back |
| Baseline | Immutable Generation／CAS Pointer／Pinned Read |
| Execution State | Expected Version CAS |
| Report | Immutable Generation／CAS Pointer |
| Temporary／Quarantine | Private Namespace／Quota／通常Consumer禁止 |
| Audit | Append Only／Access Audit／改変検知 |
| Recovery Case | Version付き更新／Append Only Action |

### 15.2 Profile候補

| Profile | 適用候補 | 条件 |
|---|---|---|
| `LOCAL_PRIVATE_FS` | `RTP-LOCAL-ISOLATED` | 単一Process、正式共有Baseline不可、Root隔離 |
| `SINGLE_NODE_DURABLE_FS` | 単一Node共有Runtime | Local Durable Storage、同一Host Lock、Atomic Capability実証 |
| `CONDITIONAL_OBJECT_STORE` | Container／分離Storage | Create-Only、Version、Conditional Write、Pinned Read |
| `TRANSACTIONAL_METADATA_PLUS_BLOB` | 高整合共有Runtime | Metadata Transaction／FencingとImmutable Artifact分離 |

製品は本書で未選定である。Profile選択はEnvironment Inventory、NFR、運用能力およびCapability Test結果に基づき承認する。

### 15.3 Physical Root

本書では次のLogical Root Handleだけを定義する。

- `definitionRoot`
- `runtimePublishedRoot`
- `adapterPrivateRoot`
- `protectedEvidenceRoot`
- `auditStore`
- `recoveryCaseStore`

Absolute Path、Bucket、Container、Mount、ShareまたはSigned URLを設計正本および永続Artifactへ保存しない。

### 15.4 Permission

- Application／DefinitionはRead Only。
- Runtime Published RootはRuntime WriterだけがCreate／Conditional Write可能。
- Published Runは更新／削除不可。
- Temporary／Quarantineは通常Readerから不可視。
- Protected Evidenceは専用RoleだけがAccess可能。
- World Writable、共有Groupへの無制限WriteおよびSymbolic Link経由Writeを禁止する。
- Encryption at RestとTransitをShared／Production-like Profileで必須とする。

## 16. Lock、Lease、Fencing

### 16.1 Scope

| Operation | Lock Scope | Storage条件 |
|---|---|---|
| 同一Execution Identity実行 | Execution Identity | Lease／Fencing |
| Baseline Pointer更新 | Execution Identity | Expected Pointer Version＋Fencing |
| Execution State更新 | Execution Identity | Expected State Version＋Fencing |
| Report Current更新 | Report Identity | Expected Pointer Version |
| Recovery Action | Recovery Case | Expected Case Version |

`runId`の一意性だけでは同一Execution Identityの競合を防げない。

### 16.2 Profile別制約

- Local単一ProcessではProcess内Mutexを使用できるが、正式共有Baselineの安全性根拠にしない。
- Single NodeではOS LockだけでなくOwner、Lease、Fencing TokenおよびStorage条件を組み合わせる。
- Multi Nodeでは外部分散LockまたはTransactional Metadataを必須とする。
- PID File、File存在、Timestampまたは人手削除だけをLock正本にしない。
- Lease喪失後のWriterは継続せず、すべてのMutationをFencing条件で拒否する。
- Lock解除を「処理成功」とみなさない。

## 17. Process／Container構成

### 17.1 共通条件

- 一RunまたはBounded Worker Poolで実行する。
- 非root User／Service Accountを使用する。
- Application、Definition、SchemaをRead Onlyで提供する。
- Writable領域をRuntime Storage Adapterへ限定する。
- OS／ContainerのTimezone設定だけに依存せず、Runtime Time Sourceを明示する。
- `stdout/stderr`はDiagnostic Transport候補であり、Runtime Resultの正本にしない。
- RuntimeにShell、Package Manager、Compilerまたは不要なAdmin Toolを含めない。
- Resource Limit、Open File、Thread、ConnectionおよびTemp上限を設定する。

### 17.2 Container固有条件

- ImageはDigestで固定し、Mutable TagだけでDeployしない。
- Root File SystemはRead Onlyを原則とする。
- SecretをImage LayerへCopyしない。
- Host Socket、Privileged Modeおよび広範なHost Mountを禁止する。
- Runtime StorageとConfig／Secret Mountの権限を分離する。
- Container再起動で不完全Runを自動的に同じMutationとして再送しない。
- Replica数を1から増やす場合、Distributed Lock／Fencing Profile承認を必須とする。

### 17.3 Tomcat／常駐Application

Tomcatまたは常駐Web Containerを採用する場合も、Verification Runは独立したRun Identity、Queue、DeadlineおよびResource Budgetを持つ。

Web Request Threadで長時間Runを直接実行せず、受理と実行を分離する。採用有無は未決である。

## 18. Runtime Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Bootstrapping
    Bootstrapping --> Ready: Capability OK
    Bootstrapping --> Unready: Validation Failure
    Ready --> Running: Run Accepted
    Running --> Draining: Shutdown Requested
    Running --> Ready: Run Finalized
    Draining --> Stopped: Safe Boundary
    Unready --> Stopped
    Stopped --> [*]
```

この状態はProcess Lifecycleであり、Execution／Verification／Change／Recoveryの四結果軸ではない。

### 18.1 Bootstrapping

1. Release Identity／署名確認
2. Runtime Profile／Config Schema読込
3. Safe Config Merge／Hash
4. Runtime Identity／Permission確認
5. Secret／Certificate Metadata確認
6. Storage／Lock／HTTP／Audit／Recovery Capability Probe
7. Disk／Quota／Clock／DNS／TLS事前確認
8. Definition Source到達性確認
9. Readiness判定

### 18.2 Run Preflight

Process Readyでも、各RunについてEnvironment、Definition、Input、Expected、Registry、Approval、Test Data Lease、Rate LimitおよびStorage Capacityを再検証する。

### 18.3 Graceful Shutdown

- 新規Run受付を停止する。
- 実行中RunへCancellation Requestを通知する。
- 未送信処理と送信済み可能性のあるAPIを区別する。
- Deadline内にArtifact Finalizeまたは安全なIncomplete処理を行う。
- Audit必須Mutation完了前にProcessを成功終了としない。
- Grace超過時は強制終了し、次回Recovery Scan対象とする。

## 19. Schedulerと起動Interface

Schedulerは製品非依存のRun Requestを発行する。

| 必須項目 | 内容 |
|---|---|
| Trigger ID | Scheduler／Manualの一意な受付Identity |
| Requested Environment | `environmentId` |
| UseCase／Scenario | 正式ID |
| Input Set | `inputSetId` |
| Run Mode | Daily／Manual等の管理分類 |
| Requested By | Service Account／Operator Role |
| Approval Reference | 必要時 |
| Idempotency／Request Key | 二重受付検出 |
| Request Time | UTC Timestamp |

Scheduler未実行、二重Trigger、遅延およびManual再実行はOperation設計で監視する。

SchedulerのPID、Cron ProcessまたはJob名を`runId`として使用しない。二重Triggerでも各物理Runは別`runId`を持ち、Execution Identity Lockで競合を制御する。

## 20. ConcurrencyとResource Budget

### 20.1 階層

| 階層 | 制御 |
|---|---|
| Platform | 最大同時Run、Queue長、CPU／Memory |
| Environment | Target別同時Run、Rate Limit |
| Execution Identity | 原則単一Writer |
| UseCase／Scenario | Java設計上の順序と分岐 |
| API Target | Connection Pool、In-flight Call |
| Artifact | Writer、Buffer、Size |

### 20.2 必須Limit

- Maximum Concurrent Runs
- Maximum Queue Length／Wait
- Maximum API Calls per Run
- Maximum Attempts per API Call
- Maximum Request／Response Bytes
- Maximum JSON Depth／Array Items／Diff Items
- Maximum Context Memory
- Maximum Artifact Package Size
- Maximum Temporary／Quarantine Size
- Connect／Read／Overall Timeout
- Shutdown Grace

具体値はNFR、E6制約、代表Dataおよび負荷試験で決定する。`0`を無制限の暗黙値として使用しない。

## 21. 時刻、Timezone、Clock

- 永続TimestampはUTCのISO 8601とする。
- 表示Timezoneは原則`Asia/Tokyo`とし、Reportで明示する。
- ID生成をSystem Clockだけに依存しない。
- Deadline計測はMonotonic Clockを使用する。
- NTP等の時刻同期とDrift監視をRuntime Profileの前提とする。
- Clock Driftが許容範囲外の場合、期限、Lease、CertificateおよびAudit順序へ影響するためRunをFail Closedできる。
- Directory TimestampからPrevious、Current、成功またはRecovery結果を推測しない。

## 22. Health、Readiness、Liveness

| Check | 目的 | 外部副作用 | 失敗時 |
|---|---|:---:|---|
| Liveness | Process Loopと致命的Deadlock確認 | 禁止 | Process再起動候補 |
| Readiness | 新規Run受付可否 | 禁止 | 新規受付停止 |
| Startup | Release／Config／Provider Capability | 禁止 | 起動停止 |
| Run Preflight | Run固有Definition／Environment／Approval | API呼出前 | Run `REJECTED` |
| Synthetic／Smoke | Deploy後の明示試験 | 承認範囲のみ | Deploy Gate失敗 |

Liveness／Readinessで代表E6更新APIを呼び出さない。E6接続確認が必要なSmoke Testは、専用Read-only APIまたはMockを用い、通常Health Endpointと分離する。

Health結果はRuntime Resultではない。Readiness Failureから既存Runの四結果軸を再判定しない。

## 23. Observability Adapter

### 23.1 必須Signal

| Signal | 最小内容 |
|---|---|
| Diagnostic | Component、Event Type、Safe Failure Code、Correlation |
| Audit | Actor、Action、Target、Before／After Reference、Decision |
| Metric | Count、Latency、Size、Queue、Capacity、Drop |
| Trace | Run／Scenario／API Call Span、Attempt、Dispatch |
| Recovery | Case、Action、Owner Role、Expected Version |

### 23.2 Provider要件

- Diagnostic Sink障害とAudit Sink障害を区別する。
- Audit必須MutationはAudit不可時にFail Closedする。
- BufferはBoundedとし、Drop／Backpressure Policyを明示する。
- Secret、Body全文、Full URL、Physical Pathおよび高Cardinality IDをMetric Labelへ含めない。
- Provider CredentialはSecret Providerで解決する。
- Sinkへの送信失敗で四結果軸を推測変更しない。

Alert Route、通知先、SLAおよびEscalationはOperation設計で確定する。

## 24. Retention、Archive、Delete

### 24.1 Class

| Class | 例 | 原則 |
|---|---|---|
| Immutable Run | Core Artifact、Manifest | Policy期間中改変禁止 |
| Baseline | Current＋承認済みGeneration | 参照中Generation削除禁止 |
| Execution State | Versioned Current State | Recovery／Audit整合 |
| Report | Generation＋Pointer | Source Runより長く保持しない条件確認 |
| Diagnostic | Mask済みEvent | Rotation／Retention |
| Audit | Mutation／Access Record | Append Only、長期候補 |
| Quarantine | 不完全／不正Artifact | 通常より短期、制限Access |
| Protected Evidence | 例外Raw | 最短、Approval必須 |
| Recovery Case | Case／Action | 元Run／Auditとの整合 |

### 24.2 Delete Gate

Delete／ArchiveはRuntimeの通常Run Pathから分離し、次を確認する。

- Current Pointer参照
- Active Run／Pinned Reader
- Recovery Case
- Legal／Audit Hold
- Baseline／Report／State参照
- Backup完了
- Approval

Retention Jobが四結果軸、ManifestまたはSource Runを編集してはならない。

具体的日数と世代数は未決である。

## 25. BackupとRestore

### 25.1 Backup対象

- Baseline GenerationとPointer
- Execution State
- Immutable Run Artifact
- Report Generation
- Audit／Recovery Case
- Config Template／Profile Metadata

ApplicationとDefinitionは承認済みRelease／Source Revisionから再配置可能であることを確認する。

### 25.2 Backup要件

- Encryption、Integrity、VersionおよびAccess Control
- SourceとBackupのEnvironment／Tenant分離
- Backup IdentityをPrimary Runtime Identityから分離
- Pointer、Generation、Stateの整合したRecovery Point
- 定期Restore Test
- RPO／RTOの明示

### 25.3 Restore規則

Restoreは別の運用ActionとしてAuditし、復元元Version、対象Namespace、Integrity結果および承認を記録する。

Restoreにより元Runの四結果軸を編集しない。Current Pointerを切り替える場合はCAS／FencingとOperation Approvalを必須とする。

## 26. Disaster Recovery

| Failure | Recovery方針 |
|---|---|
| Runtime Process破損 | 同一Release Digestを再配置 |
| Config破損 | 承認済みConfig Versionを再解決 |
| Secret失効 | Rotation／再発行、旧値Fallback禁止 |
| Certificate失効 | 更新後Capability Probe |
| Run Publication結果不明 | `runId + manifestHash`で照合 |
| Baseline Pointer不整合 | Generation／Pointer／State／Audit照合 |
| Storage障害 | Pinned VersionとBackupから復元判断 |
| Audit Sink障害 | Audit必須Mutation停止 |
| E6 Outcome不明 | Provider確認／Recovery Case、Mutation自動再送禁止 |
| Node障害 | 承認済みProfileへ再配置、Lock／Lease確認 |

DR Site、Failover方式、RPOおよびRTOはInfrastructure／Operation設計で確定する。

## 27. Deployment

### 27.1 Flow

```mermaid
flowchart TD
    A["Build・Test"] --> B["Sign・Publish"]
    B --> C["Deploy Candidate"]
    C --> D["Config・Capability Validation"]
    D --> E["No-side-effect Smoke"]
    E --> F["Readiness"]
    F --> G["Controlled Run"]
    G --> H["Release Decision"]
```

### 27.2 Deploy Gate

- Release Digest／Signature／SBOM確認
- Definition／Schema互換性
- Config Schema／Hash
- Secret／Certificate Metadata
- Network／DNS／TLS／Proxy
- Storage／Lock／CAS／Fencing
- Permission／Encryption／Quota
- Diagnostic／Audit／Recovery Provider
- Time Sync
- No-side-effect Smoke
- Rollback Candidate
- Environment Owner／Operation Approval

### 27.3 Deployment単位

| 対象 | 扱い |
|---|---|
| Application Artifact／Image | Immutable Release |
| Definition／Schema | Version固定、ReleaseとのCompatibility |
| Config | Environment別、Versioned、Secretなし |
| Secret／Certificate | 別Provider、別Lifecycle |
| Runtime Data／Baseline | Deploy対象外 |
| Report／Audit | Deploy対象外 |

## 28. Rollback

RollbackはApplication／Definition／Configを承認済み旧Versionへ戻すことであり、Runtime DataまたはBaselineを無条件に巻き戻すことではない。

1. Rollback対象ReleaseとCompatibilityを確認する。
2. 新Versionで生成済みArtifact／State Schemaとの互換性を確認する。
3. Config／Secret／Certificateの互換性を確認する。
4. 新規Run受付を停止する。
5. 実行中Runを安全にDrainする。
6. 旧Release DigestをDeployする。
7. Capability ProbeとSmoke Testを実行する。
8. Rollback ActionをAuditする。

Schema Downgrade、Baseline巻戻しまたはState復元が必要な場合は通常Rollbackから分離し、Migration／Restore手順と承認を必須とする。

## 29. Production／更新API安全Gate

`ENV-PROD`は現行Masterで`enabled=false`であり、本Toolからの実行可否も未確認である。明示承認まで実行禁止を維持する。

Production-like／Productionまたは更新APIでは次を追加必須とする。

- Environment Owner承認
- UseCase／Scenario Environment許可
- API CapabilityがUpdateであることの明示
- 専用Test Data Lease
- 実行Window
- Rate／Concurrency制限
- Idempotency特性確認
- Cleanup／Compensation Runbook
- Recovery Owner
- Audit Sink健全性
- Evidence Mask／Completeness
- Unknown Outcome時のProvider確認経路

`updateApiEnabled=true`の単一Flagだけで許可しない。

## 30. Configuration Drift

### 30.1 検知対象

- Release Digest
- Definition Revision／Hash
- Schema Set
- External Config Version／Hash
- Runtime Deployment Profile
- Storage／Lock／HTTP／Sink Capability
- TLS／Certificate Metadata
- Runtime Identity／Permission

Sealed Plan生成後に上記が変化した場合、実行前は`REJECTED`、実行中は影響に応じて`INCOMPLETE`または`UNKNOWN_OUTCOME`とし、Reason／Recoveryを別軸で記録する。

### 30.2 禁止

- Deploy済みFileの直接編集
- Mutable TagだけによるRelease識別
- Run中Config Reload
- 環境差異をCode Branchへ埋め込む
- Secret RotationをConfig Hashへ平文反映
- DriftをLog Warningだけで許容する

## 31. Failureと四結果軸

| Failure Point | Execution | Verification | Change | Recovery |
|---|---|---|---|---|
| Boot／Capability不足、Run未作成 | Run受付不可 | 該当なし | 該当なし | Operation判断 |
| Run Preflight Config／Approval不足 | `REJECTED` | `NOT_EVALUATED` | `NOT_COMPARED` | 条件により`REQUIRED` |
| 実行開始後Storage／Audit障害 | `INCOMPLETE` | 原結果または`NOT_EVALUATED` | 原結果または`NOT_COMPARED` | 通常`REQUIRED` |
| 更新API送信可能性ありTimeout | `UNKNOWN_OUTCOME` | `NOT_EVALUATED` | `NOT_COMPARED` | `REQUIRED` |
| Verification不一致 | `COMPLETED` | `FAIL` | 独立判定 | 通常`NOT_REQUIRED` |
| Report Sink障害 | Source Run不変 | Source Run不変 | Source Run不変 | Report再生成判断 |

Process Health、Deployment Status、Alert SeverityまたはHTTP Client Errorを四結果軸の代替にしない。

## 32. Runtime Capability Manifest

Run開始前に次のProfileを検証し、安全な識別情報をSealする。

```json
{
  "runtimeProfileId": "RTP-SHARED-SINGLE-NODE",
  "runtimeProfileVersion": "1.0.0",
  "releaseDigest": "sha256:<digest>",
  "configHash": "sha256:<hash>",
  "storageProfile": "SINGLE_NODE_DURABLE_FS",
  "lockProfile": "LEASE_FENCING_REQUIRED",
  "httpProfile": "DISPATCH_AWARE_BOUNDED",
  "secretProfile": "REFERENCE_ONLY",
  "auditProfile": "APPEND_ONLY_REQUIRED",
  "capabilityStatus": "VALIDATED"
}
```

例示値であり、実Digest、Physical Locator、Credential、Host名または製品名を正本化しない。

## 33. Capability Probe

| Probe ID | 確認内容 | 失敗時 |
|---|---|---|
| `ERT-CAP-001` | Release Digest／署名 | Runtime起動禁止 |
| `ERT-CAP-002` | Config Schema／Hash／Unknown Key | Runtime起動禁止 |
| `ERT-CAP-003` | Secret／Certificate Referenceと期限 | 対象Run禁止 |
| `ERT-CAP-004` | Definition Revision／Hash固定 | 対象Run禁止 |
| `ERT-CAP-005` | Run Create-Only／Read-back | 対象Run禁止 |
| `ERT-CAP-006` | Baseline／Report Pointer CAS | 正式Baseline／Report禁止 |
| `ERT-CAP-007` | State CAS／Pinned Read | 対象Run禁止 |
| `ERT-CAP-008` | Lock／Lease／Fencing | 同一Identity実行禁止 |
| `ERT-CAP-009` | HTTP Timeout／Dispatch／Cancel | 対象API禁止 |
| `ERT-CAP-010` | Audit Append／Access | Audit必須Mutation禁止 |
| `ERT-CAP-011` | Quota／Disk／Memory／Queue | 新規Run禁止 |
| `ERT-CAP-012` | DNS／TLS／Proxy／Allowlist | 対象Environment禁止 |
| `ERT-CAP-013` | Clock Sync／Drift | Lease／期限依存Run禁止 |
| `ERT-CAP-014` | Backup／Restore Test Status | Production-like Release Gate失敗 |

Probeが副作用APIを呼び出してはならない。

## 34. Validation

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `ERT-V001` | Target EnvironmentとRuntime Profileが別Identityである。 | ERROR |
| `ERT-V002` | Build EnvironmentがEnvironment Masterへ混入していない。 | ERROR |
| `ERT-V003` | 同一Release Digestを環境別外部Configで使用できる。 | ERROR |
| `ERT-V004` | Config PriorityとOverride禁止Keyが一意である。 | ERROR |
| `ERT-V005` | Secret実値がRepository、Image、Command Line、Log、Artifactにない。 | ERROR |
| `ERT-V006` | Shared Runtimeが非root、Read Only Applicationである。 | ERROR |
| `ERT-V007` | Physical LocatorがManifest／Reportへ保存されない。 | ERROR |
| `ERT-V008` | Storage／Lock／HTTP／Audit CapabilityがPreflightで検証される。 | ERROR |
| `ERT-V009` | PID／Lock FileだけでExecution Identity競合を制御しない。 | ERROR |
| `ERT-V010` | 更新API送信後Timeoutを自動Retryしない。 | ERROR |
| `ERT-V011` | Health Checkが副作用APIを呼び出さない。 | ERROR |
| `ERT-V012` | Process Lifecycleと四結果軸が分離される。 | ERROR |
| `ERT-V013` | Resource Limitに無制限Defaultがない。 | ERROR |
| `ERT-V014` | Deploy／RollbackがRuntime Dataを無条件変更しない。 | ERROR |
| `ERT-V015` | Restore／Recoveryが元Runを変更しない。 | ERROR |
| `ERT-V016` | Production／Update APIが単一Flagで許可されない。 | ERROR |
| `ERT-V017` | Clock、TLS、CertificateおよびSecret期限を監視する。 | ERROR |
| `ERT-V018` | Frozen Runtime Treeへ`logs/`、`tmp/`、`secret/`等を追加していない。 | ERROR |

## 35. Test観点

### 35.1 Config／Secret

- [ ] Unknown Config Key、Duplicate Key、型不一致を拒否する。
- [ ] Run RequestでTLS検証またはAuditを無効化できない。
- [ ] 別EnvironmentのAuth Referenceを拒否する。
- [ ] Secret取得失敗時に旧値へFallbackしない。
- [ ] Command Line、Process一覧、DiagnosticおよびArtifactにSecretがない。
- [ ] Rotation中のRunが規定Version境界を維持する。

### 35.2 Runtime／Storage

- [ ] 同一`runId`の二重Publishで一方だけ成功する。
- [ ] 同一Execution IdentityのConcurrent RunがLock／Fencingされる。
- [ ] Lock喪失後のWriterがState／Pointerを更新できない。
- [ ] Capability不足StorageでRunを開始しない。
- [ ] Disk／Quota不足時にPackageをCompleteとしない。
- [ ] Container再起動で更新APIを自動再送しない。

### 35.3 Network／HTTP

- [ ] 不許可Host、Redirect、DNS Rebindingを拒否する。
- [ ] TLS Hostname／Trust ErrorをRetryしない。
- [ ] Proxy CredentialをLogへ出さない。
- [ ] Connect、Header、Body、Overall Timeoutを独立検証する。
- [ ] 更新APIの`MAYBE_DISPATCHED`を`NOT_DISPATCHED`へ丸めない。
- [ ] Cancellation Requestと成立を区別する。

### 35.4 Deployment／Operation

- [ ] Mutable TagだけのDeployを拒否する。
- [ ] Config DriftをRun前／Run中で検出する。
- [ ] Audit Sink停止中のBaseline更新を拒否する。
- [ ] Liveness／ReadinessがE6更新APIを呼ばない。
- [ ] RollbackでBaseline／Stateを無条件に巻き戻さない。
- [ ] BackupからPointer／Generation／Stateを整合して復元できる。
- [ ] RetentionがCurrent／Pinned／Recovery対象を削除しない。

## 36. Open Issue

| Issue ID | 未確定事項 | 本書の制約 | 決定先 |
|---|---|---|---|
| `ERT-OI-001` | Java Runtime Version、Build Tool、Source Root | Release Metadataと互換性を必須とし、値を推測しない。 | Implementation Architecture Review |
| `ERT-OI-002` | Container／Process／Tomcat採用 | Profile契約を満たし、Runtime Portへ製品型を漏らさない。 | Infrastructure／Runtime Review |
| `ERT-OI-003` | Runtime Data物理Root／Storage製品 | Logical HandleとCapabilityだけを正本とする。 | Infrastructure Review |
| `ERT-OI-004` | Lock／Lease／Fencing製品と実値 | Profile別必須条件を満たす。 | Runtime／Infrastructure Review |
| `ERT-OI-005` | HTTP Client、Pool、Timeout実値 | Dispatch-aware、Bounded、更新API自動Retry禁止。 | Runtime／API／NFR Review |
| `ERT-OI-006` | Secret／Certificate Provider | Reference Only、最小権限、Rotation、Audit。 | Security／Infrastructure Review |
| `ERT-OI-007` | Logging／Metric／Trace／Audit製品 | Signal分離、Audit Fail Closed、Bounded Buffer。 | Operation／Security Review |
| `ERT-OI-008` | Scheduler製品、時刻、Calendar | Trigger契約、二重受付検出、Execution Identity Lock。 | Operation設計 |
| `ERT-OI-009` | Retention、Archive、Backup、RPO／RTO | Current／Pinned／Recovery保護、Restore Test。 | NFR／Operation／Security |
| `ERT-OI-010` | 最大Size、Concurrency、Queue、Quota | 無制限禁止、代表Data／負荷試験で決定。 | NFR／Performance Test |
| `ERT-OI-011` | PROD／Production-like実体と実行可否 | `ENV-PROD enabled=false`を維持する。 | Environment Owner／Operation |
| `ERT-OI-012` | Update API Test Data Lease／Approval Interface | 単一Flag禁止、Owner、期限、Scopeを必須とする。 | Business／Operation／Security |
| `ERT-OI-013` | Protected Evidence物理暗号Domain | Default Disabled、通常Consumer分離。 | Security／Infrastructure |
| `ERT-OI-014` | Multi-node Runtime必要性 | Distributed Lock／FencingなしではReplicaを増やさない。 | Capacity／Architecture Review |

## 37. Review Checklist

### 37.1 Architecture

- [ ] Target Environment、Build Environment、Runtime Profileが分離されている。
- [ ] Product名ではなくCapabilityでPort／Adapterを定義している。
- [ ] Environment MasterへRuntime Tuningを戻していない。
- [ ] Frozen Repository／Runtime Logical Treeを変更していない。
- [ ] 未決Java Root、Package、Physical Pathを固定していない。

### 37.2 Runtime

- [ ] Boot、Ready、Running、Drainingと四結果軸が分離されている。
- [ ] Storage、Lock、CAS、Fencing、Pinned Readが整合する。
- [ ] HTTP Dispatch StateとCancellation能力がある。
- [ ] Concurrency、Memory、Connection、QueueおよびSizeがBoundedである。
- [ ] Graceful ShutdownとCrash RecoveryがAPI副作用を推測しない。

### 37.3 Security

- [ ] Secret、Certificate、Physical LocatorおよびFull URLを永続化しない。
- [ ] Build、Deploy、Runtime、Backup Identityを分離する。
- [ ] Shared Runtimeが非rootかつApplication Read Onlyである。
- [ ] TLS検証、Allowlist、ProxyおよびRedirect境界がある。
- [ ] Protected EvidenceがDefault Disabledである。

### 37.4 Verification

- [ ] Release、Definition、ConfigおよびCapabilityがRunに追跡される。
- [ ] Environment DriftでPlanを再Sealせず停止する。
- [ ] Health／Deploy／Alert Statusが四結果軸を上書きしない。
- [ ] Verification `FAIL`とRuntime／Environment Failureを区別する。
- [ ] PROD／Update APIが明示的な多重Gateを持つ。

### 37.5 Operation

- [ ] Capability Probe、Deploy Gate、RollbackおよびRestore Testがある。
- [ ] Audit不可時のFail Closed操作が明示されている。
- [ ] RetentionがCurrent／Pinned／Recovery対象を保護する。
- [ ] Schedulerの二重TriggerとExecution Lockを区別する。
- [ ] 未決SLA、通知先、日数および製品を完了済みと表示していない。

## 38. 完了条件

本書の正文作成完了は次を満たすことを意味する。

1. Environment MasterとRuntime Deployment Profileが分離されている。
2. Release、Config、Secret、Provider CapabilityおよびSealed Runtime Profileの境界が定義されている。
3. Network、TLS、Proxy、HTTP Client、Storage、LockおよびFencing要件が定義されている。
4. Process／Container Lifecycle、Health、ShutdownおよびCrash Recoveryが定義されている。
5. Concurrency、Resource、Retention、Backup、RestoreおよびDRの決定境界がある。
6. Deployment、Rollback、DriftおよびProduction安全Gateが定義されている。
7. 四結果軸、Artifact、File I/O、Log／RecoveryおよびEnvironment Masterとの現行不整合が0件である。
8. Front Matter、H1、Code Fence、JSON例、Tableおよび`document_id`の機械Validationが成功する。

正文作成完了は、製品選定、物理構築、Config実値、Credential、Capacity実値、正式Role Review、Decision承認、文書Lifecycle `APPROVED`またはProduction実行許可を意味しない。

## 39. 下流への引渡し

### 39.1 第8バッチSchema

- `run-meta.json`のRuntime Profile／Config Hash／Capability Reference
- API MetaのDispatch State／Attempt／Timeout
- Artifact ManifestのStorage Profile／Integrity
- Execution State／Baseline MetaのVersion／Fencing
- Secret値を含まないConfig Trace

### 39.2 Operation／Monitoring

- Scheduler、Run Calendar、Maintenance Window
- Alert Route、On-call、SLA、Escalation
- Recovery Runbook、Provider確認、Compensation
- Retention／Archive／Delete Job
- Backup、Restore Test、RPO／RTO
- Certificate／Secret Rotation

### 39.3 Infrastructure／Implementation

- Runtime Deployment Profile選定
- JDK／Container／Process／Tomcat判断
- Storage、Lock、Secret、Audit、Recovery Adapter選定
- Runtime Physical Root／Network／IAM
- Capacity／Performance TestとLimit実値
- Deployment／Rollback／DR Runbook

## 40. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-28 | Environment MasterとRuntime Profileの二軸分離、Immutable Release、External Config／Secret、Network／HTTP、Storage／Lock、Process／Container、Health、Deployment、Backup／DRおよびProduction安全Gateに基づき新規作成 | DRAFT |
