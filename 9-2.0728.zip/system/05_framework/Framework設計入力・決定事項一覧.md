---
title: Framework設計入力・決定事項一覧
document_id: E6-API-VAL-FW-INPUT-DECISION-REGISTER
version: 2.0.0-draft.17
status: DRAFT
document_type: Framework Design Input and Decision Register
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Framework設計入力・決定事項一覧

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Framework設計入力・決定事項一覧 |
| 文書ID | `E6-API-VAL-FW-INPUT-DECISION-REGISTER` |
| 対象 | `system/05_framework/`の設計入力、決定、未決事項および完了Gate |
| 配置 | `system/05_framework/` |
| 文書種別 | Framework設計統制台帳 |
| 版数 | `2.0.0-draft.17` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | System Architecture Team |
| レビュー責任 | System Architect / Runtime Lead / Verification Lead / Operation Lead |
| 承認責任 | System Owner |

## 2. 目的

本書は、E6 API Verification Platformの横断Frameworkを再設計するために、次を一意に管理する。

1. 現行設計が受け取る確定済み入力
2. Framework全体へ適用する設計決定
3. 未決事項、暫定方針および決定責任
4. 旧Frameworkから継承、再設計または廃止する責務
5. 各Framework設計書の作成順序、入力、出力および完了条件
6. Java実装、JSON SchemaおよびRuntime構成へ進むためのGate

本書はFramework詳細設計そのものではない。詳細なClass、Package、物理Path、Storage、Deployment方式を本書だけで確定してはならない。

## 3. 正本性と優先順位

### 3.1 正本性

本書は、Framework設計の入力、決定状態およびOpen Issueを管理する現行正本である。

`recovery/legacy_05_framework/`の文書は履歴上の要件抽出にだけ使用し、現行設計、Java、RuntimeまたはReview CheckからReferenceしてはならない。

### 3.2 判断優先順位

競合がある場合は、次の順序で判断する。

```text
承認済みの現行設計決定
→ FROZENのRepository Structure
→ 現行01～07設計書
→ business/の確認済みAs-Is事実
→ recovery/から抽出した未失効要求
→ 未確認の仮説
```

旧文書に記載されていても、現行の5 Master、Java First、Scenario Input／Expected、結果軸分離またはRepository配置に反する内容は継承しない。

## 4. 管理区分

| 区分 | ID Prefix | 内容 |
|---|---|---|
| Design Input | `FW-IN-*` | Frameworkが満たす要求、制約、前提 |
| Decision | `FW-DEC-*` | 適用範囲と根拠が明確な設計決定 |
| Open Issue | `FW-OI-*` | 決定が必要だが、現時点で確定できない事項 |
| Validation | `FW-VAL-*` | 決定または設計成果物の確認方法 |
| Migration | `FW-MIG-*` | 旧構成から現行構成への移行管理 |

### 4.1 Status

| 対象 | Status |
|---|---|
| Design Input | `CONFIRMED / PROVISIONAL / REJECTED / SUPERSEDED` |
| Decision | `APPROVED / PROPOSED / REJECTED / DEPRECATED` |
| Open Issue | `OPEN / INVESTIGATING / WAITING / RESOLVED / CLOSED` |
| Validation | `NOT_STARTED / IN_PROGRESS / PASSED / FAILED / BLOCKED` |
| Migration | `NOT_STARTED / IN_PROGRESS / COMPLETED / CANCELLED` |

`CONFIRMED`および`APPROVED`は、根拠となる現行正本が存在する場合だけ使用する。

### 4.2 成果物状態の分離

第5バッチ以降は、次の状態を別々に管理する。相互に自動昇格させてはならない。

| 状態軸 | Status | 意味 |
|---|---|---|
| 内容作成 | `NOT_STARTED / CONTENT_PROVIDED / REWRITE_REQUIRED` | 本文が存在し、予定した章と契約が記載されているか |
| 機械Validation | `NOT_STARTED / IN_PROGRESS / PASSED / FAILED / BLOCKED` | Front Matter、ID、Reference、Fence、JSON等の機械確認結果 |
| 横断Review | `NOT_STARTED / IN_PROGRESS / PASSED / REWORK / BLOCKED` | 関連文書間の意味、責務、状態語彙およびFailure境界の確認結果 |
| Decision | `PROPOSED / APPROVED / REJECTED / DEPRECATED` | 設計判断の正式な承認状態 |
| 文書Lifecycle | `DRAFT / IN_REVIEW / APPROVED / RELEASED / DEPRECATED / RETIRED` | `文書作成規約.md`に従う文書全体の状態 |

```text
CONTENT_PROVIDED
≠ Validation PASSED
≠ Review PASSED
≠ Decision APPROVED
≠ Document APPROVED
```

AIによる作成、静的検証または事前整合確認だけを根拠に、Decisionまたは文書Lifecycleを`APPROVED`へ変更してはならない。

## 5. Framework対象範囲

### 5.1 対象

- Batch、UseCaseおよびScenario実行制御
- Master、詳細設計、Scenario Input／ExpectedとJavaの接続
- Environment解決とAPI Client生成
- Request Builder、Response MapperおよびCheck Registry
- Scenario Context、API ExchangeおよびRun Isolation
- Execution Identity、ResultおよびReason Code
- Snapshot、EvidenceおよびArtifact Manifest
- Execution State、PreviousおよびBaseline
- File I/O、Atomic Write、整合性確認および公開
- Structured Log、Exception変換、TimeoutおよびRecovery
- Runtime構成、Secret境界、Concurrencyおよび運用Handoff

### 5.2 対象外

| 対象外 | 正式な管理先 |
|---|---|
| 現行業務Flowの事実 | `business/` |
| 5 Masterの固定定義 | `system/02_master/` |
| API Request／Response項目定義 | `system/03_api_design/` |
| UseCase／Scenario固有の呼出順序、分岐、Mapping | `system/04_usecase_design/`およびJava Scenario Class |
| Response Field Diffの詳細Algorithm | `system/06_verification_assets/APIレスポンスDiff設計書.md` |
| Expectedの詳細契約 | `system/06_verification_assets/検証結果・Expected設計書.md` |
| Report Layoutおよび表示責務 | `system/07_report/Report設計書.md` |
| 実Credential | Secret Storeまたは環境固有の安全な設定 |
| Runtime Artifact実体 | Repository外のRuntime Data Root |

## 6. 確定済みDesign Input

| Input ID | 要求・制約 | 根拠 | 影響設計 | Status |
|---|---|---|---|---|
| `FW-IN-001` | 約7業務Flowを入口、分岐、終点の単位で検証可能とする。正式名称と件数は実資料で確定する。 | Business計画 | System／Framework／連携 | `PROVISIONAL` |
| `FW-IN-002` | 約24 APIを単体および複数API連携で検証可能とする。重複排除後の件数を正とする。 | API棚卸計画 | System／Framework | `PROVISIONAL` |
| `FW-IN-003` | API呼出順序、条件分岐、前段Responseから後続RequestへのMappingをJavaで実装する。 | `REP-D002` | Framework／連携 | `CONFIRMED` |
| `FW-IN-004` | Scenario InputとExpectedはScenario単位の静的資産として管理する。 | `REP-D003` | Framework／Context／File I/O | `CONFIRMED` |
| `FW-IN-005` | 入口Parameterは指定可能とし、後続Parameterは前段結果、条件または明示値から構築する。 | UseCase要求 | Framework／Context | `CONFIRMED` |
| `FW-IN-006` | Status Code、存在、型、Null、空文字、長さ、桁数、固定値、Enumおよび業務属性を検証する。 | Verification要求 | Result／Registry／Expected | `CONFIRMED` |
| `FW-IN-007` | JSON Fieldの追加、削除、型変化および値変化をPrevious／Baselineと比較する。 | Diff設計 | Identity／Snapshot／File I/O | `CONFIRMED` |
| `FW-IN-008` | `IGNORE_VALUE`でも存在、型、Null、形式、Object／Array構造および子項目Checkを独立して実行可能とする。 | API分析Template／Diff設計 | Registry／Result | `CONFIRMED` |
| `FW-IN-009` | Execution、Verification、ChangeおよびRecoveryを別軸で表現する。 | 現行Verification／Report設計 | Identity／Result | `CONFIRMED` |
| `FW-IN-010` | 同一Scenarioの同時実行を`runId`で隔離する。 | ScenarioContext設計 | Context／File I/O／Log | `CONFIRMED` |
| `FW-IN-011` | PreviousおよびBaselineを日付、更新時刻またはDirectory順から推測しない。 | Baseline設計 | Identity／File I/O | `CONFIRMED` |
| `FW-IN-012` | BaselineはExecution Identity単位で管理し、完全Runから全体を原子的に置換する。 | Baseline設計 | Identity／File I/O／Recovery | `CONFIRMED` |
| `FW-IN-013` | Verification `FAIL`とExecution Incompleteを区別する。 | Baseline／Expected設計 | Identity／Result | `CONFIRMED` |
| `FW-IN-014` | Timeoutまたは通信切断後に更新APIの結果を推測せず、自動RetryをDefaultにしない。 | 現行設計判断 | Framework／Recovery | `CONFIRMED` |
| `FW-IN-015` | Request、Response、Result、Diff、LogおよびReportをRun単位で追跡可能にする。 | Traceability規約 | Identity／Snapshot／Report | `CONFIRMED` |
| `FW-IN-016` | Secret、Token、CookieおよびMask前の機密情報を通常Evidenceへ保存しない。 | Repository／Security原則 | Snapshot／Log／Environment | `CONFIRMED` |
| `FW-IN-017` | Runtime Artifact、BaselineおよびExecution State実体を`system/`へ保存しない。 | `REP-D007` | File I/O／Environment | `CONFIRMED` |
| `FW-IN-018` | 同じRelease Artifactを環境別外部設定で実行できる構成を目標とする。 | Environment要求 | System／Environment | `PROVISIONAL` |
| `FW-IN-019` | 日次実行結果を承認者が確認できるSummary、DiffおよびEvidenceとして生成する。 | Report要求 | System／Snapshot／Report | `CONFIRMED` |
| `FW-IN-020` | 不明なMaster、Class、Input、Expected、SchemaまたはBaselineを推測補完せず、起動前に停止する。 | No Guess原則 | Framework／連携／Result | `CONFIRMED` |

## 7. Decision台帳

| Decision ID | 決定 | 適用範囲 | 根拠 | Status |
|---|---|---|---|---|
| `FW-DEC-001` | 横断Framework設計の正本Directoryを`system/05_framework/`とする。 | Repository | `REP-D004` | `APPROVED` |
| `FW-DEC-002` | MasterはBusiness、Environment、API、UseCase、Scenarioの5種類だけとする。 | Framework Loader | `REP-D001` | `APPROVED` |
| `FW-DEC-003` | Context、Verification、Verification PolicyおよびCompare Policy Masterを復元しない。 | Definition解決 | Repository Freeze | `APPROVED` |
| `FW-DEC-004` | API呼出順序、Mapping、分岐、Check登録およびCompare DefinitionはJava Firstとする。 | Runtime | `REP-D002` | `APPROVED` |
| `FW-DEC-005` | Markdown／JSONは入力値、期待値、固定定義および証跡契約に限定し、実行Scriptまたは式言語を埋め込まない。 | Runtime／Security | Java First | `APPROVED` |
| `FW-DEC-006` | Scenario ContextをRunごとに生成し、異なるRun間でObject、Map、WriterおよびTemporary領域を共有しない。 | Context | ScenarioContext設計 | `APPROVED` |
| `FW-DEC-007` | API呼出実体はScenario内一意の`apiCallCode`で識別し、`apiId`だけを実体Keyにしない。 | Context／Diff | ScenarioContext設計 | `APPROVED` |
| `FW-DEC-008` | DTOはJava処理、JSONは送受信証跡とField Diffに使用し、両者の同一性を検証する。 | Client／Context | ScenarioContext設計 | `APPROVED` |
| `FW-DEC-009` | Expected、Actual、Previous／BaselineおよびDiffを別Artifactとして管理する。 | Result／Artifact | 現行06設計 | `APPROVED` |
| `FW-DEC-010` | 初回実行は空JSONと比較せず、`NOT_COMPARED + INITIAL_EXECUTION`を記録する。 | Diff／Result | Baseline／Diff設計 | `APPROVED` |
| `FW-DEC-011` | Baseline更新可否はVerification PASSだけでなくExecution Completenessで判定する。 | Baseline | Baseline設計 | `APPROVED` |
| `FW-DEC-012` | Report生成処理はBaselineまたはExecution Stateを更新しない。 | Report | 責務分離 | `APPROVED` |
| `FW-DEC-013` | Response Field Diffは`06_verification_assets`、Reportは`07_report`に置く。 | Repository | `REP-D005` | `APPROVED` |
| `FW-DEC-014` | Runtime契約Schemaは`06_verification_assets/common/schemas/`に置く。 | Schema | Repository Freeze | `APPROVED` |
| `FW-DEC-015` | `recovery/`は移行入力であり、現行設計とRuntimeのReference先にしない。 | 全体 | `REP-P012` | `APPROVED` |
| `FW-DEC-016` | Java Source Root、Package、Runtime物理RootおよびDeployment構成は関連設計承認前に固定しない。 | 実装／環境 | `REP-D010` | `APPROVED` |
| `FW-DEC-017` | 一回の物理実行を`runId`、Baseline比較Slotを`environmentId + useCaseId + scenarioId + inputSetId`からなるExecution Identityで識別し、両者を分離する。 | Runtime／Baseline／Artifact | `共通Identity・Resultモデル設計書.md` | `PROPOSED` |
| `FW-DEC-018` | Execution、Verification、ChangeおよびRecoveryの四軸原結果を保持し、表示用SummaryまたはSeverityで上書きしない。 | Result／Report／Recovery | `共通Identity・Resultモデル設計書.md` | `PROPOSED` |
| `FW-DEC-019` | 外部API呼出前に全Definition、Reference、Registry、Schemaおよび環境制約を検証し、不変Execution PlanをSealする。 | Framework／Runtime | `共通Framework設計書.md` | `PROPOSED` |
| `FW-DEC-020` | CoreをPort／Adapterで外部製品から分離し、個別Scenario、Check、ReportおよびAdapterからState／Baselineを直接変更させない。 | Architecture／Dependency | `共通Framework設計書.md` | `PROPOSED` |
| `FW-DEC-021` | 更新APIのTimeoutまたは送信後接続断で結果が確認できない場合は自動Retryせず、`UNKNOWN_OUTCOME`かつRecovery Requiredとして後続副作用を停止する。 | Runtime／Recovery | `共通Framework設計書.md` | `PROPOSED` |
| `FW-DEC-022` | 5 Master、03／04設計、Scenario Input／ExpectedおよびJava Registryを一つの検証済みDefinition Graphとして解決し、API呼出前に不変Bundleへ固定する。 | Definition／Runtime | `Framework・業務定義連携設計書.md` | `PROPOSED` |
| `FW-DEC-023` | `API_UseCase_Scenario対応表.md`は生成可能なTrace Viewとし、第6 Masterまたは単独の実行定義として扱わない。 | Master／Trace | `Framework・業務定義連携設計書.md` | `PROPOSED` |
| `FW-DEC-024` | Java Registryは明示Keyを0件でも複数件でもなく一件だけ解決し、Version／Capabilityを検証する。類似Class推測、外部Class名の反射実行およびRun中の差替えを禁止する。 | Java／Security | `Framework・業務定義連携設計書.md` | `PROPOSED` |
| `FW-DEC-025` | 通常Evidenceは保存前Mask、Secret Scan、Schema ValidationおよびCanonical化を通過したArtifactだけとし、Mask前Raw DataはDefault永続化禁止、例外時もCredentialを必ず除去する。 | Artifact／Security | `Snapshot・Evidence設計書.md` | `PROPOSED` |
| `FW-DEC-026` | Artifact ManifestはMask後Canonical ContentのSHA-256、Size、Schema、Owner、相対Path、Mask ProfileおよびOutcome別Requirementを保持し、Package CompletenessをExecution Statusから独立して判定する。 | Artifact／Manifest | `Snapshot・Evidence設計書.md` | `PROPOSED` |
| `FW-DEC-027` | Core Run Artifact Manifestは後生成Reportを含めず、Report Setは独立した原子的公開単位とする。Baseline完全性索引は`baseline-meta.json`内Artifact Inventoryとして保持する。 | Artifact／Report／Baseline | `Snapshot・Evidence設計書.md` | `PROPOSED` |
| `FW-DEC-028` | Consumer可視Logical PathとTemporary、Versioned、Pointer、QuarantineのAdapter内部Namespaceを分離し、物理Locatorを永続Artifactへ保存しない。 | File I/O／Security | `ファイル入出力設計書.md` | `PROPOSED` |
| `FW-DEC-029` | Runは`runId`単位のCreate-Only Publication、Baseline／ReportはImmutable Versioned SetとCAS Pointer、Execution StateはExpected Version付き単一Object CASを使用する。 | File I/O／Atomicity | `ファイル入出力設計書.md` | `PROPOSED` |
| `FW-DEC-030` | Platform JSONはUTF-8、BOMなし、LFおよびCanonical Profileを使用し、Mask後Final Byte列のSize／SHA-256とPublished Read-backをIntegrity正本とする。 | File I/O／Integrity | `ファイル入出力設計書.md` | `PROPOSED` |
| `FW-DEC-031` | StorageはCreate-Only、Versioned Set、CAS、Pinned ReadおよびPrivate Temporary／QuarantineをCapability Probeで証明し、Lock喪失後のMutationをFencing条件で拒否する。 | File I/O／Concurrency | `ファイル入出力設計書.md` | `PROPOSED` |
| `FW-DEC-032` | 四結果軸のResult、Diagnostic Log、Audit Record、Metric、TraceおよびRecovery Caseを別責務とし、Log MessageからResultを再判定しない。 | Observability／Result | `ログ・例外・Recovery設計書.md` | `PROPOSED` |
| `FW-DEC-033` | Platform Error／Failure CodeはComponent障害の診断、Reason Codeは四結果軸の理由として別Field・別Catalogで保持し、製品固有Exceptionを境界でFailure Recordへ変換する。 | Exception／Result | `ログ・例外・Recovery設計書.md` | `PROPOSED` |
| `FW-DEC-034` | API Timeout、Cancelおよび接続断はDispatch Stateで判定し、更新APIが送信された可能性を否定できない場合は自動Retryせず`UNKNOWN_OUTCOME + Recovery REQUIRED`とする。 | Timeout／Retry／Recovery | `ログ・例外・Recovery設計書.md` | `PROPOSED` |
| `FW-DEC-035` | Recovery Caseは元Runと別Identityで管理し、ActionとAuditをAppend Onlyで保持する。Resolution、再実行、補償または訂正で元Runの四結果軸とPublished Artifactを書き換えない。 | Recovery／Audit | `ログ・例外・Recovery設計書.md` | `PROPOSED` |
| `FW-DEC-036` | Diagnostic、AuditおよびRecoveryはLogical Portで外部Sinkへ分離し、凍結Runtime Treeへ未承認の`logs/`、`error.json`または`recovery/`を追加しない。 | Log／File I/O／Repository | `ログ・例外・Recovery設計書.md` | `PROPOSED` |
| `FW-DEC-037` | Environment Masterの論理接続先EnvironmentとRuntime Deployment Profileを別Identityとして管理し、Build Environmentまたは物理Hostを第6 Masterとして追加しない。 | Environment／Runtime／Master | `環境・Runtime構成設計書.md` | `PROPOSED` |
| `FW-DEC-038` | 同一のImmutable Release Artifact／Imageを環境別External Configで実行し、Release Digest、Definition Hash、Config HashおよびCapability ProfileをRun開始前にSealして追跡する。 | Release／Config／Trace | `環境・Runtime構成設計書.md` | `PROPOSED` |
| `FW-DEC-039` | Secret、CertificateおよびCredentialはReference／Provider境界で解決し、Repository、Image、Command Line、通常Artifact、LogおよびReportへ実値を保存しない。 | Security／Environment | `環境・Runtime構成設計書.md` | `PROPOSED` |
| `FW-DEC-040` | Shared／Production-like Runtimeは非root Identity、Read Only Application、分離されたWritable Storageおよび最小Network／Secret権限で動作する。 | Runtime／Security | `環境・Runtime構成設計書.md` | `PROPOSED` |
| `FW-DEC-041` | Storage、Lock／Fencing、HTTP Dispatch、Audit、SecretおよびRecovery AdapterのCapabilityを起動／Run Preflightで証明し、不足時は外部API呼出前にFail Closedする。 | Runtime／Capability | `環境・Runtime構成設計書.md` | `PROPOSED` |
| `FW-DEC-042` | Local、Single Node、ContainerおよびDistributed RuntimeをCapability Profileとして分離し、Distributed Lock／FencingなしでReplica数を増やさない。 | Deployment／Concurrency | `環境・Runtime構成設計書.md` | `PROPOSED` |
| `FW-DEC-043` | Liveness／Readinessは副作用APIを呼び出さず、E6接続確認を行うSmoke Testは明示的なRead-only／Mock試験としてHealth Checkから分離する。 | Health／Safety | `環境・Runtime構成設計書.md` | `PROPOSED` |
| `FW-DEC-044` | Deployment Rollback、Backup Restore、RetentionおよびRecoveryでPublished Runの四結果軸とArtifactを書き換えず、Pointer／State変更はCAS、Fencing、Auditおよび承認下で行う。 | Deployment／Backup／Recovery | `環境・Runtime構成設計書.md` | `PROPOSED` |
| `FW-DEC-045` | Platform JSON SchemaはDraft 2020-12、Version非埋込みFile名、Version付きURN `$id`およびInstance `schemaVersion`のMajor.Minorを使用し、Patch差分をSource Revision／Release Digest／Content Hashで追跡する。 | Schema／Version | `命名規約.md`／`scenario-input.schema.json` | `PROPOSED` |
| `FW-DEC-046` | 永続JSON ArtifactではJSON Schemaを機械契約とし、Java DTO／Serializer／LoaderはSchemaを緩和しない。業務分岐、Mapping、CheckおよびCompare DefinitionのJava Firstとは責務を分離する。 | Schema／Java／Contract Test | `Scenario入力データ設計書.md` | `PROPOSED` |
| `FW-DEC-047` | 凍結7 Schemaは初期必須集合であり全Runtime JSONの完全集合とはみなさない。未対象Artifactを既存Schemaへ混在させず、追加Schemaは責務と移行影響のArchitecture Review後にRepository変更として承認する。 | Schema／Runtime Artifact | 第8バッチCoverage Review | `PROPOSED` |
| `FW-DEC-048` | Scenario Expectedは`environmentId + useCaseId + scenarioId + inputSetId`で対応資産を一意に選択し、独立した`expectedSetId`を追加しない。Expected内容改訂は`expectedVersion`で追跡する。 | Expected／Identity／Schema | `scenario-expected.schema.json` | `PROPOSED` |
| `FW-DEC-049` | Scenario Expectedは終端Execution／Verification／Recovery Statusだけを保持し、`UNKNOWN_OUTCOME`はRecovery `REQUIRED`を必須とする。`expectedValue`を持つCheckは`valueType`を必須とし、JSON型をSchemaで一致させる。 | Expected／Result／Schema | `scenario-expected.schema.json` | `PROPOSED` |
| `FW-DEC-050` | Scenario Verification ResultはResult Identity、Owner、元Run確定時の四結果軸、Severity、Reason、Child Reference、Check、Summaryおよび安全なArtifact Referenceを保持し、Batch Resultを同Schemaへ混在させない。`UNKNOWN_OUTCOME`はRecovery `REQUIRED`、`INCOMPLETE／REJECTED`はVerification `NOT_EVALUATED`を構造制約とする。 | Verification／Result／Schema | `verification-result.schema.json` | `PROPOSED` |
| `FW-DEC-051` | Response Field DiffはDocument／Item比較状態、Change、Ignoreおよび観測値だけを保持し、Business Verificationを再判定しない。初回／比較不能は`NOT_COMPARED`とReasonを必須とする。 | Diff／Schema／Verification | `response-field-diff.schema.json` | `PROPOSED` |
| `FW-DEC-052` | Execution StateはExecution Identity、初回Flag、Previous Run Pointerおよび監査時刻だけを保持し、Storage Version Token／Lock／Fencingを内容Schemaへ混入させない。Baseline Metaは一つのComplete Run、Source Manifest、対象Artifact Inventoryおよび独立Inventory Hashを保持する。 | State／Baseline／Schema | `execution-state.schema.json`／`baseline-meta.schema.json` | `PROPOSED` |
| `FW-DEC-053` | Core Artifact Manifestは自身と後生成ReportをEntryへ列挙せず、Effective Requirement、Core Artifact Entry、Mask、Hash、CompletenessおよびPublicationを保持する。`PUBLISHED`は`COMPLETE`かつ`publishedAt`必須とする。 | Artifact／Manifest／Schema | `artifact-manifest.schema.json` | `PROPOSED` |
| `FW-DEC-054` | 双方向Trace Validationを`TRACE-STATIC / TRACE-BUILD / TRACE-SEAL / TRACE-RUNTIME / TRACE-REPORT`の5 Gateへ分離し、後段は前段成功を前提とする。入力不足、Java未実装またはSchema未対象を`PASS`にしない。 | Trace／Release Gate | `トレーサビリティ規約.md` | `PROPOSED` |
| `FW-DEC-055` | `Scenario_Master.executionClass`はBuild Trace用宣言であり反射実行命令ではない。Scenario Registryを`scenarioId`で一件解決し、Descriptorの`implementationType`完全一致後にRegistry管理済みInstanceだけを使用する。 | Java／Registry／Security | `Framework・業務定義連携設計書.md` | `PROPOSED` |
| `FW-DEC-056` | Trace Projectionは既存Master、設計、Registry SnapshotおよびArtifactから導出し、第6 Master、専用Repository Registryまたは表示順によるJoinを追加しない。 | Master／Trace／Repository | `トレーサビリティ規約.md`／`Framework・業務定義連携設計書.md` | `PROPOSED` |
| `FW-DEC-057` | Runtime Artifact公開前にRun／Execution／Bundle／Owner／Hashを横断検証し、Report公開前に全表示行をResult／Diff／Manifest Entryへ逆引きする。Runtime／Report Trace FailureでSource Runの四結果軸を書き換えない。 | Artifact／Evidence／Report | `Snapshot・Evidence設計書.md`／`Report設計書.md` | `PROPOSED` |
| `FW-DEC-058` | 初期7 Schemaへ異種Artifactを混在させず、Definition Bundle、Runtime Meta 3種、Batch ResultおよびReport 4種を9独立Schemaとして受控追加し、現行共通Schema集合を16種類とする。 | Schema／Repository／Migration | `Repository_Structure.md` | `PROPOSED` |
| `FW-DEC-059` | Definition Bundleは5 Master Snapshot、設計／Asset Snapshot、Registry Snapshot、Reference Graph、Validation ResultおよびHashを同一Source RevisionでSealし、5 Master Type一意性と実Source解決はSemantic Validatorで保証する。 | Definition／Trace／Schema | `definition-bundle.schema.json` | `PROPOSED` |
| `FW-DEC-060` | Run Meta、Scenario ExecutionおよびAPI Call Metaを独立Schema化し、Run／Scenario／API Call親子Identity、Bundle／Registry、Plan Call、Disposition、Dispatch StateおよびArtifact Referenceを構造化する。空Responseで未実行事実を偽装しない。 | Runtime／Evidence／Schema | `run-meta.schema.json`／`scenario-execution.schema.json`／`api-meta.schema.json` | `PROPOSED` |
| `FW-DEC-061` | Batch Verification ResultはScenario Resultと別Identity／別Schemaで管理し、Scenarioの四結果軸とSource Referenceを再判定せず決定的に集約する。 | Batch／Result／Schema | `batch-verification-result.schema.json` | `PROPOSED` |
| `FW-DEC-062` | Scenario Summary、Diff Report、Evidence IndexおよびDaily Summaryを4独立Schemaとし、Report Status、Generation Identity、Generator Version、Source Locatorおよび種別固有行を構造化する。 | Report／Trace／Schema | `scenario-summary.schema.json`等4 Schema | `PROPOSED` |
| `FW-DEC-063` | JSON SchemaはArtifact単体の構造をFail Closedで検証し、Stable Key一意性、件数集約、時刻順序、Hash／実Byte、親子IdentityおよびSource逆引きはSemantic Validator／Java Contract Testで検証する。Schema正文完成だけでTrace Gateを`PASS`にしない。 | Validation／Java／Release Gate | 第9バッチ第2段階Contract Test | `PROPOSED` |

## 8. Open Issue

| Issue ID | 論点 | 現時点の制約・暫定方針 | 決定先 | Status |
|---|---|---|---|---|
| `FW-OI-001` | Java source／test／resource Root | 仮Directoryを正本として記載しない。 | システム設計／共通Framework設計 | `OPEN` |
| `FW-OI-002` | Java Package、ModuleおよびDependency方向 | 文書上は論理Component名だけを使用する。 | システム設計／共通Framework設計 | `OPEN` |
| `FW-OI-003` | Run、Batch、UseCase、Scenario、API Callの正式Identity構造 | DraftでStatic、RuntimeおよびExecution Identityを分離し、Cardinalityを定義済み。横断Reviewと承認を待つ。 | 共通Identity・Resultモデル設計 | `WAITING` |
| `FW-OI-004` | Execution／Verification／Change／Recoveryの正式Enum、Severity、優先順位 | Draftで四軸Enum、Severity、Reasonおよび集約優先順位を定義済み。横断Reviewと承認を待つ。 | 共通Identity・Resultモデル設計 | `WAITING` |
| `FW-OI-005` | Artifact Manifestの項目、Hash、Complete判定およびSchema Version | Draft本文と`artifact-manifest.schema.json`正文・機械Validationは整合済み。正式Role Review、過去Artifact MigrationおよびRuntime実装Contract Testを待つ。 | Snapshot・Evidence／File I/O設計 | `WAITING` |
| `FW-OI-006` | Runtime Dataの物理RootとStorage種別 | Environment DraftでLogical Root Handle、Profile候補、PermissionおよびCapability Gateを定義済み。物理Locatorと製品選定を待つ。 | Infrastructure／Runtime Review | `WAITING` |
| `FW-OI-007` | Atomic Rename非対応Storageでの公開方式 | Immutable Versioned Set＋CAS Pointerを正とし、Environment DraftのCapability Probeで採用Storageを判定する。製品選定を待つ。 | Infrastructure／Runtime Review | `WAITING` |
| `FW-OI-008` | 同一Execution IdentityのLock実装 | Profile別にMutex、Single Node Lease／Fencing、Distributed Lock境界を定義済み。製品、Lease値およびFencing実装を待つ。 | Runtime／Infrastructure Review | `WAITING` |
| `FW-OI-009` | Timeout Harness、CancellationおよびUnknown Outcome表現 | Dispatch-aware HTTP Capability、独立Timeout、Bounded Responseおよび更新API自動Retry禁止を定義済み。HTTP Client製品と実値を待つ。 | Runtime／API／NFR Review | `WAITING` |
| `FW-OI-010` | Recovery Handoff Interfaceと再開単位 | Recovery Case契約、Adapter Capability、Auditおよび元Run不変を定義済み。Store、Ticket連携、RunbookおよびSLAを待つ。 | Operation／Security Review | `WAITING` |
| `FW-OI-011` | HTTP Client、Connection Pool、TLS、Proxyおよび認証Provider | Environment Draftで必須Capability、Network／TLS／Proxy／Secret境界を定義済み。製品、Profileおよび値を待つ。 | Runtime／Infrastructure／Security Review | `WAITING` |
| `FW-OI-012` | Container、Tomcat、Compose、SchedulerおよびDeployment | Runtime Profile、Process／Container条件、Deploy／Rollback Gateを定義済み。採用形態、製品および物理配置を待つ。 | Architecture／Infrastructure／Operation Review | `WAITING` |
| `FW-OI-013` | Retention、Archive、Backup、旧Baseline保持世代 | Class、Delete Gate、Backup／Restore／DR契約を定義済み。日数、世代、RPO／RTOを待つ。 | NFR／Operation／Security Review | `WAITING` |
| `FW-OI-014` | 最大Response、Context Memory、Diff ItemおよびReport Size | Bounded Resource階層と必須Limitを定義済み。具体値は代表Data、E6制約、NFRおよび負荷試験を待つ。 | NFR／Performance Review | `WAITING` |
| `FW-OI-015` | 正式7業務、API、UseCase、ScenarioおよびClass | Business分析完了まで正式Masterを0件とする。 | `business/`および02～04設計 | `WAITING` |
| `FW-OI-016` | PROD実行可否、更新API制限、Test Data Lease | Environment Masterだけで安全性を代替しない。 | Environment／Operation設計 | `OPEN` |
| `FW-OI-017` | `run-meta.json`、`scenario-execution.json`、`api-meta.json`および`batch-verification-result.json`のSchema追加要否 | 4独立Schemaの正文・機械Validation済み。正式Role Review、過去Artifact MigrationおよびJava Writer／Reader Contract Testを待つ。 | 第9バッチSchema／Architecture Review | `WAITING` |
| `FW-OI-018` | Recovery Case／Action／AuditのSchema追加要否 | 四軸Recovery Statusは`verification-result`、Case／Actionは別Identityを維持し、外部Store契約と凍結Repositoryへの影響をReviewする。 | Schema／Operation／Architecture Review | `OPEN` |
| `FW-OI-019` | Definition BundleおよびReport JSONのSchema追加要否 | Bundle 1種とReport 4種を独立Schema化し正文・機械Validation済み。正式Role Review、Generator／PublisherおよびCross-Artifact Contract Testを待つ。 | Schema／Report／Architecture Review | `WAITING` |

## 9. 旧Framework責務の移行判定

| 旧文書／責務 | 現行移行先 | 判定 | 現行処置 |
|---|---|---|---|
| システム設計 | `システム設計書.md` | `REWRITE_REQUIRED` | 現行5 Master、Java First、3専門領域分離で再設計する。 |
| 共通Framework | `共通Framework設計書.md` | `REWRITE_REQUIRED` | Runner、Resolver、Client、Builder、Registry、Publisherの責務を再定義する。 |
| RunContext | `ScenarioContext設計書.md`、`ExecutionState・Baseline管理設計書.md` | `PARTIAL_MIGRATION` | 現行2文書を継承済み。Run／Batch集約は中核設計で補う。 |
| Identity／Result | `共通Identity・Resultモデル設計書.md` | `REWRITE_REQUIRED` | 複数判定軸と集約規則を統合する。 |
| Snapshot | `Snapshot・Evidence設計書.md` | `PARTIAL_MIGRATION` | 現行契約で全面再設計し、現行16 Schema正文・機械Validation済み。正式Review、Java Writer／Reader、Cross-Artifact ValidationおよびRuntime実装を待つ。 |
| Diff | `06_verification_assets/APIレスポンスDiff設計書.md` | `CURRENT_REPLACEMENT` | API Response Diffを05へ戻さない。 |
| Report | `07_report/Report設計書.md` | `CURRENT_REPLACEMENT` | Layoutと生成責務を05へ戻さない。 |
| File I/O | `ファイル入出力設計書.md` | `PARTIAL_MIGRATION` | 現行契約で全面再設計済み。正式Review、Environment Adapter選定および運用値を待つ。 |
| Log／Exception | `ログ・例外・Recovery設計書.md` | `PARTIAL_MIGRATION` | 現行契約で全面再設計済み。正式Review、Environment Adapterおよび運用Runbookを待つ。 |
| Environment | `環境・Runtime構成設計書.md` | `PARTIAL_MIGRATION` | 論理Target EnvironmentとRuntime Profileを分離して全面再設計済み。製品、物理値および正式Reviewを待つ。 |
| 業務定義連携 | `Framework・業務定義連携設計書.md` | `REWRITE_REQUIRED` | Loader、Resolver、Registry、Java Traceを現行構造で再設計する。 |

## 10. Framework設計書作成順序

| 順序 | 成果物 | 主出力 | 内容作成 | 機械Validation | 横断Review |
|---:|---|---|---|---|---|
| 1 | `Framework設計入力・決定事項一覧.md` | Input／Decision／Open Issue | `CONTENT_PROVIDED` | `PASSED` | `IN_PROGRESS` |
| 2 | `システム設計書.md` | System Boundary、論理Component、Data Flow | `CONTENT_PROVIDED` | `PASSED` | `IN_PROGRESS` |
| 3 | `共通Identity・Resultモデル設計書.md` | Identity、Result、Reason、集約規則 | `CONTENT_PROVIDED` | `PASSED` | `IN_PROGRESS` |
| 4 | `共通Framework設計書.md` | Runtime Component契約とLifecycle | `CONTENT_PROVIDED` | `PASSED` | `IN_PROGRESS` |
| 5 | `Framework・業務定義連携設計書.md` | Loader、Resolver、Registry、Trace | `CONTENT_PROVIDED` | `PASSED` | `IN_PROGRESS` |
| 6 | `Snapshot・Evidence設計書.md` | Artifact、Manifest、Mask、Complete条件 | `CONTENT_PROVIDED` | `PASSED` | `IN_PROGRESS` |
| 7 | `ファイル入出力設計書.md` | Logical Path、Atomic Write、Storage Port | `CONTENT_PROVIDED` | `PASSED` | `IN_PROGRESS` |
| 8 | `ログ・例外・Recovery設計書.md` | Error変換、Log、Timeout、Recovery | `CONTENT_PROVIDED` | `PASSED` | `IN_PROGRESS` |
| 9 | `環境・Runtime構成設計書.md` | Environment、Config、Secret、Deployment候補 | `CONTENT_PROVIDED` | `PASSED` | `IN_PROGRESS` |
| 10 | 既存文書整合 | 双方向ReferenceとBlocker解消 | `IN_PROGRESS` | `IN_PROGRESS` | `IN_PROGRESS` |

`ScenarioContext設計書.md`および`ExecutionState・Baseline管理設計書.md`は作成済みの基礎設計として継承し、上記設計による整合確認後にReview対象とする。

## 11. 設計書別Definition of Ready

| 成果物 | 着手条件 |
|---|---|
| システム設計 | 本書の確定入力とOpen Issueが分類済みである。 |
| Identity／Result | 現行Context、Expected、Diff、Reportの状態語彙が棚卸済みである。 |
| 共通Framework | System BoundaryとIdentity／Resultの責務が定義済みである。 |
| 業務定義連携 | 5 Masterと03／04 TemplateのReference項目が確定している。 |
| Snapshot／Evidence | Complete Run、Mask、ResultおよびReport入力が定義済みである。 |
| File I/O | Artifact一覧、Manifestおよび公開単位が定義済みである。 |
| Log／Recovery | Error Taxonomy、Execution StatusおよびTimeout結果が定義済みである。 |
| Environment／Runtime | Component、Port、Storage要件、Secret境界が定義済みである。 |

## 12. Framework全体Definition of Done

次をすべて満たすまで、Framework設計完了またはJava実装着手可能と判定しない。

1. 11設計書が現行Directoryに存在し、Front Matterと一意な`document_id`を持つ。
2. 旧4 Master、旧YAML駆動、旧Policy駆動およびRecovery正文へのReferenceが0件である。
3. Execution、Verification、ChangeおよびRecoveryの状態と集約規則が一意である。
4. Run、Batch、UseCase、Scenario、API Call、ResultおよびArtifact Identityが追跡可能である。
5. Scenario Input、Expected、Java Class、`apiCallCode`、`resultKey`およびEvidenceの双方向Traceが定義されている。
6. Artifact Manifestと7 JSON Schemaの責務、VersionおよびJava DTO関係が定義されている。
7. Complete Run、Baseline更新、Atomic Publish、Crash RecoveryおよびLockの契約が矛盾しない。
8. Timeout、Unknown Outcome、Retry禁止条件およびRecovery Handoffが定義されている。
9. Secret非保存、保存前Mask、Path Traversal防止および最小権限が設計されている。
10. Java Source Root、PackageおよびRuntime物理Rootは、決定済みの場合だけ正本へ記載されている。
11. 06 Diff／Expected、07 Reportおよび既存Context／Baseline設計とのReferenceが解決する。
12. Architecture、Runtime、Verification、SecurityおよびOperation Reviewで重大指摘が0件である。

## 13. Validation計画

| Validation ID | 確認内容 | 方法 | Status |
|---|---|---|---|
| `FW-VAL-001` | `system/05_run_context/`を現行Reference先とする記述が0件 | Reference欄とLinkの検索 | `PASSED` |
| `FW-VAL-002` | `recovery/`を現行正本Reference先とする記述が0件 | Reference欄とLinkの検索 | `PASSED` |
| `FW-VAL-003` | Front Matter、H1、Code Fenceおよび`document_id`が正常 | 静的検証 | `PASSED` |
| `FW-VAL-004` | 5 Master以外をRuntime定義として使用しない | Reference／設計Review | `PASSED` |
| `FW-VAL-005` | Java FirstとInput／Expected境界が一貫する | 03～06横断事前確認 | `PASSED` |
| `FW-VAL-006` | Result語彙が4軸へ分類可能 | 状態語彙棚卸 | `PASSED` |
| `FW-VAL-007` | ArtifactからSource Run、Scenario、Call、Resultへ追跡可能 | Snapshot／Manifest契約と現行16 SchemaのIdentity／Reference構造を事前確認。実File／Hash／Runtime統合Testは実装時に実施 | `IN_PROGRESS` |
| `FW-VAL-008` | TimeoutとBaseline更新禁止条件が矛盾しない | Failure Scenario Review | `PASSED` |
| `FW-VAL-009` | Mask前機密情報を通常Artifactへ保存しない | Security横断事前確認。例外領域詳細は後続設計 | `IN_PROGRESS` |
| `FW-VAL-010` | 未決物理構成を仮決めしていない | Open Issue／設計本文比較 | `PASSED` |
| `FW-VAL-011` | `IGNORE_VALUE`が現行Diff契約と一致する | Identity／Framework／Diff横断確認 | `PASSED` |
| `FW-VAL-012` | Definition Source、Definition Bundle、Execution Planの生成境界が一意である | Framework／業務定義連携横断確認 | `PASSED` |
| `FW-VAL-013` | 内容作成、Validation、Review、Decision承認および文書Lifecycleが分離される | 台帳／Repository進捗表示確認 | `PASSED` |
| `FW-VAL-014` | Run、Baseline、StateおよびReportのPublication方式がStorage能力に応じて一意である | File I/O／Snapshot／Baseline／Report横断確認 | `PASSED` |
| `FW-VAL-015` | Runtime `api-calls/`のDirectory Keyが全正本で`apiCallCode`へ統一される | Repository／Context／Artifact Path検索 | `PASSED` |
| `FW-VAL-016` | Failure Code、Reason Code、四結果軸およびLog Levelが混在しない | Identity／Framework／Log／Report横断確認 | `PASSED` |
| `FW-VAL-017` | 更新API Timeout、Dispatch State、自動Retry禁止およびRecovery Handoffが一意である | Framework／API Meta／Log・Recovery横断確認 | `PASSED` |
| `FW-VAL-018` | Diagnostic／Audit／Recovery設計が凍結Runtime Treeへ未承認Pathを追加しない | Repository／Snapshot／File I/O／Log Path確認 | `PASSED` |
| `FW-VAL-019` | Logical Target Environment、Build EnvironmentおよびRuntime Deployment Profileが混在しない | Environment Master／Environment Runtime設計横断確認 | `PASSED` |
| `FW-VAL-020` | External Config、Secret、ReleaseおよびCapability ProfileがRun単位で安全に追跡できる | Environment Runtime／Snapshot／File I/O横断確認 | `PASSED` |
| `FW-VAL-021` | Health、Scheduler、Lock、DeploymentおよびRestoreが四結果軸とFrozen Runtime Treeを変更しない | Environment Runtime／Identity／Repository横断確認 | `PASSED` |
| `FW-VAL-022` | `scenario-input.schema.json`がDraft 2020-12として有効で、3 Exampleと正反例Testに適合する | JSON Schema Validator／Contract Test | `PASSED` |
| `FW-VAL-023` | 7 SchemaとRuntime ArtifactのCoverageが一意で、未対象Artifactが別Schemaへ混入しない | Producer／Consumer／Path Matrix | `PASSED` |
| `FW-VAL-024` | `scenario-expected.schema.json`がDraft 2020-12として有効で、3 Example、5反例および重複`resultKey`のSemantic境界Testに適合する | JSON Schema Validator／Contract Test／Semantic Test | `PASSED` |
| `FW-VAL-025` | `verification-result.schema.json`がResult Identity／Owner、四結果軸、Severity／Reason、Check、SummaryおよびBatch非混在契約に適合する | Draft 2020-12 Compile／正反例／Summary・Key・Time Semantic Test | `PASSED` |
| `FW-VAL-026` | `response-field-diff.schema.json`が初回、比較完了、比較Error、IgnoreおよびChange分離契約に適合する | Draft 2020-12 Compile／正反例／Summary・Path Semantic Test | `PASSED` |
| `FW-VAL-027` | `execution-state.schema.json`がInitial FlagとPrevious Pointerの合法組合せを拒否／受理する | Draft 2020-12 Compile／正反例Contract Test | `PASSED` |
| `FW-VAL-028` | `baseline-meta.schema.json`がComplete Source Run、Source ManifestおよびInventory契約に適合する | Draft 2020-12 Compile／正反例／Inventory Identity Semantic Test | `PASSED` |
| `FW-VAL-029` | `artifact-manifest.schema.json`がCore Artifact、Self／Report除外、Mask、CompletenessおよびPublication契約に適合する | Draft 2020-12 Compile／正反例／Reference・Sort Semantic Test | `PASSED` |
| `FW-VAL-030` | `definition-bundle.schema.json`が5 Master、設計／Asset、Registry、Reference GraphおよびSeal契約に適合する | Draft 2020-12 Compile／正反例／Master Type・Edge Semantic Test | `PASSED` |
| `FW-VAL-031` | `run-meta.schema.json`がRun、Bundle、Build、Runtime、Lifecycle、四軸およびManifest Trace契約に適合する | Draft 2020-12 Compile／正反例Contract Test | `PASSED` |
| `FW-VAL-032` | `scenario-execution.schema.json`がPlan Call、Branch、Disposition、Child Resultおよび終端契約に適合する | Draft 2020-12 Compile／正反例／Call集合Semantic Test | `PASSED` |
| `FW-VAL-033` | `api-meta.schema.json`がDisposition、Call Status、Dispatch、Transport、TimingおよびArtifact存在条件に適合する | Draft 2020-12 Compile／正反例Contract Test | `PASSED` |
| `FW-VAL-034` | `batch-verification-result.schema.json`がBatch Identity、四軸集約、Scenario Sourceおよび完全Summary契約に適合する | Draft 2020-12 Compile／正反例／件数・Source Semantic Test | `PASSED` |
| `FW-VAL-035` | `scenario-summary.schema.json`がReport Set Identity、四軸、Check／API Call行およびSource Locator契約に適合する | Draft 2020-12 Compile／正反例Contract Test | `PASSED` |
| `FW-VAL-036` | `diff-report.schema.json`がEffective／Ignored表示、Change分離およびDiff Source逆引き契約に適合する | Draft 2020-12 Compile／正反例Contract Test | `PASSED` |
| `FW-VAL-037` | `evidence-index.schema.json`がAvailable／Unavailable相互排他、Manifest／Artifact SourceおよびHash索引契約に適合する | Draft 2020-12 Compile／正反例Contract Test | `PASSED` |
| `FW-VAL-038` | `daily-summary.schema.json`がBatch Result、Scenario Summary／Result SourceおよびReport集約契約に適合する | Draft 2020-12 Compile／正反例Contract Test | `PASSED` |

### 13.1 第5～7バッチ再審査記録

本表はAIによる静的・意味整合の事前確認であり、正式な人間Reviewまたは承認記録ではない。

| Finding ID | 内容 | Severity | 処置 | 状態 |
|---|---|---|---|---|
| `FW-REAUDIT-001` | Draftを根拠とする`FW-DEC-017～024`が`APPROVED`になっていた。 | HIGH | `PROPOSED`へ是正し、横断Review後に承認判定する。 | `CORRECTED` |
| `FW-REAUDIT-002` | 既存2設計書のFront Matter版数と本文版数が不一致だった。 | HIGH | 本文版数をFront Matterと改訂履歴へ一致させる。 | `CORRECTED` |
| `FW-REAUDIT-003` | `IGNORE_VALUE`を未比較として扱える記述が現行Diff契約と矛盾した。 | HIGH | 変化を記録し`effectiveChanged=false`とする契約へ統一する。 | `CORRECTED` |
| `FW-REAUDIT-004` | Definition Source読込、Bundle固定、Plan Sealの生成境界が曖昧だった。 | MEDIUM | Source Set、Validated Bundle、Sealed Planの3段階へ明確化する。 | `CORRECTED` |
| `FW-REAUDIT-005` | Reason Code例が`VERIFY_*`規則と不一致だった。 | MEDIUM | `VERIFY_VALUE_MISMATCH`へ統一する。 | `CORRECTED` |
| `FW-REAUDIT-006` | Architecture／Runtime／Verification／Security／Operationの正式横断Reviewが未実施である。 | HIGH | Review Package化後、各責任Roleが判定する。 | `OPEN` |
| `FW-REAUDIT-007` | Review基準、ExpectedおよびReportが旧3軸・4段階Verification Statusを保持し、現行四結果軸と競合していた。 | HIGH | Verificationを`NOT_EVALUATED／PASS／FAIL`、Changeを`NOT_COMPARED／UNCHANGED／CHANGED`へ統一し、Recovery軸を追加する。 | `CORRECTED` |
| `FW-REAUDIT-008` | Run進行PhaseとExecution／Recovery Statusが同一状態図で混在していた。 | HIGH | `RunPhase`を別属性として定義し、四結果軸から分離する。 | `CORRECTED` |
| `FW-REAUDIT-009` | Open Issue台帳が未定義Status `PARTIALLY_RESOLVED`を使用していた。 | MEDIUM | 定義済みStatus `WAITING`へ是正し、後続決定待ちを明記する。 | `CORRECTED` |
| `FW-REAUDIT-010` | Artifact Package完全性とExecution `COMPLETED`の関係が曖昧で、失敗Run Evidence公開またはBaseline判定を誤る余地があった。 | HIGH | 終端Outcome別Artifact完全性を独立属性とし、BaselineにはExecution `COMPLETED`を追加必須条件とする。 | `CORRECTED` |
| `FW-REAUDIT-011` | ScenarioContextの内部Lifecycleと四結果軸が`COMPLETED／FAILED／ERROR／BLOCKED`で混在していた。 | HIGH | `ContextLifecycleState`を`CREATED／LOADED／ACTIVE／SEALED／ABORTED／RELEASED`へ分離する。 | `CORRECTED` |
| `FW-REAUDIT-012` | Baseline Error処理がCanonical Execution／Verification／Recovery Statusを使用していなかった。 | HIGH | Preflight失敗を`REJECTED`、実行後失敗を`INCOMPLETE`、未評価を`NOT_EVALUATED`へ統一する。 | `CORRECTED` |
| `FW-REAUDIT-013` | ReportのAPI Call Meta PathとCall StatusがContext／Baseline設計と不一致だった。 | MEDIUM | `api-meta.json`および`SUCCEEDED`へ統一する。 | `CORRECTED` |
| `FW-REAUDIT-014` | UseCase／Scenario／API／Expected／Test／ReportのConsumerに旧3軸または4段階Verificationが残存していた。 | HIGH | 全Consumerを四結果軸へ再走査し、Verificationを`NOT_EVALUATED／PASS／FAIL`へ統一する。 | `CORRECTED` |
| `FW-REAUDIT-015` | Scenario InputおよびTest Data異常がExecution `FAILED／ERROR／BLOCKED`へ直接Mappingされていた。 | HIGH | 起動前を`REJECTED`、起動後を`INCOMPLETE`、Check未評価を`NOT_EVALUATED`とReason Codeへ分離する。 | `CORRECTED` |
| `FW-REAUDIT-016` | Change軸のCanonical Enumと`IGNORED_ONLY／COMPARE_ERROR`等の表示Categoryが一部Templateで混在していた。 | HIGH | Changeを`NOT_COMPARED／UNCHANGED／CHANGED`へ限定し、表示Categoryを別列へ分離する。 | `CORRECTED` |
| `FW-REAUDIT-017` | API Call MetaのFile名が`api-meta.json`と`api-call-meta.json`で混在していた。 | MEDIUM | Frozen Repository Tree、命名規約、ReportおよびEvidenceを`api-meta.json`へ統一する。 | `CORRECTED` |
| `FW-REAUDIT-018` | Evidence／Diff／Daily Templateに中核設計是正後も旧Result Placeholderが残っていた。 | HIGH | Evidence索引、Diff Check ReferenceおよびDaily集約を四結果軸とReport固有Statusへ分離する。 | `CORRECTED` |
| `FW-REAUDIT-019` | Execution／Verification／Evidence Consumerが凍結Runtime Treeにない`input.json`、`expected.json`および`error.json`を必須Artifactとしていた。 | HIGH | Input／Expectedを`run-meta.json`内Definition Snapshotへ統合し、Failure Metadataを`api-meta.json`へ統一した。 | `CORRECTED` |
| `FW-REAUDIT-020` | Baseline設計が別Manifest生成を要求する一方、凍結Baseline TreeにManifest Fileがなく完全性索引が不明確だった。 | HIGH | `baseline-meta.json`内Artifact InventoryとInventory Hashを正本として統一した。 | `CORRECTED` |
| `FW-REAUDIT-021` | Core Manifestを入力にReportを生成しながら、そのReportを同じManifestへ含めると循環依存になる余地があった。 | HIGH | Core Run Artifact Manifestと後生成Report Setを別の原子的公開単位へ分離した。 | `CORRECTED` |
| `FW-REAUDIT-022` | Repositoryの凍結Runtime TreeだけがAPI Call Directoryを`{apiCallId}`と記載し、現行Identity正本の`apiCallCode`と競合していた。 | HIGH | Baseline／Run双方のDirectory Keyを`{apiCallCode}`へ統一した。 | `CORRECTED` |
| `FW-REAUDIT-023` | 既存の非空Baseline／Report Directoryを一般的なAtomic Renameで直接置換できるように読め、File System／Object Storageで成立しない実装を許す余地があった。 | HIGH | Run Create-Only、Baseline／Report Versioned Set＋CAS Pointer、State単一Object CASへ公開契約を分離した。 | `CORRECTED` |
| `FW-REAUDIT-024` | Temporary／Versioned／Quarantineの物理Pathを凍結Runtime Treeへ追加するか、Evidence Referenceへ保存する余地があった。 | HIGH | Consumer可視Logical PathとAdapter内部Namespaceを分離し、物理Locatorの永続化を禁止した。 | `CORRECTED` |
| `FW-REAUDIT-025` | Platform Error Codeと四結果軸のReason Codeの引渡し境界が未定義で、Component Error CodeをResult Reasonへ直接混入させる余地があった。 | HIGH | Failure Code、Failure Record、Axis ImpactおよびReason Codeを別契約として定義した。 | `CORRECTED` |
| `FW-REAUDIT-026` | 旧Log設計の`runs/{runId}/logs/`、`error.json`相当Snapshotおよび共通Log Fileを移行すると、凍結Runtime TreeとDiagnostic分離に違反する。 | HIGH | Diagnostic／Audit／RecoveryをLogical Portへ分離し、未承認Runtime Pathの新設を禁止した。 | `CORRECTED` |
| `FW-REAUDIT-027` | 用語集がRuntime Artifact例に廃止済みのInput Copyを残し、`run-meta.json`内Definition Snapshot契約と競合していた。 | MEDIUM | Scenario Input／Expected実体を複製せずVersion／Hash／Source Revisionで追跡する表現へ是正した。 | `CORRECTED` |
| `FW-REAUDIT-028` | Review基準のEvidence観点に旧Runtime状態語`Blocked`が残り、四結果軸の終端状態と競合していた。 | MEDIUM | `REJECTED / INCOMPLETE / UNKNOWN_OUTCOME`へ置換し、Log／Exception／Recovery専用横断観点を追加した。 | `CORRECTED` |
| `FW-REAUDIT-029` | 旧Environment設計がE6論理Environment、Build EnvironmentおよびRuntime配置形態を一つのEnvironment一覧へ混在させていた。 | HIGH | Environment MasterとRuntime Deployment Profileの二軸へ分離し、Buildを非Target Environmentとした。 | `CORRECTED` |
| `FW-REAUDIT-030` | 旧Environment設計が固定Secret Directory、平文Environment VariableおよびConfig FileへCredential実値を置ける構成だった。 | CRITICAL | Reference／Provider／Handle境界、Repository／Image／CLI／Artifact非保存および最小権限へ統一した。 | `CORRECTED` |
| `FW-REAUDIT-031` | 旧Environment設計の`logs/`、`tmp/`、`secret/`およびRaw Snapshot物理PathがFrozen Runtime TreeとLogical Sink分離へ競合した。 | HIGH | Logical Root HandleとAdapter Private Namespaceだけを正本とし、未承認Directoryを追加しない。 | `CORRECTED` |
| `FW-REAUDIT-032` | 旧Scheduler設計がPID／Lock Fileと日時形式Run IDだけで重複実行を制御し、Execution Identity Lock、CASおよびFencingを満たさなかった。 | HIGH | Trigger Identity、Opaque `runId`、Execution Identity Lock、Lease／FencingおよびStorage条件を分離した。 | `CORRECTED` |
| `FW-REAUDIT-033` | 旧Health／Smoke設計が代表E6 API実行をHealth Checkへ含め、副作用または自動再送を誘発する余地があった。 | CRITICAL | Liveness／ReadinessをNo-side-effectとし、明示Read-only／Mock Smoke Testへ分離した。 | `CORRECTED` |
| `FW-REAUDIT-034` | 旧Environment監視表が`PASS / WARN / FAIL / ERROR`をRun総合結果として使用し、四結果軸と競合した。 | HIGH | Process Health、Alert Severityおよび四結果軸を分離した。 | `CORRECTED` |
| `FW-REAUDIT-035` | 「7必須Schema」が全Runtime JSONを機械検証するように読める一方、`run-meta.json`、`scenario-execution.json`および`api-meta.json`等が対象外だった。 | HIGH | 初期7 SchemaのCoverageを明示し、未対象Artifactを`FW-OI-017`としてImplementation Blockerへ分離した。 | `CORRECTED` |
| `FW-REAUDIT-036` | `apiCallCode`のKey単位一意性をJSON Schemaだけで保証できるように読めた。 | HIGH | Schemaは構造と完全一致重複を検証し、Key単位一意性をSemantic Validatorの必須責務として分離した。 | `CORRECTED` |
| `FW-REAUDIT-037` | Scenario Input設計にRun内Input Snapshotを許容する旧表現が残り、凍結Runtime TreeとDefinition Snapshot契約に競合していた。 | HIGH | `run-meta.json`内のInput Version／Hash／Source Revision追跡へ統一し、Input Runtime Copy追加を禁止した。 | `CORRECTED` |
| `FW-REAUDIT-038` | Expected／ReportのRelease BlockerがFile I/O設計を未完成／未確定とする第7バッチ以前の状態を残していた。 | MEDIUM | File I/O契約はDraft正文完成として扱い、残りSchemaおよびCoverage判断を現行Blockerへ更新した。 | `CORRECTED` |
| `FW-REAUDIT-039` | Frameworkの旧Expected Identity記述が、現行Expected正本、ExampleおよびExecution Identityに存在しない`expectedSetId`を要求していた。 | HIGH | Expected選択を`environmentId + useCaseId + scenarioId + inputSetId`へ統一し、内容改訂は`expectedVersion`で追跡する。 | `CORRECTED` |
| `FW-REAUDIT-040` | Repository移行表とUseCase Test Templateが、第7バッチ完了後もEnvironment／Runtimeを未完成として表示していた。 | MEDIUM | Framework 11文書の正文完成と正式Review待ちを分離し、移行進捗およびTest Blockerを現行状態へ同期した。 | `CORRECTED` |
| `FW-REAUDIT-041` | Baseline Metadataの旧最小例にSource Manifest、Artifact InventoryおよびInventory Hashの区別がなく、第7バッチ契約を機械化できなかった。 | HIGH | `sourceManifestHash`、対象Artifact Inventoryおよび独立`manifestHash`を`baseline-meta.schema.json`と設計本文へ統一した。 | `CORRECTED` |
| `FW-REAUDIT-042` | DiffのMask例だけが未定義`valueStorage`を使用し、`additionalProperties=false`のSchemaと競合した。 | MEDIUM | `valueStorage`を任意の安全表示方式CodeとしてSchemaへ登録し、許可Catalog照合をSemantic Validatorへ分離した。 | `CORRECTED` |
| `FW-REAUDIT-043` | Core ManifestがManifest自身または後生成ReportをEntryへ含められる余地があり、Self HashまたはReport循環依存を再発させ得た。 | HIGH | Artifact Type allowlistからManifest／Reportを除外し、SchemaとSemantic Validatorの二段階で拒否する。 | `CORRECTED` |
| `FW-REAUDIT-044` | 残り5 Schema作成前のBlocker／進捗表現が各Consumerに残り、Schema正文完成とRuntime Meta Coverage未完成を区別できなかった。 | MEDIUM | 初期7 Schema正文・機械Validation完了と、`FW-OI-017／018`および正式Review待ちを分離して同期した。 | `CORRECTED` |
| `FW-REAUDIT-045` | Verification Result旧例が共通Result契約の`resultId`、Owner、Severity、頂点Reason、Child Referenceおよび`finalizedAt`を欠き、Schemaが第6バッチ契約を弱める余地があった。 | HIGH | 共通Result項目を`verification-result.schema.json`とVerification設計へ復元し、Batch固有項目とは分離した。 | `CORRECTED` |
| `FW-REAUDIT-046` | Scenario Masterの`executionClass`をRegistry Keyまたは外部反射実行Classとして読める余地があり、Allowlist Registry契約と競合していた。 | CRITICAL | `scenarioId` Registry解決、Descriptor `implementationType`完全一致およびRegistry管理済みInstance使用へ統一した。 | `CORRECTED` |
| `FW-REAUDIT-047` | Preflight、Artifact FinalizeおよびReport FinalizeのTrace Ruleが同一失敗処理に見え、実行後Failureで元Runを`REJECTED`へ書換える余地があった。 | HIGH | 5段階GateとCommit Point別Failureを定義し、後段FailureによるSource Run四結果軸の書換えを禁止した。 | `CORRECTED` |
| `FW-REAUDIT-048` | Repository Blockerが初期7 Schema完成後も「6 Schema未作成」と表示していた。 | MEDIUM | 初期7 Schema完成とRuntime Meta／Bundle／Report等の未対象Coverageを分離して現行化した。 | `CORRECTED` |
| `FW-REAUDIT-049` | Report JSON例にReport Set IdentityとSource Result／Diff／Manifestへの安定した逆引きKeyが不足していた。 | HIGH | `generationId`とSource Locator契約を追加し、表示値・行番号・Path類似によるJoinを禁止した。 | `CORRECTED` |
| `FW-REAUDIT-050` | Batch Result旧例がBatch Result／Scenario Result Identity、Input Set、Reason、完全SummaryおよびFinalized時刻を欠き、安定したSource Traceを機械化できなかった。 | HIGH | `batch-verification-result.schema.json`と本文例へ不足項目を追加し、Scenario Result Schemaから分離した。 | `CORRECTED` |
| `FW-REAUDIT-051` | Scenario／Daily Report旧例がReport Status、Generator Version、Generated時刻またはBatch Result Sourceを欠き、Report Set公開契約と不一致だった。 | HIGH | 4 Report Schemaと本文例をReport Generation／Source Locator契約へ同期した。 | `CORRECTED` |
| `FW-REAUDIT-052` | 論理Runtime TreeにDiff Report／Evidence Index JSONが存在する一方、JSON固有構造が未定義だった。 | HIGH | `diff-report.schema.json`と`evidence-index.schema.json`を独立追加し、表示ProjectionとSource Artifactを分離した。 | `CORRECTED` |
| `FW-REAUDIT-053` | API MetaのSkip／Not Reached時にRequest／Response Artifactを持てる余地があり、未実行事実を空Artifactで偽装できた。 | CRITICAL | `api-meta.schema.json`で非実行Dispositionを`NOT_DISPATCHED`かつRequest／Response／Diff参照禁止へ制約した。 | `CORRECTED` |
| `FW-REAUDIT-054` | Schema正文完成を5段階Trace GateのRuntime実装成功と誤認する余地があった。 | HIGH | Schema Compile／Contract TestとJava Build／Runtime Publication／正式Role ReviewのStatusを分離した。 | `CORRECTED` |

### 13.2 五視点横断事前Review

本表はAIによる事前整合確認であり、`レビュー観点一覧.md`が要求する独立した責任Roleの正式Reviewまたは承認ではない。

| 視点 | 主な確認対象 | AI事前確認 | 内容指摘Critical／High未修正 | 正式Role Review |
|---|---|---|---:|---|
| Architecture | System Boundary、責務、依存方向、Phase／Result分離 | `CLEAR` | 0 | `NOT_EXECUTED` |
| Runtime | Sealed Plan、Context、Lifecycle、Timeout、Lock、Baseline | `CLEAR` | 0 | `NOT_EXECUTED` |
| Verification | Expected、Check、Diff、四軸集約、Report表示 | `CLEAR` | 0 | `NOT_EXECUTED` |
| Security | Secret非保存、保存前Mask、任意Class／Path拒否 | `CLEAR_WITH_OPEN_INPUTS` | 0 | `NOT_EXECUTED` |
| Operation | Recovery Handoff、Baseline、Audit、Retention、承認境界 | `CLEAR_WITH_OPEN_INPUTS` | 0 | `NOT_EXECUTED` |

`CLEAR_WITH_OPEN_INPUTS`は後続設計に明示的な入力が残ることを表し、正式承認を意味しない。表の0件はAI事前確認で検出した内容指摘の未修正件数であり、`FW-REAUDIT-006`の正式Role Review未実施を除外していないように見せてはならない。正式Role Reviewは右端列のとおり全視点で`NOT_EXECUTED`である。Securityの例外Raw Evidence原則とEnvironment／RuntimeのProfile境界はDraftで定義済みだが、物理暗号領域、製品、Approval Interface、Retention実値およびAccess Audit実装はSecurity／Infrastructure／Operation Reviewで確定する。

本事前Reviewは中核設計だけでなく、現行の主要Consumer、Template、Exampleおよび旧Environment移行入力まで再走査し、検出したCritical／High不整合を是正した。第7バッチ5設計書の正文とAI事前整合確認まで完了したが、Framework文書の横断Review Statusは、責任Roleによる確認と物理製品／値の決定が終わるまで`IN_PROGRESS`のままとする。

## 14. Change Control

### 14.1 Decision変更

`APPROVED` Decisionを変更する場合は次を必須とする。

```text
変更要求
→ 根拠と影響範囲
→ ConsumerおよびMigration分析
→ 代替案比較
→ Architecture Review
→ 承認
→ 関連設計・Schema・Java・Testを同一Change Setで更新
```

### 14.2 Open Issue解決

Open Issueを`RESOLVED`へ変更するときは、決定内容を`FW-DEC-*`へ登録し、確定先文書、Validationおよび影響成果物を記録する。

会話上の暫定案、Exampleまたは旧文書記載だけを根拠にOpen Issueを解決済みとしてはならない。

## 15. Review Checklist

- [ ] 確定事項と未決事項が混在していない。
- [ ] `CONFIRMED`または`APPROVED`に現行根拠がある。
- [ ] 旧Frameworkの責務を原文コピーせず現行移行先へ対応付けている。
- [ ] 5 Master以外のMasterを要求していない。
- [ ] Java Firstを外部Policyまたは式言語へ戻していない。
- [ ] ExpectedとBaselineを同一視していない。
- [ ] Verification FAILとExecution Incompleteを区別している。
- [ ] Value IgnoreとField全体無検証を同一視していない。
- [ ] Timeout時の自動Retryを既定化していない。
- [ ] Runtime物理Path、PackageまたはDeploymentを未承認のまま固定していない。
- [ ] Recovery文書を現行Reference先にしていない。
- [ ] 次工程の着手条件と完了条件が明示されている。

## 16. 現行Blocker

| Block ID | 内容 | 解除条件 |
|---|---|---|
| `FW-BLOCK-001` | 正式Business／API／UseCase／Scenarioが0件 | 実資料に基づくBusiness分析とMaster登録 |
| `FW-BLOCK-002` | Framework中核3設計のAI横断事前Reviewは重大指摘0件まで是正済みだが、責任Roleによる正式Reviewが未実施 | Architecture／Runtime／Verification／Security／Operation責任RoleのReview記録 |
| `FW-BLOCK-003` | File I/O、Environment Capabilityおよび現行16 SchemaはDraft正文・機械Validation済みだが、正式Review、Storage Adapter、Java Writer／Reader、Cross-Artifact／Publication Contract TestおよびRecovery系Schema判断が未完成 | 正式Review、Infrastructure製品選定、Java／Runtime実装および`FW-OI-018`のArchitecture判定 |
| `FW-BLOCK-004` | Runtime Profile契約はDraft化済みだが、物理Root、Storage、Lock／Fencing、Process／ContainerおよびCapacity実値が未決 | Architecture／Infrastructure／Runtime ReviewとCapability Test |
| `FW-BLOCK-005` | Timeout／Recovery／Environment論理契約はDraft化済みだが、HTTP Client、Recovery Store、Runbook、運用SLAおよび正式Reviewが未完成 | 製品選定、Operation設計、Contract Testおよび正式Review |
| `FW-BLOCK-006` | Java Source RootとPackage境界が未決 | 中核設計Reviewで承認 |

上記Blockerが存在する間、正式E6 ScenarioのRuntime実行開始またはFramework設計完了を宣言してはならない。

## 17. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 凍結済Repository構造、現行Context／Baseline／Diff／Expected／Report設計および旧Framework移行判定を統合し、現行Framework入力・決定台帳として全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | 第5バッチのシステム設計書作成を反映し、設計入力台帳とシステム設計の作成Statusを完了へ更新 | DRAFT |
| `2.0.0-draft.3` | 2026-07-27 | Identity／Result設計を反映し、`FW-OI-003/004`を決定`FW-DEC-017/018`へ移行、設計順序とValidation／Blockerを同期 | DRAFT |
| `2.0.0-draft.4` | 2026-07-27 | 共通Framework設計を反映し、Execution Plan、Port／Adapter、更新API Timeout契約を`FW-DEC-019～021`として登録、第6バッチ中核3設計の作成完了を同期 | DRAFT |
| `2.0.0-draft.5` | 2026-07-27 | Framework・業務定義連携設計を反映し、Definition Bundle、対応表のTrace View化およびJava Registry一意解決を`FW-DEC-022～024`として登録 | DRAFT |
| `2.0.0-draft.6` | 2026-07-27 | 第5～7バッチを再審査し、成果物状態を5軸へ分離、`FW-DEC-017～024`を`PROPOSED`へ是正、Open Issueと横断Validationを同期 | DRAFT |
| `2.0.0-draft.7` | 2026-07-27 | 五視点横断事前Reviewを実施し、旧結果語彙、Phase混在、Artifact完全性、Context／Baseline／Report不整合を是正して正式Review待ちを分離 | DRAFT |
| `2.0.0-draft.8` | 2026-07-27 | 横断再走査をConsumer、Template、Exampleへ拡張し、旧Verification／Execution／Change語彙、API Call Meta名およびEvidence表示契約を是正 | DRAFT |
| `2.0.0-draft.9` | 2026-07-28 | Snapshot／Evidence正文、保存前Mask、Canonical Hash、Outcome別Completeness、Core Manifest／Report非循環境界を反映し、`FW-DEC-025～027`と再審査指摘019～021を登録 | DRAFT |
| `2.0.0-draft.10` | 2026-07-28 | File I/O正文、Logical／Physical分離、Run Create-Only、Baseline／Report Versioned Set＋CAS、State条件更新、Storage Capabilityを反映し、`FW-DEC-028～031`と再審査指摘022～024を登録 | DRAFT |
| `2.0.0-draft.11` | 2026-07-28 | Log／Exception／Recovery正文、Signal分離、Failure／Reason Code、Dispatch State、Timeout／Retry／Cancellation、AuditおよびImmutable Recovery Caseを反映し、`FW-DEC-032～036`と再審査指摘025～028を登録 | DRAFT |
| `2.0.0-draft.12` | 2026-07-28 | Environment／Runtime正文、Target Environment／Runtime Profile分離、Immutable Release、External Config／Secret、Capability Gate、Deployment／Backup／DRを反映し、`FW-DEC-037～044`と再審査指摘029～034を登録 | DRAFT |
| `2.0.0-draft.13` | 2026-07-28 | 第8バッチ第1 Schema、Draft 2020-12／URN Version契約、Schema Firstの永続JSON境界、7 Schema Coverageおよび再審査指摘035～038を反映 | DRAFT |
| `2.0.0-draft.14` | 2026-07-28 | 第8バッチ第2 Schema、Expected Identity、終端Status、型付きExpected Value、Schema／Semantic境界および再審査指摘039～040を反映 | DRAFT |
| `2.0.0-draft.15` | 2026-07-28 | 第8バッチ残り5 Schemaを一括反映。Verification Result、Field Diff、Execution State、Baseline Inventory、Core Manifestの構造契約、正反例／Semantic Testおよび再審査指摘041～045を登録 | DRAFT |
| `2.0.0-draft.16` | 2026-07-28 | 第9バッチとして5段階Trace Gate、Master／Registry Binding、Runtime Trace Envelope、Report Source Locator、`FW-DEC-054～057`および再審査指摘046～049を登録 | DRAFT |
| `2.0.0-draft.17` | 2026-07-28 | 第9バッチ第2段階として追加9 Schema、`FW-DEC-058～063`、`FW-VAL-030～038`および再審査指摘050～054を登録し、`FW-OI-017／019`を正文完成・正式Review待ちへ更新 | DRAFT |
