---
title: Execution仕様書 Template
document_id: E6-API-VAL-EXECUTION-SPEC-TEMPLATE
version: 2.0.0-draft.8
status: DRAFT
document_type: Execution Specification Template
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Execution仕様書 Template

> 本Templateを複製し、実行対象の選択、実行順、運用上の停止方針および実行前Gateを定義する。  
> `<>`内のPlaceholder、説明文および不要な記入例は、Review依頼前に置換または削除する。  
> 本書はScenario詳細設計、Java Scenario Class、Scenario Input、ExpectedまたはCompare Definitionの代替ではない。

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | `<実行用途名> Execution仕様書` |
| 文書ID | `<E6-API-VAL-EXEC-NNN-SPEC>` |
| Execution Spec ID | `<EXEC-E6-NNN>` |
| 対象Environment | `<ENV-LOCAL / ENV-STAGING / ...>` |
| 実行用途 | `<DAILY_REGRESSION / RELEASE_VERIFICATION / MANUAL_INVESTIGATION>` |
| 文書種別 | Execution仕様書 |
| 版数 | `<1.0.0-draft.1>` |
| 文書状態 | `<DRAFT / REVIEW / APPROVED / FROZEN>` |
| 最終更新日 | `<YYYY-MM-DD>` |
| 作成責任 | `<Execution Design Owner>` |
| レビュー責任 | `<Runtime Lead / Test Lead / Operations Owner / Security Owner>` |
| 承認責任 | `<System Owner / Environment Owner>` |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更理由 | 影響対象 | 担当 |
|---|---|---|---|---|---|
| `<1.0.0-draft.1>` | `<YYYY-MM-DD>` | `<初版作成>` | `<新規実行用途>` | `<Scenario / Input / Operation>` | `<担当>` |

## 3. 目的

本書は、承認済みのUseCaseおよびScenarioから今回の実行対象を選択し、Environment、Input Set、実行順、並行実行、停止方針、安全条件、実行前Validationおよび必要Artifactを定義する。

本書は次の問いに回答できなければならない。

1. どのEnvironmentで、どのScenarioとInput Setを実行するか。
2. Scenario間をどの順序または並行Groupで実行するか。
3. Business `FAIL`、前提`BLOCKED`およびRuntime `ERROR`時に後続Scenarioをどう扱うか。
4. 更新系Scenarioを安全に実行するために、どの承認、Data、Cleanupが必要か。
5. 実行開始前に何を検証し、何が未成立なら起動を拒否するか。
6. 実行後にどのRun／Batch ArtifactとReportが必要か。

## 4. 適用範囲

### 4.1 対象

- Execution Spec単位の目的とEnvironment
- 実行対象UseCase、ScenarioおよびInput Setの選択
- Scenario間の実行順序または並行Group
- Batch単位の継続／停止方針
- 更新系実行の安全条件、承認およびCleanup要求
- 実行前Static／Dynamic Validation
- 必須ArtifactおよびReport要求
- 実行選択からRun／BatchへのTrace

### 4.2 対象外

| 対象外 | 正本 |
|---|---|
| Scenario内のAPI呼出順序、分岐、Skip、Mapping | Scenario詳細設計書、Java Scenario Class |
| API Method、Path、Request／Response契約 | API Master、API詳細設計書、Java DTO |
| Scenario開始値 | Scenario Input JSON |
| Scenario期待値、`resultKey` | Expected JSON、Java Check |
| Check Logic | Java `VerificationCheck` |
| `IGNORE_FIELD`／`IGNORE_VALUE` | API別／`apiCallCode`別Java `ResponseCompareDefinition` |
| Previous／Baseline Runの実値選択 | Execution State・Baseline管理 |
| URL、Credential、Token、Password | 外部Configuration、Secret Provider |
| Runtime物理Root | File I/O設計、Environment設定 |
| Scheduler製品固有設定 | 運用設計 |

## 5. 本書の責務境界

### 5.1 本書が正本とするもの

- `executionSpecId`
- Execution Specの用途と適用Environment
- 対象ScenarioおよびInput Setの選択
- Scenario間のSequence／Parallel Group
- Batch継続方針
- 更新系安全Gate
- 実行前GateとRelease Blocker
- 必須ArtifactおよびReportの要求

### 5.2 本書が正本としないもの

- Master属性の複製
- Scenario内部の処理
- Input／Expectedの実値
- Java Classの処理Logic
- Runtimeが生成する`runId`、`batchId`、時刻または結果
- Baselineの`sourceRunId`
- Diff RuleまたはCompare Policy

## 6. 参照成果物

| 分類 | ID／File | Version | 参照目的 | 解決状態 |
|---|---|---|---|---|
| Business Master | `system/02_master/Business_Master.md` | `<version>` | Business有効性 | `<VALID / BLOCKED / BROKEN>` |
| Environment Master | `system/02_master/Environment_Master.md` | `<version>` | Environment有効性 | `<status>` |
| API Master | `system/02_master/E6_API_Master.md` | `<version>` | 参照API有効性 | `<status>` |
| UseCase Master | `system/02_master/UseCase_Master.md` | `<version>` | UseCase選択 | `<status>` |
| Scenario Master | `system/02_master/Scenario_Master.md` | `<version>` | Scenario、Class、Input、Expected | `<status>` |
| Traceability View | `system/02_master/API_UseCase_Scenario対応表.md` | `<version>` | Cross-Master確認 | `<status>` |
| Repository Structure | `system/01_repository/Repository_Structure.md` | `<version>` | 配置、論理Runtime Path | `<status>` |
| Scenario Input設計 | `system/04_usecase_design/Scenario入力データ設計書.md` | `<version>` | Input契約 | `<status>` |
| Scenario Context設計 | `system/05_framework/ScenarioContext設計書.md` | `<version>` | Run分離 | `<status>` |
| Baseline設計 | `system/05_framework/ExecutionState・Baseline管理設計書.md` | `<version>` | Previous／Baseline | `<status>` |
| Verification仕様 | `<verificationSpecRef>` | `<version>` | Check Coverage | `<status>` |
| Report設計 | `system/07_report/Report設計書.md` | `<version>` | Artifact／Report | `<status>` |

必須Referenceが`BLOCKED`または`BROKEN`の場合、本書を`FROZEN`にしてはならない。

## 7. Execution基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `EXEC-P001` | Select, not redefine | 承認済みScenarioを選択し、Scenario内部を再定義しない。 |
| `EXEC-P002` | Java First | 呼出、分岐、Mapping、CheckおよびCompareはJava実装へ追跡する。 |
| `EXEC-P003` | Immutable Input | 実行開始後にInput、ExpectedまたはExecution Specを変更しない。 |
| `EXEC-P004` | Identity Separation | Environment、UseCase、Scenario、Input SetごとにRunを分離する。 |
| `EXEC-P005` | No Guess | 欠落Class、Input、ExpectedまたはBaselineを推測補完しない。 |
| `EXEC-P006` | Safe Update | 更新系はEnvironment許可、Test Data、冪等性およびCleanupを確認する。 |
| `EXEC-P007` | Axis Separation | Execution、Verification、Change、Recoveryを独立して扱う。 |
| `EXEC-P008` | Complete Evidence | 成功、失敗、中断のいずれでも取得済みEvidenceを保持する。 |
| `EXEC-P009` | No Secret | Secret実値を本書、引数、LogまたはArtifact名へ記載しない。 |
| `EXEC-P010` | Deterministic Plan | 実行対象、順序および停止条件を同じ入力から再現できる。 |

## 8. Execution概要

| 項目 | 内容 |
|---|---|
| Execution Spec ID | `<EXEC-E6-NNN>` |
| 名称 | `<日次回帰検証>` |
| 目的 | `<承認対象となる業務回帰検証を実施する>` |
| Environment ID | `<ENV-STAGING>` |
| Trigger種別 | `<SCHEDULED / MANUAL / RELEASE_GATE>` |
| 実行Owner | `<Operations Owner>` |
| 予定頻度 | `<DAILY / ON_DEMAND / RELEASE>` |
| 対象UseCase数 | `<N>` |
| 対象Scenario数 | `<N>` |
| 更新系含有 | `<Yes / No>` |
| Production Like | `<true / false>` |
| 承認Reference | `<approvalRef / NONE>` |

予定時刻やCron式は運用設計の正本を参照する。本書へScheduler製品固有設定を複製しない。

## 9. Environment選択

| 確認項目 | 設定／Reference | Gate |
|---|---|---|
| `environmentId` | `<ENV-STAGING>` | Environment Masterで`enabled=true` |
| 用途整合 | `<結合・日次検証>` | Execution用途と一致 |
| Base URL Reference | `<CONFIG:E6:STAGING:BASE_URL>` | 外部設定で解決可能 |
| Auth Profile Reference | `<AUTH:E6:STAGING>` | Secret Providerで解決可能 |
| Production Like | `<false>` | `true`時は追加承認 |
| Maintenance Window | `<operationRef>` | 更新系の場合は必須 |
| External Impact | `<READ_ONLY / CONTROLLED_UPDATE>` | Owner承認 |

本書へURL、Host、IP AddressまたはCredential実値を記載しない。

## 10. 実行対象

### 10.1 Scenario選択表

| Execution Item ID | Sequence | Parallel Group | Business ID | UseCase ID | Scenario ID | Input Set ID | 有効性 | 実行目的 |
|---|---:|---|---|---|---|---|---|---|
| `<EXI-001>` | `<10>` | `<PG-01>` | `<BUS-E6-NNN>` | `<UC-E6-NNN>` | `<SC-E6-NNN>` | `<INPUT-001>` | `<VALID / BLOCKED>` | `<目的>` |

### 10.2 選択規則

1. Business、UseCase、Scenarioおよび参照APIがすべて有効でなければならない。
2. Scenario Masterの`executionClass`、`inputRef`、`expectedRef`および`scenarioDesignRef`が解決できなければならない。
3. InputのExecution Identityが選択行と一致しなければならない。
4. ExpectedのExecution IdentityがInputと一致しなければならない。
5. `inputSetId`が異なる場合は別Runとする。
6. `enabled=false`のScenarioを一時的に実行する目的で、本書からDenyを解除してはならない。
7. 未選択Scenarioを「Coverage済み」と扱ってはならない。

## 11. Scenario間実行順序

`Sequence`はScenario間の順序を表す。Scenario内のAPI呼出順序を表してはならない。

```mermaid
flowchart TD
    A["Execution Spec検証"]
    B["Run Plan生成"]
    C["Scenario実行"]
    D["Batch集約・Report"]
    A --> B
    B --> C
    C --> D
```

| 規則 | 内容 |
|---|---|
| Sequence | 数値昇順。異なる値は原則として前Group完了後に開始する。 |
| Parallel Group | 同一Sequence内で並行実行を許可する論理Group。 |
| 未指定 | 並行を推測せず逐次実行とする。 |
| Scenario内部 | Java Scenario Classの責務であり、本表から生成しない。 |
| 同一Identity | Baseline更新競合を避けるため同時実行しない。 |

## 12. 並行実行

| 観点 | 要求 |
|---|---|
| Run Isolation | ScenarioContext、OutputおよびTemporary領域を`runId`で分離する。 |
| Baseline Lock | 同一Execution IdentityのBaseline更新を排他する。 |
| Test Data | 同一更新対象を複数Runで競合させない。 |
| HTTP制限 | Environment上限を超えない。具体値はRuntime設定を正本とする。 |
| Failure Scope | 一つのRun異常で他RunのContextを変更しない。 |
| Artifact | 異なるRunのArtifactを同一Directoryへ書かない。 |

並行数の物理上限はRuntime／Environment設定に従う。本書から上限を緩和してはならない。

## 13. Batch継続・停止方針

### 13.1 判定別方針

| 発生事象 | 対象Run | 後続Scenario | Batch結果への反映 |
|---|---|---|---|
| Verification `FAIL` | `COMPLETED`可能 | 原則継続 | `FAIL`を集約 |
| Verification `NOT_EVALUATED` | Execution／Reasonに従う | 独立Scenarioは継続可 | `NOT_EVALUATED`を集約 |
| Transport Error | Scenario設計に従う | 依存関係がある場合停止 | Evidence保持 |
| Secret／Security Error | `REJECTED`または`INCOMPLETE` | 停止 | Security Reasonを記録 |
| Artifact書込失敗 | `INCOMPLETE` | 停止または隔離 | Artifact Reasonを記録 |
| User Interrupt | `INCOMPLETE` | 新規開始停止 | 中断Reasonを記録 |

### 13.2 必須規則

- Business `FAIL`だけを理由にExecutionを`INCOMPLETE`へ変換しない。
- `FAIL`を理由に独立Scenarioを暗黙Skipしない。
- 依存Scenarioを導入する場合は、依存理由と停止範囲を本書へ明示する。
- Runtime異常後の更新API自動再実行はDefault禁止とする。明示的な安全性、Idempotency、承認済みRetry条件がすべて成立する場合だけ別設計で許可する。
- `SKIP`はStep／Scenarioの実行状態説明に使用できるが、Verification Resultへ追加してはならない。

## 14. Execution Identity

Scenario Runの比較単位は次とする。

```text
environmentId
+
useCaseId
+
scenarioId
+
inputSetId
```

Runtimeが生成するIdentityは次の責務分担とする。

| ID | 生成者 | 本書での扱い |
|---|---|---|
| `executionSpecId` | Design | 本書のStable ID |
| `batchId` | Runtime／Scheduler | 実行開始時に生成し、実値を本書へ固定しない |
| `runId` | Runtime | Scenario Runごとに生成 |
| `inputSetId` | Scenario Input | 選択表で参照 |
| `generationId` | Baseline更新処理 | 実行後に生成 |

PID、Thread IDまたは時刻だけを`runId`として使用しない。

## 15. Input解決

| 確認 | 要求 |
|---|---|
| Reference | Scenario Masterの`inputRef`から解決する。 |
| Identity | Environment、UseCase、Scenario、Input Setが選択表と一致する。 |
| Schema | Runtimeが対応する`schemaVersion`である。 |
| Immutable | Load後に変更しない。 |
| Secret | Credential実値を含まない。 |
| API Call | `apiCallCode + apiId`がScenario詳細設計と一致する。 |
| Responsibility | Inputから呼出順、分岐またはMappingを生成しない。 |

## 16. Expected解決

| 確認 | 要求 |
|---|---|
| Reference | Scenario Masterの`expectedRef`から解決する。 |
| Identity | Inputと4要素が一致する。 |
| `resultKey` | Java Check Registryと双方向一致する。 |
| Value | Scenario固有期待値だけを保持する。 |
| Prohibited | Actual、Baseline、Diff、Ignore、Class名またはScriptを含まない。 |

Expected欠落時に別Scenarioまたは前回RunのExpectedを流用してはならない。

## 17. Java実装解決

| 対象 | Reference | 必須Validation |
|---|---|---|
| Scenario Class／Registry | Scenario Master `scenarioId + executionClass` | FQCN解決、Build成功、Scenario Registry一件解決、Descriptor `implementationType`完全一致 |
| API Executor／Client | API設計 | API ID、DTO、Endpoint契約一致 |
| Request Builder | Scenario詳細設計／Java | Source、Target、型変換一致 |
| Check Registry | Verification仕様／Java | 必須`resultKey`完全一致 |
| Compare Definition | API別／Call別Java | Mode、Priority、Mask一致 |
| Report Builder | Report設計／Java | Source Result再判定なし |

Java Source RootとBase Packageが未確定の場合、存在しない仮Referenceを`PASS`にせず`BLOCKED`とする。

## 18. 実行前Gate

### 18.1 Gate順序

1. Execution Spec構造
2. Environment解決
3. 5類Master整合
4. UseCase／Scenario有効性
5. Scenario／API Call整合
6. Java Class／Registry Binding／Build解決
7. Input Schema／Identity
8. Expected Schema／Identity／`resultKey`
9. Compare Definition
10. Test Data利用可否
11. 更新系安全条件
12. Output／Lock／Capacity
13. 承認

前段Gateが失敗し後段を正しく評価できない場合、後段を`PASS`にしない。

### 18.2 Gate Matrix

| Gate ID | 確認内容 | 不成立時 | Evidence |
|---|---|---|---|
| `EXEC-G001` | Environmentが有効で設定を解決できる。 | 起動拒否 | `<reference>` |
| `EXEC-G002` | 有効Sourceが無効Targetを参照しない。 | 起動拒否 | `<trace result>` |
| `EXEC-G003` | 全Scenario ClassをBuildで解決し、`scenarioId`単位のRegistry Descriptorと完全一致する。 | 起動拒否 | `<build/registry evidence>` |
| `EXEC-G004` | Input／Expected Identityが一致する。 | 起動拒否 | `<validation result>` |
| `EXEC-G005` | 必須`resultKey`が双方向一致する。 | 起動拒否 | `<coverage result>` |
| `EXEC-G006` | 更新系DataとCleanupが準備済みである。 | 起動拒否 | `<approval/data ref>` |
| `EXEC-G007` | Secret検査に合格する。 | 起動拒否 | `<security result>` |
| `EXEC-G008` | Output、Lock、容量が利用可能である。 | 起動拒否 | `<runtime preflight>` |

## 19. 更新系安全設計

| 項目 | 内容 | Gate |
|---|---|---|
| 対象Scenario | `<SC-E6-NNN>` | 明示必須 |
| 更新対象 | `<Entity／Test Data ID>` | 一意 |
| Environment許可 | `<approvalRef>` | 必須 |
| 冪等性 | `<IDEMPOTENT / CONDITIONAL / NON_IDEMPOTENT>` | Retry方針と整合 |
| 競合防止 | `<lock/data allocation>` | 必須 |
| Cleanup／Reset | `<cleanupRef>` | 必須 |
| Timeout後確認 | `<status inquiry/operation>` | 結果不明を放置しない |
| 本番影響 | `<NONE / CONTROLLED>` | Owner承認 |

ProductionまたはProduction-like Environmentで更新系Scenarioを実行する場合、Environment OwnerとBusiness Ownerの承認Referenceを必須とする。

## 20. Retry／Timeout

1. API固有TimeoutとRetry上限はAPI設計およびRuntime設定を正本とする。
2. 本書から未承認のTimeout延長またはRetry増加を行わない。
3. 更新APIのRetryは冪等性または結果照会手段が確認済みの場合だけ許可する。
4. Retry前後のRequest、Correlation IDおよび結果を追跡可能にする。
5. Timeout後に後続Scenarioを継続するかは安全性と依存関係で決定する。
6. Retry ExhaustedをBusiness `FAIL`へ変換しない。

## 21. Baseline／Diff

- 本書は`baselineRunId`を固定しない。
- Previous／BaselineはExecution IdentityによりBaseline管理処理が解決する。
- 初回は空Objectと比較せず`NOT_COMPARED + INITIAL_EXECUTION`とする。
- Business `FAIL`でも完全RunであればBaseline更新対象になり得る。
- API Error、Parse Error、中断またはArtifact不完全時はBaselineを更新しない。
- `IGNORE_FIELD／IGNORE_VALUE`はJava Compare Definitionだけで管理する。
- Effective DiffをVerification `FAIL`へ自動変換しない。

## 22. Artifact要求

| Artifact | 論理Path | 必須 | 完了条件 |
|---|---|:---:|---|
| Batch Meta | `batches/{batchId}/batch-meta.json` | 条件付き | 複数Run時 |
| Run Meta | `runs/{runId}/run-meta.json` | Yes | Identity、Version、時刻 |
| Definition Snapshot | `runs/{runId}/run-meta.json`内 | Yes | Input／Expectedを含むBundle Version、Source Revision、Hash一致 |
| Request／Response | `runs/{runId}/api-calls/{apiCallCode}/` | 条件付き | Mask、Identity一致 |
| Field Diff | `runs/{runId}/api-calls/{apiCallCode}/response-field-diff.json` | 条件付き | 比較実施時 |
| Verification Result | `runs/{runId}/verification-result.json` | Yes | Summary整合 |
| Artifact Manifest | `runs/{runId}/artifact-manifest.json` | Yes | Outcome別必須Artifact、Mask、Schema、Hash一致 |
| Scenario Report | `runs/{runId}/reports/` | 条件付き | Source Resultと一致。Core Package公開後に別生成 |
| Daily Summary | `batches/{batchId}/reports/` | 条件付き | Batch実行時 |

Artifact Manifestの正本File名は`artifact-manifest.json`とする。`artifact-manifest.schema.json`正文・機械Validation済みだが、本TemplateだけでSchema承認、Java WriterまたはRuntime Publication完了とみなさない。

## 23. Report要求

| Report | 利用者 | 必須表示 |
|---|---|---|
| Daily Summary | Approver | Execution、Verification、Change、Recovery、Blocker |
| Scenario Summary | Business Owner／Developer | API Call、Check、Evidence |
| Diff Report | Developer | Effective／Ignored／Not Compared |
| Evidence Index | Auditor | Artifact、Hash、Relative Link |

ReportはExecution SpecまたはResultを再評価せず、確定結果を集約・表示する。

## 24. Security

- Secret実値を本書、Input、Expected、CLI ArgumentまたはLogへ保存しない。
- Environment ID、Configuration ReferenceおよびAuth Profile Referenceだけを扱う。
- Production-like実行は追加承認、最小権限および監査記録を必須とする。
- Request／Response／Diff／Reportは同一Mask定義を適用する。
- Mask失敗時に未Mask値へFallbackしない。
- OutputへのAccess OwnerとRetentionを運用設計で定義する。

## 25. 実行Flow

```mermaid
flowchart TD
    A["Static Gate"]
    B["Dynamic Preflight"]
    C["Run Plan生成"]
    D["Scenario Run"]
    E["Result・Diff・Report"]
    A --> B
    B --> C
    C --> D
    D --> E
```

Run Planは本書の選択情報とRuntime解決結果から生成する。Run PlanへScenario内部Logicを動的記述しない。

## 26. Execution結果

| 軸 | 許可Status | 意味 |
|---|---|---|
| Execution | `NOT_STARTED / RUNNING / COMPLETED / INCOMPLETE / REJECTED / UNKNOWN_OUTCOME` | Runの成立状態 |
| Verification | `NOT_EVALUATED / PASS / FAIL` | Check結果 |
| Change | `NOT_COMPARED / UNCHANGED / CHANGED` | Diff観測 |
| Recovery | `NOT_REQUIRED / REQUIRED / IN_PROGRESS / RESOLVED` | 運用介入 |

合法例：

| Execution | Verification | Change | Recovery | 説明 |
|---|---|---|---|---|
| `COMPLETED` | `PASS` | `CHANGED` | `NOT_REQUIRED` | 業務期待成立、Response変化あり |
| `COMPLETED` | `FAIL` | `UNCHANGED` | `NOT_REQUIRED` | 同じ誤りが継続 |
| `COMPLETED` | `PASS` | `NOT_COMPARED` | `NOT_REQUIRED` | 初回実行 |
| `INCOMPLETE` | `NOT_EVALUATED` | `NOT_COMPARED` | `NOT_REQUIRED` | Response取得または処理失敗 |
| `UNKNOWN_OUTCOME` | `NOT_EVALUATED` | `NOT_COMPARED` | `REQUIRED` | 更新APIの外部結果不明 |

## 27. Traceability

| Execution Item ID | Environment | UseCase | Scenario | Input | Expected | Java Class | Verification Spec | Run |
|---|---|---|---|---|---|---|---|---|
| `<EXI-001>` | `<ENV-...>` | `<UC-...>` | `<SC-...>` | `<inputRef>` | `<expectedRef>` | `<executionClass>` | `<verificationSpecRef>` | `<runtime>` |

Runtime実行後、`executionSpecId`とVersionを`run-meta.json`へ記録する。

## 28. Test観点

- [ ] 同一Execution Specから同一対象選択を再現できる。
- [ ] `enabled=false`のTargetを起動前に拒否する。
- [ ] Input／Expected／Context Identity不一致を拒否する。
- [ ] Java Class不存在またはBuild不成立を拒否する。
- [ ] 異なるInput SetのBaselineを混用しない。
- [ ] Business `FAIL`後も独立Scenarioを継続できる。
- [ ] Runtime `ERROR`時の停止範囲が方針と一致する。
- [ ] 同一Identityの並行Baseline更新を拒否する。
- [ ] 更新系Timeout時に二重更新を起こさない。
- [ ] Interrupt後に不完全RunをBaseline化しない。
- [ ] SecretをPreflight、Log、Artifactへ出力しない。
- [ ] 必須Artifact欠落をComplete扱いしない。

## 29. Static Validation

| Validation ID | 確認内容 | Level |
|---|---|---|
| `EXEC-V001` | `document_id`と`executionSpecId`が一意である。 | ERROR |
| `EXEC-V002` | Environment、UseCase、Scenarioが各Masterで解決する。 | ERROR |
| `EXEC-V003` | 有効Sourceが無効Targetを参照しない。 | ERROR |
| `EXEC-V004` | Execution Item IDとSequenceが一意である。 | ERROR |
| `EXEC-V005` | Input SetがScenario Inputで解決する。 | ERROR |
| `EXEC-V006` | Input／Expected Identityが一致する。 | ERROR |
| `EXEC-V007` | Java Class、Scenario Registry Bindingおよび必須CheckをBuildで双方向解決できる。 | BLOCKED |
| `EXEC-V008` | 更新系安全Gateがすべて成立する。 | BLOCKED |
| `EXEC-V009` | Secret実値を含まない。 | ERROR |
| `EXEC-V010` | Scenario内部LogicまたはCompare Policyを重複保持しない。 | ERROR |
| `EXEC-V011` | 必須Artifact／Report要求がReport設計と一致する。 | ERROR |
| `EXEC-V012` | Open IssueにOwnerと解決先がある。 | WARNING |

## 30. Review Checklist

### 30.1 Scope

- [ ] Execution用途とEnvironmentが明確である。
- [ ] 選択Scenarioと非選択Scenarioの理由を説明できる。
- [ ] Scenario内部を再定義していない。

### 30.2 Safety

- [ ] 更新系ScenarioのOwner、Data、冪等性およびCleanupがある。
- [ ] Production-like実行の承認がある。
- [ ] 並行実行がDataとBaselineを競合させない。

### 30.3 Runtime

- [ ] Gate順序と停止方針が明確である。
- [ ] Input、Expected、JavaおよびConfigurationを解決できる。
- [ ] Runtime物理PathまたはSecret実値をHard Codeしていない。

### 30.4 Result

- [ ] Execution／Verification／Change／Recoveryの四結果軸を分離している。
- [ ] ArtifactとReportをRun／Batchから追跡できる。
- [ ] 不完全RunをCompleteまたはBaseline対象にしない。

## 31. 完了条件

1. 全Placeholderが置換または説明付きで残置されている。
2. 全Execution Itemが有効なMaster、Input、ExpectedおよびJavaへ解決する。
3. 更新系安全Gateが承認済みである。
4. Cross-Master Validationが`PASS`である。
5. Static Validationの`ERROR`と`BLOCKED`が0件である。
6. Test仕様から本書の主要方針を検証できる。
7. Runtime、Test、OperationsおよびSecurity Reviewが完了している。

## 32. Release Blocker

次のいずれかが存在する場合、本書を`FROZEN`またはRelease対象にしてはならない。

- 有効UseCaseまたはScenarioが無効Environment／APIを参照する。
- Scenario Class、Input、Expectedまたは詳細設計が解決しない。
- Input／Expected／Context Identityが一致しない。
- 必須`resultKey`とJava Checkが双方向一致しない。
- 更新系のEnvironment許可、Test Data、冪等性またはCleanupが未確認である。
- Secret実値が成果物に含まれる。
- Artifact保存、Mask、Lockまたは容量Preflightが成立しない。
- Cross-Master Errorが未解消である。

## 33. Current Architecture適用時の既知Blocker

現行正本へ本Templateを適用する場合、少なくとも次を解消する必要がある。

| Blocker | 現状 | 必要処置 |
|---|---|---|
| 正式Business／API | 0件 | 7業務FlowとAPI分析から正式Masterを登録 |
| 正式UseCase／Scenario | 0件 | 承認済みBusiness目的とAPI経路から設計・登録 |
| Scenario実行資産 | 0件 | 詳細設計、Input、ExpectedおよびJava Classを同一Change Setで作成 |
| Java Source Root | 未確定 | Architectureで正式配置を承認 |
| 現行16 Schemaの正式Review／Java Contract Test | 未実施 | Schema正文をJava DTO／Writer／ReaderへMappingし、Cross-Artifact Testを実施 |

## 34. Open Issues

| Issue ID | 論点 | 暫定方針 | Owner／確定先 |
|---|---|---|---|
| `EXEC-ISSUE-001` | Java Source Root／Base Package | 仮Pathを正本化しない。 | Architecture |
| `EXEC-ISSUE-002` | Runtime物理Root | 論理Pathだけを使用する。 | File I/O／Environment設計 |
| `EXEC-ISSUE-003` | Artifact Manifest／Runtime MetaのJava実装 | 現行Schemaを緩和せず、Writer／Reader／Publication Contract Testを必須とする。 | File I/O／Java実装設計 |
| `EXEC-ISSUE-004` | Scheduler製品とSchedule表現 | 本書ではTrigger種別までとする。 | Operations設計 |
| `EXEC-ISSUE-005` | Parallel上限 | Environment／Runtime設定で確定する。 | Runtime／NFR設計 |

## 35. 禁止事項

- 本書へAPI呼出順序、Mapping式またはJava Logicを記載する。
- Input、Expected、BaselineまたはActual実値を複製する。
- `enabled=false`をExecution SpecでOverrideする。
- Compare Policy、YAML Ruleまたは任意Scriptを導入する。
- PID、Thread IDまたは時刻だけでRunを識別する。
- Business `FAIL`をExecution `INCOMPLETE`または`REJECTED`へ自動変換する。
- Effective DiffをVerification `FAIL`へ自動変換する。
- URL、Credential、Token、Passwordまたは個人情報を記載する。
- 未承認のJava Package、Schema、Runtime Directoryを正式契約として追加する。

## 36. Template利用手順

1. Templateを複製し、文書IDと`executionSpecId`を採番する。
2. 用途、EnvironmentおよびOwnerを確定する。
3. 承認済みScenarioとInput Setだけを選択する。
4. Scenario間Sequence、並行Groupおよび停止方針を定義する。
5. 更新系安全Gateと承認を定義する。
6. Input、Expected、Java、VerificationおよびReport Referenceを解決する。
7. Static ValidationとTest Reviewを実施する。
8. Blockerが0件になった後に承認する。

## 37. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 5類Master、Java First、Input／Expected／Baseline／Diff／Report境界に基づく全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | SC-E6-001の3 Reference作成後の状態と残存起動前Blockerを同期 | DRAFT |
| `2.0.0-draft.3` | 2026-07-27 | Scenario ContextおよびBaseline設計Referenceを`system/05_framework/`へ同期 | DRAFT |
| `2.0.0-draft.4` | 2026-07-27 | Framework横断Reviewにより四結果軸、Canonical Statusおよび更新API Retry境界へ統一 | DRAFT |
| `2.0.0-draft.5` | 2026-07-27 | 横断再走査によりResult Review Checklistを四結果軸へ同期 | DRAFT |
| `2.0.0-draft.6` | 2026-07-28 | Snapshot／Evidence設計に合わせ、Input／Expected別CopyをDefinition Snapshotへ統合し、Outcome別Artifact ManifestとReport後生成境界を反映 | DRAFT |
| `2.0.0-draft.7` | 2026-07-28 | 第9バッチとしてScenario Class／Registry Binding、Build双方向Traceおよび起動前Fail Closed Gateを追加 | DRAFT |
| `2.0.0-draft.8` | 2026-07-28 | 第9バッチ第2段階の現行16 Schema正文を反映し、Manifest／Runtime Metaの未確定表示をJava Contract Test／正式Review待ちへ更新 | DRAFT |
