---
title: API単体テスト仕様書 Template
document_id: E6-API-VAL-API-UNIT-TEST-SPEC-TEMPLATE
version: 2.0.0-draft.3
status: DRAFT
document_type: API Unit Test Specification Template
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# API単体テスト仕様書 Template

> 本Templateを複製し、1 APIの通信契約、DTO、Client、Contract CheckおよびCompare Definitionを検証するTest仕様書を作成する。  
> `<>`内のPlaceholder、説明文および不要な記入例は、Review依頼前に置換または削除する。  
> 本書はAPI設計、Test Data、Scenario Expected、Java実装または実行結果の正本ではない。

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | `<API正式名称> API単体テスト仕様書` |
| 文書ID | `<E6-API-VAL-API-NNN-UNIT-TEST-SPEC>` |
| Test Spec ID | `<TS-API-NNN>` |
| API ID | `<API-NNN>` |
| 対象Environment | `<LOCAL / ENV-STAGING / 複数の場合は一覧>` |
| 文書種別 | API単体テスト仕様書 |
| 版数 | `<1.0.0-draft.1>` |
| 文書状態 | `<DRAFT / REVIEW / APPROVED / FROZEN>` |
| 最終更新日 | `<YYYY-MM-DD>` |
| 作成責任 | `<API Test Owner>` |
| レビュー責任 | `<API Design Lead / Java Lead / Test Lead / Security Owner>` |
| 承認責任 | `<API Owner / System Owner>` |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更理由 | 影響対象 | 担当 |
|---|---|---|---|---|---|
| `<1.0.0-draft.1>` | `<YYYY-MM-DD>` | `<初版作成>` | `<API追加／契約変更>` | `<DTO / Check / Compare / Test Data>` | `<担当>` |

## 3. 目的

本書は、`<API-NNN>`について、Request、Response、HTTP Status、Error、DTO Serialization、Client処理、Contract Check、SecurityおよびResponse Compareの各契約を、再現可能なTest Caseとして定義する。

本書は次の問いに回答できなければならない。

1. API設計の各Required、Type、Length、Range、Pattern、Enum、Fixed RuleをどのTestで確認するか。
2. Null、Absent、Empty、Boundary、Unknown Fieldをどう区別するか。
3. Success、Business Error、Transport ErrorおよびParse Errorをどう検証するか。
4. Java DTO、Serializer、Client、CheckおよびCompare DefinitionをどのTest Levelで確認するか。
5. `STANDARD`、`IGNORE_FIELD`、`IGNORE_VALUE`の境界をどう検証するか。
6. Test Data、Expected Assertion、Evidenceおよび自動Test Classをどう追跡するか。

## 4. 適用範囲

### 4.1 対象

- Request Header／Path／Query／Body契約
- Success／Error Response契約
- HTTP Status、Header、Content Type
- Required、Null、Type、Length、Range、Scale、Pattern、Format、Enum、Fixed
- Arrayの0件、1件、複数、上限、順序、Keyおよび重複
- Java Request／Response DTO
- Serialization／Deserialization
- HTTP ClientのTimeout、Error MappingおよびEvidence生成
- API共通Contract Check
- API既定および`apiCallCode`固有Compare Definitionの単体検証
- Sensitive DataのMask

### 4.2 対象外

| 対象外 | 正本／別Test |
|---|---|
| 複数APIの呼出順序、分岐、Mapping | Scenario詳細設計、UseCaseテスト仕様 |
| Scenario固有Input | Scenario Input、Test Data |
| Scenario固有Expected値 | Expected JSON、UseCaseテスト仕様 |
| 業務状態遷移 | Java Business Check、UseCaseテスト仕様 |
| Previous／Baseline選定 | Baseline管理設計、UseCaseテスト |
| Batch実行選択 | Execution仕様書 |
| E6 Provider内部実装の全Unit Test | Provider側Test |
| Performance／Load Test | 非機能Test計画 |

## 5. 本書の責務境界

### 5.1 本書が正本とするもの

- API単体Test Scope
- Test Case IDとCoverage
- Test Level、前提、操作、期待観測および判定基準
- API設計RuleからTestへのTrace
- Test Data、Java Test ClassおよびEvidenceへのReference
- API単体TestのRelease Gate

### 5.2 本書が正本としないもの

- API契約値そのもの
- 大量のTest Data実値
- Scenario Expected JSON
- Java Production／Test Code
- RuntimeのCheck ResultまたはDiff Result
- Compare Policy File
- Secret、Credentialまたは実個人情報

## 6. 参照成果物

| 分類 | ID／File | Version | 参照目的 | 解決状態 |
|---|---|---|---|---|
| API Master | `system/02_master/E6_API_Master.md` | `<version>` | API ID、Method、Path、DTO | `<VALID / BLOCKED / BROKEN>` |
| API詳細設計 | `system/03_api_design/API-<NNN>設計書.md` | `<version>` | Request／Response／Error契約 | `<status>` |
| Verification仕様 | `<verificationSpecRef>` | `<version>` | Contract Check Coverage | `<status>` |
| Expected設計 | `system/06_verification_assets/検証結果・Expected設計書.md` | `<version>` | `resultKey`／Result契約 | `<status>` |
| Diff設計 | `system/06_verification_assets/APIレスポンスDiff設計書.md` | `<version>` | Compare結果契約 | `<status>` |
| Test Data設計 | `system/06_verification_assets/test_data/TestData設計書.md` | `<version>` | Test Data契約 | `<status>` |
| Java DTO | `<requestDto / responseDto classRef>` | `<build>` | 型／Serialization | `<status>` |
| Java Client | `<clientClassRef>` | `<build>` | HTTP実行 | `<status>` |
| Java Check | `<checkClassRef>` | `<build>` | Contract Check | `<status>` |
| Compare Definition | `<compareDefinitionRef>` | `<build>` | Diff Mode | `<status>` |

API詳細設計またはJava Referenceが未解決の場合、本書を`FROZEN`にしない。

## 7. Test基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `API-TST-P001` | Design Derived | TestはAPI詳細設計の契約から導出する。 |
| `API-TST-P002` | One Rule, Observable Proof | 各契約Ruleを少なくとも一つの観測可能なTestへ追跡する。 |
| `API-TST-P003` | Absent ≠ Null ≠ Empty | 欠落、Null、空文字、空配列を区別する。 |
| `API-TST-P004` | Boundary Pair | 境界値は直前、境界、直後を必要に応じて確認する。 |
| `API-TST-P005` | Java First | CheckおよびCompareの振る舞いをJava Testで確定する。 |
| `API-TST-P006` | Ignore非免責 | Diff Ignoreでも契約Checkを実行する。 |
| `API-TST-P007` | Deterministic Data | Test Dataを再現可能かつ他Testから分離する。 |
| `API-TST-P008` | No Secret | Secretおよび実個人情報をTest Spec／Data／Logに保存しない。 |
| `API-TST-P009` | Result Separation | Test実行結果とPlatform Verification Resultを混同しない。 |
| `API-TST-P010` | No Provider Guess | Provider未確認挙動を期待値として推測しない。 |

## 8. 対象API概要

| 項目 | 内容 |
|---|---|
| API ID | `<API-NNN>` |
| API名称 | `<正式名称>` |
| Method | `<POST>` |
| Endpoint Path | `</api/...>` |
| Request DTO | `<RequestDto>` |
| Response DTO | `<ResponseDto>` |
| 業務データ更新 | `<READ_ONLY / CREATE / UPDATE / DELETE>` |
| 冪等性 | `<IDEMPOTENT / CONDITIONAL / NON_IDEMPOTENT>` |
| Sensitive Data | `<Yes / No>` |
| API Master有効性 | `<enabled=true/false>` |

## 9. Test Level

| Test Level | 対象 | 外部接続 | 主な目的 |
|---|---|---|---|
| `JAVA_UNIT` | Validator、Builder、Check、Compare | なし | Logicと境界 |
| `SERIALIZATION` | DTO、JSON Mapper | なし | JSON名、型、Null、Unknown Field |
| `CLIENT_COMPONENT` | HTTP Client＋Mock Server | Mock | Method、Path、Header、Status、Timeout |
| `ENVIRONMENT_CONTRACT` | 実Environment API | あり | Providerとの実契約一致 |

`ENVIRONMENT_CONTRACT`はEnvironment Ownerの許可と隔離Test Dataを必要とする。

## 10. Test Case共通属性

| 属性 | 必須 | 内容 |
|---|:---:|---|
| `testCaseId` | Yes | `TC-API-{NNN}-{NNN}`形式のStable ID |
| `testLevel` | Yes | 9章のTest Level |
| `ruleRef` | Yes | API設計Field／Rule／Section Reference |
| `category` | Yes | Request、Response、Error、DTO、Client、Compare、Security |
| `precondition` | Yes | 実行前提 |
| `testDataRef` | Yes | 外部Test DataまたはFactory Reference |
| `operation` | Yes | 実行操作 |
| `expectedObservation` | Yes | 観測可能な期待 |
| `evidence` | Yes | Assertion、Response、LogまたはArtifact |
| `automationRef` | Yes | Java Test Class／Method Reference |
| `readiness` | Yes | `READY / BLOCKED` |

`readiness`はTest Caseの準備状態であり、Verification Resultではない。

## 11. Test Case一覧

| Test Case ID | Level | Category | Rule Ref | Test概要 | Test Data Ref | Expected Observation | Automation Ref | Readiness |
|---|---|---|---|---|---|---|---|---|
| `<TC-API-NNN-001>` | `<JAVA_UNIT>` | `<REQUEST>` | `<API-DES-...>` | `<必須項目欠落>` | `<TD-...>` | `<Validation Error>` | `<Class#method>` | `<READY / BLOCKED>` |

Test Case IDを行番号として扱わない。並び替え後もIDを維持する。

## 12. Request Header／Parameter Test

| Test Case ID | 対象 | 条件 | 入力区分 | Expected | Rule Ref |
|---|---|---|---|---|---|
| `<TC-...>` | `<Authorization>` | `<欠落>` | `<Absent>` | `<起動前拒否／HTTP Error>` | `<reference>` |
| `<TC-...>` | `<Path Parameter>` | `<不正Format>` | `<Invalid>` | `<Validation Error>` | `<reference>` |
| `<TC-...>` | `<Query Parameter>` | `<Unknown>` | `<Additional>` | `<仕様どおり拒否／許容>` | `<reference>` |

Authorizationの実値を表へ記載しない。Auth Profile ReferenceまたはMock Tokenを使用する。

## 13. Request Body Test

### 13.1 観点Matrix

| 観点 | Positive | Negative | 適用条件 |
|---|---|---|---|
| Required | 値あり | Absent | 必須項目 |
| Nullability | 非Null | Null | Null契約あり |
| String Length | Min、Max | Min未満、Max超過 | 長さ制約 |
| Number Range | Min、Max | Min未満、Max超過 | 数値範囲 |
| Decimal | 許可桁／Scale | 桁／Scale超過 | Decimal |
| Pattern／Format | 合法値 | 不正値 | Patternあり |
| Enum | 全許可値または代表値 | 未知値、大小文字差 | Enum |
| Fixed | 固定値 | 別値 | 固定項目 |
| Unknown Field | なし | 追加 | Unknown Field契約 |
| Nested Object | 完全 | Object欠落／部分欠落 | Object |
| Array | 0／1／複数／上限 | 上限超過／重複 | Array |

### 13.2 Request Test Case

| Test Case ID | JSON Path | 観点 | Input | Expected Observation | Test Data Ref | Automation Ref |
|---|---|---|---|---|---|---|
| `<TC-...>` | `<$.memberId>` | `<Required>` | `<Absent>` | `<Validation Error Code>` | `<TD-...>` | `<Class#method>` |

入力値そのものはTest Dataへ配置し、本表には意図とReferenceを記載する。

## 14. Request生成／Serialization Test

| Test Case ID | 対象 | 確認内容 | Expected |
|---|---|---|---|
| `<TC-...>` | Request DTO | Java FieldとJSON Propertyが一致する。 | 期待JSONと一致 |
| `<TC-...>` | Null | Null Propertyの送信／省略が設計どおりである。 | 契約どおり |
| `<TC-...>` | Date／Time | Format、Zone、Precisionが一致する。 | 契約どおり |
| `<TC-...>` | Decimal | PrecisionとScaleを失わない。 | 値一致 |
| `<TC-...>` | Enum | 外部値とJava Enum Mappingが一致する。 | Mapping一致 |
| `<TC-...>` | Unknown Field | 設計どおり拒否または無視する。 | Error／Success |

## 15. Success Response Test

### 15.1 HTTP／Header

| Test Case ID | 観点 | Response条件 | Expected |
|---|---|---|---|
| `<TC-...>` | HTTP Status | 正常Response | `<200>` |
| `<TC-...>` | Content-Type | JSON Response | `<application/json>` |
| `<TC-...>` | Correlation ID | Headerあり／なし | `<契約どおり>` |
| `<TC-...>` | Charset | Multi-byte値 | `<UTF-8保持>` |

### 15.2 Response Body

| Test Case ID | JSON Path | 観点 | Response Fixture | Expected Observation | Rule Ref |
|---|---|---|---|---|---|
| `<TC-...>` | `<$.memberId>` | `<Required／Type>` | `<fixtureRef>` | `<PASS／Contract Error>` | `<reference>` |

Response TestはProvider Responseの契約確認とJava Deserializationの確認を区別して記録する。

## 16. Array／Collection Test

| Test Case ID | 条件 | Expected |
|---|---|---|
| `<TC-...>` | 0件 | 空配列、NullまたはField欠落の契約どおり |
| `<TC-...>` | 1件 | 1要素を正しくDeserialization |
| `<TC-...>` | 複数件 | 全要素、順序、Keyを保持 |
| `<TC-...>` | 上限件数 | 完全取得またはPaging契約どおり |
| `<TC-...>` | 重複Key | 設計どおり拒否／保持 |
| `<TC-...>` | 順序変化 | Ordered／Unordered契約どおり |
| `<TC-...>` | 要素内Field欠落 | Element単位Contract Error |

## 17. Error Response Test

| Test Case ID | Error種別 | Trigger | Expected HTTP | Expected Schema／Code | Retry可否 |
|---|---|---|---:|---|---|
| `<TC-...>` | `<VALIDATION>` | `<必須欠落>` | `<400>` | `<errorCode>` | `No` |
| `<TC-...>` | `<AUTHENTICATION>` | `<無効Mock Token>` | `<401>` | `<schema>` | `No` |
| `<TC-...>` | `<BUSINESS>` | `<対象不存在>` | `<status>` | `<businessCode>` | `<No>` |
| `<TC-...>` | `<SERVER>` | `<Mock 500>` | `500` | `<schema／body none>` | `<Policyに従う>` |

業務エラーResponseをTransport Errorとして処理しない。

## 18. HTTP Client／Transport Test

| Test Case ID | 条件 | Client期待動作 | Evidence |
|---|---|---|---|
| `<TC-...>` | Connect Timeout | 規定Error CodeへMapping | Exception Type、Mask済Log |
| `<TC-...>` | Read Timeout | Retry方針と冪等性に従う | Attempt、Correlation |
| `<TC-...>` | DNS／Connection Error | Transport Errorとして記録 | Error Code |
| `<TC-...>` | Invalid JSON | Parse Error、Response Artifact保持 | Mask済Body／Hash |
| `<TC-...>` | Empty Body | Status別契約に従う | Status、Header |
| `<TC-...>` | Oversize Response | 上限超過Error、安全に中断 | Size、Error Code |

## 19. Contract Check Test

| Test Case ID | `resultKey`／Rule | Fixture | Expected Verification Status | Expected Reason Code | 備考 |
|---|---|---|---|---|---|
| `<TC-...>` | `<API契約Rule／resultKey>` | `<valid fixture>` | `PASS` | `NONE` | 正常 |
| `<TC-...>` | `<Required>` | `<field absent>` | `FAIL` | `<VERIFY_REQUIRED_MISSING>` | 評価可能な不一致 |
| `<TC-...>` | `<DTO type mismatch>` | `<invalid fixture>` | `NOT_EVALUATED` | `<RESPONSE_PARSE_ERROR>` | Executionは`INCOMPLETE` |
| `<TC-...>` | `<前提Responseなし>` | `<transport error>` | `NOT_EVALUATED` | `<TRANSPORT_ERROR>` | Execution／Recoveryに従う |

Contract CheckのStatusは`NOT_EVALUATED／PASS／FAIL`だけを使用する。前提不足または実装異常はReason CodeおよびExecution／Recovery Statusで区別する。

## 20. Compare Definition Test

### 20.1 Mode別期待

| Mode | Change Type | Expected Effective | Expected Ignored |
|---|---|:---:|:---:|
| `STANDARD` | Added／Removed／Type／Value | Yes | No |
| `IGNORE_FIELD` | Added／Removed／Type／Value | No | Yes |
| `IGNORE_VALUE` | Value、同一Type | No | Yes |
| `IGNORE_VALUE` | Added／Removed／Type | Yes | No |

### 20.2 Test Case

| Test Case ID | Java Definition Ref | JSON Path | Mode | Previous | Current | Expected Change／Ignored |
|---|---|---|---|---|---|---|
| `<TC-...>` | `<CompareDefinition>` | `<$.updatedAt>` | `IGNORE_VALUE` | `<fixtureRef>` | `<fixtureRef>` | `<VALUE_CHANGED / true>` |

Previous／Currentの実値はFixtureへ分離する。Sensitive値はMask済みまたは架空値を使用する。

### 20.3 必須境界

- [ ] `IGNORE_FIELD`でAdded／Removed／Type／Valueの全種を確認する。
- [ ] `IGNORE_VALUE`で同一型Value ChangeだけがIgnoredになる。
- [ ] `IGNORE_VALUE`でAdded／Removed／Type ChangeがEffectiveになる。
- [ ] 未定義Pathは`STANDARD`となる。
- [ ] API既定と`apiCallCode`固有Overrideの優先順位を確認する。
- [ ] Ignored Diffも明細へ保存される。
- [ ] Ignore対象でもRequired／Type／Fixed Checkが実行される。

## 21. Security／Mask Test

| Test Case ID | 対象 | 条件 | Expected |
|---|---|---|---|
| `<TC-...>` | Request Log | Authorizationあり | Token非表示 |
| `<TC-...>` | Response Artifact | 個人情報あり | 指定Mask |
| `<TC-...>` | Diff | Sensitive値変化 | Previous／CurrentともMask |
| `<TC-...>` | Exception | Parse Error | Raw Body全量をMessageへ含めない |
| `<TC-...>` | Mask失敗 | Mask処理Error | 未Mask値へFallbackしない |

## 22. Test Data

### 22.1 Data分類

| Data区分 | 用途 | 管理方法 |
|---|---|---|
| Valid | 正常／境界内 | Test Data Reference |
| Invalid | 必須欠落、型、範囲外 | Factory／Fixture |
| Response Fixture | Success／Error／Invalid JSON | Resource Reference |
| Compare Pair | Previous／Current組 | Fixture Pair |
| Environment Data | 実API Contract Test | Data Owner承認 |

### 22.2 規則

- 本書へ大量のData値を複製しない。
- Test Data ID、生成規則および期待用途をReferenceする。
- Date、UUID等の可変値はClock／Generatorを固定する。
- Test間でMutable Fixtureを共有しない。
- 更新系DataはTest Caseごとに分離し、Cleanupを持つ。
- 実個人情報を使用しない。

## 23. 更新系API Test

| 観点 | 必須内容 |
|---|---|
| Data Isolation | Test専用Entityまたは一意Key |
| Precondition | 更新前状態 |
| Idempotency | 同一Request再送結果 |
| Timeout | 結果不明時の照会方法 |
| Retry | 二重更新防止 |
| Cleanup | 更新後Reset／削除 |
| Parallel | 同一Entity競合 |
| Approval | Environment／Data Owner |

Environment許可またはCleanup未確認時は、実API Testを`BLOCKED`とする。

## 24. Automation設計

| Test Case ID | Test Class | Method／Dynamic Source | Level | 実行Profile |
|---|---|---|---|---|
| `<TC-...>` | `<MemberSearchContractTest>` | `<methodRef>` | `<JAVA_UNIT>` | `<unit>` |

Java Source RootおよびBase Packageが未確定の場合、仮Pathを確定値として記載しない。Class名候補は`BLOCKED`とする。

## 25. Test実行結果

Test FrameworkのCase結果は次を使用する。

| Status | 意味 |
|---|---|
| `PASS` | Test Assertion成立 |
| `FAIL` | Test Assertion不成立 |
| `BLOCKED` | 前提、Data、Environmentまたは実装未成立 |
| `ERROR` | Test Infrastructure、Fixture、Runtime異常 |

`SKIP`を最終品質結果として集約しない。条件不成立で未実行の場合は、理由を持つ`BLOCKED`または別のExecution記録として扱う。

## 26. Evidence

| Level | 必須Evidence |
|---|---|
| `JAVA_UNIT` | Test Case ID、Class、Method、Build、Assertion結果 |
| `SERIALIZATION` | Input Fixture、Serialized／Deserialized結果、Assertion |
| `CLIENT_COMPONENT` | Mock Expectation、Request、Response、Client結果 |
| `ENVIRONMENT_CONTRACT` | Environment、Correlation、Mask済Request／Response、時刻 |

EvidenceからSecretと実個人情報を除去する。失敗時も取得済みEvidenceを保持する。

## 27. Coverage Matrix

| API Design Ref | Rule種別 | Positive Test | Negative Test | Boundary Test | Automation | Coverage |
|---|---|---|---|---|---|---|
| `<reference>` | `<Required>` | `<TC-...>` | `<TC-...>` | `<N/A>` | `<Class>` | `<COVERED / GAP / BLOCKED>` |

`N/A`には理由を記載する。件数が多いことだけでCoverage成立としない。

## 28. Traceability

```text
API Analysis
→ API Master
→ API Detail Design Rule
→ API Unit Test Case
→ Test Data
→ Java Test
→ Test Result／Evidence
```

| Test Case ID | API ID | Design Rule | resultKey／Compare Ref | Test Data | Java Test | Evidence |
|---|---|---|---|---|---|---|
| `<TC-...>` | `<API-NNN>` | `<ruleRef>` | `<resultKey / NONE>` | `<dataRef>` | `<automationRef>` | `<evidenceRef>` |

## 29. Entry Criteria

- API Master Recordが存在し、対象属性が確認済みである。
- API詳細設計のRequest／Response／Error契約がReview可能である。
- DTO、Client、CheckおよびCompare Definitionの対象版が特定できる。
- Test DataまたはFixture生成方法が準備済みである。
- Environment Contract Testの場合、接続、認証およびData利用が承認済みである。

## 30. Exit Criteria

1. 必須契約RuleのCoverageが`COVERED`である。
2. Critical／High Testがすべて実行済みである。
3. `FAIL`、`ERROR`および未説明`BLOCKED`が0件である。
4. DTO、Client、CheckおよびCompare Definition Testが合格している。
5. Security／Mask Testが合格している。
6. Test結果からDesign Ruleへ逆Traceできる。
7. 未実施TestにOwner、理由および実施条件がある。

## 31. Static Validation

| Validation ID | 確認内容 | Level |
|---|---|---|
| `API-TST-V001` | 文書ID、Test Spec ID、Test Case IDが一意である。 | ERROR |
| `API-TST-V002` | API IDがAPI Masterで解決する。 | ERROR |
| `API-TST-V003` | API詳細設計Referenceが存在する。 | ERROR |
| `API-TST-V004` | 全Test CaseにRule RefとExpected Observationがある。 | ERROR |
| `API-TST-V005` | Test DataとAutomation Referenceが解決する。 | BLOCKED |
| `API-TST-V006` | 必須Contract Ruleに未説明Gapがない。 | ERROR |
| `API-TST-V007` | Compare Testが3 Modeの境界を満たす。 | ERROR |
| `API-TST-V008` | Ignore対象のContract Checkを除外していない。 | ERROR |
| `API-TST-V009` | Secret／実個人情報を含まない。 | ERROR |
| `API-TST-V010` | Scenario呼出順、MappingまたはExpectedを正本化しない。 | ERROR |

## 32. Review Checklist

### 32.1 Contract

- [ ] Request／Response／Error契約を網羅する。
- [ ] Required、Null、Absent、Emptyを区別する。
- [ ] BoundaryとNegative Testが設計Ruleから導出される。
- [ ] ArrayとUnknown Fieldの扱いがある。

### 32.2 Java

- [ ] DTO、Serializer、Client、Check、Compareを対象とする。
- [ ] Test CaseからJava Testへ追跡できる。
- [ ] Mockと実Environment Testを区別する。

### 32.3 Diff／Security

- [ ] Compare 3 ModeとOverride優先順位を確認する。
- [ ] IgnoreがContract Checkを免責しない。
- [ ] Request、Response、Diff、ExceptionのMaskを確認する。

### 32.4 Operation

- [ ] 更新系Dataが隔離されCleanup可能である。
- [ ] Environment Contract Testに承認がある。
- [ ] Test Evidenceが再現可能である。

## 33. Release Blocker

- API詳細設計が未完成またはAPI Masterと不一致である。
- `enabled=false`のAPIを有効APIとして実Environment Testする。
- DTO、Client、CheckまたはCompare Definitionが解決しない。
- 必須契約RuleにCoverage Gapがある。
- 更新系Test Data、冪等性、Timeout後確認またはCleanupが未確認である。
- Security／Mask Testが未実施または失敗している。
- Secretまたは実個人情報がTest Artifactに含まれる。
- Critical／High Testに未説明の`BLOCKED`がある。

## 34. Current Architecture適用時の既知Blocker

| Blocker | 現状 | 必要処置 |
|---|---|---|
| 正式API登録 | 0件 | 正式API分析書からAPI MasterとAPI詳細設計を作成 |
| API契約 | 未登録 | Endpoint、DTO、Error、SecurityおよびOwner Reviewを確定 |
| Java Source Root | 未確定 | 正式配置承認後にAutomation Reference確定 |
| Compare Definition実体 | Java Reference未解決 | API別／Call別Classを実装しBuild確認 |
| TestData設計 | 設計本文あり、正式Data 0件 | 正式Test Case確定後にDataを作成・承認 |

## 35. Open Issues

| Issue ID | 論点 | 暫定方針 | Owner／確定先 |
|---|---|---|---|
| `API-TST-ISSUE-001` | Java Test Package／Method命名 | 仮Pathを正本化しない。 | Coding Standard |
| `API-TST-ISSUE-002` | Test Result物理配置 | 論理Evidence Referenceだけを記載する。 | File I/O／Test設計 |
| `API-TST-ISSUE-003` | Coverage閾値 | Critical Rule完全Coverageを必須とし、数値は別途決定する。 | Test Strategy |
| `API-TST-ISSUE-004` | Provider契約Testの実行頻度 | 本書ではLevelまでとする。 | Operations |

## 36. 禁止事項

- API詳細設計の契約値を無根拠に変更する。
- Scenario呼出順、Mapping、Business Transitionを本書の正本とする。
- Scenario Expected JSONをAPI単体Testの期待値として流用する。
- Compare Ruleを外部YAML／Policyへ移す。
- Ignore対象FieldのRequired／Type／Fixed Testを省略する。
- `SKIP`、`WARN`または`IGNORED`をVerification Resultへ追加する。
- 大量のTest Data、Secretまたは実個人情報を本文へ記載する。
- Mock TestだけでProvider実契約確認済みと表示する。

## 37. Template利用手順

1. API MasterとAPI詳細設計を確定する。
2. Test Spec IDとTest Case IDを採番する。
3. Field／Rule Inventoryを作成する。
4. Positive、Negative、BoundaryおよびError Caseを展開する。
5. DTO、Client、Check、CompareおよびSecurity Testを追加する。
6. Test DataとJava Automationへ接続する。
7. Coverage MatrixとStatic Validationを実施する。
8. Release Blockerが0件になった後に承認する。

## 38. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | Current API契約、Java First、Compare DefinitionおよびSecurity境界に基づく全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | Framework横断ReviewによりContract Check StatusをCanonical Verification軸へ統一 | DRAFT |
| `2.0.0-draft.3` | 2026-07-27 | 横断再走査によりContract Check例の`ERROR／BLOCKED`を`NOT_EVALUATED`とReason Codeへ分離 | DRAFT |
