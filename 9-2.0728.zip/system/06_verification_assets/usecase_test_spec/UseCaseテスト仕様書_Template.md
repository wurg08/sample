---
title: UseCaseテスト仕様書 Template
document_id: E6-API-VAL-USECASE-TEST-SPEC-TEMPLATE
version: 2.0.0-draft.9
status: DRAFT
document_type: UseCase Test Specification Template
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# UseCaseテスト仕様書 Template

> 本Templateを複製し、1 UseCaseに属するScenario経路、Context、Mapping、分岐、業務Check、BaselineおよびRun Isolationを検証するTest仕様書を作成する。  
> `<>`内のPlaceholder、説明文および不要な記入例は、Review依頼前に置換または削除する。  
> 本書はUseCase／Scenario設計、Scenario Input、Expected、Java実装、Baselineまたは実行結果の正本ではない。

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | `<UseCase正式名称> UseCaseテスト仕様書` |
| 文書ID | `<E6-API-VAL-UC-E6-NNN-TEST-SPEC>` |
| Test Spec ID | `<TS-UC-E6-NNN>` |
| UseCase ID | `<UC-E6-NNN>` |
| 対象Environment | `<ENV-LOCAL / ENV-STAGING / ...>` |
| 文書種別 | UseCaseテスト仕様書 |
| 版数 | `<1.0.0-draft.1>` |
| 文書状態 | `<DRAFT / REVIEW / APPROVED / FROZEN>` |
| 最終更新日 | `<YYYY-MM-DD>` |
| 作成責任 | `<UseCase Test Owner>` |
| レビュー責任 | `<Business Owner / Scenario Lead / Runtime Lead / Test Lead / Operations Owner>` |
| 承認責任 | `<System Owner>` |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更理由 | 影響対象 | 担当 |
|---|---|---|---|---|---|
| `<1.0.0-draft.1>` | `<YYYY-MM-DD>` | `<初版作成>` | `<UseCase／Scenario追加>` | `<Input / Expected / Java / Baseline>` | `<担当>` |

## 3. 目的

本書は、`<UC-E6-NNN>`の業務目的が、各Scenarioの開始条件、API経路、Mapping、分岐、停止、Context、Expected、Business Check、DiffおよびArtifactを通じて成立することを、再現可能なTest Caseとして定義する。

本書は次の問いに回答できなければならない。

1. UseCaseの正常、代替、異常、BoundaryおよびTimeout経路をどのScenarioで確認するか。
2. 各ScenarioでAPI呼出順序、条件、Mapping、Skip、Stopおよび終了状態をどう観測するか。
3. Input、Expected、Java Checkおよび`resultKey`の整合性をどう確認するか。
4. Execution、Verification、Change、Recoveryの四軸をどの期待組合せで確認するか。
5. 初回、Baselineあり、Ignored Diff、Compare Errorおよび不完全Runをどう確認するか。
6. 並行実行、更新系副作用、Crash RecoveryおよびArtifact完全性をどう確認するか。

## 4. 適用範囲

### 4.1 対象

- UseCase業務目的とScenario Coverage
- Scenario入口、終了状態および経路
- API呼出順序、条件、Skip、Stop、ContinueおよびRetry
- `apiCallCode`単位のRequest／Response
- 前段Responseから後続RequestへのMapping
- ScenarioContext、ApiExchangeおよびRun Isolation
- Scenario Input／Expected／Java Checkの整合
- Business Value、Cross-API、State Transition Check
- Previous／Baseline／Response Diff
- Execution／Verification／Change／Recoveryの四結果軸
- 更新系副作用、Cleanup、Timeout後確認
- Artifact、ReportおよびTraceability

### 4.2 対象外

| 対象外 | 正本／別Test |
|---|---|
| API Field単位の全Boundary | API単体テスト仕様 |
| API Provider内部Logic | Provider側Test |
| Load／Stress／Long Run | 非機能Test計画 |
| Scheduler製品固有設定 | 運用設計 |
| URL／Credential実値 | 外部Configuration／Secret Provider |
| Scenario外の業務全Flow | 現行業務分析 |

## 5. 本書の責務境界

### 5.1 本書が正本とするもの

- UseCase Test Scope
- Scenario／Test Case Coverage
- Test Caseの前提、操作、期待観測、判定およびEvidence
- UseCase／Scenario RequirementからTestへのTrace
- Test Data、Expected、Java TestおよびRun EvidenceへのReference
- UseCase TestのEntry／Exit CriteriaとRelease Gate

### 5.2 本書が正本としないもの

- UseCase／Scenarioの業務仕様
- Scenario内API呼出定義
- Input／Expected実値
- Mapping／Branch／Check／Compare Logic
- Previous／Baseline実値
- Runtime結果またはReport
- Secretまたは実個人情報

## 6. 参照成果物

| 分類 | ID／File | Version | 参照目的 | 解決状態 |
|---|---|---|---|---|
| Business Analysis | `<businessAnalysisRef>` | `<version>` | 業務Flow | `<VALID / BLOCKED / BROKEN>` |
| 5類Master | `system/02_master/` | `<version>` | ID、有効性、Reference | `<status>` |
| Traceability View | `system/02_master/API_UseCase_Scenario対応表.md` | `<version>` | API Call関係 | `<status>` |
| UseCase設計 | `system/04_usecase_design/UC-<system>-<NNN>設計書.md` | `<version>` | 業務目的、Coverage | `<status>` |
| Scenario設計 | `system/04_usecase_design/scenario/SC-<system>-<NNN>設計書.md` | `<version>` | 呼出、分岐、Mapping | `<status>` |
| Scenario Input | `system/04_usecase_design/input/<scenarioId>-input.json` | `<version/hash>` | 実行初期値 | `<status>` |
| Expected | `system/04_usecase_design/expected/<scenarioId>-expected.json` | `<version/hash>` | 期待値 | `<status>` |
| Scenario Context設計 | `system/05_framework/ScenarioContext設計書.md` | `<version>` | Context／Isolation | `<status>` |
| Baseline設計 | `system/05_framework/ExecutionState・Baseline管理設計書.md` | `<version>` | Previous／Baseline | `<status>` |
| Verification仕様 | `<verificationSpecRef>` | `<version>` | Check Coverage | `<status>` |
| Diff設計 | `system/06_verification_assets/APIレスポンスDiff設計書.md` | `<version>` | Change観測 | `<status>` |
| Execution仕様 | `<executionSpecRef>` | `<version>` | 実行選択、停止方針 | `<status>` |
| Test Data設計 | `system/06_verification_assets/test_data/TestData設計書.md` | `<version>` | Test Data | `<status>` |
| Report設計 | `system/07_report/Report設計書.md` | `<version>` | Report／Evidence | `<status>` |

## 7. Test基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `UC-TST-P001` | Scenario Based | 業務経路差はScenario単位でTestする。 |
| `UC-TST-P002` | Reference, not duplicate | 呼出、Mapping、Expectedを重複定義せず正本を参照する。 |
| `UC-TST-P003` | Java First | Scenario、Mapping、CheckおよびCompareをJava実装で確定する。 |
| `UC-TST-P004` | Four Axes | Execution、Verification、Change、Recoveryを独立してAssertionする。 |
| `UC-TST-P005` | Stable Trace | `scenarioId + apiCallCode`と`resultKey`で追跡する。 |
| `UC-TST-P006` | No Guess | 欠落Input、Expected、Class、Baselineを推測しない。 |
| `UC-TST-P007` | Complete Run | Baseline更新とArtifact完全性を明示的に確認する。 |
| `UC-TST-P008` | Isolation | Run、Data、Context、OutputおよびBaselineを分離する。 |
| `UC-TST-P009` | Safe Update | 更新系はData、冪等性、Cleanupおよび承認を持つ。 |
| `UC-TST-P010` | No Secret | Secretおよび実個人情報をTest成果物へ保存しない。 |

## 8. 対象UseCase概要

| 項目 | 内容 |
|---|---|
| UseCase ID | `<UC-E6-NNN>` |
| UseCase名称 | `<正式名称>` |
| Business ID | `<BUS-E6-NNN>` |
| 業務目的 | `<成立させる業務目的>` |
| 開始点 | `<開始状態>` |
| 終了点 | `<終了状態>` |
| 対象Scenario | `<SC-E6-NNN, ...>` |
| Environment | `<ENV-STAGING>` |
| 更新系 | `<Yes / No>` |
| Verification Spec | `<reference>` |

## 9. Scenario Coverage

| Scenario ID | Scenario Type | 経路概要 | 対象Requirement | Test Case | Coverage | 未Coverage理由 |
|---|---|---|---|---|---|---|
| `<SC-E6-NNN>` | `<NORMAL>` | `<主正常経路>` | `<UC-VR-...>` | `<TC-UC-...>` | `<COVERED / GAP / BLOCKED>` | `<理由／NONE>` |

`enabled=false`のScenarioをTest実行対象に含めない。設計Coverageとして必要な場合は`BLOCKED`と理由を記録する。

## 10. Test Level

| Test Level | 対象 | 外部接続 | 主目的 |
|---|---|---|---|
| `SCENARIO_COMPONENT` | Scenario Class＋Mock API | Mock | 分岐、Mapping、Stop／Skip |
| `SCENARIO_INTEGRATION` | Scenario＋Runtime Component | 部分Mock／Local | Context、Artifact、Result |
| `ENVIRONMENT_E2E` | 実E6 Environment | あり | 実API Chainと業務結果 |
| `BASELINE_REGRESSION` | Current＋Baseline | Fixture／実Artifact | Diff、Initial、更新 |
| `RECOVERY` | Failure Injection | Local／隔離 | Crash、Resume、Atomicity |
| `CONCURRENCY` | 複数Run | Local／隔離 | Run／Data／Baseline Isolation |

## 11. Test Case共通属性

| 属性 | 必須 | 内容 |
|---|:---:|---|
| `testCaseId` | Yes | `TC-UC-{systemCode}-{useCaseNo}-{NNN}`形式 |
| `scenarioId` | Yes | 対象Scenario |
| `testLevel` | Yes | 10章のLevel |
| `requirementRef` | Yes | UseCase／Scenario／Verification Reference |
| `inputRef` | Yes | Input／Test Data Reference |
| `expectedRef` | Yes | Expected Reference |
| `precondition` | Yes | Environment、Data、Baseline、Mock |
| `operation` | Yes | 起動またはFailure Injection |
| `expectedObservation` | Yes | Flow／Check／Artifactの期待 |
| `automationRef` | Yes | Java Test／Execution Reference |
| `cleanupRef` | 条件付き | 更新系または外部Data利用時 |
| `readiness` | Yes | `READY / BLOCKED` |

## 12. Test Case一覧

| Test Case ID | Scenario | Level | Test概要 | Requirement Ref | Input／Data Ref | Expected Ref | Automation Ref | Readiness |
|---|---|---|---|---|---|---|---|---|
| `<TC-UC-E6-NNN-001>` | `<SC-E6-NNN>` | `<SCENARIO_COMPONENT>` | `<正常経路>` | `<reference>` | `<dataRef>` | `<expectedRef>` | `<Class#method>` | `<READY / BLOCKED>` |

## 13. Scenario正常経路Test

| Checkpoint | 観測対象 | Expected Observation | Evidence |
|---|---|---|---|
| Start | Execution Identity | Input、Expected、Contextが一致 | Run Meta／Validation |
| API Call | `scenarioId + apiCallCode` | 設計順・条件で呼出 | ApiExchange |
| Mapping | Source → Target | 型検証後に後続Requestへ設定 | Request／Response |
| Check | `resultKey` | Java CheckとExpectedが一致 | Check Result |
| Finish | Scenario State | 期待終了状態 | Verification Result |
| Artifact | Run Root | 必須Artifact完全 | Evidence Index |

本表は観測点であり、API呼出定義の正本ではない。

## 14. Alternative／Business Error Test

| Test Case ID | Scenario | Trigger | Expected Flow | Expected Check | Expected Final State |
|---|---|---|---|---|---|
| `<TC-...>` | `<SC-...>` | `<対象不存在>` | `<更新Call未実行>` | `<resultKey結果>` | `<COMPLETED／期待状態>` |

想定Business Errorは、設計に従い業務正常終了またはVerification `FAIL`になり得る。`WARN`を新設して曖昧さを隠さない。

## 15. Timeout／Transport Error Test

| Test Case ID | 対象API Call | Failure | Retry | 後続Step | Execution | Verification | Evidence |
|---|---|---|---|---|---|---|---|
| `<TC-...>` | `<CALL-NNN>` | `<READ_TIMEOUT>` | `<0 / 設計値>` | `<STOP / SKIP>` | `<INCOMPLETE>` | `<NOT_EVALUATED>` | `<reason／exchange>` |

### 15.1 必須確認

- [ ] Timeout対象Callを`apiCallCode`で特定する。
- [ ] Connect／Read Timeoutを区別する。
- [ ] 更新API Retryが冪等性と一致する。
- [ ] Retry Exhausted後の後続処理が設計どおりである。
- [ ] 未実行Stepを実行済みとして記録しない。
- [ ] 取得済みArtifactを保持する。
- [ ] 不完全RunをBaseline化しない。

## 16. API呼出順序／条件Test

| Test Case ID | Scenario | Expected Call | Execute Condition | Non-Expected Call | 観測方法 |
|---|---|---|---|---|---|
| `<TC-...>` | `<SC-...>` | `<CALL-001 → CALL-002>` | `<前提成立>` | `<CALL-003 before CALL-002>` | `<ApiExchange sequence>` |

TestはScenario詳細設計とJava実装の一致を確認し、本書の表だけからRun Planを生成しない。

## 17. Mapping／Context Test

| Test Case ID | Source | Target | 型／変換 | Expected | Evidence |
|---|---|---|---|---|---|
| `<TC-...>` | `<CALL-001.response.memberId>` | `<CALL-002.request.memberId>` | `<String / none>` | `<一致>` | `<response + request>` |

### 17.1 Negative

| 条件 | Expected |
|---|---|
| Source Field欠落 | Execution `INCOMPLETE`、Verification `NOT_EVALUATED`、Mapping Reason Code |
| Source Null | Null契約に従い停止／許容 |
| Type不一致 | Execution `INCOMPLETE`、Verification `NOT_EVALUATED`、Type Reason Code |
| Target Required未設定 | API呼出前に拒否 |
| 同一API複数回 | `apiCallCode`で正しいResponseを選択 |
| 別Run Context | 参照拒否 |

## 18. Branch／Skip／Stop／Continue Test

| Test Case ID | 条件 | Expected Branch | Expected Step State | Verificationへの影響 |
|---|---|---|---|---|
| `<TC-...>` | `<条件成立>` | `<Branch A>` | `<後続実行>` | `<Check結果に従う>` |
| `<TC-...>` | `<条件不成立>` | `<Branch B>` | `<対象Step未実行>` | `<必要CheckはNOT_EVALUATED＋Reason Code>` |

`SKIP`、`STOP`および`CONTINUE`はFlow状態であり、Verification ResultのEnumではない。

## 19. Scenario Input Test

| Test Case ID | 観点 | 条件 | Expected |
|---|---|---|---|
| `<TC-...>` | Identity | Environment不一致 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `<TC-...>` | `apiCallCode` | 未知Code | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `<TC-...>` | Initial Value | 必須値欠落 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `<TC-...>` | Logic混入 | Mapping式／Branch定義あり | Schema／Semantic Error |
| `<TC-...>` | Secret | Credential実値あり | Log非出力、起動拒否 |
| `<TC-...>` | Immutable | 実行中変更 | 変更拒否 |

## 20. Expected／Check Test

| Test Case ID | 条件 | Expected |
|---|---|---|
| `<TC-...>` | 必須`resultKey`がExpectedにない | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `<TC-...>` | Expectedに未知`resultKey` | Execution `REJECTED`、または明示的Optionalとして非対象 |
| `<TC-...>` | 重複`resultKey` | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `<TC-...>` | `valueType`不一致 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `<TC-...>` | Check値不一致 | `FAIL` |
| `<TC-...>` | 必要Responseなし | Verification `NOT_EVALUATED`、Executionに応じたReason Code |
| `<TC-...>` | Check実装例外 | Verification `NOT_EVALUATED`、Execution `INCOMPLETE` |

ExpectedへClass名、Script、JSONPath実行LogicまたはCompare Policyがないことも確認する。

## 21. Business Check Test

| Test Case ID | resultKey | Check Type | Input／Source | Expected Ref | Expected Status |
|---|---|---|---|---|---|
| `<TC-...>` | `<CALL-003_MEMBER_STATUS>` | `<BUSINESS_TRANSITION>` | `<CALL-001／CALL-003>` | `<expectedRef>` | `<PASS / FAIL>` |

### 21.1 必須観点

- InputとResponseの一致
- 前段と後段APIのID一致
- 更新前後の状態遷移
- 固定値または許可Enum
- Scenario最終状態
- Evidence完全性

## 22. 四結果軸Test

| Test Case ID | 条件 | Expected Execution | Expected Verification | Expected Change | Expected Recovery |
|---|---|---|---|---|---|
| `<TC-...>` | 業務期待成立、Response変化 | `COMPLETED` | `PASS` | `CHANGED` | `NOT_REQUIRED` |
| `<TC-...>` | 業務期待不成立、変化なし | `COMPLETED` | `FAIL` | `UNCHANGED` | `NOT_REQUIRED` |
| `<TC-...>` | 初回 | `COMPLETED` | `<PASS / FAIL>` | `NOT_COMPARED` | `NOT_REQUIRED` |
| `<TC-...>` | Compare処理異常 | `INCOMPLETE` | `NOT_EVALUATED` | `NOT_COMPARED` | `<NOT_REQUIRED / REQUIRED>` |
| `<TC-...>` | Ignored Diffのみ | `COMPLETED` | `<PASS / FAIL>` | `UNCHANGED` | `NOT_REQUIRED` |

四軸を一つの総合PASS／FAILへ潰さない。

## 23. Initial／Baseline Test

| Test Case ID | 条件 | Previous解決 | Expected Diff | Baseline更新 |
|---|---|---|---|---|
| `<TC-...>` | 初回、Baselineなし | なし | `NOT_COMPARED + INITIAL_EXECUTION` | 完全Run後に作成 |
| `<TC-...>` | 固定Baselineあり | 固定Path | 同一Identityで比較 | 完全Run後に置換 |
| `<TC-...>` | Baseline欠落、`previousRunId`有効 | 指定Run | 比較実施 | 条件成立時 |
| `<TC-...>` | 非初回、復旧不能 | なし | Error | 更新なし |
| `<TC-...>` | API Error | 選択済みでもCurrent不完全 | `NOT_COMPARED`等 | 更新なし |

日付、Directory順または更新時刻から前回Runを推測しない。

## 24. Response Diff Test

| Test Case ID | Mode／条件 | Expected Change Status | Expected Display Category | Effective | Ignored |
|---|---|---|---|---:|---:|
| `<TC-...>` | 差異なし | `UNCHANGED` | `NO_CHANGE` | `0` | `0` |
| `<TC-...>` | Standard差異 | `CHANGED` | `EFFECTIVE_CHANGE` | `<N>` | `<N>` |
| `<TC-...>` | Ignoredのみ | `UNCHANGED` | `IGNORED_ONLY` | `0` | `<N>` |
| `<TC-...>` | 初回 | `NOT_COMPARED` | `<INITIAL>` | `0` | `0` |
| `<TC-...>` | Comparator Error | `NOT_COMPARED` | `COMPARE_ERROR` | `<0>` | `<0>` |

Ignored Diffも明細へ保存し、「変化なし」へ変換しない。

## 25. Verification Result集約Test

| Check明細 | Expected Verification Status |
|---|---|
| 全必須Check `PASS` | `PASS` |
| 1件以上`FAIL` | `FAIL` |
| 必須Checkに未評価があり、`FAIL`なし | `NOT_EVALUATED` |

優先順位は`FAIL > NOT_EVALUATED > PASS`とする。Optional Checkの影響はScenario設計に従う。

## 26. Artifact完全性Test

| Test Case ID | 条件 | Expected |
|---|---|---|
| `<TC-...>` | 正常Run | 必須Artifact、Hash、Referenceが完全 |
| `<TC-...>` | Business FAIL | `COMPLETED`かつResult／Evidenceあり |
| `<TC-...>` | API Timeout | 取得済みArtifactとError Evidenceあり |
| `<TC-...>` | Artifact書込失敗 | 不完全Run、Baseline更新なし |
| `<TC-...>` | Mask失敗 | 未Mask値を保存せずError |
| `<TC-...>` | Report生成失敗 | Source Result保持、Report Status不完全 |

## 27. Report Test

| Test Case ID | Report | 確認内容 |
|---|---|---|
| `<TC-...>` | Scenario Summary | 四軸、API Call、Check、EvidenceがSourceと一致 |
| `<TC-...>` | Diff Report | Effective／Ignored／Not Comparedを分離 |
| `<TC-...>` | Evidence Index | 全LinkがRun Root相対で解決 |
| `<TC-...>` | Daily Summary | Scenario件数とStatus別集計が一致 |

ReportがResultを再判定していないことを確認する。

## 28. Run Isolation／Concurrency Test

| Test Case ID | 条件 | Expected |
|---|---|---|
| `<TC-...>` | 異なるScenario同時実行 | Context、Output、Resultが分離 |
| `<TC-...>` | 同一Scenario、異Input Set | Baselineを混用しない |
| `<TC-...>` | 同一Execution Identity同時起動 | 一方を拒否またはQueue |
| `<TC-...>` | 同一API複数回 | `apiCallCode`別に保持 |
| `<TC-...>` | 一方のRun失敗 | 他RunのContext／Artifactへ影響なし |

Mutable Global Stateを使用してはならない。

## 29. Crash Recovery Test

| Test Case ID | Failure Point | Expected Recovery |
|---|---|---|
| `<TC-...>` | API Response保存前 | Run不完全、旧Baseline維持 |
| `<TC-...>` | Verification Result書込中 | PartialをComplete扱いしない |
| `<TC-...>` | Baseline Copy中 | Temporary破棄、旧Baseline維持 |
| `<TC-...>` | Baseline切替後、State更新前 | 新BaselineからState復旧 |
| `<TC-...>` | Report生成中 | Result保持、Report再生成可能 |

## 30. 更新系副作用／Cleanup Test

| Test Case ID | 対象Data | 更新前 | 操作 | 更新後 | Cleanup | 再実行 |
|---|---|---|---|---|---|---|
| `<TC-...>` | `<Entity ID>` | `<state>` | `<Scenario>` | `<state>` | `<resetRef>` | `<期待>` |

### 30.1 Gate

- Test専用Dataまたは承認済みDataである。
- 同時実行で競合しない。
- Timeout後に結果を確認できる。
- Cleanup失敗を検出し、次Testを停止できる。
- Baseline更新と業務Data更新を混同しない。

## 31. Security Test

| Test Case ID | 対象 | Expected |
|---|---|---|
| `<TC-...>` | Input／Expected | Secret実値なし |
| `<TC-...>` | Request／Response | 保存前Mask |
| `<TC-...>` | Diff | Previous／CurrentともMask |
| `<TC-...>` | Exception／Log | Raw Body、Token非表示 |
| `<TC-...>` | Cross-Run Access | 別Run Artifact参照拒否 |
| `<TC-...>` | Production-like | 承認、最小権限、監査記録 |

## 32. Test Data

| Data ID | Scenario | Input Set | Environment | 初期状態 | Cleanup | Owner | 利用可否 |
|---|---|---|---|---|---|---|---|
| `<TD-UC-...>` | `<SC-...>` | `<INPUT-...>` | `<ENV-...>` | `<state>` | `<cleanupRef>` | `<owner>` | `<READY / BLOCKED>` |

本書へCredential、実個人情報または大量のData値を記載しない。

## 33. Automation設計

| Test Case ID | Java Test Class | Method／Source | Level | Failure Injection | Execution Ref |
|---|---|---|---|---|---|
| `<TC-...>` | `<ScenarioTest>` | `<methodRef>` | `<level>` | `<mock/faultRef>` | `<executionRef>` |

Java Source Rootが未確定の場合、仮Class Pathを`PASS`として扱わない。

## 34. Test結果

| Status | 意味 |
|---|---|
| `PASS` | Test Assertion成立 |
| `FAIL` | Assertion不成立 |
| `BLOCKED` | Scenario、Data、Environment、Classまたは承認未成立 |
| `ERROR` | Test Infrastructure、FixtureまたはRuntime異常 |

Flow上の`SKIP`とTest結果の`BLOCKED`を区別する。

## 35. Evidence

| Test Level | 必須Evidence |
|---|---|
| Scenario Component | Test Case、Mock Interaction、Context、Check Result |
| Scenario Integration | Run Meta、Input、Expected、ApiExchange、Result |
| Environment E2E | Environment、Correlation、Mask済Request／Response、Result |
| Baseline Regression | Baseline Metadata、Previous／Current、Field Diff |
| Recovery | Failure Point、旧／新State、Recovery結果 |
| Concurrency | 複数Run ID、Lock、分離されたArtifact |

## 36. Traceability

```text
Business Analysis
→ UseCase Requirement
→ Scenario Design
→ Input／Expected
→ Java Scenario／Check
→ UseCase Test Case
→ Run／Result／Evidence
→ Report
```

| Test Case ID | UseCase Req | Scenario | API Call | resultKey | Input／Expected | Java Test | Evidence |
|---|---|---|---|---|---|---|---|
| `<TC-...>` | `<UC-VR-...>` | `<SC-...>` | `<CALL-... / NONE>` | `<resultKey / NONE>` | `<refs>` | `<automationRef>` | `<evidenceRef>` |

## 37. Coverage Matrix

| Requirement／Risk | Normal | Alternative | Error／Timeout | Boundary | Recovery／Concurrency | Coverage |
|---|---|---|---|---|---|---|
| `<business transition>` | `<TC-...>` | `<TC-...>` | `<N/A>` | `<TC-...>` | `<N/A>` | `<COVERED / GAP / BLOCKED>` |

`N/A`には理由を記載する。未完成Scenarioを暗黙にCoverage済みとしない。

## 38. Entry Criteria

- Business Analysis、5類Master、UseCase設計および対象Scenario設計が解決する。
- 対象Scenarioが`enabled=true`で、参照APIも有効である。
- Scenario Class、Input、ExpectedおよびJava CheckがBuildで解決する。
- Test Data、Environment、Auth ProfileおよびCleanupが準備済みである。
- Execution仕様とVerification仕様がReview可能である。
- Cross-Master Errorが0件である。

## 39. Exit Criteria

1. 必須ScenarioとRequirementのCoverageが`COVERED`である。
2. 正常、代替、異常、TimeoutおよびBoundaryの必要経路を実施している。
3. 四結果軸、Baseline、ArtifactおよびReport Testが合格している。
4. 更新系Cleanupと再実行性が確認済みである。
5. `FAIL`、`ERROR`および未説明`BLOCKED`が0件である。
6. Test結果からBusiness／UseCase／Scenario／`resultKey`へ逆Traceできる。
7. Security、Run IsolationおよびRecoveryの必須Riskが確認済みである。

## 40. Static Validation

| Validation ID | 確認内容 | Level |
|---|---|---|
| `UC-TST-V001` | 文書ID、Test Spec ID、Test Case IDが一意である。 | ERROR |
| `UC-TST-V002` | UseCaseとScenarioがMasterで解決する。 | ERROR |
| `UC-TST-V003` | 有効Scenarioが無効API／Environmentを参照しない。 | ERROR |
| `UC-TST-V004` | Scenario設計、Input、Expected、Java Classが解決する。 | BLOCKED |
| `UC-TST-V005` | Input／Expected／Context Identityが一致する。 | ERROR |
| `UC-TST-V006` | 必須`resultKey`とJava Checkが双方向一致する。 | ERROR |
| `UC-TST-V007` | 全Test CaseにRequirement、Data、Expected、Automationがある。 | ERROR |
| `UC-TST-V008` | 四結果軸を独立して確認する。 | ERROR |
| `UC-TST-V009` | 更新系TestにOwner、Isolation、Cleanupがある。 | BLOCKED |
| `UC-TST-V010` | Secret／実個人情報を含まない。 | ERROR |
| `UC-TST-V011` | ReportがSource Resultを再判定しない。 | ERROR |
| `UC-TST-V012` | 未説明Coverage Gapがない。 | ERROR |

## 41. Review Checklist

### 41.1 Business／Scenario

- [ ] UseCase目的からScenario Coverageを説明できる。
- [ ] Scenario追加を単一Field Checkのために行っていない。
- [ ] 未完成ScenarioをCoverage済みとしない。

### 41.2 Flow／Java

- [ ] 呼出、Mapping、Branch、Stop、SkipがJavaへ追跡可能である。
- [ ] 同一API複数回を`apiCallCode`で区別する。
- [ ] ExpectedとJava Checkの`resultKey`が一致する。

### 41.3 Result／Baseline

- [ ] 四結果軸の合法組合せを確認する。
- [ ] Initial、Ignored Only、Compare Errorを確認する。
- [ ] 不完全RunをBaseline化しない。

### 41.4 Safety／Evidence

- [ ] 更新系DataとCleanupが安全である。
- [ ] Run Isolation、Crash Recovery、Maskを確認する。
- [ ] 必須ArtifactとReportのSource整合を確認する。

## 42. Release Blocker

- 有効UseCase／Scenarioが無効EnvironmentまたはAPIを参照する。
- Business Analysis、Scenario設計、Input、ExpectedまたはJava Classが解決しない。
- Input／Expected／Context Identityが一致しない。
- 必須`resultKey`とJava Checkが一致しない。
- Test Data、更新系安全条件、CleanupまたはEnvironment承認が未成立である。
- 必須Scenario／RequirementにCoverage Gapがある。
- Run Isolation、Baseline、RecoveryまたはSecurity Testが失敗している。
- Secretまたは実個人情報がArtifactへ含まれる。

## 43. Current Architecture適用時の既知Blocker

| Blocker | 現状 | 必要処置 |
|---|---|---|
| 正式Business／API | 0件 | 業務分析とAPI分析を完了 |
| 正式UseCase／Scenario | 0件 | 経路Coverageを設計しMasterへ登録 |
| Scenario実行資産 | 0件 | 詳細設計、Input、Expected、Java CheckおよびScenario Classを作成 |
| TestData設計 | 設計本文あり、正式Data 0件 | 正式Scenario確定後にDataを作成・承認 |
| Framework横断契約 | 11文書のDRAFT正文完成／正式Review未実施 | Architecture／Runtime／Verification／Security／Operation責任RoleのReviewと決定承認を完了 |

## 44. Open Issues

| Issue ID | 論点 | 暫定方針 | Owner／確定先 |
|---|---|---|---|
| `UC-TST-ISSUE-001` | Java Test Source Root／Package | 仮Pathを正本化しない。 | Architecture／Coding Standard |
| `UC-TST-ISSUE-002` | Test Evidence物理配置 | Run Root相対Referenceだけを使用する。 | File I/O設計 |
| `UC-TST-ISSUE-003` | Scenario Test Coverage数値閾値 | 必須経路完全Coverageを優先する。 | Test Strategy |
| `UC-TST-ISSUE-004` | SC-E6-003 Retry方針 | 無承認Retryを行わない。 | API仕様／Runtime設計 |

## 45. 禁止事項

- 本書をScenario API呼出順序の正本にする。
- Input、Expected、Mapping、CheckまたはCompare Logicを重複保持する。
- 未完成Scenario、無効APIまたは無効Environmentを実行可能と表示する。
- Effective Diffを自動的にVerification `FAIL`へ変換する。
- Business `FAIL`をExecution `INCOMPLETE`へ変換する。
- Flowの`SKIP`をVerification Resultへ追加する。
- Previous Runを日付またはDirectory順から推測する。
- 大量のTest Data、Secretまたは実個人情報を本文へ記載する。
- 未承認のJava Package、Runtime DirectoryまたはSchemaを正式契約にする。

## 46. Template利用手順

1. UseCase目的、Scenario一覧およびCoverage Riskを確定する。
2. Test Spec IDとTest Case IDを採番する。
3. 正常、代替、異常、Timeout、Boundary Caseを展開する。
4. Mapping、Context、Check、四軸、Baseline、ArtifactのTestを追加する。
5. 更新系、Concurrency、RecoveryおよびSecurity Testを追加する。
6. Input、Expected、Test DataおよびJava Automationへ接続する。
7. Coverage Matrix、Static ValidationおよびReviewを実施する。
8. Release Blockerが0件になった後に承認する。

## 47. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 5類Master、Java First、Scenario Input／Expected、三判定軸、Baseline／Diff／Report境界に基づく全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | SC-E6-001の3 Reference作成後のTest対象状態と残存Automation Blockerを同期 | DRAFT |
| `2.0.0-draft.3` | 2026-07-27 | SC-E6-002の3 Reference作成後のTest対象状態と、業務結果未決・Java未実装Blockerを同期 | DRAFT |
| `2.0.0-draft.4` | 2026-07-27 | SC-E6-003の3 Reference作成後のTest対象状態と、Timeout／No Retry／Recovery／Java未実装Blockerを同期 | DRAFT |
| `2.0.0-draft.5` | 2026-07-27 | Scenario ContextおよびBaseline設計Referenceを`system/05_framework/`へ同期 | DRAFT |
| `2.0.0-draft.6` | 2026-07-27 | Framework横断Reviewにより四結果軸、Canonical Statusおよび集約順序へ統一 | DRAFT |
| `2.0.0-draft.7` | 2026-07-27 | 横断再走査によりScope、完了条件、ValidationおよびChecklistの残存三軸表現を四結果軸へ同期 | DRAFT |
| `2.0.0-draft.8` | 2026-07-27 | 横断再走査によりInput／Mapping／Expected異常、Diff表示CategoryおよびVerification集約をCanonical四軸へ統一 | DRAFT |
| `2.0.0-draft.9` | 2026-07-28 | Framework 11文書のDRAFT正文完成を反映し、Framework未完成表示を正式Role Review／Decision承認待ちへ更新 | DRAFT |
