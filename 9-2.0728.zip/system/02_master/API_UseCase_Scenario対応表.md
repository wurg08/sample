---
title: API・UseCase・Scenario対応表
document_id: TRC-E6-API-UC-SC-001
version: 3.0.0-draft.1
status: DRAFT
data_status: EMPTY_PENDING_SCENARIO_DESIGN
document_type: Traceability View
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# API・UseCase・Scenario対応表

## 1. 文書目的

本書は、UseCase、ScenarioおよびScenario内のAPI呼出実体を、各正本から導出して表示するTraceability Viewである。

本書で関係を新規決定しない。表示項目、粒度および導出規則は`system/02_master/design/API・UseCase・Scenario対応表設計書.md`に従う。

## 2. 現在の生成状態

正式UseCase、ScenarioおよびAPIが0件であるため、対応行を生成しない。

| 区分 | 件数 | 状態 |
|---|---:|---|
| UseCase | 0 | 未登録 |
| Scenario | 0 | 未登録 |
| API | 0 | 未登録 |
| API呼出関係 | 0 | `EMPTY_PENDING_SCENARIO_DESIGN` |

架空の`UC-E6-001`、`SC-E6-001～003`、`API-001／002`による7行は正式対応表から除外し、Recoveryへ隔離した。

## 3. 正式14項目

| useCaseId | useCaseName | scenarioId | scenarioName | scenarioType | callSequence | apiCallCode | apiId | apiName | callPurpose | executeCondition | scenarioDesignRef | apiDesignRef | relationStatus |
|---|---|---|---|---|---:|---|---|---|---|---|---|---|---|

## 4. 生成入力

| 情報 | 正本 |
|---|---|
| UseCase Identity、名称、Scenario集合 | `UseCase_Master.md` |
| Scenario Identity、名称、種別、有効状態 | `Scenario_Master.md` |
| API Identity、名称、有効状態 | `E6_API_Master.md`（`API_Master.md`へ移行予定） |
| 呼出順序、`apiCallCode`、目的、条件 | Scenario詳細設計書 |

ExampleまたはRecoveryを生成入力にしてはならない。

## 5. 生成Gate

1. 三Masterの正式レコードが存在する。
2. Scenario詳細設計書が存在し、API呼出集合を確定している。
3. `scenarioId + apiCallCode`が一意である。
4. 全Referenceが正式成果物へ解決できる。
5. `relationStatus`を三Masterの`enabled`から導出できる。

推測による空欄補完、仮API呼出または架空Pathの生成を禁止する。

## 6. 現在のValidation

| Validation ID | 確認内容 | 判定 |
|---|---|---|
| `TRC-V001` | 正式表が14列である。 | PASS |
| `TRC-V002` | Example／Recoveryの行が正式表へ混入していない。 | PASS |
| `TRC-V003` | 正式MasterとScenario詳細設計から全関係を生成できる。 | NOT_APPLICABLE（0件） |
| `TRC-V004` | 有効Scenarioが無効APIを参照しない。 | NOT_APPLICABLE（0件） |
| `TRC-R001` | 7業務Flowの正式Traceabilityが完成している。 | BLOCKED |

## 7. 要確認事項

| Issue ID | 確認事項 | 影響 | 状態 |
|---|---|---|---|
| `TRC-ISSUE-001` | 正式Master初回登録 | 対応表生成開始 | Open |
| `TRC-ISSUE-002` | Scenario詳細設計の呼出定義 | API呼出行生成 | Open |
| `TRC-ISSUE-003` | CIでの自動生成・差分Gate | Release運用 | Open |

## 8. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `3.0.0-draft.1` | 2026-07-27 | 架空001系列の7行を正式対応表から除外。正式正本が0件である状態を明示し、生成Gateを再定義。 |
