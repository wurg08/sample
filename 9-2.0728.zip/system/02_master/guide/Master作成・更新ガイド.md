---
title: Master作成・更新ガイド
document_id: GUIDE-E6-MST-001
version: 2.0.0-draft.1
status: DRAFT
document_type: Guide
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# Master作成・更新ガイド

## 1. 目的

本書は、E6 API Verification PlatformのMasterを新規作成、変更、無効化、置換およびReleaseする際の標準作業手順を定義する。

本書は作業手順のGuideであり、各Masterの項目定義または業務値の正本ではない。共通統制は`system/02_master/design/Master共通設計書.md`、個別項目は各Master設計書を正本とする。

## 2. 適用対象

| 区分 | 対象ファイル | 位置付け |
|---|---|---|
| Business Master | `system/02_master/Business_Master.md` | 業務分類・業務境界の正本 |
| Environment Master | `system/02_master/Environment_Master.md` | 実行環境識別・安定属性の正本 |
| API Master | `system/02_master/E6_API_Master.md` | API識別・安定技術属性の正本 |
| UseCase Master | `system/02_master/UseCase_Master.md` | 業務検証目的・範囲の正本 |
| Scenario Master | `system/02_master/Scenario_Master.md` | 確定実行経路・実行資産参照の正本 |
| Traceability View | `system/02_master/API_UseCase_Scenario対応表.md` | 正本およびScenario詳細設計から導出する確認用View |

次の情報は、本Guideを使用して新しいMasterとして追加してはならない。

- Runtime Context、Run ID、実行日時および実行Status
- Request／Response実値、SnapshotおよびEvidence
- Expected値、`resultKey`別判定、Business Check
- Baseline、Previous／CurrentおよびDiff結果
- `IGNORE_FIELD`、`IGNORE_VALUE`およびJava比較ロジック
- API呼出順序、分岐、Skip、RetryおよびTimeout実装

## 3. 前提文書

作業開始前に、変更対象に応じて次を確認する。

| 文書 | 必須となる作業 |
|---|---|
| `design/Master共通設計書.md` | 全作業 |
| 対象Masterの個別設計書 | 対象Masterの追加・変更・無効化 |
| `guide/Master_ID・Reference記述ガイド.md` | ID採番、ID参照、File Reference変更 |
| `checklist/MasterレビューChecklist.md` | Review |
| `checklist/Master整合性Checklist.md` | Cross-Master Validation |
| 対応するExample | 記述形式の確認。ただし業務値の転記は禁止 |

Exampleは架空値を含む。`900`番台のExample IDを正式Masterへ転記してはならない。

## 4. 役割と責任

| 役割 | 主な責任 |
|---|---|
| Requester | 変更理由、対象Release、期限および業務要求を提示する。 |
| Master Owner | 正本を特定し、変更内容、ID継続可否および影響範囲を決定する。 |
| Editor | 本Guideおよび個別設計書に従って成果物を更新する。 |
| Domain Reviewer | 業務または技術内容の妥当性を確認する。 |
| System Architect | 正本境界、ID、ReferenceおよびCross-Master整合性を確認する。 |
| Test Lead | Scenario、Input、Expected、Java実装および検証観点の整合性を確認する。 |
| Release Approver | Validation結果とReview Evidenceに基づきRelease可否を承認する。 |

作成者と最終承認者は、原則として同一人物にしない。

## 5. 変更受付

### 5.1 必須入力

| 項目 | 内容 |
|---|---|
| Change ID | 変更を一意に追跡する識別子 |
| 変更理由 | 業務要求、API変更、障害是正、保守性改善等 |
| 対象Release | 変更を反映するReleaseまたは適用日 |
| 対象成果物 | 正本、詳細設計、実装、Input、Expected、View |
| 変更種別 | 追加、属性変更、関係変更、無効化、置換、物理削除 |
| 影響候補 | Business、Environment、API、UseCase、Scenario、Java、運用 |
| 根拠 | 要件、現行仕様、API仕様、決定記録または承認記録 |

根拠がなく、値を推測しなければ登録できない場合は、正式値として登録しない。候補を保持する必要がある場合は`enabled=false`とし、未確認事項と完了条件を明記する。

### 5.2 変更種別

| 種別 | 例 | IDの扱い |
|---|---|---|
| 追加 | 新API、新UseCase、新Scenario | 新IDを採番 |
| 属性変更 | 名称、説明、Path、Class名 | 同一性が維持される限りID継続 |
| 関係変更 | Scenario所属、API呼出先 | 関係の正本を変更し影響Review |
| 無効化 | 廃止、未完成、利用停止 | IDを維持し`enabled=false` |
| 置換 | 非互換API、業務目的の全面変更 | 新IDを採番し旧IDを無効化 |
| 物理削除 | 誤登録、保持期限経過後の例外処理 | 承認、参照0件、履歴解決性確認が必須 |

## 6. 正本判定

変更対象を決める前に、情報の正本を判定する。

| 変更内容 | 更新する正本 |
|---|---|
| 業務分類、業務境界 | Business Master |
| Environment識別、安定接続属性 | Environment Master |
| API名称、Method、Endpoint、DTO、API設計参照 | API Master |
| 業務検証目的、業務範囲、Scenario逆引き一覧 | UseCase Master |
| Scenario概要、種別、Java Class、Input／Expected／設計参照 | Scenario Master |
| API呼出順序、`apiCallCode`、実行条件 | Scenario詳細設計書 |
| UseCase・Scenario・APIの横断表示 | 対応表。ただし値は正本から導出 |

対応表だけを修正して、正本またはJavaへ逆反映してはならない。

## 7. 標準作業フロー

```mermaid
flowchart TD
    A["変更受付・根拠確認"] --> B["正本・Owner特定"]
    B --> C["影響分析・ID判定"]
    C --> D["正本と関連資産を更新"]
    D --> E["対応表を再生成・再照合"]
    E --> F["Validation・Review"]
    F --> G{"Release Gate通過"}
    G -->|Yes| H["承認・凍結"]
    G -->|No| C
```

### 7.1 作業手順

1. Change ID、変更理由、対象Releaseおよび根拠を確認する。
2. 変更する情報の正本とMaster Ownerを特定する。
3. 既存ID、参照元、参照先、派生成果物、Javaおよび運用への影響を検索する。
4. IDを継続するか、新IDを採番して置換するかを決定する。
5. 対象Masterの個別設計書で正式列、型、必須性および禁止項目を確認する。
6. 正本と、同一Change Setで更新すべき詳細設計・実行資産を更新する。
7. UseCaseとScenarioの双方向関係を更新する。
8. Scenario詳細設計のAPI呼出変更を反映する。
9. 対応表を正本とScenario詳細設計から再生成または再照合する。
10. 構文、単一ファイル、Reference、Cross-MasterおよびCoverage Validationを実行する。
11. Domain Review、Architecture Reviewおよび必要なTest Reviewを実施する。
12. `ERROR=0`、未承認`WARNING=0`を確認して承認・Releaseする。

前段の不整合を、後段のViewまたは実装で補正してはならない。

## 8. 新規レコード作成

### 8.1 共通手順

1. 既存レコードと同一対象でないことをID、名称、設計参照および業務目的から確認する。
2. `Master_ID・Reference記述ガイド.md`に従い未使用IDを採番する。
3. 個別設計書の正式列をすべて作成する。
4. 未確認値を空文字、`-`または推測値で隠さない。
5. 必須設計、実装または参照資産が未完成の場合は`enabled=false`とする。
6. 参照先を作成または確定し、Repository Root基準の相対Pathを設定する。
7. 個別Validationを実施する。
8. 親子関係と逆引き一覧を同一Change Setで更新する。
9. 対応表を更新し、正方向・逆方向Traceabilityを確認する。

### 8.2 Master別の成立確認

| Master | 新規登録前に確認する事項 |
|---|---|
| Business | 他Businessと目的・境界が重複していない。 |
| Environment | 論理環境として独立し、名称だけの別名ではない。 |
| API | API契約上同一のAPIが既に登録されていない。 |
| UseCase | 独立した業務検証目的であり、入力差や経路差だけではない。 |
| Scenario | 開始条件、経路および期待終了状態が確定し、同期Batch単位として実行可能である。 |

## 9. 属性変更

### 9.1 IDを維持する変更

- 誤字修正
- 意味を変えない名称改善
- 説明の明確化
- 同一契約内のEndpoint Path修正
- File名またはClass名の変更
- 対象の同一性を維持する内部実装変更

PathまたはClass名を変更する場合は、全Reference、Build設定、Java実装およびEvidenceリンクを同一Change Setで更新する。

### 9.2 新IDが必要な変更

- API契約上、旧APIと新APIを別対象として追跡すべき非互換置換
- UseCaseの業務目的または責任範囲が別物になる変更
- Scenarioの開始条件、主要経路および期待終了状態が同時に変わり、過去実行との同一性が失われる変更
- Environmentの論理的な実行境界が別環境へ変更される場合

判断が分かれる場合は、過去Snapshot、Reportおよび変更履歴を旧IDで説明できるかを基準とする。

## 10. 関係変更

### 10.1 UseCaseとScenario

Scenarioを追加、移管または無効化する場合、次を同一Change Setで更新する。

```text
Scenario_Master.useCaseId
UseCase_Master.scenarioIds
Scenario詳細設計書
API_UseCase_Scenario対応表
Java Scenario登録
Testおよび運用対象一覧
```

`UseCase_Master.scenarioIds`と、`Scenario_Master.md`で同じ`useCaseId`を持つScenario集合は完全一致させる。

### 10.2 ScenarioとAPI

API呼出先、回数または順序を変更する場合、Scenario詳細設計書を正本として更新する。API Masterへ`apiCallCode`または`callSequence`を追加してはならない。

同一APIを複数回呼び出す場合は、API Masterのレコードを複製せず、Scenario内で異なる`apiCallCode`を使用する。

## 11. 無効化・置換・削除

### 11.1 無効化

1. 参照元と定期実行対象を抽出する。
2. 新規参照を停止する。
3. 有効な親・子・API参照との矛盾を解消する。
4. 対象レコードを`enabled=false`へ変更する。
5. 対応表の`relationStatus`を正本から再導出する。
6. 過去RunからID、設計およびReportを追跡できる状態を保持する。

### 11.2 置換

1. 後継対象へ新IDを採番する。
2. 後継レコード、設計、実装およびTestを作成する。
3. 参照元を後継IDへ移行する。
4. 双方向TraceabilityとCoverageを確認する。
5. 旧IDを`enabled=false`とする。
6. 旧IDを再利用しない。

### 11.3 物理削除

物理削除は例外とし、次をすべて満たす場合だけ実施する。

- 誤登録または承認済み保持期限超過である。
- 現在の参照元が0件である。
- 過去Run、Snapshot、Diff、Reportの解決性を損なわない。
- Master OwnerとSystem Architectが承認している。
- 削除理由とEvidenceが変更履歴に記録されている。

## 12. `enabled`設定

| 状態 | 設定条件 |
|---|---|
| `true` | 正式値が確認済みで、必須参照、詳細設計および実装がValidation可能 |
| `false` | 未完成、利用停止、将来候補または履歴追跡対象 |

`enabled=false`は、ID重複、参照先不在、親子不一致または列不足を許容するための値ではない。

有効Scenarioは、少なくとも次を満たす。

- 親UseCaseが有効である。
- Java実行Class、Input、ExpectedおよびScenario設計書を解決できる。
- 一件以上のAPI呼出を持つ。
- 呼出先APIが有効である。

## 13. Traceability View更新

### 13.1 入力

- `UseCase_Master.md`
- `Scenario_Master.md`
- `E6_API_Master.md`
- Scenario詳細設計書

### 13.2 更新規則

1. 一行を`scenarioId + apiCallCode`の呼出実体とする。
2. `callSequence`をIdentityとして扱わない。
3. 名称、設計参照および有効状態は正本から取得する。
4. `relationStatus`を各正本の`enabled`から導出する。
5. Orphan、重複および正本不一致を状態値で吸収しない。
6. 生成済みViewを直接修正しない。

### 13.3 更新後確認

- 有効Scenarioに一件以上の行がある。
- 同一`scenarioId + apiCallCode`が重複していない。
- 全`apiId`がAPI Masterで解決できる。
- 有効Scenarioが無効APIを参照していない。
- 正方向と逆方向の追跡結果が一致する。

## 14. Validation

### 14.1 実行順序

| 順序 | Validation | 主な確認 |
|---:|---|---|
| 1 | 構文 | Front Matter、Markdown、Table列数 |
| 2 | 単一ファイル | 必須列、型、Enum、ID一意性 |
| 3 | Reference | ID、Path、Classおよび実行資産の解決 |
| 4 | Cross-Master | 親子、逆引き、状態、重複 |
| 5 | Scenario設計 | API呼出、`apiCallCode`、実装との一致 |
| 6 | View・Coverage | 対応表、Orphan、未使用、逆方向追跡 |
| 7 | Release Gate | `ERROR`、`WARNING`、承認Evidence |

### 14.2 判定

| Level | 処置 |
|---|---|
| `ERROR` | 修正完了までReview完了およびRelease不可 |
| `WARNING` | 修正、または理由・Owner・期限を付けて承認 |
| `INFO` | 件数・Coverage情報として記録 |

## 15. Review

### 15.1 Review Package

Review依頼には次を含める。

- Change IDと変更理由
- 変更前後差分
- 変更対象の正本
- 関連詳細設計、Input、ExpectedおよびJava差分
- 対応表の更新結果
- Validation結果
- 影響分析
- 未決事項と残存Risk
- 対象ReleaseとRollback方針

### 15.2 Review順序

1. Master Ownerによる内容確認
2. Domain Reviewerによる業務・技術妥当性確認
3. System Architectによる正本境界・ID・Reference確認
4. Test LeadによるScenario・Expected・実装整合確認
5. Release ApproverによるRelease Gate確認

## 16. 文書Lifecycle

```text
DRAFT
→ IN_REVIEW
→ APPROVED
→ RELEASED
→ DEPRECATED
→ RETIRED
```

| 状態 | 更新可否 |
|---|---|
| DRAFT | 作成者が更新可能 |
| IN_REVIEW | 指摘対応を中心に更新し、差分を再Review |
| APPROVED | Release候補。内容変更時は再Review |
| RELEASED | Change Request承認後に変更 |
| DEPRECATED | 新規参照禁止。後継へ移行し履歴を保持 |
| RETIRED | 利用終了。履歴追跡のみ |

文書`status`とレコード`enabled`を同一視しない。

## 17. Release Gate

次をすべて満たすまでReleaseしない。

- [ ] 対象文書が承認済みである。
- [ ] 正式列が個別設計書と一致している。
- [ ] `ERROR`が0件である。
- [ ] `WARNING`が修正済みまたは承認済みである。
- [ ] 有効なID ReferenceとFile Referenceがすべて解決できる。
- [ ] UseCaseとScenarioの双方向関係が一致する。
- [ ] 有効Scenarioが有効APIだけを参照する。
- [ ] 対応表が正本とScenario詳細設計に一致する。
- [ ] 変更履歴、影響分析および承認Evidenceがある。

現行の正式Business、API、UseCaseおよびScenarioは0件である。初回登録時は、架空001系列、900番台ExampleまたはRecoveryを入力元にせず、正式業務分析とAPI分析から順方向に登録する。

## 18. 緊急変更

緊急変更でもID再利用、正本省略またはValidation省略を認めない。時間上すべての通常Reviewを事前実施できない場合は、次を最低条件とする。

1. 緊急理由と適用期限を記録する。
2. Master OwnerとRelease Approverの承認を得る。
3. 影響対象とRollback手順を記録する。
4. `ERROR=0`を確認する。
5. 適用後の再Review期限と担当者を設定する。

## 19. 作業完了記録

| 項目 | 記録内容 |
|---|---|
| Change ID | 変更識別子 |
| 対象Version | 更新後Version |
| 更新者 | Editor |
| Review者 | Domain／Architecture／Test |
| Validation結果 | ERROR／WARNING／INFO件数 |
| 対応表更新 | 実施日時またはCommit |
| 承認 | Approver、承認日 |
| 未決事項 | Owner、期限、Release影響 |

## 20. 禁止事項

1. 凍結済みのMaster体系へ独断で新Masterを追加する。
2. Exampleの値を正式値として転記する。
3. 名称、Path、`callSequence`またはClass名を外部参照Keyにする。
4. 欠番を詰めるため廃止IDを再利用する。
5. 未確認値を推測して`enabled=true`にする。
6. 対応表だけを修正し、正本との不一致を残す。
7. Runtime、Expected、Diffまたは比較ロジックをMasterへ移す。
8. Validation Errorを`enabled=false`または`INACTIVE`で隠す。
9. Review Evidenceなしで`APPROVED`または`RELEASED`へ変更する。
10. 過去Runの追跡性を確認せず物理削除する。

## 21. 完了条件

本Guideに基づく一件のMaster変更は、次を満たした時点で完了とする。

1. 変更理由と正本が明確である。
2. ID継続・新規採番の判断根拠が記録されている。
3. 正本と関連資産が同一Change Setで更新されている。
4. 対応表と双方向Traceabilityが最新である。
5. 全ValidationとReviewが完了している。
6. Release Gateを通過している。
7. 変更履歴、承認Evidenceおよび未決事項が記録されている。
