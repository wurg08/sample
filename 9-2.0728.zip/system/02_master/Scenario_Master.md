---
title: Scenario Master
document_id: MST-E6-SC-001
version: 3.0.0-draft.2
status: DRAFT
data_status: EMPTY_PENDING_USECASE_DESIGN
document_type: Master
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Scenario Master

## 1. 文書目的

本書は、UseCase内の開始条件、実行経路または期待終了状態が異なるScenarioの固定Identity、種別、Java実行Class、Input、Expectedおよび詳細設計Referenceを一元管理する正本である。

正式項目とValidation規則は`system/02_master/design/Scenario_Master設計書.md`に従う。

## 2. 現在の登録状態

正式UseCaseが0件であり、Java Source Rootも未確定であるため、Scenarioを登録しない。

| 区分 | 件数 | 状態 |
|---|---:|---|
| 正式Scenario | 0 | `EMPTY_PENDING_USECASE_DESIGN` |
| 有効Scenario | 0 | 実行対象なし |
| Java／Registry解決可能Scenario | 0 | Java実装開始前 |

架空の`SC-E6-001～003`、InputおよびExpectedは正式一覧から除外し、Recoveryへ隔離した。

## 3. 正式Scenario一覧

| scenarioId | useCaseId | scenarioName | scenarioType | executionClass | inputRef | expectedRef | scenarioDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|

## 4. 登録Gate

Scenarioは次の条件をすべて満たした場合だけ登録する。

1. 所属する正式UseCaseが存在する。
2. 開始条件、経路または期待終了状態の差異を説明できる。
3. Scenario詳細設計、InputおよびExpectedの作成計画が確定している。
4. 参照APIをAPI Masterで解決できる。
5. `executionClass`を正式Java Source Rootで解決でき、`scenarioId`で一意に解決したScenario Registry Descriptorの`implementationType`と完全一致するか、実装計画と有効化Gateが承認されている。

存在しないJava Classや架空Input／Expectedを参照するScenarioを`enabled=true`にしてはならない。

## 5. Scenario種別

| scenarioType | 説明 |
|---|---|
| `NORMAL` | 主正常経路。 |
| `ALTERNATIVE` | 正常に成立し得る分岐経路。 |
| `EXCEPTION` | 業務Errorまたは技術Error経路。 |
| `BOUNDARY` | 境界値・上限・下限を確認する経路。 |
| `TIMEOUT` | Timeout、停止、SkipおよびRecovery引渡しを確認する経路。 |

## 6. 参照整合性

| Validation ID | 確認内容 | 現在の判定 |
|---|---|---|
| `SC-MST-V001` | 正式表が固定10列と一致する。 | PASS |
| `SC-MST-V002` | 所属UseCaseと双方向Referenceが一致する。 | NOT_APPLICABLE（0件） |
| `SC-MST-V003` | Input、Expectedおよび詳細設計を解決できる。 | NOT_APPLICABLE（0件） |
| `SC-MST-V004` | `executionClass`をBuild対象で解決でき、`scenarioId`単位のScenario Registry Descriptorと完全一致する。 | NOT_APPLICABLE（0件） |
| `SC-MST-V005` | 有効Scenarioが無効APIを参照しない。 | NOT_APPLICABLE（0件） |
| `SC-MST-V006` | ExampleまたはRecoveryを正式Referenceにしていない。 | PASS |
| `SC-MST-R001` | 正式UseCaseのScenario Coverageが承認済みである。 | BLOCKED |

## 7. 要確認事項

| Issue ID | 確認事項 | 影響 | 状態 |
|---|---|---|---|
| `SC-MST-ISSUE-001` | 正式UseCaseとScenario Coverage | Scenario登録 | Open |
| `SC-MST-ISSUE-002` | Java Source Root、Base PackageおよびRegistry Descriptor抽出方式 | `executionClass`／Build Trace | Open |
| `SC-MST-ISSUE-003` | Input／Expected SchemaとBuild Validation | 実行前Gate | Open |

## 8. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `3.0.0-draft.1` | 2026-07-27 | 架空のSC-E6-001～003を正式一覧から除外。正式UseCaseとJava設計完了後に登録するGateを明文化。 |
| `3.0.0-draft.2` | 2026-07-28 | 第9バッチのScenario Registry Bindingに合わせ、`executionClass`のBuild解決、Descriptor完全一致および反射実行禁止Gateを同期。 |
