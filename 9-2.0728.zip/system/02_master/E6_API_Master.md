---
title: E6 API Master
document_id: MST-E6-API-001
version: 3.0.0-draft.1
status: DRAFT
data_status: EMPTY_PENDING_API_ANALYSIS
document_type: Master
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# E6 API Master

## 1. 文書目的

本書は、E6 API Verification Platformが参照するAPIの固定Identityおよび安定した技術属性を一元管理する正本である。

設計規則は`system/02_master/design/API_Master設計書.md`に従う。最終構造では本書を`API_Master.md`へ改名するが、本批では受控移行項目としてFile名を維持する。

## 2. 現在の登録状態

現行API仕様、API分析書およびProvider Reviewが未完了であるため、正式APIを登録しない。

| 区分 | 件数 | 状態 |
|---|---:|---|
| 正式API | 0 | `EMPTY_PENDING_API_ANALYSIS` |
| 有効API | 0 | 実行対象なし |
| 初期調査対象 | 約24 | 7業務Flowの分析後に確定 |

会話中の設計検討で作成した`API-001／002`はE6の確認済みAPIではないため、正式一覧から除外した。履歴は`recovery/synthetic_001_member_model/`に隔離する。

## 3. 正式API一覧

| apiId | apiName | systemId | method | endpointPath | requestDto | responseDto | apiDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|

空表に対して件数合わせの仮APIを登録してはならない。

## 4. 登録Gate

APIは次の条件をすべて満たした場合だけ登録する。

1. `business/API分析書/API-{NNN}分析書.md`または同等の正式Provider資料が存在する。
2. API名称、Method、Endpoint Pathおよび対象Systemを確認できる。
3. Request／Response DTOまたは契約の正本を特定できる。
4. `apiDesignRef`の作成責任と作成順序が確定している。
5. API OwnerのReview Evidenceがある。

未確認契約を`enabled=false`の正式レコードとして先行登録しない。

## 5. 参照整合性

| Validation ID | 確認内容 | 現在の判定 |
|---|---|---|
| `API-MST-V001` | 正式表が固定10列と一致する。 | PASS |
| `API-MST-V002` | API ID、Method、EndpointおよびDTOが根拠資料で確認済みである。 | NOT_APPLICABLE（0件） |
| `API-MST-V003` | `apiDesignRef`が正式API設計書を指す。 | NOT_APPLICABLE（0件） |
| `API-MST-V004` | Scenarioが参照する全APIを解決できる。 | NOT_APPLICABLE（Scenario 0件） |
| `API-MST-V005` | ExampleまたはRecoveryを正式Referenceにしていない。 | PASS |
| `API-MST-R001` | 約24 APIの分析、採番および登録が完了している。 | BLOCKED |

## 6. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| API呼出順序、条件、`apiCallCode` | Scenario詳細設計書／Java |
| Request／Response項目、型、必須、桁数 | API詳細設計書／Java DTO |
| API間Mapping | Scenario詳細設計書／Java |
| Expected、Business Check、Diff | Expected／Java Check／Diff設計 |
| Endpoint Host、Credential | Environment／Secret設定 |

## 7. 要確認事項

| Issue ID | 確認事項 | 影響 | 状態 |
|---|---|---|---|
| `API-MST-ISSUE-001` | 7業務FlowのAPI一覧と重複排除 | API Coverage | Open |
| `API-MST-ISSUE-002` | API分析書の正本PathとOwner | 登録根拠 | Open |
| `API-MST-ISSUE-003` | `E6_API_Master.md`から`API_Master.md`への改名時期 | Repository移行 | Open |

## 8. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `3.0.0-draft.1` | 2026-07-27 | 架空のAPI-001／002を正式一覧から除外。正式APIを0件とし、API分析完了後に登録するGateを明文化。 |
