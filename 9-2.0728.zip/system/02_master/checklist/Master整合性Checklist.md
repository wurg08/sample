---
title: Master整合性Checklist
document_id: CHECK-E6-MST-002
version: 2.0.0-draft.3
status: DRAFT
document_type: Checklist
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Master整合性Checklist

## 1. 目的

本Checklistは、E6 API Verification PlatformのMaster一式について、構文、Schema、ID、Reference、状態、正本関係、TraceabilityおよびRelease Gateの整合性を、同一条件で繰り返し確認するための基準を定義する。

本Checklistは機械検証および機械検証に準じた照合作業の正本である。業務妥当性、設計判断、指摘管理および承認は`MasterレビューChecklist.md`を正本とする。

## 2. 適用対象

### 2.1 正本Master

| 区分 | ファイル | 主ID |
|---|---|---|
| Business Master | `system/02_master/Business_Master.md` | `businessId` |
| Environment Master | `system/02_master/Environment_Master.md` | `environmentId` |
| API Master | `system/02_master/E6_API_Master.md` | `apiId` |
| UseCase Master | `system/02_master/UseCase_Master.md` | `useCaseId` |
| Scenario Master | `system/02_master/Scenario_Master.md` | `scenarioId` |

### 2.2 派生成果物

| 区分 | ファイル | 複合Key |
|---|---|---|
| Traceability View | `system/02_master/API_UseCase_Scenario対応表.md` | `scenarioId + apiCallCode` |

### 2.3 支援成果物

本Checklistは`design/`、`guide/`、`checklist/`および`examples/`の文書構造、参照、IDおよび責務境界も確認対象とする。

## 3. 責務分離

| 成果物 | 責務 | 本Checklistとの関係 |
|---|---|---|
| `MasterレビューChecklist.md` | 人による妥当性Review、指摘、承認 | 本ChecklistのEvidenceを受け取る |
| `Master整合性Checklist.md` | 再現可能な整合性検証 | Validation結果を生成する |
| 各Master設計書 | 正式列、型、必須、Enumおよび個別規則 | Schema検証の定義元 |
| `Master共通設計書.md` | 共通規則とRelease Gate | 共通Validationの定義元 |
| 対応表 | 横断追跡用View | 正本から導出して検証する |

本Checklistの結果だけで業務仕様を承認してはならない。また、人のReviewによってValidation `ERROR`を上書きしてはならない。

## 4. 実施記録

| 項目 | 記入欄 |
|---|---|
| Validation Run ID |  |
| Change ID |  |
| 対象Release |  |
| 対象Commit／Source Version |  |
| 実行日時 |  |
| 実行者 |  |
| Validation Tool Version |  |
| 対象ファイル一覧 |  |
| 結果Evidence Path |  |
| ERROR件数 |  |
| WARNING件数 |  |
| INFO件数 |  |
| 最終判定 | PASS／FAIL／BLOCKED |

## 5. 判定体系

### 5.1 Level

| Level | 意味 | Release |
|---|---|---|
| `ERROR` | 参照不能、重複、責務違反または実行不能につながる不整合 | Release不可 |
| `WARNING` | 直ちに実行不能ではないが、品質または保守性に懸念がある | 修正または承認が必要 |
| `INFO` | 件数、Coverageまたは状態の参考情報 | Releaseを妨げない |

### 5.2 Result

| Result | 意味 |
|---|---|
| `PASS` | 規則を満たす |
| `FAIL` | 規則違反を検出した |
| `BLOCKED` | 必須入力または参照先がなく判定不能 |
| `N/A` | 対象変更に適用しない。理由必須 |

`BLOCKED`は`PASS`として扱わない。Release必須規則が`BLOCKED`の場合、Release不可とする。

## 6. 実行順序と停止条件

```text
01 File Inventory
→ 02 Front Matter／Markdown
→ 03 単一Master Schema
→ 04 ID
→ 05 ID／File Reference
→ 06 Cross-Master
→ 07 Scenario詳細設計／Java
→ 08 Traceability View
→ 09 状態・責務境界
→ 10 Example分離
→ 11 Release Gate
```

構文解析不能、正式列不足または主ID重複が発生したファイルは、後続結果を誤認させないため当該ファイルのCross-Master検証を`BLOCKED`とする。

## 7. File Inventory整合性

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-FS-001` | `02_master`直下の正式MasterがBusiness、Environment、API、UseCase、Scenarioの5種類だけである。 | ERROR |  |  |
| `INT-FS-002` | 対応表がMasterではなくTraceability Viewとして1ファイルだけ存在する。 | ERROR |  |  |
| `INT-FS-003` | `design/`の正式ファイル構成がREADMEの固定一覧と一致する。 | ERROR |  |  |
| `INT-FS-004` | `guide/`の正式ファイル構成がREADMEの固定一覧と一致する。 | ERROR |  |  |
| `INT-FS-005` | `checklist/`にReview用と整合性用の2種類が存在する。 | ERROR |  |  |
| `INT-FS-006` | `examples/`に各正式Master／Viewに対応するExampleが存在する。 | WARNING |  |  |
| `INT-FS-007` | 同名の重複ファイル、`(1)`付き複製または未承認の派生版が正式範囲にない。 | ERROR |  |  |
| `INT-FS-008` | Context、Verification、Verification Policy、Compare Policy Masterが復活していない。 | ERROR |  |  |
| `INT-FS-009` | 未承認のDirectoryまたはMaster種別が追加されていない。 | ERROR |  |  |

## 8. Front Matter・Markdown整合性

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-DOC-001` | 全正式文書がYAML Front Matterを持つ。 | ERROR |  |  |
| `INT-DOC-002` | 新規・更新文書のキーが`snake_case`で統一され、同一文書内で`camelCase`と混在しない。 | ERROR |  |  |
| `INT-DOC-003` | `title`、`document_id`、`version`、`status`、`updated`が存在する。 | ERROR |  |  |
| `INT-DOC-004` | `document_id`が`02_master`内で一意である。 | ERROR |  |  |
| `INT-DOC-005` | `updated`が`YYYY-MM-DD`形式である。 | ERROR |  |  |
| `INT-DOC-006` | Markdown TableのHeader、Separatorおよび全Data Rowの列数が一致する。 | ERROR |  |  |
| `INT-DOC-007` | Code Fenceが対になり、Mermaid Blockが解析可能である。 | ERROR |  |  |
| `INT-DOC-008` | 内部File ReferenceがBacktickで記述され、実Pathと大小文字が一致する。 | ERROR |  |  |
| `INT-DOC-009` | 改訂履歴のVersion、日付および変更内容がFront Matterと一致する。 | WARNING |  |  |

既存設計書の旧`camelCase` Front Matterは移行対象として検出し、同一Change Setで更新しない場合は`WARNING`とする。新規または今回更新した文書での混在は`ERROR`とする。

## 9. 単一Master Schema整合性

### 9.1 API Master

正式列順は次の10項目とする。

```text
apiId
apiName
systemId
method
endpointPath
requestDto
responseDto
apiDesignRef
enabled
description
```

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-API-001` | 正式表が10列で、列名と順序が設計書に一致する。 | ERROR |  |  |
| `INT-API-002` | `apiId`が一意で`API-NNN`形式である。 | ERROR |  |  |
| `INT-API-003` | `method`が許可Enumである。 | ERROR |  |  |
| `INT-API-004` | `endpointPath`が`/`で始まり、Host、Query実値またはEnvironment差分を含まない。 | ERROR |  |  |
| `INT-API-005` | 同一APIがScenarioごとまたは呼出回数ごとに重複登録されていない。 | ERROR |  |  |
| `INT-API-006` | 有効APIのDTO、詳細設計および実装参照が解決できる。 | ERROR |  |  |

### 9.2 UseCase Master

正式列順は次の10項目とする。

```text
useCaseId
useCaseName
businessIds
businessPurpose
businessScope
preconditionSummary
applicableEnvironmentIds
scenarioIds
useCaseDesignRef
enabled
```

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-UC-001` | 正式表が10列で、列名と順序が設計書に一致する。 | ERROR |  |  |
| `INT-UC-002` | `useCaseId`が一意で`UC-E6-NNN`形式である。 | ERROR |  |  |
| `INT-UC-003` | `businessIds`と`applicableEnvironmentIds`に重複がない。 | ERROR |  |  |
| `INT-UC-004` | `scenarioIds`が重複せず、Scenario Masterとの完全な双方向関係を表す。 | ERROR |  |  |
| `INT-UC-005` | 有効UseCaseに1件以上の有効Scenarioが存在する。 | ERROR |  |  |
| `INT-UC-006` | API呼出順序、ExpectedまたはCheck明細が正式列へ混入していない。 | ERROR |  |  |

### 9.3 Scenario Master

正式列順は次の10項目とする。

```text
scenarioId
useCaseId
scenarioName
scenarioType
executionClass
inputRef
expectedRef
scenarioDesignRef
enabled
description
```

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-SC-001` | 正式表が10列で、列名と順序が設計書に一致する。 | ERROR |  |  |
| `INT-SC-002` | `scenarioId`が一意で`SC-E6-NNN`形式である。 | ERROR |  |  |
| `INT-SC-003` | `scenarioType`が許可Enumである。 | ERROR |  |  |
| `INT-SC-004` | `executionClass`が完全修飾Class名形式である。 | ERROR |  |  |
| `INT-SC-005` | 有効ScenarioのInput、Expected、詳細設計およびJava Classが解決できる。 | ERROR |  |  |
| `INT-SC-006` | API呼出明細、`apiCallCode`、`resultKey`またはCheck明細が正式列へ混入していない。 | ERROR |  |  |
| `INT-SC-007` | Scenario Registryが`scenarioId`で一件解決し、Descriptorの`implementationType`が`executionClass`と完全一致する。 | ERROR |  |  |

### 9.4 Business・Environment Master

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-BUS-001` | Business正式列がBusiness Master設計書と一致する。 | ERROR |  |  |
| `INT-BUS-002` | `businessId`が一意で`BUS-E6-NNN`形式である。 | ERROR |  |  |
| `INT-ENV-001` | Environment正式列がEnvironment Master設計書と一致する。 | ERROR |  |  |
| `INT-ENV-002` | `environmentId`が一意で定義Patternに一致する。 | ERROR |  |  |
| `INT-ENV-003` | Credential、Secretまたは個人情報が記載されていない。 | ERROR |  |  |

## 10. ID整合性

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-ID-001` | `businessId`が全システムScopeで一意である。 | ERROR |  |  |
| `INT-ID-002` | `environmentId`が全システムScopeで一意である。 | ERROR |  |  |
| `INT-ID-003` | `apiId`が全システムScopeで一意である。 | ERROR |  |  |
| `INT-ID-004` | `useCaseId`が全システムScopeで一意である。 | ERROR |  |  |
| `INT-ID-005` | `scenarioId`が全システムScopeで一意である。 | ERROR |  |  |
| `INT-ID-006` | `apiCallCode`が一つのScenario内で一意である。 | ERROR |  |  |
| `INT-ID-007` | `resultKey`が定義されたScope内で一意かつ安定している。 | ERROR |  |  |
| `INT-ID-008` | 廃止済みID、欠番または900番台正式IDが再利用されていない。 | ERROR |  |  |
| `INT-ID-009` | 名称、Path、Class名、`callSequence`または表示順をIdentityとして使用していない。 | ERROR |  |  |
| `INT-ID-010` | Exampleの900番台IDが正式Masterまたは正式Viewへ混入していない。 | ERROR |  |  |

## 11. ID Reference整合性

| Rule ID | 参照元 | 参照先正本 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|---|
| `INT-REF-001` | UseCase `businessIds` | Business Master `businessId` | ERROR |  |  |
| `INT-REF-002` | UseCase `applicableEnvironmentIds` | Environment Master `environmentId` | ERROR |  |  |
| `INT-REF-003` | UseCase `scenarioIds` | Scenario Master `scenarioId` | ERROR |  |  |
| `INT-REF-004` | Scenario `useCaseId` | UseCase Master `useCaseId` | ERROR |  |  |
| `INT-REF-005` | Scenario詳細設計 `apiId` | API Master `apiId` | ERROR |  |  |
| `INT-REF-006` | 対応表の各ID | 各Master／Scenario詳細設計 | ERROR |  |  |
| `INT-REF-007` | 有効レコード | 有効な必須参照先 | ERROR |  |  |
| `INT-REF-008` | List Reference | 重複なし、空要素なし、定義された区切り | ERROR |  |  |

## 12. UseCase・Scenario双方向整合性

各`UC`について、次の集合一致を検証する。

```text
UseCase_Master.scenarioIds
==
Scenario_Master[useCaseId = 対象UseCase].scenarioId
```

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-US-001` | UseCase側だけに存在するScenarioがない。 | ERROR |  |  |
| `INT-US-002` | Scenario側だけに所属するScenarioがない。 | ERROR |  |  |
| `INT-US-003` | 一つのScenarioが複数UseCaseへ所属していない。 | ERROR |  |  |
| `INT-US-004` | 無効Scenarioを含む場合も所属関係自体は追跡可能である。 | ERROR |  |  |
| `INT-US-005` | `scenarioIds`の並びを実行順序として扱っていない。 | ERROR |  |  |

## 13. Scenario・API整合性

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-SA-001` | 有効Scenarioに1件以上の正式API呼出実体がある。 | ERROR |  |  |
| `INT-SA-002` | 全呼出実体の`apiId`がAPI Masterで解決できる。 | ERROR |  |  |
| `INT-SA-003` | 有効Scenarioが無効APIを参照していない。 | ERROR |  |  |
| `INT-SA-004` | 同一APIの複数回呼出が異なる`apiCallCode`で識別される。 | ERROR |  |  |
| `INT-SA-005` | `callSequence`がScenario内で一意の正整数である。 | ERROR |  |  |
| `INT-SA-006` | 条件付き呼出の条件元が先行呼出または明示入力で解決できる。 | ERROR |  |  |
| `INT-SA-007` | Skip、停止、TimeoutおよびRetryの経路がScenario詳細設計とJavaで一致する。 | ERROR |  |  |

## 14. Traceability View整合性

正式表示列は次の14項目とする。

```text
useCaseId
useCaseName
scenarioId
scenarioName
scenarioType
callSequence
apiCallCode
apiId
apiName
callPurpose
executeCondition
scenarioDesignRef
apiDesignRef
relationStatus
```

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-TRC-001` | 正式表が14列で、列名と順序が設計書に一致する。 | ERROR |  |  |
| `INT-TRC-002` | `scenarioId + apiCallCode`が一意である。 | ERROR |  |  |
| `INT-TRC-003` | 名称、TypeおよびDesign Referenceが各正本と一致する。 | ERROR |  |  |
| `INT-TRC-004` | `callSequence`、目的および条件がScenario詳細設計と一致する。 | ERROR |  |  |
| `INT-TRC-005` | `relationStatus`がUseCase、Scenario、APIの`enabled`から導出される。 | ERROR |  |  |
| `INT-TRC-006` | 有効Scenarioの正式呼出実体がすべてViewへ展開されている。 | ERROR |  |  |
| `INT-TRC-007` | 詳細設計に存在しない推測行がViewへ追加されていない。 | ERROR |  |  |
| `INT-TRC-008` | Viewの手修正を正本またはJavaへ逆反映していない。 | ERROR |  |  |
| `INT-TRC-009` | 順方向と逆方向の件数が一致する。 | ERROR |  |  |
| `INT-TRC-010` | Orphan UseCase、Scenario、APIまたはAPI Callがない。 | ERROR |  |  |

## 15. File・Java Reference整合性

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-PATH-001` | File ReferenceがRepository Root基準の相対Pathである。 | ERROR |  |  |
| `INT-PATH-002` | `./`、`../`、絶対Path、URLまたは個人PC Pathを使用していない。 | ERROR |  |  |
| `INT-PATH-003` | 有効APIの`apiDesignRef`が存在する。 | ERROR |  |  |
| `INT-PATH-004` | 有効UseCaseの`useCaseDesignRef`が存在する。 | ERROR |  |  |
| `INT-PATH-005` | 有効Scenarioの`inputRef`、`expectedRef`、`scenarioDesignRef`が存在する。 | ERROR |  |  |
| `INT-PATH-006` | 有効Scenarioの`executionClass`がBuild対象で解決でき、Scenario Registry Bindingから双方向に追跡できる。 | ERROR |  |  |
| `INT-PATH-007` | 有効APIのRequest／Response DTOがBuild対象で解決できる。 | ERROR |  |  |
| `INT-PATH-008` | File名に対象IDが含まれ、参照対象を一意に判別できる。 | WARNING |  |  |

## 16. 状態・Lifecycle整合性

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-STS-001` | 文書`status`とMasterレコード`enabled`を別項目として扱う。 | ERROR |  |  |
| `INT-STS-002` | `DRAFT`または`IN_REVIEW`文書をRelease入力として扱っていない。 | ERROR |  |  |
| `INT-STS-003` | `DEPRECATED`／`RETIRED`文書または無効レコードが新規の有効関係から参照されていない。 | ERROR |  |  |
| `INT-STS-004` | `relationStatus`を手入力で正本状態と異なる値へ変更していない。 | ERROR |  |  |
| `INT-STS-005` | 未確認値または未完成資産を持つ対象が`enabled=true`になっていない。 | ERROR |  |  |
| `INT-STS-006` | 無効化・置換後も過去Runから旧IDを解決できる。 | ERROR |  |  |
| `INT-STS-007` | 物理削除対象の参照が0件で、承認Evidenceが存在する。 | ERROR |  |  |

## 17. 責務境界整合性

| Rule ID | Masterへ混入してはならない情報 | 正式な管理先 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|---|
| `INT-SOR-001` | API呼出順序、分岐、Skip、`apiCallCode` | Scenario詳細設計／Java | ERROR |  |  |
| `INT-SOR-002` | Request実値、Test Data、値引継ぎ | Scenario Input／Java | ERROR |  |  |
| `INT-SOR-003` | Expected値、`resultKey`、Business Check | Expected／Java Check | ERROR |  |  |
| `INT-SOR-004` | `IGNORE_FIELD`、`IGNORE_VALUE` | Java比較定義 | ERROR |  |  |
| `INT-SOR-005` | Context、ApiExchange、Run ID | Runtime Object／Run成果物 | ERROR |  |  |
| `INT-SOR-006` | Previous、Current、Baseline、Diff | Execution State／Diff成果物 | ERROR |  |  |
| `INT-SOR-007` | Execution／Verification／Change／Recoveryの実行結果 | Run Result／Verification Result | ERROR |  |  |
| `INT-SOR-008` | Retry、Timeout、並列数、Scheduler時刻 | Runtime／運用設計 | ERROR |  |  |

## 18. Example分離整合性

| Rule ID | 確認内容 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `INT-EX-001` | Exampleの`status`がCanonical Lifecycle値であり、File名と`document_type`でExampleと識別できる。 | ERROR |  |  |
| `INT-EX-002` | Example本文に架空値であることが明記される。 | ERROR |  |  |
| `INT-EX-003` | Example IDが900番台で統一される。 | ERROR |  |  |
| `INT-EX-004` | Example内のAPI、UseCase、Scenarioおよび対応表参照が相互に解決できる。 | ERROR |  |  |
| `INT-EX-005` | Example値が正式Masterまたは正式Coverageへ集計されない。 | ERROR |  |  |
| `INT-EX-006` | 誤記例に期待するValidation Errorが明記される。 | WARNING |  |  |

## 19. Coverage整合性

| Rule ID | 指標 | 算出方法 | Level | 結果 | Evidence／Comment |
|---|---|---|---|---|---|
| `INT-COV-001` | UseCase数 | UseCase Masterの正式レコード数 | INFO |  |  |
| `INT-COV-002` | Scenario数 | Scenario Masterの正式レコード数 | INFO |  |  |
| `INT-COV-003` | 有効Scenario Coverage | API呼出を持つ有効Scenario数／有効Scenario数 | ERROR |  |  |
| `INT-COV-004` | API参照Coverage | 1件以上参照される有効API数／対象有効API数 | WARNING |  |  |
| `INT-COV-005` | Orphan API数 | 対象範囲内で参照0件のAPI数 | WARNING |  |  |
| `INT-COV-006` | INACTIVE関係数 | 有効Scenarioに含まれる非ACTIVE行数 | ERROR |  |  |
| `INT-COV-007` | 未展開Scenario数 | 呼出詳細を持たないScenario数を状態別集計 | INFO |  |  |

Coverage件数だけで業務網羅性を承認してはならない。7業務Flowとの網羅性はBA分析およびReviewで別途確認する。

## 20. 現行E6データ検証結果

2026-07-27時点では、Business、API、UseCase、Scenarioおよび対応表の正式レコードは0件である。構造と分離規則は検証し、レコード間Validationは`NOT_APPLICABLE`とする。

| Validation ID | 確認内容 | 結果 | Level | 処置 |
|---|---|---|---|---|
| `TRC-V001` | 対応表が正式14列である。 | PASS | ERROR | なし |
| `TRC-V002` | `scenarioId + apiCallCode`が一意である。 | NOT_APPLICABLE | ERROR | 正式Scenario登録後に実行 |
| `TRC-V004` | UseCase／Scenario参照が解決できる。 | NOT_APPLICABLE | ERROR | 正式登録後に実行 |
| `TRC-V005` | API参照がAPI Masterで解決できる。 | NOT_APPLICABLE | ERROR | 正式登録後に実行 |
| `TRC-V006` | UseCase／Scenario双方向関係が一致する。 | NOT_APPLICABLE | ERROR | 正式登録後に実行 |
| `TRC-V007` | 有効ScenarioにAPI呼出が存在する。 | NOT_APPLICABLE | ERROR | 正式登録後に実行 |
| `TRC-V008` | 有効Scenarioが無効APIを参照しない。 | NOT_APPLICABLE | ERROR | 正式登録後に実行 |
| `INT-EX-001` | 900番台Exampleが正式Masterへ混入していない。 | PASS | ERROR | なし |
| `INT-REC-001` | Recoveryが正式Master／Runtimeから参照されていない。 | PASS | ERROR | なし |
| `INT-COV-001` | 7業務FlowのBusiness Coverageが確認済みである。 | BLOCKED | ERROR | Business分析とReviewを完了する |

したがって、現行Master一式のRelease判定は`BLOCKED`である。理由はレコード不整合ではなく、正式業務・API登録が未開始で実行対象が0件であるためである。

## 21. Release Gate

| Gate ID | Gate条件 | 必須結果 | 結果 | Evidence／Comment |
|---|---|---|---|---|
| `GATE-MST-001` | 対象文書が承認済み状態である。 | PASS |  |  |
| `GATE-MST-002` | 正式列と責務境界が設計書に一致する。 | PASS |  |  |
| `GATE-MST-003` | Validation `ERROR`が0件である。 | PASS |  |  |
| `GATE-MST-004` | `WARNING`が修正済みまたは承認済みである。 | PASS |  |  |
| `GATE-MST-005` | 有効IDと必須Referenceがすべて解決できる。 | PASS |  |  |
| `GATE-MST-006` | 有効UseCaseに有効Scenarioが存在する。 | PASS |  |  |
| `GATE-MST-007` | 有効Scenarioに正式API呼出が存在する。 | PASS |  |  |
| `GATE-MST-008` | 有効Scenarioが無効APIを参照しない。 | PASS |  |  |
| `GATE-MST-009` | 対応表が正本とScenario詳細設計に一致する。 | PASS |  |  |
| `GATE-MST-010` | 改訂履歴、影響分析、Reviewおよび承認Evidenceが存在する。 | PASS |  |  |

一つでも`FAIL`または`BLOCKED`がある場合、Release判定は`FAIL`とする。

## 22. Validation結果記録

| Rule ID | Result | Actual | Expected | Source | Evidence | Issue ID |
|---|---|---|---|---|---|---|
|  | PASS／FAIL／BLOCKED／N/A |  |  |  |  |  |

Validation Toolは、少なくともRule ID、Result、対象ID、対象ファイル、期待値、実値およびEvidenceを出力する。

## 23. 完了条件

本Checklistによる整合性確認は、次をすべて満たした時点で完了とする。

1. 適用対象ファイルのInventoryが固定されている。
2. 全必須Ruleに結果とEvidenceがある。
3. `BLOCKED`に不足入力と再実行条件が記録されている。
4. `FAIL`にIssue ID、Owner、期限およびRelease影響が設定されている。
5. Cross-Master、Scenario詳細設計、JavaおよびTraceability Viewの照合が完了している。
6. Coverage値が同一Source Versionから算出されている。
7. Release Gate判定が`MasterレビューChecklist.md`へEvidenceとして引き渡されている。

## 24. 禁止事項

1. Validation ErrorをViewの手修正で隠す。
2. `BLOCKED`を`PASS`または`N/A`へ置換する。
3. `enabled=false`でOrphan、重複または参照不能を正当化する。
4. 人の承認だけで`ERROR`を解除する。
5. Exampleを正式Masterと同じ集計対象にする。
6. 異なるCommitまたはSource Versionのファイルを混在させて検証する。
7. 実在しない参照先を存在すると推測して判定する。

## 25. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 五つのMaster、Traceability View、Scenario詳細設計およびJavaを対象とするCross-Master整合性Checklistとして全面再作成し、Lifecycle ValidationをCanonical値へ統一。 |
| `2.0.0-draft.2` | 2026-07-27 | Framework横断再走査によりMaster非保持対象の実行結果をCanonical四結果軸へ統一。 |
| `2.0.0-draft.3` | 2026-07-28 | 第9バッチとしてScenario Registryの一意解決、Class完全一致、Build IdentityおよびReverse Binding検証を追加。 |
