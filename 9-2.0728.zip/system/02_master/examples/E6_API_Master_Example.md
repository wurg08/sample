---
title: E6 API Master記入例
document_id: EX-MST-E6-API-001
version: 1.0.0-draft.1
status: DRAFT
document_type: Master Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# E6 API Master記入例

## 1. 目的

本書は、`E6_API_Master.md`の正式10項目を記入する際の形式、粒度および禁止事項を示す例である。

本書中の`API-901～903`、名称、Path、DTOおよび参照先は説明用の架空値であり、実システムのMasterへコピーしてはならない。

## 2. 記入例

| apiId | apiName | systemId | method | endpointPath | requestDto | responseDto | apiDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|
| API-901 | 注文情報取得API | EXAMPLE | GET | /api/v1/orders/{orderId} | NONE | OrderDetailResponse | system/03_api_design/examples/API-901設計書_Example.md | true | 注文IDを指定して注文情報を取得する。 |
| API-902 | 注文状態更新API | EXAMPLE | PATCH | /api/v1/orders/{orderId}/status | OrderStatusUpdateRequest | OrderStatusUpdateResponse | system/03_api_design/examples/API-902設計書_Example.md | true | 指定注文の状態を更新する。 |
| API-903 | 旧注文検索API | EXAMPLE | POST | /api/v0/orders/search | LegacyOrderSearchRequest | LegacyOrderSearchResponse | system/03_api_design/examples/API-903設計書_Example.md | false | 旧方式の検索条件で注文を検索する廃止予定API。 |

## 3. 項目別の読み方

| 項目 | API-901の例 | 説明 |
|---|---|---|
| `apiId` | `API-901` | API自身の固定Identity。Scenarioごとに採番しない。 |
| `apiName` | 注文情報取得API | 処理対象と目的が分かる正式名称。 |
| `systemId` | `EXAMPLE` | Provider側システムの固定ID。Environment名は設定しない。 |
| `method` | `GET` | 許可Enumを大文字で設定する。 |
| `endpointPath` | `/api/v1/orders/{orderId}` | Scheme、Host、具体的なPath値およびQuery Stringを含めない。 |
| `requestDto` | `NONE` | Request Body用DTOが存在しないことを明示する。 |
| `responseDto` | `OrderDetailResponse` | Javaプロジェクト内で一意なClass名を設定する。 |
| `apiDesignRef` | `system/03_api_design/examples/API-901設計書_Example.md` | Repository Root基準の相対Path。 |
| `enabled` | `true` | 新規Scenarioから参照可能。 |
| `description` | 注文IDを指定して注文情報を取得する。 | Scenario固有の期待値を含めずAPI機能を一文で示す。 |

## 4. 同一APIを複数回呼び出す例

次の二つの呼出は、同じ`API-901`を参照する。API Masterへ`API-901`を2行登録しない。

| scenarioId | apiCallCode | apiId | 呼出目的 |
|---|---|---|---|
| SC-E6-901 | CALL-001 | API-901 | 更新前注文情報取得 |
| SC-E6-901 | CALL-003 | API-901 | 更新後注文情報再取得 |

`apiCallCode`と呼出目的はScenario詳細設計書で定義し、API Masterの列には追加しない。

## 5. 有効・無効の使い分け

| 状態 | 設定 | 取扱い |
|---|---|---|
| 現行APIとして新規参照可能 | `enabled=true` | API詳細設計、DTOおよび実装が解決可能であることを確認する。 |
| 廃止予定または参照禁止 | `enabled=false` | レコードを履歴として保持し、新しい有効Scenarioから参照しない。 |
| 仕様未確認 | 正式レコードへ未登録 | `TBD`値で行を作らず、要確認事項として管理する。 |

## 6. 誤記例

| 誤記 | 問題 | 正しい対応 |
|---|---|---|
| `https://stg.example.com/api/v1/orders/O001?detail=true` | Host、Environment、具体値、Query Stringを含む。 | `/api/v1/orders/{orderId}`とする。 |
| `API-901-STG` | Environment別にAPI IDを分割している。 | Environmentに依存しない`API-901`を使用する。 |
| Request DTOを空欄にする | 未設定かDTO不要か判別できない。 | DTO不要の場合は`NONE`とする。 |
| `CALL-001`列を追加する | APIとScenario呼出実体の責務が混在する。 | Scenario詳細設計書で管理する。 |
| 「レスポンスのstatusがDONEになる」 | Scenario固有ExpectedがAPI概要へ混入する。 | ExpectedまたはJava Checkで管理する。 |
| 未確認Endpointを仮登録して`enabled=true`にする | 誤ったPathが正式値として利用される。 | 正式仕様確認まで登録または有効化を保留する。 |

## 7. 記入時Validation

| Rule | 確認内容 |
|---|---|
| API-EX-V001 | 全10項目が設定されている。 |
| API-EX-V002 | `apiId`が`^API-[0-9]{3}$`に一致し、Master内で一意である。 |
| API-EX-V003 | `method`が許可Enumに含まれる。 |
| API-EX-V004 | `endpointPath`が`/`で始まり、Scheme、HostおよびQuery Stringを含まない。 |
| API-EX-V005 | DTO未使用時に`NONE`が明示されている。 |
| API-EX-V006 | `apiDesignRef`の参照先とAPI ID、Method、PathおよびDTOが一致する。 |
| API-EX-V007 | 有効APIのDTOおよび実装がBuild時に解決できる。 |
| API-EX-V008 | `apiCallCode`、Expected、ContextおよびDiff規則が混入していない。 |

## 8. 正式Master反映前Checklist

- [ ] API分析書または現行API仕様で名称、MethodおよびEndpointを確認した。
- [ ] Provider側`systemId`を確認した。
- [ ] Request／Response DTOをJava実装と照合した。
- [ ] API詳細設計書の参照先と内容を確認した。
- [ ] 既存APIとの重複を確認した。
- [ ] 新規Scenarioから参照可能な状態か確認した。
- [ ] 未確認値を推測で設定していない。
- [ ] Scenario、Expected、VerificationまたはCompareの項目を追加していない。

## 9. 参照先

- 正式Master：`system/02_master/E6_API_Master.md`
- 設計規則：`system/02_master/design/API_Master設計書.md`
