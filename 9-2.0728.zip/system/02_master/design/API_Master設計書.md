---
title: API Master設計書
document_id: E6-API-VAL-MST-API-DESIGN
version: 1.0.0-draft.4
status: DRAFT
document_type: Master詳細設計書
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# API Master設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | API Master設計書 |
| 文書ID | `E6-API-VAL-MST-API-DESIGN` |
| 対象システム | E6 API Verification Platform |
| 対象Master | `system/02_master/E6_API_Master.md` |
| 文書種別 | Master詳細設計書 |
| 版数 | `1.0.0-draft.4` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Verification Platform Team |
| レビュー責任 | System Architect / API Analysis Lead / Runtime Lead |
| 承認責任 | System Owner / API Owner |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-25 | Master体系の再編後の責務に基づき全面再作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | Front Matterを`snake_case`へ移行し、Current Architecture、現行Cross-Master Blockerおよび次工程を再確認 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | Canonical Lifecycle Enumへの統一に伴いRelease表記を同期 | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | API-001／002詳細設計書作成後のReference解決状態と残存契約Blockerを同期 | DRAFT |

## 3. 目的

本書は、E6 API Verification Platformで使用するAPI Masterの責務、管理項目、記述形式、整合性規則、変更管理および関連成果物との境界を定義する。

API Masterは、全システムを通じて各APIを一度だけ登録し、次の問いに対する正本を提供する。

- どのAPIが存在するか。
- APIを一意に識別するIDは何か。
- APIはどのシステムに属するか。
- HTTP MethodおよびEndpoint Pathは何か。
- 対応するRequest／Response DTOは何か。
- API詳細設計書はどこにあるか。
- 現在利用可能なAPIか。

API Masterは、ScenarioごとのAPI呼出方法や、Request／Responseのフィールド詳細、検証・比較・期待結果を定義するものではない。

## 4. 適用範囲

本書は、検証ツールが認識または呼び出す次のAPIに適用する。

- E6業務システムAPI
- 関連内部システムAPI
- 認証・Token取得API
- 参照・検索API
- 登録・更新API
- 非同期処理受付・状態照会API
- 検証環境用Stub API

初期管理対象は、7業務Flowで使用する約24 APIを想定する。API件数の増減によって、本書の責務または1 API 1レコードの原則は変更しない。

## 5. 基本原則

| 原則ID | 原則 | 説明 |
|---|---|---|
| `API-MST-P001` | 1 API 1レコード | 同一APIをUseCaseまたはScenarioごとに重複登録しない。 |
| `API-MST-P002` | API定義と呼出実体の分離 | `apiId`はAPI Master、`apiCallCode`はScenarioで管理する。 |
| `API-MST-P003` | 安定属性のみ管理 | APIの固定識別情報と詳細設計参照だけを管理する。 |
| `API-MST-P004` | フィールド定義を重複保持しない | Request／Responseの項目定義はAPI詳細設計書およびDTOを正本とする。 |
| `API-MST-P005` | Environment値を保持しない | Base URL、Credential、Proxy等の環境依存値を保持しない。 |
| `API-MST-P006` | 実行・検証結果を保持しない | Request／Response実値、Expected、Diff、Check結果を保持しない。 |
| `API-MST-P007` | 参照可能性を保証する | `apiId`からAPI詳細設計書および実装DTOを追跡できること。 |
| `API-MST-P008` | 物理削除を原則禁止する | 利用停止APIは履歴追跡のためレコードを削除せず、`enabled=false`とする。 |

## 6. 責務

API Masterは、次の情報を管理する。

1. APIの固定識別子
2. API名称および概要
3. 所属システム
4. HTTP Method
5. Endpoint Path
6. Request DTO識別子
7. Response DTO識別子
8. API詳細設計書への参照
9. APIの有効・無効状態

API Masterを参照する側は、`apiId`を使用して対象APIを解決する。名称やEndpoint Pathを外部参照キーとして使用してはならない。

## 7. 管理対象外

次の情報はAPI Masterに定義しない。

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| `apiCallCode` | Scenario設計 |
| Scenario内のAPI呼出順序 | Scenario詳細設計書 |
| 分岐、Skip、停止条件 | Scenario設計およびScenario Java実装 |
| 初期入力値 | Scenario入力データ |
| 前段Responseから後段Requestへの値引継ぎ | Scenario Java実装 |
| Request／ResponseのJSON項目、Java変数名、型、必須、長さ、固定値、許容値 | API詳細設計書およびDTO |
| HTTP Status、Error Responseの詳細契約 | API詳細設計書 |
| Base URL、接続先、Credential、TLS、Proxy | Environment Masterおよび実行環境設定 |
| `Expected`、`resultKey` | Scenario Expected、検証結果・Expected設計およびJava Check実装 |
| 業務必須、非空、桁数、固定値、属性値、状態遷移等の判定 | Business Check |
| 前回・今回Responseの差分結果 | API Response Diff |
| `IGNORE_FIELD`、`IGNORE_VALUE` | API専用Java比較定義およびAPIレスポンスDiff設計書 |
| Run ID、実行日時、Request／Response実値 | RunContext、Snapshot、実行成果物 |

特に、比較除外フィールドをAPI Masterの列として追加してはならない。比較除外の既定値は`apiId`単位のJava比較定義で管理し、Scenario固有の差異は`apiCallCode`単位で上書きする。

## 8. 関連成果物と責務境界

```mermaid
flowchart TD
    M["E6_API_Master.md<br/>API固定定義"]
    D["03_api_design<br/>項目・契約詳細"]
    U["UseCase Master<br/>業務目的"]
    S["Scenario詳細設計<br/>呼出実体・順序"]
    T["対応表<br/>Traceability View"]
    J["Java実装<br/>呼出・値引継ぎ・Diff・Check"]

    M --> D
    M --> S
    M --> T
    U --> S
    U --> T
    S --> T
    D --> J
    S --> J
```

| 成果物 | API Masterとの関係 | API Masterが参照するか |
|---|---|---:|
| `Business_Master.md` | 業務の固定識別と概要を管理する。APIと業務の利用関係は対応表上で参照表示する。 | No |
| `Environment_Master.md` | 環境別接続情報を管理する。API Masterは環境値を持たない。 | No |
| `03_api_design/API-XXX設計書.md` | Request／Response、Status、Error等の詳細契約を定義する。 | Yes |
| `UseCase_Master.md` | 検証対象となる業務目的と範囲を管理する。 | No |
| `Scenario_Master.md` | Scenarioの固定識別、条件および実行パターンを管理する。 | No |
| `API_UseCase_Scenario対応表.md` | UseCase、Scenario、`apiId`の利用関係を正本から生成して表示する。 | No |
| Scenario設計書 | `apiCallCode`、API呼出順序、分岐および呼出条件を定義する。 | No |
| APIレスポンスDiff設計書 | Response構造・値の差分および無視判定を定義する。 | No |
| Java API Client | `apiId`を解決し、API詳細設計とDTOに従って呼び出す。 | Consumer |

## 9. API定義モデル

### 9.1 正式レコード

`E6_API_Master.md`では、1行を1 APIの正式レコードとする。

| No. | 表示名 | 列名 | 型 | 必須 | 設定規則 |
|---:|---|---|---|:---:|---|
| 1 | API ID | `apiId` | String | Yes | `API-NNN`形式。一意かつ不変。 |
| 2 | API名称 | `apiName` | String | Yes | 業務担当者と開発担当者が識別できる正式名称。 |
| 3 | 所属システムID | `systemId` | String | Yes | APIを提供するシステムの固定識別子。 |
| 4 | HTTP Method | `method` | Enum | Yes | `GET`、`POST`、`PUT`、`PATCH`、`DELETE`のいずれか。 |
| 5 | Endpoint Path | `endpointPath` | String | Yes | Hostを含まない絶対Path。先頭は`/`。 |
| 6 | Request DTO | `requestDto` | String | Yes | Java Request DTOの完全修飾名またはプロジェクト内で一意なClass名。存在しない場合は`NONE`。 |
| 7 | Response DTO | `responseDto` | String | Yes | Java Response DTOの完全修飾名またはプロジェクト内で一意なClass名。存在しない場合は`NONE`。 |
| 8 | API設計書参照 | `apiDesignRef` | Path | Yes | Repository Root基準の相対Path。 |
| 9 | 有効フラグ | `enabled` | Boolean | Yes | `true`または`false`。 |
| 10 | API概要 | `description` | String | Yes | APIの目的を一文で記述する。 |

### 9.2 記述形式

```markdown
| apiId | apiName | systemId | method | endpointPath | requestDto | responseDto | apiDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|---:|---|
| API-901 | 注文情報取得API | EXAMPLE | POST | /api/v1/orders/search | OrderSearchRequest | OrderSearchResponse | system/03_api_design/examples/API-901設計書_Example.md | true | 注文番号を指定して注文情報を取得する架空Example。 |
```

### 9.3 `apiId`と`apiCallCode`の区別

| 識別子 | 意味 | 定義単位 | 例 |
|---|---|---|---|
| `apiId` | APIそのものの固定識別子 | API Masterで1回 | `API-001` |
| `apiCallCode` | 特定Scenario内の呼出実体 | Scenarioの呼出ごと | `CALL-001` |

同一APIを複数回呼び出す場合も、API Masterのレコードは増やさない。

| scenarioId | apiCallCode | apiId | 説明 |
|---|---|---|---|
| `SC-001` | `CALL-001` | `API-001` | 更新前照会 |
| `SC-001` | `CALL-003` | `API-001` | 更新後照会 |
| `SC-002` | `CALL-002` | `API-001` | 別Scenarioでの照会 |

## 10. 項目別設計規則

### 10.1 API ID

- 形式は`API-NNN`とする。
- 初回登録後は変更しない。
- 欠番を許容し、既存番号を再利用しない。
- APIを置換する場合は、新しい`apiId`を採番し、旧APIを`enabled=false`とする。
- 表示順は`apiId`の昇順を基本とする。

Pattern:

```regex
^API-[0-9]{3}$
```

### 10.2 API名称

- 日本語の正式名称を使用する。
- 「取得」「登録」「更新」「削除」「照会」等、処理目的が判別できる名称とする。
- Environment名、Scenario名、TestCase名を含めない。
- API名称を参照キーとして使用しない。

### 10.3 所属システムID

- APIを提供するシステムを示す。
- Consumer側システムではなくProvider側システムを設定する。
- 同一APIに複数の所属システムを設定しない。
- Environment固有のHost名またはURLを設定しない。

### 10.4 HTTP Method

- 大文字で記述する。
- 実際のAPI仕様およびAPI詳細設計書と一致させる。
- Method変更は互換性影響ありとして扱い、API詳細設計、ScenarioおよびJava Clientへの影響を確認する。

### 10.5 Endpoint Path

- `https://host.example.com`等のSchemeおよびHostを含めない。
- Query Stringおよび具体的なPath Parameter値を含めない。
- Path Parameterは`{memberId}`形式で記述する。
- 末尾`/`の有無はAPI仕様に合わせて統一する。
- Base URLはEnvironment Masterまたは実行環境設定で解決する。

正しい例:

```text
/api/v1/members/{memberId}
```

誤った例:

```text
https://dev.example.com/api/v1/members/M001?detail=true
```

### 10.6 Request／Response DTO

- API MasterにはClass識別子のみを記載する。
- DTOのフィールド一覧、JSON名、型、必須、長さ等を記載しない。
- DTOが存在しない場合は空欄にせず`NONE`を設定する。
- 同名Classが複数Packageに存在する場合は完全修飾Class名を使用する。
- API詳細設計書に記載されたDTOと一致させる。

### 10.7 API設計書参照

- Repository Root基準の相対Pathで記述する。
- 原則として1 APIにつき1 API詳細設計書を参照する。
- 参照先が存在しない状態で`enabled=true`にしてはならない。
- File名変更時は同一変更単位で参照を更新する。

### 10.8 有効フラグ

| 値 | 意味 |
|---|---|
| `true` | 新規Scenarioから参照可能。 |
| `false` | 新規Scenarioから参照不可。履歴および既存成果物の追跡目的で保持する。 |

`enabled=false`は過去実行結果を無効化または削除するものではない。

### 10.9 API概要

- APIが「何を対象に、何を行うか」を一文で記述する。
- Scenario固有の目的や期待結果を記述しない。
- 実装方式ではなくAPIの機能を記述する。

## 11. 正本と重複項目の扱い

| 情報 | 正本 | 他成果物での扱い |
|---|---|---|
| `apiId` | API Master | 参照のみ |
| `apiName` | API Master | 表示用に複製可。相違は不可。 |
| `systemId` | API Master | 参照のみ |
| `method` | API Master | API詳細設計書にも表示するが、一致必須。 |
| `endpointPath` | API Master | API詳細設計書にも表示するが、一致必須。 |
| `requestDto`／`responseDto` | API Master | API詳細設計書にも表示するが、一致必須。 |
| Request／Response項目仕様 | API詳細設計書／DTO | API Masterには保持しない。 |
| `apiCallCode`と呼出順序 | Scenario設計 | API Masterには保持しない。 |

共有項目に不一致がある場合、自動的に一方を優先して実行してはならない。整合性Errorとして更新を停止し、API Ownerによる確認後、同一変更単位で修正する。

## 12. 整合性Validation

### 12.1 単一レコードValidation

| Rule ID | 検証内容 | Severity |
|---|---|---|
| `API-MST-V001` | 必須10項目がすべて設定されていること。 | ERROR |
| `API-MST-V002` | `apiId`が`^API-[0-9]{3}$`に一致すること。 | ERROR |
| `API-MST-V003` | `method`が許容Enumに含まれること。 | ERROR |
| `API-MST-V004` | `endpointPath`が`/`で始まること。 | ERROR |
| `API-MST-V005` | `endpointPath`にScheme、Host、Query Stringを含まないこと。 | ERROR |
| `API-MST-V006` | DTO未使用時に`NONE`が明示されていること。 | ERROR |
| `API-MST-V007` | `apiDesignRef`がRepository内に存在すること。 | ERROR |
| `API-MST-V008` | `enabled`がBooleanであること。 | ERROR |
| `API-MST-V009` | `description`にScenario固有の入力値または期待値を記載していないこと。 | WARNING |

### 12.2 Master全体Validation

| Rule ID | 検証内容 | Severity |
|---|---|---|
| `API-MST-V101` | `apiId`がMaster内で一意であること。 | ERROR |
| `API-MST-V102` | `systemId + method + endpointPath`の組合せが一意であること。 | ERROR |
| `API-MST-V103` | `apiDesignRef`が原則として1 APIだけから参照されていること。 | WARNING |
| `API-MST-V104` | `enabled=false`のAPIを有効な新規Scenarioが参照していないこと。 | ERROR |
| `API-MST-V105` | API詳細設計書の`apiId`、Method、Path、DTOがMasterと一致すること。 | ERROR |
| `API-MST-V106` | 対応表に記載されたすべての`apiId`がAPI Masterに存在すること。 | ERROR |
| `API-MST-V107` | 同一APIがScenario別レコードとして重複登録されていないこと。 | ERROR |
| `API-MST-V108` | API Masterに禁止項目が追加されていないこと。 | ERROR |

### 12.3 禁止列Validation

次の列または同等の意味を持つ列をAPI Masterへ追加してはならない。

```text
apiCallCode
stepNo
scenarioId
useCaseInput
initialValue
contextId
verificationId
expected
resultKey
baseline
comparePolicy
ignoreFields
ignoreValues
businessCheck
```

追加が必要に見える場合は、まず責務先となる通常設計書またはJava実装を確認し、Master共通レビューで承認されるまでMaster構造を変更しない。

## 13. 参照解決規則

### 13.1 Scenarioからの解決

1. Scenarioの`apiCallCode`から`apiId`を取得する。
2. `apiId`でAPI Masterを一意に検索する。
3. 対象レコードが存在しない場合は設計整合性Errorとする。
4. `enabled=false`の場合は新規実行対象として解決しない。
5. `apiDesignRef`およびDTO識別子を使用して実装・設計の整合性を確認する。
6. 接続先Base URLはEnvironment情報から解決する。

### 13.2 Java実装での扱い

- Javaは`apiId`をAPI呼出定義の安定キーとして使用する。
- `apiCallCode`は実行単位、Snapshot単位、Diff単位の識別子として保持する。
- 同じ`apiId`に対する既定のResponse比較定義は再利用してよい。
- Scenario固有の比較定義が必要な場合は`apiCallCode`で上書きする。
- 比較結果は`COMPARED`または`IGNORED`として出力し、Master自体には書き戻さない。

## 14. 変更管理

### 14.1 変更区分

| 変更内容 | 取扱い | 主な影響確認先 |
|---|---|---|
| API名称・概要の表現修正 | 非互換性なし | API詳細設計、表示名称 |
| Method変更 | 互換性影響あり | API詳細設計、Scenario、Java Client、Test |
| Endpoint Path変更 | 互換性影響あり | API詳細設計、Environment接続、Scenario、Java Client |
| Request／Response DTO変更 | 互換性影響あり | API詳細設計、Java Client、Business Check、Diff |
| `apiDesignRef`変更 | 文書参照変更 | Link、レビュー、Traceability |
| `enabled: true → false` | 利用停止 | Scenario、対応表、実行計画、定期実行 |
| `apiId`変更 | 禁止 | 新ID採番と旧ID無効化で対応 |

### 14.2 API追加

1. API分析結果およびAPI Ownerを確認する。
2. 未使用の`apiId`を採番する。
3. API詳細設計書およびDTOを準備する。
4. API Masterに1レコード追加する。
5. 単一レコードValidationおよびMaster全体Validationを実施する。
6. 必要なScenario詳細設計へ`apiId`参照を追加し、対応表を再生成する。
7. Java Client、Business Check、Response Diffの実装・試験要否を確認する。
8. レビュー承認後に`enabled=true`とする。

### 14.3 API変更

API MasterとAPI詳細設計書の共有項目は、同一Change Request内で更新する。Method、PathまたはDTOを変更する場合は、参照中の全ScenarioとJava実装について影響分析を必須とする。

### 14.4 API利用停止

1. 対象APIを参照するUseCase、Scenario、対応表および定期実行を抽出する。
2. 新規参照を停止する。
3. 代替APIがある場合は新しい`apiId`を登録する。
4. 既存APIを`enabled=false`へ変更する。
5. 過去のSnapshot、Diff、Reportから参照できるようレコードを保持する。

## 15. Review Checklist

### 15.1 責務

- [ ] 1 API 1レコードになっている。
- [ ] API定義とScenario内の呼出実体が分離されている。
- [ ] Request／Response項目詳細がAPI Masterへ重複記載されていない。
- [ ] Context、Expected、Verification、Compare、Business Checkが混入していない。
- [ ] Environment固有のURLまたはCredentialが混入していない。

### 15.2 項目

- [ ] `apiId`が一意かつ命名規則に準拠している。
- [ ] `systemId`がProvider側システムを示している。
- [ ] MethodおよびEndpoint PathがAPI詳細設計書と一致している。
- [ ] Request／Response DTOが実装と一致している。
- [ ] `apiDesignRef`の参照先が存在する。
- [ ] `enabled`の状態とScenario参照が矛盾していない。

### 15.3 変更影響

- [ ] API追加・変更・利用停止の影響先を確認している。
- [ ] 対応表に未登録または不明な`apiId`が存在しない。
- [ ] 無効APIを有効Scenarioが参照していない。
- [ ] Java Client、Business Check、Response Diffへの影響を確認している。

## 16. 完了条件

本設計書は、次の条件をすべて満たした時点で承認可能とする。

1. API Masterの責務と管理対象外が合意されている。
2. 10項目の正式レコードモデルが承認されている。
3. `apiId`と`apiCallCode`の責務分離が承認されている。
4. API詳細設計、UseCase、Scenario、対応表およびJava実装との境界が合意されている。
5. Validation Ruleがレビュー済みである。
6. API追加・変更・利用停止手順がレビュー済みである。
7. 既存約24 APIを本モデルで表現できることが確認されている。
8. Critical Open Issueが存在しない。

## 17. 未決事項・現行Blocker

| Issue ID | 内容 | 現在の扱い | Release影響 |
|---|---|---|---|
| `API-MST-ISSUE-001` | `E6_API_Master.md`のFile名 | Current Repositoryの正式File名として維持する。表記統一だけを理由に改名しない。 | なし |
| `API-MST-ISSUE-002` | DTOの完全修飾Class名とJava Source Root | Java Package未確定のため、既存単純Class名は暫定表示とし、Build Trace成立前は解決済みと扱わない。 | BLOCKED |
| `API-MST-ISSUE-003` | API MasterとAPI詳細設計書の機械整合性検査 | Validation Ruleは本書を正本とし、実装方式はFile I/O／Java構成確定後に決定する。 | 条件付き |
| `API-MST-BLOCK-001` | 正式APIが0件である。 | 7業務FlowのAPI分析書から正式情報を取得し、仮レコードを作らず登録する。 | Release Block |
| `API-MST-BLOCK-002` | 正式API契約、DTO、Status、ErrorおよびJava実装へのTraceが未作成である。 | 正式API登録後にAPI詳細設計を作成し、契約・Build Traceを成立させる。 | Release Block |
| `API-MST-BLOCK-003` | 初期調査対象約24 APIのCoverageが未確認である。 | 業務別API一覧、依存関係および呼出Sequenceから重複排除してCoverage Reviewする。 | Coverage Block |

## 18. 残作業

本設計の責務再編、Master、Example、GuideおよびChecklistへの反映は完了している。Release前に次を実施する。

1. 7業務FlowのAPI分析を完成し、正式APIを登録する。
2. 登録したAPIごとにMethod、Endpoint、DTO、Document IDおよびOwnerを照合する。
3. Java Source RootとBase Package確定後、DTOおよびCompare DefinitionのBuild Traceを検証する。
4. 7業務FlowのAPI分析書から残りAPIを正式登録する。
5. Cross-Master Validation Errorが0件になった後、`02_master` Release Reviewを実施する。
