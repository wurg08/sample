---
title: UseCase Master設計書
document_id: E6-API-VAL-MST-UC-DESIGN
version: 1.0.0-draft.5
status: DRAFT
document_type: Master詳細設計書
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# UseCase Master設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | UseCase Master設計書 |
| 文書ID | `E6-API-VAL-MST-UC-DESIGN` |
| 対象システム | E6 API Verification Platform |
| 対象Master | `system/02_master/UseCase_Master.md` |
| 文書種別 | Master詳細設計書 |
| 版数 | `1.0.0-draft.5` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Verification Platform Team |
| レビュー責任 | System Architect / Business Analysis Lead / Scenario Design Lead |
| 承認責任 | System Owner / Business Owner |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-25 | Master体系再編後の責務に基づき全面再作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | Front Matterを`snake_case`へ移行し、有効参照Validation、現行Cross-Master Blockerおよび次工程を再確認 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | Canonical Lifecycle Enumへの統一に伴いRelease表記を同期 | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | UC-E6-001詳細設計書作成後のReference解決状態と残存Business／Environment／Scenario Blockerを同期 | DRAFT |
| `1.0.0-draft.5` | 2026-07-27 | SC-E6-001詳細設計、Input、ExpectedのReference解決状態と残存実行Blockerを同期 | DRAFT |

## 3. 目的

本書は、E6 API Verification Platformで使用するUseCase Masterの責務、管理項目、記述形式、整合性規則、変更管理および関連成果物との境界を定義する。

UseCase Masterは、検証対象となる一つの業務目的を一意に登録し、次の問いに対する正本を提供する。

- どのUseCaseが存在するか。
- UseCaseが達成または確認する業務目的は何か。
- どのBusinessを対象とするか。
- どの業務範囲を対象とするか。
- 共通する前提条件は何か。
- どのEnvironmentで適用可能か。
- どのScenarioによって業務経路を具体化するか。
- UseCase詳細設計書はどこにあるか。
- 現在利用可能なUseCaseか。

UseCase Masterは、個別ScenarioのAPI呼出順序、入力値、Context、Expected、Check、Diffまたは実行制御を定義するものではない。

## 4. 適用範囲

本書は、7業務Flowを基に設計する最大10件程度の業務UseCaseに適用する。

UseCaseはAPI本数や画面操作単位ではなく、業務担当者が独立して目的、開始条件および完了状態を説明できる単位で定義する。

対象には次を含む。

- 正常な業務処理を検証するUseCase
- 同一業務目的に対して複数の分岐経路を持つUseCase
- 複数APIの連携結果を確認するUseCase
- 業務状態の照会、登録、更新または取消を確認するUseCase
- 業務上意味のある異常終了までを範囲とするUseCase

入力値、データPatternまたはAPI応答差異だけが異なる場合は、原則として新しいUseCaseではなく、同一UseCase配下のScenarioとして定義する。

## 5. 基本原則

| 原則ID | 原則 | 説明 |
|---|---|---|
| `UC-MST-P001` | 1業務目的1 UseCase | 同一の業務目的をScenarioやEnvironmentごとに重複登録しない。 |
| `UC-MST-P002` | UseCaseとScenarioの分離 | UseCaseは業務目的と範囲、Scenarioは具体的な実行経路を表す。 |
| `UC-MST-P003` | 安定情報のみ管理 | 実行ごとに変化する入力、結果、Run情報を保持しない。 |
| `UC-MST-P004` | API実行定義を保持しない | API、順序、分岐、Skip、`apiCallCode`はScenario側で定義する。 |
| `UC-MST-P005` | 検証実装を保持しない | Expected、`resultKey`、Business Check、Diff定義を保持しない。 |
| `UC-MST-P006` | Scenarioによる具体化 | 一つのUseCaseは一つ以上のScenarioによって具体化する。 |
| `UC-MST-P007` | 参照可能性を保証する | `useCaseId`からBusiness、ScenarioおよびUseCase詳細設計を追跡できること。 |
| `UC-MST-P008` | 物理削除を原則禁止する | 利用停止UseCaseは削除せず、`enabled=false`として履歴を保持する。 |

## 6. UseCaseの成立条件

次の条件をすべて満たす単位をUseCaseとして登録する。

1. 業務上の目的を一文で説明できる。
2. 業務上の開始条件と完了範囲を説明できる。
3. 一つ以上のBusinessと追跡関係を持つ。
4. 一つ以上のScenarioによって具体的な経路を表現できる。
5. 特定のAPI実装、入力値または実行日だけに依存しない。
6. 業務担当者が他のUseCaseと区別してレビューできる。

次の差異だけでは新しいUseCaseを作成しない。

| 差異 | 取扱い |
|---|---|
| 正常、代替、異常、境界の違い | Scenarioを分ける。 |
| Request値またはTest Dataの違い | Scenario InputまたはTest Dataを分ける。 |
| APIの途中終了、Skip、Timeout | Scenarioを分ける。 |
| Expectedの違い | Scenario Expectedを分ける。 |
| Response比較の除外項目の違い | API比較定義または`apiCallCode`単位の上書きで扱う。 |
| 実行Environmentの違い | 同一UseCaseの適用Environmentとして扱う。 |

業務目的または業務完了条件そのものが異なる場合は、別UseCaseとして登録する。

## 7. 責務

UseCase Masterは、次の情報を管理する。

1. UseCaseの固定識別子
2. UseCase名称
3. 対象Business
4. 業務目的
5. 業務範囲
6. 共通前提条件の概要
7. 適用可能なEnvironment
8. 所属Scenarioの一覧
9. UseCase詳細設計書への参照
10. UseCaseの有効・無効状態

UseCaseを参照する側は`useCaseId`を使用する。UseCase名称、Business名称または表示順を参照キーとして使用してはならない。

## 8. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| 対象APIおよびAPI呼出順序 | Scenario詳細設計書。対応表は正本から生成するTraceability View。 |
| `apiCallCode` | Scenario設計 |
| API分岐、Skip、停止条件 | Scenario設計およびScenario Java実装 |
| Request初期値、Test Data | Scenario Input／Test Data |
| 前段Responseから後段Requestへの値引継ぎ | Scenario Java実装 |
| ScenarioContextの項目とLifetime | Scenario設計および共通実行設計 |
| `expectedRef`、Expected内容 | Scenario Master／Expectedファイル |
| `resultKey`、Check順序 | Scenario設計およびJava Check実装 |
| 業務必須、非空、型、桁数、固定値、属性値、状態遷移の判定 | API詳細設計、Business CheckおよびJava実装 |
| Previous／Current／Expected結果 | 実行成果物およびReport |
| Baseline識別、前回Runの選定 | Execution State／Baseline管理設計 |
| Response Diff、`IGNORE_FIELD`、`IGNORE_VALUE` | API専用Java比較定義およびAPIレスポンスDiff設計書 |
| 実行頻度、起動時刻、自動実行有無 | Scheduler／運用設計 |
| Retry、Timeout、並列数 | 共通実行設計およびRuntime設定 |
| Base URL、Credential、Proxy | Environment Masterおよび実行環境設定 |
| Run ID、実行日時、実行結果 | RunContextおよび実行成果物 |

UseCase Masterへ実行しやすさを理由にこれらの列を追加してはならない。

## 9. 関連成果物と責務境界

```mermaid
flowchart TD
    B["Business Master<br/>業務分類・境界"]
    U["UseCase Master<br/>業務目的・範囲"]
    S["Scenario Master<br/>具体的な実行経路"]
    D["Scenario設計／Java<br/>API呼出・Input・Expected・Check"]

    B --> U
    U --> S
    S --> D
```

| 成果物 | UseCase Masterとの関係 | 正本関係 |
|---|---|---|
| `Business_Master.md` | 対象業務の固定識別と業務境界を提供する。 | `businessIds`の参照先 |
| `Environment_Master.md` | 適用Environmentの固定識別を提供する。 | `applicableEnvironmentIds`の参照先 |
| `E6_API_Master.md` | APIの固定定義を提供する。UseCaseからAPIを直接参照しない。 | 直接関係なし |
| `Scenario_Master.md` | UseCaseを具体化するScenarioを登録する。 | Scenario自身の定義の正本 |
| `API_UseCase_Scenario対応表.md` | UseCase、Scenario、APIの追跡関係を表示する。 | Traceability View |
| `04_usecase_design/UC-XXX設計書.md` | UseCaseのActor、Trigger、前提、業務Flow等を詳細化する。 | UseCase詳細の正本 |
| Scenario設計書 | API呼出順序、Input、Context、Expected、Checkを定義する。 | 実行経路の正本 |
| Java Scenario実装 | Scenario設計に従って同期Batchを実行する。 | 実行実装 |
| APIレスポンスDiff設計書 | Response構造・値の差分と無視判定を定義する。 | Diff仕様の正本 |

### 9.1 Scenario一覧の正本規則

`UseCase_Master.md`の`scenarioIds`は、UseCase単位でScenarioの全体像をレビューするための必須逆引き一覧とする。

Scenario自身の属性および親UseCaseは`Scenario_Master.md`の各Scenarioレコードを正本とする。両者は常に一致しなければならない。

```text
UseCase_Master.scenarioIds
    =
Scenario_Masterで同一useCaseIdを持つscenarioIdの集合
```

不一致時は自動補正せず、Master整合性Errorとして更新または実行を停止する。

## 10. UseCase定義モデル

### 10.1 正式レコード

`UseCase_Master.md`では、1行を1 UseCaseの正式レコードとする。

| No. | 表示名 | 列名 | 型 | 必須 | 設定規則 |
|---:|---|---|---|:---:|---|
| 1 | UseCase ID | `useCaseId` | String | Yes | `UC-E6-NNN`形式。一意かつ不変。 |
| 2 | UseCase名称 | `useCaseName` | String | Yes | 業務目的が判別できる正式名称。 |
| 3 | Business ID一覧 | `businessIds` | List&lt;String&gt; | Yes | `Business_Master.md`に存在するIDを1件以上設定する。 |
| 4 | 業務目的 | `businessPurpose` | String | Yes | 「何を確認するか」を一文で記述する。 |
| 5 | 業務範囲 | `businessScope` | String | Yes | 業務上の開始点、対象処理および完了範囲を要約する。 |
| 6 | 共通前提条件 | `preconditionSummary` | String | Yes | 全Scenarioに共通する前提だけを記述する。存在しない場合は`NONE`。 |
| 7 | 適用Environment ID一覧 | `applicableEnvironmentIds` | List&lt;String&gt; | Yes | `Environment_Master.md`に存在するIDを1件以上設定する。 |
| 8 | Scenario ID一覧 | `scenarioIds` | List&lt;String&gt; | Yes | 有効UseCaseは1件以上。`Scenario_Master.md`と一致必須。 |
| 9 | UseCase設計書参照 | `useCaseDesignRef` | Path | Yes | Repository Root基準の相対Path。 |
| 10 | 有効フラグ | `enabled` | Boolean | Yes | `true`または`false`。 |

### 10.2 記述形式

List値は`<br>`で区切り、1セル内の順序はID昇順とする。

```markdown
| useCaseId | useCaseName | businessIds | businessPurpose | businessScope | preconditionSummary | applicableEnvironmentIds | scenarioIds | useCaseDesignRef | enabled |
|---|---|---|---|---|---|---|---|---|---:|
| UC-E6-901 | 注文状態変更検証 | BUS-E6-901 | 注文状態の変更前後を確認し、想定した状態遷移が成立することを検証する架空Example。 | 注文照会開始から状態変更後の再照会完了まで。 | Example用注文Dataが準備済みであること。 | ENV-LOCAL<br>ENV-STAGING | SC-E6-901<br>SC-E6-902<br>SC-E6-903 | system/04_usecase_design/examples/UC-E6-901設計書_Example.md | true |
```

### 10.3 識別子階層

| 識別子 | 意味 | 定義単位 | 例 |
|---|---|---|---|
| `businessId` | 業務分類または業務境界 | Business Master | `BUS-E6-001` |
| `useCaseId` | 一つの業務検証目的 | UseCase Master | `UC-E6-001` |
| `scenarioId` | 一つの具体的な実行経路 | Scenario Master | `SC-E6-001` |
| `apiId` | APIそのもの | API Master | `API-001` |
| `apiCallCode` | Scenario内のAPI呼出実体 | Scenario設計 | `CALL-001` |
| `resultKey` | Expectedと実行結果を対応させるCheck単位 | Expected／Java Check | `ORDER_STATUS_CHECK` |

`useCaseId`から`apiCallCode`または`resultKey`を直接解決してはならない。必ずScenarioを介して解決する。

## 11. 項目別設計規則

### 11.1 UseCase ID

- 形式は`UC-E6-NNN`とする。
- 初回登録後は変更しない。
- 欠番を許容し、既存番号を再利用しない。
- UseCaseを置換する場合は新しいIDを採番し、旧UseCaseを`enabled=false`とする。

Pattern:

```regex
^UC-E6-[0-9]{3}$
```

### 11.2 UseCase名称

- 日本語の正式名称を使用する。
- 業務対象と目的を判別できる名称とする。
- 「正常系」「異常系」「Timeout」「Pattern A」等のScenario差異を名称にしない。
- Environment名、API名、TestCase名または実行日を名称に含めない。
- 名称を参照キーとして使用しない。

### 11.3 Business ID一覧

- `Business_Master.md`に存在する有効なIDだけを設定する。
- 主対象を先頭とし、以降はID昇順で記述する。
- 同じIDを重複設定しない。
- 複数Businessを設定する場合は、業務目的が一つにまとまることを確認する。
- 複数の独立した業務目的が存在する場合はUseCaseを分割する。

### 11.4 業務目的

- 「対象」「確認内容」「成立条件」が分かる一文とする。
- APIを呼び出すこと自体を目的にしない。
- 正常、異常等の個別経路を列挙しない。
- Expected値、`resultKey`またはJava Class名を記載しない。

### 11.5 業務範囲

- 業務上の開始点と完了範囲を明確にする。
- API Stepの列挙ではなく、業務処理の言葉で記述する。
- 対象外範囲が誤解を生む場合はUseCase詳細設計書で明記する。
- Scenarioごとの差異は記述せず、全Scenarioが共通して属する範囲を記述する。

### 11.6 共通前提条件

- 全Scenarioに共通する業務前提だけを要約する。
- Scenario固有の入力条件または分岐条件は記載しない。
- Credential、URL、日付等のRuntime値を記載しない。
- 共通前提がない場合は空欄にせず`NONE`を設定する。
- 詳細は`useCaseDesignRef`で参照する。

### 11.7 適用Environment ID一覧

- `Environment_Master.md`に存在するIDだけを設定する。
- Base URL、Host、Credentialまたは接続設定を記載しない。
- Environment別にUseCaseを複製しない。
- 一部Environmentで未対応の場合は、対象外IDを含めない。
- Environment追加時は、適用要否を明示的にレビューする。

### 11.8 Scenario ID一覧

- `Scenario_Master.md`に存在し、同一`useCaseId`を持つScenarioだけを設定する。
- 同じScenarioを複数UseCaseに所属させない。
- 有効UseCaseは、原則として有効Scenarioを1件以上持つ。
- API呼出順序、Scenario種別、InputまたはExpectedをセル内へ記載しない。
- ID昇順で記述し、重複を許可しない。

### 11.9 UseCase設計書参照

- Repository Root基準の相対Pathで記述する。
- 原則として1 UseCaseにつき1詳細設計書を参照する。
- 参照先文書の`useCaseId`がMasterと一致しなければならない。
- 参照先が存在しない状態で`enabled=true`にしてはならない。

### 11.10 有効フラグ

| 値 | 意味 |
|---|---|
| `true` | 新規Scenarioおよび新規実行計画から参照可能。 |
| `false` | 新規参照不可。過去設計および実行結果の追跡目的で保持する。 |

`enabled=false`は、配下Scenario、過去Snapshot、DiffまたはReportを削除する指示ではない。

## 12. 正本と重複項目の扱い

| 情報 | 正本 | 他成果物での扱い |
|---|---|---|
| `useCaseId` | UseCase Master | 参照のみ |
| `useCaseName` | UseCase Master | 表示用に複製可。相違は不可。 |
| Businessの名称・境界 | Business Master | UseCase側ではID参照と目的を記載する。 |
| `businessPurpose`／`businessScope` | UseCase Master | 詳細設計で詳細化可。矛盾は不可。 |
| Environment定義 | Environment Master | UseCase側では適用IDだけを参照する。 |
| Scenario自身の属性と親UseCase | Scenario Master | UseCase側の`scenarioIds`と一致必須。 |
| 三者の追跡関係 | API・UseCase・Scenario対応表 | Master間から導出できるTraceability View。 |
| API呼出順序と`apiCallCode` | Scenario設計 | UseCase Masterには保持しない。 |
| Input、Context、Expected、Check | Scenario設計／Java実装 | UseCase Masterには保持しない。 |

共有項目に不一致がある場合、自動的に一方を優先して実行してはならない。整合性Errorとして変更または実行を停止し、各Ownerが同一変更単位で修正する。

## 13. 整合性Validation

### 13.1 単一レコードValidation

| Rule ID | 検証内容 | Severity |
|---|---|---|
| `UC-MST-V001` | 必須10項目がすべて設定されていること。 | ERROR |
| `UC-MST-V002` | `useCaseId`が`^UC-E6-[0-9]{3}$`に一致すること。 | ERROR |
| `UC-MST-V003` | `businessIds`が1件以上で、すべてBusiness Masterに存在すること。 | ERROR |
| `UC-MST-V004` | `businessPurpose`が業務目的を一文で説明していること。 | ERROR |
| `UC-MST-V005` | `preconditionSummary`が空欄でないこと。前提なしは`NONE`であること。 | ERROR |
| `UC-MST-V006` | `applicableEnvironmentIds`が1件以上で、すべてEnvironment Masterに存在すること。 | ERROR |
| `UC-MST-V007` | `enabled=true`の場合、`scenarioIds`が1件以上であること。 | ERROR |
| `UC-MST-V008` | `useCaseDesignRef`がRepository内に存在すること。 | ERROR |
| `UC-MST-V009` | `enabled`がBooleanであること。 | ERROR |
| `UC-MST-V010` | 目的、範囲、前提にScenario実行詳細が混入していないこと。 | ERROR |

### 13.2 Master間Validation

| Rule ID | 検証内容 | Severity |
|---|---|---|
| `UC-MST-V101` | `useCaseId`がUseCase Master内で一意であること。 | ERROR |
| `UC-MST-V102` | `scenarioIds`に重複がないこと。 | ERROR |
| `UC-MST-V103` | 各`scenarioId`がScenario Masterに存在すること。 | ERROR |
| `UC-MST-V104` | 各Scenarioの`useCaseId`が当該UseCaseと一致すること。 | ERROR |
| `UC-MST-V105` | Scenario Master上の当該UseCase配下Scenarioが`scenarioIds`から欠落していないこと。 | ERROR |
| `UC-MST-V106` | 一つのScenarioが複数UseCaseの`scenarioIds`に存在しないこと。 | ERROR |
| `UC-MST-V107` | `enabled=false`のUseCaseを有効Scenarioまたは新規実行計画が参照していないこと。 | ERROR |
| `UC-MST-V108` | 対応表のUseCase／Scenario関係が両Masterと一致すること。 | ERROR |
| `UC-MST-V109` | UseCase詳細設計書の`useCaseId`、名称、BusinessがMasterと一致すること。 | ERROR |
| `UC-MST-V110` | Environment、Scenario、API等の理由で同一業務目的が重複登録されていないこと。 | WARNING |
| `UC-MST-V111` | `enabled=true`のUseCaseが参照するBusiness、EnvironmentおよびScenarioがすべて`enabled=true`であること。 | ERROR |
| `UC-MST-V112` | `preconditionSummary`にCredential、接続設定、具体Test Dataまたは実行時準備状態が混入していないこと。 | ERROR |

### 13.3 禁止列Validation

次の列または同等の意味を持つ列をUseCase Masterへ追加してはならない。

```text
targetApiIds
apiCallCode
apiExecutionOrder
stepNo
inputRef
initialValue
contextId
expectedRef
expectedResult
resultKey
checkClass
verificationId
verificationPolicy
comparePolicy
ignoreFields
ignoreValues
baseline
previousRunId
executionFrequency
schedule
autoExecute
retry
timeout
```

追加が必要に見える場合は、Scenario設計、共通実行設計または運用設計のどこに置くべきかを確認し、Master共通レビューで承認されるまでMaster構造を変更しない。

## 14. 参照解決規則

### 14.1 UseCaseからScenarioへの解決

1. `useCaseId`でUseCase Masterを一意に検索する。
2. レコードが存在しない場合は設計整合性Errorとする。
3. `enabled=false`の場合は新規実行対象として解決しない。
4. `scenarioIds`を取得する。
5. 各`scenarioId`をScenario Masterで解決する。
6. Scenarioの`useCaseId`が一致しない場合は設計整合性Errorとする。
7. 実行対象Scenarioは実行要求またはScheduler側で選択する。UseCase Masterは選択条件を持たない。

### 14.2 Scenario以降の解決

```text
useCaseId
    ↓
scenarioId
    ↓
Scenario設計
    ├── apiCallCode → apiId
    ├── inputRef
    ├── expectedRef
    ├── Check順序
    └── Java executionClass
```

UseCase Masterを読み込んだだけでAPI実行を開始してはならない。実行には、選択されたScenarioとその詳細設計・実装が必要である。

### 14.3 Java実装での扱い

- Javaは`useCaseId`を業務検証単位の安定キーとして保持する。
- `scenarioId`を同期Batch実行経路の識別子として使用する。
- API実行およびSnapshotは`apiCallCode`単位で管理する。
- Expected、Previous、Currentの対応は`resultKey`で行う。
- UseCase Masterへ実行状態または結果を書き戻さない。

## 15. 変更管理

### 15.1 変更区分

| 変更内容 | 取扱い | 主な影響確認先 |
|---|---|---|
| UseCase名称の表現修正 | 非互換性なし | UseCase詳細設計、Report表示 |
| Business目的・範囲の修正 | 業務影響あり | Business分析、Scenario、Expected、Check |
| `businessIds`変更 | Traceability影響あり | Business Master、UseCase詳細設計、対応表 |
| 共通前提条件変更 | Scenario影響あり | 全配下Scenario、Input、Test Data |
| 適用Environment変更 | 実行可否影響あり | Environment Master、運用、実行設定 |
| Scenario追加・削除 | 経路影響あり | Scenario Master、対応表、実行計画 |
| `useCaseDesignRef`変更 | 文書参照変更 | Link、レビュー、Traceability |
| `enabled: true → false` | 利用停止 | Scenario、定期実行、Report |
| `useCaseId`変更 | 禁止 | 新ID採番と旧ID無効化で対応 |

### 15.2 UseCase追加

1. 現行業務分析書およびBusiness Ownerを確認する。
2. 既存UseCaseと業務目的が重複しないことを確認する。
3. 未使用の`useCaseId`を採番する。
4. Business、業務目的、範囲、共通前提、適用Environmentを定義する。
5. UseCase詳細設計書を作成する。
6. 少なくとも一つのScenarioを設計し、Scenario Masterへ登録する。
7. `scenarioIds`を更新し、対応表を全件再生成する。
8. 全Validationとレビューを完了後、`enabled=true`とする。

### 15.3 Scenario追加・変更・削除

Scenario変更時は、UseCaseの業務目的または範囲が変わるかを確認する。

- 目的と範囲が変わらない場合は、Scenario側と`scenarioIds`を更新し、対応表を全件再生成する。
- 目的または完了条件が変わる場合は、UseCase変更または新規UseCaseの要否を判断する。
- Scenarioを物理削除する場合は、過去実行結果の追跡性を損なわないことを確認する。原則はScenario側の無効化とする。

### 15.4 UseCase分割・統合

既存`useCaseId`の意味を上書きして分割・統合してはならない。

1. 新しいUseCaseに新しいIDを採番する。
2. Scenarioの移管先を明確にする。
3. Scenario Masterを更新し、同一変更単位で対応表を全件再生成する。
4. 旧UseCaseを`enabled=false`とする。
5. 過去のSnapshot、Diff、Reportから旧IDを参照可能な状態で保持する。

### 15.5 UseCase利用停止

1. 配下の有効Scenarioと定期実行を抽出する。
2. 新規実行要求からの参照を停止する。
3. 代替UseCaseまたは移管先Scenarioを確認する。
4. 対象UseCaseを`enabled=false`へ変更する。
5. 過去成果物の参照性を保持する。

## 16. Review Checklist

### 16.1 UseCase粒度

- [ ] 一つの独立した業務目的を表している。
- [ ] ScenarioまたはEnvironmentの違いだけでUseCaseを複製していない。
- [ ] 業務上の開始点と完了範囲が説明できる。
- [ ] 対象Businessとの関係が明確である。
- [ ] 一つ以上のScenarioで具体化されている。

### 16.2 責務

- [ ] API呼出順序、`apiCallCode`、Inputが混入していない。
- [ ] Context、Expected、`resultKey`、Business Checkが混入していない。
- [ ] Baseline、Diff、比較除外定義が混入していない。
- [ ] 実行頻度、Schedule、Retry、Timeoutが混入していない。
- [ ] 廃止済みのContext／Verification／Policy／Compare Policy Masterを参照していない。

### 16.3 項目と参照

- [ ] `useCaseId`が一意かつ命名規則に準拠している。
- [ ] `businessIds`がBusiness Masterに存在する。
- [ ] `applicableEnvironmentIds`がEnvironment Masterに存在する。
- [ ] `scenarioIds`がScenario Masterと双方向に一致する。
- [ ] `useCaseDesignRef`の参照先が存在し、同一IDを記載している。
- [ ] `enabled`の状態とScenario・実行計画の参照が矛盾していない。

### 16.4 変更影響

- [ ] Business目的または範囲変更の影響を全Scenarioで確認している。
- [ ] Scenario追加・削除後に対応表を全件再生成している。
- [ ] Environment適用変更を運用・実行設定へ反映している。
- [ ] 無効化後も過去の実行成果物から追跡できる。

## 17. 完了条件

本設計書は、次の条件をすべて満たした時点で承認可能とする。

1. UseCaseの成立条件と粒度が合意されている。
2. 10項目の正式レコードモデルが承認されている。
3. UseCaseとScenarioの責務境界が合意されている。
4. 廃止済みのContext／Verification／Policy／Compare Policy Masterへの依存が存在しない。
5. Business、Environment、Scenarioおよび対応表との整合性規則がレビュー済みである。
6. UseCase追加、変更、分割、統合および利用停止手順がレビュー済みである。
7. 7業務Flow・最大10 UseCaseを本モデルで表現できることが確認されている。
8. Critical Open Issueが存在しない。

## 18. 未決事項・現行Blocker

| Issue ID | 内容 | 現在の扱い | Release影響 |
|---|---|---|---|
| `UC-MST-DECISION-001` | `businessIds`の多値可否 | 横断業務UseCaseを考慮し複数値を許容する。ただし業務目的は一つに限定する。 | なし |
| `UC-MST-DECISION-002` | 全Environment予約値 | 予約値を設けず、適用する実在`environmentId`を明示する。 | なし |
| `UC-MST-ISSUE-001` | `scenarioIds`の更新方式 | 表示は必須とし、手動・生成の方式に関係なくScenario Masterとの完全一致を要求する。 | 条件付き |
| `UC-MST-DECISION-003` | UseCase詳細設計書の配置・命名 | `system/04_usecase_design/UC-E6-NNN設計書.md`をCurrent Repositoryの正式Patternとする。 | なし |
| `UC-MST-BLOCK-001` | 正式BusinessおよびAPIが0件である。 | 7業務FlowとAPI分析を完成し、UseCase設計の入力を確定する。 | Release Block |
| `UC-MST-BLOCK-002` | 正式UseCaseが0件である。 | Business目的、入口、分岐、終了点およびAPI集合からUseCase境界を承認する。 | Release Block |
| `UC-MST-BLOCK-003` | 正式Scenario Coverageが存在しない。 | UseCase登録後に正常、分岐、異常および境界経路を設計する。 | Release Block |
| `UC-MST-BLOCK-004` | Environment適用範囲と更新系安全GateがUseCase単位で未確認である。 | Environment OwnerとUseCase Ownerが正式適用範囲を承認する。 | Release Block |

## 19. 残作業

本設計の責務再編、Master、Example、GuideおよびChecklistへの反映は完了している。Release前に次を実施する。

1. Business／API分析から正式UseCase候補を抽出する。
2. UseCase設計書を作成し、Masterの名称、Business、目的および範囲と照合する。
3. Business Analysis正本ReferenceをCross-Master Traceへ接続する。
4. 有効ScenarioのInput必須値、Expected／Java照合およびJava Class Traceを完成する。
5. Cross-Master Validation Errorが0件になった後、`02_master` Release Reviewを実施する。
