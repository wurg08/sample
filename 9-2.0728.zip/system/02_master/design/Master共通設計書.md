---
title: Master共通設計書
document_id: E6-API-VAL-MST-COMMON-DESIGN
version: 2.0.0-draft.4
status: DRAFT
document_type: Design
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# Master共通設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Master共通設計書 |
| 文書ID | `E6-API-VAL-MST-COMMON-DESIGN` |
| 対象システム | E6 API Verification Platform |
| 対象範囲 | `system/02_master/`配下のMaster、設計書、Guide、ChecklistおよびExample |
| 文書種別 | Master共通設計書 |
| 版数 | `2.0.0-draft.4` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Verification Platform Team |
| レビュー責任 | System Architect / Business Analysis Lead / API Design Lead / Scenario Design Lead / Runtime Lead / Test Lead |
| 承認責任 | System Owner / Business Owner |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-25 | Master体系をBusiness、Environment、API、UseCase、Scenarioへ収束し、対応表をTraceability Viewとするモデルで全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-26 | README、2 Guide、2 ChecklistおよびRelease Evidenceとの関係を統合し、Front Matter、Validation、完了・凍結条件を最終更新 | DRAFT |
| `2.0.0-draft.3` | 2026-07-27 | Canonical Lifecycle EnumとExample識別規則を文書作成規約へ統一 | DRAFT |
| `2.0.0-draft.4` | 2026-07-27 | Framework横断再走査によりMaster非保持対象の実行結果をCanonical四結果軸へ統一 | DRAFT |

## 3. 目的

本書は、E6 API Verification PlatformにおけるMasterの成立条件、正本関係、共通メタデータ、識別子、参照、有効状態、変更管理、Validation、ReviewおよびRelease Gateを統一する。

本書は各Master固有の業務項目を再定義しない。個別項目は各Master設計書を正本とし、本書は複数Masterに共通する統制規則だけを定義する。

本書の主目的は次のとおりである。

1. Masterと実行仕様、Runtime情報、ExpectedおよびJava固定実装を分離する。
2. 同一情報の複数正本化を防止する。
3. IDによる安定した参照と双方向Traceabilityを保証する。
4. 変更時に関連成果物を同一変更単位で更新する。
5. 無効化、廃止および過去Runの追跡性を維持する。
6. Build前に構文、参照、状態および責務境界の不整合を検出する。

## 4. 適用範囲

### 4.1 Master

| Master | 正式ファイル | 主責務 |
|---|---|---|
| Business Master | `Business_Master.md` | 業務分類、業務境界および業務の固定識別 |
| Environment Master | `Environment_Master.md` | 実行Environmentの固定識別と適用情報 |
| API Master | `E6_API_Master.md` | API自身の固定技術属性 |
| UseCase Master | `UseCase_Master.md` | 一つの業務検証目的、範囲およびScenario一覧 |
| Scenario Master | `Scenario_Master.md` | 一つの確定業務経路と実行資産参照 |

### 4.2 Traceability View

| View | 正式ファイル | 位置付け |
|---|---|---|
| API・UseCase・Scenario対応表 | `API_UseCase_Scenario対応表.md` | 三MasterとScenario詳細設計から導出するレビュー用View |

対応表は正式成果物であるがMasterではなく、値の変更起点にもJava実行仕様の単独入力にもならない。

### 4.3 支援成果物

| 区分 | 目的 |
|---|---|
| `design/` | Master固有項目、責務境界、Validationおよび変更影響の設計 |
| `guide/` | 作成者・更新者向けの具体的作業手順 |
| `checklist/` | Reviewおよび整合性確認の実施項目 |
| `examples/` | 架空値による正しい記入例と誤記例 |

Exampleは正本ではなく、実システム値を保証しない。

### 4.4 共通支援文書

| 文書 | 正式な役割 |
|---|---|
| `README.md` | `02_master`の入口、固定構成、参照順序および基本禁止事項 |
| `guide/Master作成・更新ガイド.md` | 新規作成、変更、無効化、置換、削除およびReleaseの作業手順 |
| `guide/Master_ID・Reference記述ガイド.md` | ID、採番、ID／File／List／Java Class Referenceの記述規則 |
| `checklist/MasterレビューChecklist.md` | 人による妥当性Review、指摘、承認およびEvidence記録 |
| `checklist/Master整合性Checklist.md` | 構文、Schema、ID、Reference、Cross-MasterおよびRelease Gateの再現可能な検証 |

GuideまたはChecklistで本書と矛盾する規則が検出された場合、本書と各個別Master設計書を確認し、正本側の変更要否を決定する。Checklistだけで設計規則を変更してはならない。

## 5. Masterの成立条件

ある情報をMasterとして管理するには、次の条件をすべて満たさなければならない。

| 条件ID | 条件 |
|---|---|
| `MST-CMN-C001` | 複数の設計、実装または運用成果物から共通参照される。 |
| `MST-CMN-C002` | 実行ごとの値ではなく、一定期間安定している。 |
| `MST-CMN-C003` | 全システムで一意かつ不変のIDを付与できる。 |
| `MST-CMN-C004` | 値のOwner、変更起点および承認責任を一つに決められる。 |
| `MST-CMN-C005` | 集中管理しなければ重複、不整合または参照不能が発生する。 |
| `MST-CMN-C006` | 個別Scenarioの実行詳細またはJava固定実装と重複しない。 |
| `MST-CMN-C007` | 変更履歴と過去成果物からの追跡性を保持できる。 |

単に「一覧にすると便利」「Javaが読みやすい」「将来使うかもしれない」という理由だけでMasterを追加してはならない。

## 6. Masterではない情報

| 情報 | 正式な管理先 | Masterにしない理由 |
|---|---|---|
| API呼出順序、分岐、Skip、`apiCallCode` | Scenario詳細設計書およびJava実装 | Scenario固有の実行仕様 |
| Request初期値、Test Data | Scenario Input | 実行条件・データVariation |
| 前段Responseから後段Requestへの値引継ぎ | Scenario詳細設計書およびJava実装 | 実行時処理 |
| Scenario Context、ApiExchange | Runtime共通設計およびJava Object | 実行ごとに生成される状態 |
| Expected値、`resultKey` | Scenario ExpectedおよびJava Check | Scenario固有の検証契約 |
| 必須、型、桁数、固定値、Enum、業務状態遷移 | API詳細設計、DTOおよびJava Check | API契約または業務判定実装 |
| `IGNORE_FIELD`、`IGNORE_VALUE` | APIまたはScenario専用Java比較定義 | Javaが実行する比較規則 |
| Previous、Current、Baseline、Run ID | Execution StateおよびRun成果物 | 実行ごとに変化する情報 |
| Response Field Diff | APIレスポンスDiff成果物 | 実行結果 |
| `NOT_EVALUATED`、`PASS`、`FAIL` | Verification Result | 実行時のCheck評価 |
| Execution／Change／Recovery Status | Run Result／Execution State | 実行時の完了性、変化および復旧状態 |
| Retry、Timeout、並列数 | Runtime設定・共通実行設計 | 運用・実行制御 |
| Scheduler時刻、実行頻度 | 運用設計 | Environmentまたは運用固有 |

これらの共通仕様は通常の設計書に記載し、実データをMasterへ重複登録しない。

## 7. Master体系と正本関係

```mermaid
flowchart TD
    B["Business Master<br/>業務境界"]
    U["UseCase Master<br/>業務目的"]
    S["Scenario Master<br/>確定経路"]
    D["Scenario詳細設計<br/>API呼出実体"]
    A["API Master<br/>API固定属性"]
    T["対応表<br/>Traceability View"]

    B --> U
    U --> S
    S --> D
    A --> D
    U --> T
    S --> T
    A --> T
    D --> T
```

| 情報 | 正本 |
|---|---|
| `businessId`とBusiness属性 | Business Master |
| `environmentId`とEnvironment属性 | Environment Master |
| `apiId`とAPI固定属性 | API Master |
| `useCaseId`とUseCase属性 | UseCase Master |
| `scenarioId`とScenario属性 | Scenario Master |
| `apiCallCode`、`callSequence`、呼出目的、実行条件 | Scenario詳細設計書 |
| UseCase・Scenario・APIの横断表示 | 対応表。ただし各値は上記正本から導出 |

正本とViewが不一致の場合、Viewの値で正本またはJavaを上書きしてはならない。

## 8. 識別子共通規則

### 8.1 ID一覧

| ID | Pattern例 | Scope | 正本 |
|---|---|---|---|
| `businessId` | `BUS-E6-NNN` | 全システム | Business Master |
| `environmentId` | `ENV-NAME` | 全システム | Environment Master |
| `apiId` | `API-NNN` | 全システム | API Master |
| `useCaseId` | `UC-E6-NNN` | 全システム | UseCase Master |
| `scenarioId` | `SC-E6-NNN` | 全システム | Scenario Master |
| `apiCallCode` | `CALL-NNN` | 一つのScenario内 | Scenario詳細設計書 |
| `resultKey` | 設計書規則に従うStable Key | Scenario Expected／実行結果の対応範囲 | Scenario設計・Expected・Java |

### 8.2 不変性

1. IDは初回登録後に変更しない。
2. 名称、Path、表示順またはClass名を外部参照Keyにしない。
3. 欠番を許容し、廃止IDを再利用しない。
4. 同一対象の属性変更ではIDを維持する。
5. 対象のIdentityまたは契約上の同一性が失われる置換では新IDを採番し、旧IDを無効化する。
6. `callSequence`は順序でありIdentityではない。
7. `apiId`と`apiCallCode`、`scenarioId`と`resultKey`を混同しない。

### 8.3 名称

- 名称は日本語の正式名称を使用する。
- 名称変更は許容するが、IDは変更しない。
- Environment名、実行日、Test Data値または暫定番号を名称へ混入しない。
- 名称だけで参照先を解決しない。

## 9. Reference共通規則

### 9.1 ID Reference

Master間の論理参照はIDで行う。

```text
Business → UseCase
UseCase → Scenario
Scenario詳細設計 → API
```

参照先IDは、対応する正本に存在しなければならない。

### 9.2 File Reference

1. Repository Root基準の相対Pathを使用する。
2. `./`、`../`、絶対Path、URLまたは個人PCのPathを使用しない。
3. Pathの大文字・小文字を実ファイルと一致させる。
4. 参照先ファイル名に対象IDを含め、参照元との照合を可能にする。
5. File名変更時は、全参照元を同一変更単位で更新する。
6. `enabled=true`のレコードは、必須参照先をBuild時に解決できなければならない。

### 9.3 List Reference

- 複数IDは重複なく保持する。
- Markdownの1セルでは`<br>`区切りを使用する。
- 特別な意味がない場合はID昇順とする。
- 順序情報をListの並びだけで表現しない。
- UseCase Masterの`scenarioIds`はScenario Masterとの必須逆引き一覧であり、双方を一致させる。

## 10. 共通文書メタデータ

全Master、設計書、Guide、ChecklistおよびExampleは、先頭にYAML Front Matter形式の文書メタデータを持つ。新規文書および内容を更新する文書は`snake_case`キーへ統一する。

### 10.1 必須項目

| 項目 | 説明 | 例 |
|---|---|---|
| `title` | 文書名称 | `Scenario Master` |
| `document_id` | 文書自身の一意な識別子 | `MST-E6-SC-001` |
| `version` | 文書版数 | `1.0.0-draft.1` |
| `status` | 文書Lifecycle状態 | `DRAFT` |
| `updated` | 最終更新日 | `2026-07-27` |

`document_type`および`system_name`も原則として設定する。同一ファイル内で`snake_case`と`camelCase`を混在させてはならない。

既存の旧`camelCase`文書は移行対象として扱い、内容変更時に同一Change Setで`snake_case`へ移行する。移行前の旧文書を理由に、新規文書へ旧形式を採用してはならない。

### 10.2 文書Lifecycle

| 状態 | 意味 | 利用可否 |
|---|---|---|
| `DRAFT` | 作成・更新中 | Review前提。Release入力不可 |
| `IN_REVIEW` | Review中 | 指摘修正以外の並行変更を制限 |
| `APPROVED` | 承認済み | Release候補 |
| `RELEASED` | Release対象として確定 | Change Requestなしの変更禁止 |
| `DEPRECATED` | 後継あり・新規利用禁止 | 過去追跡のみ |
| `RETIRED` | 利用終了 | 履歴保持のみ |

文書`status`とMasterレコードの`enabled`は別概念である。

ExampleはLifecycle Statusではない。File名の`_Example`と`document_type`で識別し、未承認のExample文書は`status=DRAFT`とする。

## 11. `enabled`共通規則

### 11.1 意味

`enabled`は、対象レコードを新しい設計・実行計画から参照可能かを示す。

| 値 | 意味 |
|:---:|---|
| `true` | 新規参照可能。必須参照、詳細設計および実装の整合性確認が必要 |
| `false` | 新規参照禁止。履歴、移行または将来候補としてレコードを保持 |

### 11.2 禁止事項

- 未確認値を隠すために`enabled=true`にしない。
- `enabled=false`を参照先不在、ID重複または親子関係不一致の代替状態にしない。
- 有効UseCaseに有効Scenarioが一件もない状態をReleaseしない。
- 有効Scenarioから無効APIを参照しない。
- 無効化済みレコードを、過去Runの追跡性確認なしに物理削除しない。

### 11.3 状態導出

対応表の`relationStatus`は、UseCase、ScenarioおよびAPIの`enabled`から導出する。手入力による上書きを禁止する。

## 12. 共通記述規則

1. ファイル形式はMarkdownとする。
2. 一行を一つのMasterレコードまたは一つの対応関係とする。
3. 正式列を設計書の承認なしに追加、削除または並べ替えない。
4. 必須値を空欄にせず、設計上許可された`NONE`等の明示値を使用する。
5. 未確認値を`TBD`で正式レコードへ仮登録しない。要確認事項として分離する。
6. Booleanは`true`または`false`で記述する。
7. Enumは個別設計書で定義された大文字値を使用する。
8. Dateは`YYYY-MM-DD`形式とする。
9. PathはBacktickで囲み、Repository Root基準で記述する。
10. セル内に改行相当が必要な場合は`<br>`を使用し、Markdown表を破壊しない。
11. 説明は判断可能な一文とし、実装コードや巨大JSONをMasterへ埋め込まない。

## 13. 正本と派生成果物

### 13.1 派生順序

```text
各Master
    +
Scenario詳細設計書
    ↓
API・UseCase・Scenario対応表
    ↓
整合性Validation・Coverage
```

### 13.2 派生成果物の規則

1. 派生成果物は入力元と生成時点を追跡できること。
2. 派生成果物の手修正を正本へ逆反映しない。
3. 正本変更後は、同一Change Set内で再生成または再照合する。
4. 不一致時は正本を確認し、Viewだけで補正しない。
5. ERRORを含むViewを完成またはRelease状態にしない。

## 14. 変更管理

### 14.1 変更区分

| 区分 | 例 | 必要な処置 |
|---|---|---|
| 追加 | 新API、新UseCase、新Scenario | ID採番、個別設計、参照、対応表、Validationを更新 |
| 属性変更 | 名称、説明、Path、Class | 影響先照合、同一ID維持、関連参照更新 |
| 関係変更 | Scenario所属、API呼出先、順序 | 正本変更、双方向Traceability、実装・Test影響Review |
| 無効化 | 廃止、未完成、利用停止 | `enabled=false`、新規参照除外、過去追跡保持 |
| 置換 | API契約または業務Identity変更 | 新ID採番、旧ID無効化、移行関係記録 |
| 物理削除 | 誤登録または保持期限後 | 承認、参照0件、過去Run解決性の確認 |

### 14.2 同一変更単位

次の成果物は、該当する変更に応じて一つのChange Setで更新する。

```text
Master
個別Master設計書
UseCase／Scenario／API詳細設計
Java実装・DTO
Input／Expected
対応表
Validation結果
Guide／Checklist／Example
```

すべてを毎回変更するという意味ではない。影響分析により対象外と判断した成果物も、Review記録で確認済みとする。

### 14.3 変更順序

1. 変更要求と理由を記録する。
2. 正本およびOwnerを特定する。
3. 参照元と派生成果物を列挙する。
4. 正本と必要な詳細設計を更新する。
5. Java、DTO、InputおよびExpectedへの影響を反映する。
6. 対応表を再生成または更新する。
7. 共通・個別Validationを実行する。
8. Review、承認、Releaseを行う。

## 15. Validation体系

### 15.1 Level

| Level | 意味 | Releaseへの影響 |
|---|---|---|
| `ERROR` | 参照不能、重複、責務違反または実行不能につながる不整合 | Release不可 |
| `WARNING` | 直ちに実行不能ではないが、品質・保守性・Coverageに懸念 | 承認または修正が必要 |
| `INFO` | 件数、Coverageまたは状態の参考情報 | Releaseを妨げない |

### 15.2 共通Validation

| Rule ID | 規則 | Level |
|---|---|---|
| `MST-CMN-V001` | MarkdownおよびFront Matterが解析可能である。 | ERROR |
| `MST-CMN-V002` | 文書IDがRepository内で一意である。 | ERROR |
| `MST-CMN-V003` | Masterレコードの主IDが形式に一致し一意である。 | ERROR |
| `MST-CMN-V004` | 全必須列が存在し、全行の列数が一致する。 | ERROR |
| `MST-CMN-V005` | Boolean、Enum、DateおよびPathが規則に一致する。 | ERROR |
| `MST-CMN-V006` | 全ID Referenceが正本で解決できる。 | ERROR |
| `MST-CMN-V007` | 有効レコードの必須File Referenceが解決できる。 | ERROR |
| `MST-CMN-V008` | UseCaseとScenarioの双方向関係が一致する。 | ERROR |
| `MST-CMN-V009` | 有効Scenarioが無効APIを参照しない。 | ERROR |
| `MST-CMN-V010` | 対応表の複合Keyが一意で、正本と一致する。 | ERROR |
| `MST-CMN-V011` | MasterへRuntime、Expected、CheckまたはDiff実装が混入していない。 | ERROR |
| `MST-CMN-V012` | 無効化レコードが新しい有効関係から参照されていない。 | ERROR |
| `MST-CMN-V013` | 未確認値が正式値として有効化されていない。 | ERROR |
| `MST-CMN-V014` | Exampleの900番台架空値が正式Masterへ混入していない。 | ERROR |
| `MST-CMN-V015` | 変更に対応する改訂履歴および影響確認が存在する。 | WARNING |

### 15.3 実行順序

```text
構文Validation
→ 単一ファイル項目Validation
→ ID・Path参照Validation
→ Master間整合性Validation
→ Scenario詳細設計整合性Validation
→ 対応表・Coverage Validation
→ Release Gate
```

前段のERRORを後段で補正してはならない。

### 15.4 Validation Evidence

Validation結果は、少なくとも次の項目を保持する。

| 項目 | 内容 |
|---|---|
| Validation Run ID | 一回の整合性確認を識別するID |
| Source Version | 対象Commitまたは不変なSource識別子 |
| Rule ID | `MST-CMN-*`、個別Master Ruleまたは`INT-*` |
| Result | `PASS`、`FAIL`、`BLOCKED`、`N/A` |
| Target | 対象ファイル、対象IDまたは対象行 |
| Expected／Actual | 期待値と実値 |
| Evidence | Log、Report、Diffまたは参照Path |
| Issue ID | `FAIL`または承認対象`WARNING`との対応 |

`BLOCKED`は`PASS`として扱わない。Release必須Ruleが必須入力不足で判定不能の場合、Release Gateを通過させてはならない。

詳細な実施項目と記録形式は`checklist/Master整合性Checklist.md`を正本とする。

## 16. Review

### 16.1 Review観点

| 観点 | 確認内容 |
|---|---|
| 責務 | Masterに置くべき安定情報だけが存在するか。 |
| 正本 | 各値の変更起点が一つに決まっているか。 |
| 粒度 | Business、UseCase、Scenario、APIおよび呼出実体が混同されていないか。 |
| Identity | 不変IDと表示順・名称が分離されているか。 |
| Reference | IDおよびPathが解決可能か。 |
| 状態 | 文書状態、`enabled`および派生状態が混同されていないか。 |
| Traceability | 順方向・逆方向に追跡できるか。 |
| 実装整合 | DTO、Java Class、Input、Expectedおよび詳細設計と一致するか。 |
| 変更影響 | 関連Master、View、実装、Testおよび過去追跡性を確認したか。 |

### 16.2 Reviewer

| 変更対象 | 必須Reviewer |
|---|---|
| Business | Business Owner / Business Analysis Lead |
| Environment | Runtime Lead / Operations Lead / Security担当 |
| API | API Owner / API Design Lead / Java Client担当 |
| UseCase | Business Owner / UseCase Design Lead |
| Scenario | Scenario Design Lead / Java実装担当 / Test Lead |
| 対応表 | API、UseCase、Scenario各担当 / System Architect |
| 共通規則 | System Architect / 各領域Lead |

### 16.3 ReviewとValidationの関係

1. 整合性Validationを先に実施し、結果をReview Packageへ含める。
2. 人のReviewは業務妥当性、責務、変更理由およびRelease判断を確認する。
3. Validation `ERROR`を人の承認だけで解除してはならない。
4. 人の指摘をValidation `PASS`だけでCloseしてはならない。
5. Reviewの記録、指摘および承認は`checklist/MasterレビューChecklist.md`を使用する。
6. Cross-MasterのRule、ResultおよびEvidenceは`checklist/Master整合性Checklist.md`を使用する。

## 17. Release Gate

Master一式をRelease可能とするには、次をすべて満たす。

1. 対象文書が承認済み状態である。
2. 正式列および責務境界が各設計書と一致する。
3. `ERROR`のValidation結果が0件である。
4. `WARNING`が修正済みまたは承認済みである。
5. 有効IDと必須File Referenceがすべて解決できる。
6. 有効UseCaseに一件以上の有効Scenarioが存在する。
7. 有効Scenarioが一件以上のAPI呼出を持つ。
8. 有効Scenarioが無効APIを参照していない。
9. 対応表が最新正本およびScenario詳細設計と一致する。
10. 改訂履歴、影響分析および承認Evidenceが存在する。
11. 同一Source Versionを対象にReviewとValidationを実施している。
12. `BLOCKED`となった必須Validationが0件である。

現時点のE6データでは、有効な`SC-E6-001`が無効な`API-002`を参照しているため、`TRC-V008`が解消されるまでRelease Gateを通過しない。

また、有効ScenarioのInput、Expected、詳細設計およびJava Classが未解決である場合も、該当Validationは`BLOCKED`となりReleaseできない。

## 18. Java・Runtimeとの境界

### 18.1 JavaがMasterから解決する情報

- `apiId`からAPIの固定属性を確認する。
- `scenarioId`からJava実行Classおよび実行資産参照を確認する。
- `useCaseId`および`scenarioId`で実行対象を追跡する。
- Environment IDから実行環境設定を選択する。

### 18.2 JavaがMasterから解決しない情報

- API呼出順序および分岐
- Request実値と値引継ぎ
- Expected値と`resultKey`
- Business Checkの条件式
- JSONフィールドDiffの詳細規則
- `IGNORE_FIELD`、`IGNORE_VALUE`
- Previous、CurrentおよびBaseline実体

これらはScenario詳細設計、Java実装、Input、Expected、Runtime設定または実行成果物を正本とする。

### 18.3 対応表

Java Runtimeは対応表だけを読み、実行経路を動的構築してはならない。対応表はBuild Validation、Review、CoverageおよびReport上の追跡に使用する。

## 19. 禁止事項

1. 同じ定義を複数Masterへ重複登録する。
2. Java固定実装を外部Masterとして再定義する。
3. Scenario固有情報を全体共通Masterへ昇格する。
4. Runtime Objectまたは実行結果をMasterへ保存する。
5. 未確認値を推測して正式レコードを作成する。
6. 名称、Path、Class名または表示順を参照Keyにする。
7. ViewまたはExampleを正本として利用する。
8. `enabled=false`で参照不整合を隠す。
9. 対応表だけを修正してJavaの実行順序を変更する。
10. 過去Runの解決性を確認せずIDまたはレコードを物理削除する。
11. 承認なしに正式列を追加・削除する。
12. 廃止済みのContext、Verification、Verification Policy、Compare PolicyをMasterとして復活させる。

## 20. 支援文書との統合

### 20.1 利用順序

```text
README
→ Master共通設計書
→ 個別Master設計書
→ ID・Reference Guide
→ 作成・更新 Guide
→ 整合性Checklist
→ Review Checklist
```

### 20.2 規則と実施文書

| 対象 | 設計正本 | 実施文書 |
|---|---|---|
| Master成立条件・責務境界 | 本書 | `MasterレビューChecklist.md` |
| 正式列・型・必須・Enum | 各個別Master設計書 | `Master整合性Checklist.md` |
| ID・Reference | 本書／`Master_ID・Reference記述ガイド.md` | `Master整合性Checklist.md` |
| 変更作業 | 本書／`Master作成・更新ガイド.md` | `MasterレビューChecklist.md` |
| Cross-Master関係 | 本書／対応表設計書 | `Master整合性Checklist.md` |
| 業務妥当性・承認 | 各業務設計／本書 | `MasterレビューChecklist.md` |
| Release Gate | 本書 | 両ChecklistのEvidence |

### 20.3 重複禁止

1. Checklist内に新しい設計規則を単独で追加しない。
2. Guide内の手順をMasterの正式項目として解釈しない。
3. READMEの概要説明を個別設計書より優先しない。
4. Exampleの値をValidation期待値に使用しない。
5. 同じRule IDを異なる意味で再利用しない。

## 21. 完了条件

本設計書は、次の条件を満たした時点で完成とする。

1. Masterの成立条件と管理対象外が承認されている。
2. 五つのMasterと一つのTraceability Viewの位置付けが承認されている。
3. ID、Reference、文書メタデータおよび`enabled`の共通規則が承認されている。
4. 変更管理、Validation LevelおよびRelease Gateが承認されている。
5. 各個別Master設計書と共通規則の矛盾がない。
6. Guide、ChecklistおよびExampleが本書に整合している。
7. 廃止済みMasterに依存しないことが確認されている。
8. READMEの固定構成と本書の適用対象が一致している。
9. Review Checklistと整合性Checklistの責務が分離されている。
10. Front Matterの新規・更新ルールが`snake_case`へ統一されている。

## 22. 決定事項

| Decision ID | 決定事項 | 理由 |
|---|---|---|
| `MST-CMN-DEC-001` | MasterはBusiness、Environment、API、UseCase、Scenarioの五種類に収束する。 | 安定した共通識別情報だけを正本化するため。 |
| `MST-CMN-DEC-002` | API・UseCase・Scenario対応表はTraceability Viewとする。 | 重複正本と不一致を防止するため。 |
| `MST-CMN-DEC-003` | API呼出明細はScenario詳細設計書を正本とする。 | `apiCallCode`はScenario内の呼出実体だから。 |
| `MST-CMN-DEC-004` | Java固定比較・判定規則をMaster化しない。 | 実装との二重管理を防止するため。 |
| `MST-CMN-DEC-005` | Runtime情報と実行結果をMaster化しない。 | 実行ごとに変化し、安定情報ではないため。 |
| `MST-CMN-DEC-006` | IDを不変とし、廃止は原則`enabled=false`で表す。 | 過去Runと変更履歴の追跡性を維持するため。 |
| `MST-CMN-DEC-007` | 未確認値を推測登録しない。 | 暫定値が正式仕様として利用されることを防止するため。 |
| `MST-CMN-DEC-008` | 新規・更新文書のFront Matterを`snake_case`へ統一する。 | 文書解析とValidationを単純化するため。 |
| `MST-CMN-DEC-009` | 人のReviewと機械的整合性検証を二つのChecklistへ分離する。 | 妥当性判断と再現可能な検証を混同しないため。 |
| `MST-CMN-DEC-010` | READMEに記載した5 Master、1 View、4支援Directoryを固定構成とする。 | 未承認のMaster拡張とDirectory増殖を防止するため。 |

## 23. 未決事項

| Issue ID | 内容 | 現在の扱い | 決定時期 |
|---|---|---|---|
| `MST-CMN-ISSUE-002` | 対応表を完全自動生成するか、初期段階は手動生成とするか。 | どちらでも同一Validationを必須とする。 | Build設計時 |
| `MST-CMN-ISSUE-003` | 文書VersionとMaster Data Versionを分離管理するか。 | 現段階は文書Versionのみ。必要性を運用設計で判断する。 | 運用設計時 |
| `MST-CMN-ISSUE-004` | 過去Runが参照したMaster版をどのEvidenceで固定するか。 | Git Commit等の不変識別子を候補とする。 | RunContext／Audit設計時 |

## 24. 維持・Release固定

### 24.1 文書整備完了後の維持

1. Master変更時は`Master作成・更新ガイド.md`に従う。
2. IDまたはReference変更時は`Master_ID・Reference記述ガイド.md`に従う。
3. 同一Source Versionに対して`Master整合性Checklist.md`を実施する。
4. Validation Evidenceを`MasterレビューChecklist.md`へ添付する。
5. 承認完了後に`APPROVED`、Release確定後に`RELEASED`へ変更する。

### 24.2 Release確定条件

`02_master`を`RELEASED`とするには、次をすべて満たす。

1. 本書と各個別設計書が承認済みである。
2. 正式Master、View、Guide、ChecklistおよびExampleがREADMEの固定構成に一致する。
3. Validation `ERROR`および必須`BLOCKED`が0件である。
4. `WARNING`が修正済みまたは承認済みである。
5. 現行E6の`TRC-V008`が解消している。
6. 有効ScenarioのInput、Expected、詳細設計、Java ClassおよびAPI参照が解決可能である。
7. 必須ReviewerとApproverのEvidenceが存在する。

文書内容の作成完了とRelease確定は別判定である。文書がそろっていても、データまたは参照に`ERROR`／`BLOCKED`がある場合は`RELEASED`にしない。
