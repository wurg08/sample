---
title: API・UseCase・Scenario対応表設計書
document_id: E6-API-VAL-MST-TRACE-DESIGN
version: 1.0.0-draft.4
status: DRAFT
document_type: Traceability View設計書
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# API・UseCase・Scenario対応表設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | API・UseCase・Scenario対応表設計書 |
| 文書ID | `E6-API-VAL-MST-TRACE-DESIGN` |
| 対象システム | E6 API Verification Platform |
| 対象成果物 | `system/02_master/API_UseCase_Scenario対応表.md` |
| 文書種別 | Traceability View設計書 |
| 版数 | `1.0.0-draft.4` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Verification Platform Team |
| レビュー責任 | System Architect / API Analysis Lead / Scenario Design Lead / Test Lead |
| 承認責任 | System Owner / Business Owner / API Owner |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-25 | Master体系再編後のTraceabilityモデルに基づき全面再作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | Front Matterを`snake_case`へ移行し、Traceability View責務、現行Cross-Master Errorおよび完了済み成果物との整合を再確認 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | API-001／002詳細設計書作成後の`apiDesignRef`解決状態と残存契約Blockerを同期 | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | SC-E6-001詳細設計との呼出集合、順序、目的および条件の照合完了を同期 | DRAFT |

## 3. 目的

本書は、E6 API Verification PlatformにおけるUseCase、ScenarioおよびAPIの対応関係を、レビュー可能かつ機械検証可能な一覧として表示するための設計を定義する。

`API_UseCase_Scenario対応表.md`は、次の問いへ一つの画面で回答する。

- 一つのUseCaseは、どのScenarioによって具体化されているか。
- 一つのScenarioは、どのAPIを、どの順序で、何の目的で呼び出すか。
- 同一APIがScenario内で複数回呼び出される場合、各呼出をどう識別するか。
- 一つのAPIは、どのUseCaseおよびScenarioで利用されているか。
- 有効Scenarioが、無効または未登録のAPIを参照していないか。
- MasterとScenario詳細設計の間に欠落、重複または不整合がないか。

本対応表はTraceabilityのための派生Viewであり、UseCase、Scenario、APIまたはAPI呼出仕様の正本ではない。

## 4. 適用範囲

本書は、次の対応関係に適用する。

- 7業務Flowを基に設計する最大10件程度のUseCase
- 各UseCaseに所属する正常、代替、異常、境界等のScenario
- 各Scenarioで実行または設計上Skip判定されるAPI呼出
- 初期対象約24 API
- 同一Scenario内における同一APIの複数回呼出
- 有効レコードおよび履歴追跡に必要な無効レコード

APIを一件も呼び出さない処理は、本API検証システムにおけるScenarioとして本対応表の対象にしない。共通前処理、データ準備または運用処理として別成果物で管理する。

## 5. 用語

| 用語 | 定義 |
|---|---|
| 正本 | 対象情報を正式に定義し、変更の起点となる成果物。 |
| Traceability View | 複数の正本から情報を導出し、追跡・レビュー・整合性確認のために表示する成果物。 |
| 呼出実体 | 特定Scenario内におけるAPIの一回の呼出。 |
| `apiId` | APIそのものを全システムで一意に識別するID。 |
| `apiCallCode` | 一つのScenario内でAPI呼出実体を一意に識別する安定Key。 |
| `callSequence` | Scenario内のAPI呼出を表示する順序。Identityではない。 |
| 有効関係 | 有効なUseCase、ScenarioおよびAPI間に成立する参照関係。 |
| 無効関係 | いずれかの正本が`enabled=false`であり、履歴追跡のために表示する関係。 |
| Orphan | 親または参照先が存在せず、正本から完全に解決できないレコード。 |

## 6. 基本原則

| 原則ID | 原則 | 説明 |
|---|---|---|
| `TRC-P001` | 派生View | 対応表を第四のMasterまたは実行仕様の正本にしない。 |
| `TRC-P002` | 1呼出実体1行 | 1行は`scenarioId + apiCallCode`で識別される一つのAPI呼出実体を表す。 |
| `TRC-P003` | ID参照 | 名称、表示順またはPathではなく、安定IDで正本を結合する。 |
| `TRC-P004` | 正本優先 | 対応表と正本が不一致の場合、対応表を優先して実行してはならない。 |
| `TRC-P005` | 双方向追跡 | UseCaseからAPI、およびAPIからUseCaseへ追跡できること。 |
| `TRC-P006` | 呼出Identityと順序の分離 | `apiCallCode`をIdentity、`callSequence`を表示順として扱う。 |
| `TRC-P007` | 同一API複数回呼出を許容 | 同一`apiId`の複数行を許容するが、`apiCallCode`は呼出ごとに分ける。 |
| `TRC-P008` | 全件整合性 | 有効関係の欠落、重複、Orphanおよび参照先無効をErrorとして検出する。 |
| `TRC-P009` | 履歴追跡 | 無効化済みレコードも、物理削除せず必要な関係を追跡可能にする。 |
| `TRC-P010` | 実行非依存 | Java Runtimeは対応表だけを読んでAPI経路を組み立てない。 |

## 7. 対応表の位置付け

### 7.1 正式決定

`API_UseCase_Scenario対応表.md`の位置付けを次のとおり定める。

```text
API_UseCase_Scenario対応表.md
    = Traceability View
    ≠ Master
    ≠ Scenario実行仕様
    ≠ Java実行設定
```

対応表はRepositoryでレビュー対象となる正式成果物であるが、掲載された個々の値の定義元ではない。

### 7.2 正本

| 情報 | 正本 |
|---|---|
| UseCaseのID、名称、業務目的、有効状態 | `UseCase_Master.md` |
| ScenarioのID、名称、種別、親UseCase、有効状態 | `Scenario_Master.md` |
| APIのID、名称、Method、Path、DTO、有効状態 | `E6_API_Master.md` |
| `apiCallCode`、`callSequence`、`callPurpose`、`executeCondition` | Scenario詳細設計書 |
| API呼出の実処理、値引継ぎ、分岐 | Scenario Java実装 |
| Request／Response項目 | API詳細設計書およびDTO |

### 7.3 不一致時の処置

対応表と正本が不一致の場合は、次の順序で処理する。

1. 整合性Errorとして検出する。
2. 対応表からJava実行を開始しない。
3. 各正本とScenario詳細設計を確認する。
4. 正本が正しい場合は対応表を再生成または更新する。
5. 正本が誤っている場合は、正本を承認手続に従って修正した後、対応表を更新する。

不一致を自動的に対応表の値で上書きしてはならない。

## 8. 責務

対応表は、次の責務を持つ。

1. UseCase、Scenario、APIの関係を一行単位で可視化する。
2. Scenario内のAPI呼出順序と呼出Identityを一覧化する。
3. 同一APIの複数回呼出を区別する。
4. UseCaseからAPIへの順方向Traceabilityを提供する。
5. APIからUseCase／Scenarioへの逆方向Traceabilityを提供する。
6. API未使用、Scenario未具体化、Orphan等の検出に必要な入力を提供する。
7. MasterおよびScenario詳細設計間の整合性レビューを支援する。
8. 変更時の影響範囲確認を支援する。
9. 全有効ScenarioのAPI呼出定義が網羅されていることを証明する。

## 9. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| Businessの詳細分類・業務Flow | Business Master／現行業務分析書 |
| UseCaseの目的、範囲、前提条件 | UseCase Master／UseCase詳細設計書 |
| ScenarioのInput Pattern、期待終了状態 | Scenario Master／Scenario詳細設計書 |
| APIのMethod、Endpoint、DTO | API Master／API詳細設計書 |
| Request初期値 | Scenario Input |
| 前段Responseから後段Requestへの値Mapping | Scenario詳細設計書／Java実装 |
| Context項目、Lifecycle | ScenarioContext設計／Java実装 |
| Expected値、`resultKey` | Expected／Java Check |
| Business Checkの内容・順序 | Scenario詳細設計書／Java実装 |
| Response Diff、`IGNORE_FIELD`、`IGNORE_VALUE` | API専用Java比較定義／APIレスポンスDiff設計書 |
| Baseline、`previousRunId` | Execution State／Baseline管理設計 |
| Retry、Timeout、並列数 | 共通実行設計／Runtime設定 |
| Base URL、Credential、Proxy | Environment Master／Environment設定 |
| Run ID、実行日時、実行結果 | RunContext／実行成果物 |

対応表へInput値、Expected値、JSON Path、比較除外項目またはJava判定式を追加してはならない。

## 10. 関連成果物と責務境界

```mermaid
flowchart TD
    U["UseCase Master<br/>業務目的"]
    S["Scenario Master<br/>経路Identity"]
    A["API Master<br/>API固定定義"]
    D["Scenario詳細設計<br/>呼出実体・順序"]
    T["対応表<br/>Traceability View"]

    U --> T
    S --> T
    A --> T
    D --> T
```

| 成果物 | 対応表への提供情報 | 正本関係 |
|---|---|---|
| `UseCase_Master.md` | `useCaseId`、UseCase名称、有効状態 | UseCaseの正本 |
| `Scenario_Master.md` | `scenarioId`、`useCaseId`、Scenario名称、種別、有効状態、設計書参照 | Scenarioの正本 |
| `E6_API_Master.md` | `apiId`、API名称、有効状態、API設計書参照 | APIの正本 |
| Scenario詳細設計書 | `apiCallCode`、`callSequence`、`apiId`、呼出目的、実行条件 | API呼出仕様の正本 |
| `API_UseCase_Scenario対応表.md` | 上記情報を結合して表示 | 派生View |
| Java Scenario Class | Scenario経路を実装 | Runtime実装 |
| 実行成果物 | 実際に呼び出したAPIと結果を記録 | Runtime Evidence |

## 11. 関係モデル

### 11.1 Cardinality

```mermaid
erDiagram
    USE_CASE ||--|{ SCENARIO : contains
    SCENARIO ||--|{ API_CALL : defines
    API ||--o{ API_CALL : referenced_by
```

| 関係 | Cardinality | 規則 |
|---|---|---|
| UseCase → Scenario | 1:N | 有効UseCaseは一つ以上の有効Scenarioを持つ。 |
| Scenario → UseCase | N:1 | Scenarioは一つのUseCaseだけに所属する。 |
| Scenario → API Call | 1:N | 本システムの有効Scenarioは一つ以上のAPI呼出実体を持つ。 |
| API Call → API | N:1 | 一つの呼出実体は一つのAPIだけを参照する。 |
| API → Scenario | M:N | 一つのAPIは複数Scenarioで利用でき、Scenarioは複数APIを利用できる。 |

### 11.2 Identity

```text
UseCase                     useCaseId
Scenario                    scenarioId
API                         apiId
Scenario内のAPI呼出実体     scenarioId + apiCallCode
対応表の1行                 scenarioId + apiCallCode
```

完全な業務追跡Keyは`useCaseId + scenarioId + apiCallCode + apiId`で表現できる。ただし、`apiId`は呼出実体の参照先であり、行Identityの一部として重複判定に使用しない。

同一`scenarioId + apiCallCode`が異なる`apiId`を示した場合は、更新として黙認せず不整合として扱う。

## 12. 対応表モデル

### 12.1 行の粒度

1行は、一つのScenario内に定義された一つのAPI呼出実体を表す。

```text
1 row
    = 1 scenarioId
    + 1 apiCallCode
    + 1 referenced apiId
```

UseCase単位、Scenario単位またはAPI単位で複数呼出を一つのセルへまとめてはならない。

### 12.2 正式表示項目

| No. | 表示名 | 列名 | 型 | 必須 | 導出元 |
|---:|---|---|---|:---:|---|
| 1 | UseCase ID | `useCaseId` | String | Yes | Scenario Masterの`useCaseId` |
| 2 | UseCase名称 | `useCaseName` | String | Yes | UseCase Master |
| 3 | Scenario ID | `scenarioId` | String | Yes | Scenario Master |
| 4 | Scenario名称 | `scenarioName` | String | Yes | Scenario Master |
| 5 | Scenario種別 | `scenarioType` | Enum | Yes | Scenario Master |
| 6 | 呼出順序 | `callSequence` | Integer | Yes | Scenario詳細設計書 |
| 7 | API Call Code | `apiCallCode` | String | Yes | Scenario詳細設計書 |
| 8 | API ID | `apiId` | String | Yes | Scenario詳細設計書から参照し、API Masterで解決 |
| 9 | API名称 | `apiName` | String | Yes | API Master |
| 10 | 呼出目的 | `callPurpose` | String | Yes | Scenario詳細設計書 |
| 11 | 実行条件 | `executeCondition` | String | Yes | Scenario詳細設計書 |
| 12 | Scenario設計書参照 | `scenarioDesignRef` | Path | Yes | Scenario Master |
| 13 | API設計書参照 | `apiDesignRef` | Path | Yes | API Master |
| 14 | 関係状態 | `relationStatus` | Enum | Yes | 各正本の`enabled`から導出 |

### 12.3 記述形式

```markdown
| useCaseId | useCaseName | scenarioId | scenarioName | scenarioType | callSequence | apiCallCode | apiId | apiName | callPurpose | executeCondition | scenarioDesignRef | apiDesignRef | relationStatus |
|---|---|---|---|---|---:|---|---|---|---|---|---|---|---|
| UC-E6-901 | 注文状態変更検証 | SC-E6-901 | 注文状態変更正常経路 | NORMAL | 10 | CALL-001 | API-901 | 注文情報取得API | 変更前注文情報取得 | ALWAYS | system/04_usecase_design/examples/scenario/SC-E6-901設計書_Example.md | system/03_api_design/examples/API-901設計書_Example.md | ACTIVE |
| UC-E6-901 | 注文状態変更検証 | SC-E6-901 | 注文状態変更正常経路 | NORMAL | 20 | CALL-002 | API-902 | 注文状態更新API | 注文状態変更 | CALL-001が業務正常 | system/04_usecase_design/examples/scenario/SC-E6-901設計書_Example.md | system/03_api_design/examples/API-902設計書_Example.md | ACTIVE |
| UC-E6-901 | 注文状態変更検証 | SC-E6-901 | 注文状態変更正常経路 | NORMAL | 30 | CALL-003 | API-901 | 注文情報取得API | 変更後注文情報再取得 | CALL-002が更新成功 | system/04_usecase_design/examples/scenario/SC-E6-901設計書_Example.md | system/03_api_design/examples/API-901設計書_Example.md | ACTIVE |
```

上記は900番台の架空Exampleであり、正式Master状態を表さない。正式対応表は正式MasterとScenario詳細設計から生成し、Example行をコピーしてはならない。

### 12.4 表示順

```text
useCaseId ASC
→ scenarioId ASC
→ callSequence ASC
→ apiCallCode ASC
```

表示順をIdentityまたはJava実行Keyとして使用してはならない。

## 13. 項目別設計規則

### 13.1 UseCase

- `useCaseId`はScenario Masterの`useCaseId`から取得する。
- `useCaseName`はUseCase Masterから取得し、手入力で別名称を設定しない。
- Scenario Masterの親UseCaseとUseCase Masterの`scenarioIds`が一致することを前提とする。
- UseCaseからAPIを直接結合せず、必ずScenarioとAPI呼出実体を介する。

### 13.2 Scenario

- `scenarioId`、`scenarioName`、`scenarioType`、`scenarioDesignRef`はScenario Masterから取得する。
- 一つのScenarioを複数UseCaseの行へ重複展開しない。
- `enabled=true`のScenarioは、一つ以上のAPI呼出行を持たなければならない。
- Scenario名称または種別変更時も、既存の`scenarioId`と`apiCallCode`で関係を追跡する。

### 13.3 API Call Code

- `apiCallCode`はScenario詳細設計書で定義する。
- ScopeはScenario内とし、別Scenarioで同一値を使用できる。
- 形式は`CALL-NNN`を標準とする。
- 同一Scenario内で一意かつ安定でなければならない。
- 呼出順序が変更されても、同一の呼出目的である限り`apiCallCode`を変更しない。
- 廃止した`apiCallCode`を同一Scenario内の別目的に再利用しない。

Pattern:

```regex
^CALL-[0-9]{3}$
```

### 13.4 Call Sequence

- `callSequence`はScenario詳細設計書から取得する。
- 正の整数とする。
- 標準は`10`、`20`、`30`のように10刻みとし、挿入余地を確保する。
- 同一Scenario内で重複してはならない。
- `callSequence`変更は呼出Identity変更ではない。
- 分岐条件またはSkip判定を`callSequence`だけで表現しない。

### 13.5 API

- `apiId`はScenario詳細設計書に記載された参照値を使用する。
- `apiName`と`apiDesignRef`はAPI Masterから導出する。
- 一つの`apiCallCode`に複数の`apiId`を設定しない。
- 同一Scenario内で同じ`apiId`を複数回使用できる。
- `enabled=false`のAPIを有効Scenarioの新規呼出として設定してはならない。

### 13.6 呼出目的と実行条件

- `callPurpose`は、その呼出がScenario内で果たす役割を一文で記述する。
- 「処理1」「API呼出」等の識別不能な表現を使用しない。
- `executeCondition`は`ALWAYS`またはScenario詳細設計内で一意に理解できる条件参照とする。
- Java式、SQL、SecretまたはEnvironment固有値を直接記述しない。
- 条件詳細、分岐、値引継ぎおよび`onError`はScenario詳細設計を正本とする。

### 13.7 関係状態

`relationStatus`は手入力せず、次の規則で導出する。

| 値 | 条件 |
|---|---|
| `ACTIVE` | UseCase、Scenario、APIがすべて`enabled=true`であり、全参照が有効。 |
| `INACTIVE` | UseCase、ScenarioまたはAPIのいずれかが`enabled=false`であり、履歴追跡対象。 |

参照先不在、親子関係不一致または同一Key重複は状態値で吸収せず、Validation Errorとする。`INVALID`行を正式対応表へ残してはならない。

## 14. 特殊な関係の取扱い

### 14.1 同一APIの複数回呼出

同一`apiId`を複数回呼ぶ場合は、呼出実体ごとに別行とする。

```text
SC-E6-001 + CALL-001 → API-001  更新前照会
SC-E6-001 + CALL-003 → API-001  更新後照会
```

API Masterのレコードを複製してはならない。

### 14.2 条件付き呼出

条件付き呼出も、Scenario詳細設計に呼出実体として定義されている場合は対応表へ表示する。

- `executeCondition`に条件概要または条件参照を表示する。
- 実行時に条件不成立となった呼出は`SKIPPED`として実行成果物へ記録する。
- 対応表には実行実績Statusを記録しない。
- 分岐によって期待終了状態が変わる場合は、原則としてScenarioを分割する。

### 14.3 途中終了

期待Errorまたは途中終了により後続APIを呼ばないScenarioでは、そのScenario詳細設計に定義された経路だけを表示する。

別経路では呼び出すAPIを、実行されないことだけを理由に当該Scenarioへ追加してはならない。設計上「条件付き呼出として存在し、Skipを記録する」場合だけ表示する。

### 14.4 API置換

API置換時は次のとおり処理する。

1. 新APIへ新しい`apiId`を採番する。
2. Scenario詳細設計の対象呼出を変更する。
3. 呼出目的が同一であれば、原則として`apiCallCode`を維持する。
4. 対応表を更新する。
5. 旧関係はVersion履歴から追跡可能にする。
6. 旧APIを`enabled=false`とする。

### 14.5 無効レコード

- 無効化後も過去Runから当時のUseCase、Scenario、APIを解決できるようにする。
- 現行対応表に無効関係を掲載する場合は`relationStatus=INACTIVE`とする。
- 標準表示ではACTIVEを先に表示できるが、無効関係を黙って削除しない。
- 物理削除は、保持期間とAudit要件を確認した正式な廃止手続なしに行わない。

## 15. 作成・更新方式

### 15.1 推奨方式

対応表は、次の成果物を解析して生成する方式を推奨する。

```text
UseCase Master
      +
Scenario Master
      +
API Master
      +
Scenario詳細設計
      ↓
Traceability Builder
      ↓
API_UseCase_Scenario対応表.md
```

初期段階で手動作成する場合も、正本と同一変更単位で更新し、同じValidation Ruleを適用する。

### 15.2 生成順序

1. UseCase Masterを読み込む。
2. Scenario Masterを読み込み、親UseCaseを解決する。
3. `scenarioDesignRef`からAPI呼出定義を取得する。
4. 各`apiId`をAPI Masterで解決する。
5. 名称、種別、Pathおよび有効状態を導出する。
6. `scenarioId + apiCallCode`単位で1行を生成する。
7. 全Validationを実行する。
8. 標準表示順でMarkdownを出力する。

### 15.3 更新禁止

生成方式を採用した場合、生成済み対応表を直接編集してはならない。修正は正本またはScenario詳細設計へ行い、再生成する。

手動方式の場合も、対応表だけを変更して正本へ逆反映する運用は禁止する。

### 15.4 Source Version

対応表の文書Headerまたは生成情報には、少なくとも次を追跡可能にする。

- 生成日時
- Generator Version
- 対象Repository Revision
- UseCase Master Version
- Scenario Master Version
- API Master Version

個々の行へVersion列を追加する必要はない。

## 16. Validation・整合性規則

### 16.1 行Validation

| Rule ID | 規則 | Level |
|---|---|---|
| `TRC-V001` | 必須14項目がすべて設定されていること。 | ERROR |
| `TRC-V002` | `scenarioId + apiCallCode`が全行で一意であること。 | ERROR |
| `TRC-V003` | `apiCallCode`が標準Patternに一致すること。 | ERROR |
| `TRC-V004` | `callSequence`が正の整数であること。 | ERROR |
| `TRC-V005` | 同一Scenario内で`callSequence`が重複しないこと。 | ERROR |
| `TRC-V006` | `relationStatus`が導出規則と一致すること。 | ERROR |
| `TRC-V007` | `callPurpose`と`executeCondition`が空文字でないこと。 | ERROR |
| `TRC-V008` | PathがRepository Root基準の相対Pathであること。 | ERROR |

### 16.2 Master参照整合性

| Rule ID | 規則 | Level |
|---|---|---|
| `TRC-V101` | 全`useCaseId`がUseCase Masterに存在すること。 | ERROR |
| `TRC-V102` | 全`scenarioId`がScenario Masterに存在すること。 | ERROR |
| `TRC-V103` | 全`apiId`がAPI Masterに存在すること。 | ERROR |
| `TRC-V104` | 行の`useCaseId`がScenario Masterの親UseCaseと一致すること。 | ERROR |
| `TRC-V105` | UseCase Masterの`scenarioIds`に当該`scenarioId`が存在すること。 | ERROR |
| `TRC-V106` | 名称と種別が各Masterの値と一致すること。 | ERROR |
| `TRC-V107` | `scenarioDesignRef`がScenario Masterと一致すること。 | ERROR |
| `TRC-V108` | `apiDesignRef`がAPI Masterと一致すること。 | ERROR |
| `TRC-V109` | 有効Scenarioが無効UseCaseを参照していないこと。 | ERROR |
| `TRC-V110` | 有効Scenarioが無効APIを新規参照していないこと。 | ERROR |

### 16.3 Scenario詳細設計整合性

| Rule ID | 規則 | Level |
|---|---|---|
| `TRC-V201` | Scenario詳細設計の全API呼出実体が対応表に存在すること。 | ERROR |
| `TRC-V202` | 対応表の全API呼出実体がScenario詳細設計に存在すること。 | ERROR |
| `TRC-V203` | `apiCallCode`、`callSequence`、`apiId`がScenario詳細設計と一致すること。 | ERROR |
| `TRC-V204` | `callPurpose`、`executeCondition`がScenario詳細設計と一致すること。 | ERROR |
| `TRC-V205` | 同一`apiCallCode`が異なる`apiId`を示していないこと。 | ERROR |
| `TRC-V206` | 有効Scenarioが一つ以上のAPI呼出実体を持つこと。 | ERROR |

### 16.4 全体整合性

| Rule ID | 規則 | Level |
|---|---|---|
| `TRC-V301` | 有効UseCaseが一つ以上の有効Scenarioへ追跡できること。 | ERROR |
| `TRC-V302` | 有効Scenarioが一つ以上の有効APIへ追跡できること。 | ERROR |
| `TRC-V303` | 対象API一覧のうち未使用APIを抽出できること。 | WARNING |
| `TRC-V304` | Orphan UseCase、Scenario、API CallまたはAPIが存在しないこと。 | ERROR |
| `TRC-V305` | 同一業務目的のUseCase重複をTraceability上で確認できること。 | WARNING |
| `TRC-V306` | 廃止済みのContext／Verification／Policy／Compare Policy Masterへの参照が存在しないこと。 | ERROR |

### 16.5 Error時の動作

- ERRORが1件でも存在する場合、対応表を完成状態にしない。
- 自動生成の場合、既存の正常版を不完全な出力で上書きしない。
- Java Scenario実行前Validationで重大な参照不整合を再検出した場合、対象Scenarioを開始しない。
- WARNINGは理由と対応方針を記録し、レビューで受容可否を判断する。

## 17. Traceability確認

### 17.1 順方向

```text
UseCase
→ Scenario
→ apiCallCode
→ API
→ API詳細設計
```

UseCaseレビューでは、対象業務目的を実現するすべてのScenarioとAPI呼出を確認する。

### 17.2 逆方向

```text
API
→ apiCallCode
→ Scenario
→ UseCase
→ Business
```

API変更時は、対象APIを利用する全Scenario、UseCase、BusinessおよびJava実装を抽出する。

### 17.3 Coverage指標

| 指標 | 算出 |
|---|---|
| UseCase Scenario Coverage | 有効Scenarioを1件以上持つ有効UseCase数 ÷ 有効UseCase総数 |
| Scenario API Coverage | API呼出を1件以上持つ有効Scenario数 ÷ 有効Scenario総数 |
| API Usage Coverage | 有効Scenarioから参照される有効API数 ÷ 対象有効API総数 |
| Call Trace Completeness | 対応表と一致するAPI呼出実体数 ÷ Scenario詳細設計の全API呼出実体数 |
| Orphan Count | 解決不能なUseCase、Scenario、API Call、APIの件数 |

必須初期基準は次とする。

```text
UseCase Scenario Coverage = 100%
Scenario API Coverage      = 100%
Call Trace Completeness    = 100%
Orphan Count               = 0
```

API Usage Coverageが100%未満の場合は直ちにErrorとせず、未使用理由をAPI追加予定、廃止予定、共通利用予定等に分類してレビューする。

## 18. 変更管理

### 18.1 変更影響

| 変更 | 対応表への影響 | 必須確認先 |
|---|---|---|
| UseCase追加・分割・統合 | `useCaseId`と配下行の変更 | Business、Scenario、UseCase詳細設計 |
| Scenario追加・削除・親変更 | 行集合または`useCaseId`の変更 | UseCase Master、Scenario詳細設計、Java |
| API呼出追加・削除 | 行追加・削除 | Scenario詳細設計、Java、Input、Output |
| API呼出順序変更 | `callSequence`変更 | Scenario詳細設計、Java、回帰試験 |
| 呼出目的変更 | `callPurpose`変更 | Scenario同一性、Java、Check |
| API置換 | `apiId`、API名称、設計書参照変更 | API Master、API詳細設計、DTO、Java |
| 名称変更 | 表示列変更 | 対象Master、Report |
| 有効状態変更 | `relationStatus`変更 | Scheduler、実行対象、履歴追跡 |

### 18.2 同一変更単位

関係変更時は、次を同一Pull Requestまたは同一承認単位で更新する。

- 対象Master
- Scenario詳細設計書
- Scenario Input／Expected（影響がある場合）
- Java Scenario実装
- API・UseCase・Scenario対応表
- 関連Test

### 18.3 物理削除

IDまたは呼出関係の物理削除前に、過去のRun、Snapshot、DiffおよびReportから当時の定義を解決できることを確認する。原則は無効化およびVersion履歴による保持とする。

## 19. Java・Build連携

### 19.1 Runtime

Java Runtimeは、次を正本として使用する。

- `scenarioId`解決: Scenario Master
- API呼出順序と条件: Scenario詳細設計およびJava Scenario実装
- `apiId`解決: API Master
- Request／Response契約: API詳細設計およびDTO

対応表を唯一の入力として、汎用EngineがScenarioの業務分岐や値引継ぎを推測してはならない。

### 19.2 Build Validation

BuildまたはCIでは、少なくとも次を検証する。

1. 三MasterのFormatおよび参照整合性
2. Scenario詳細設計のAPI呼出定義
3. 対応表の完全一致
4. Java Scenario Classの存在
5. API ClientおよびDTOの存在
6. Orphan Countが0であること
7. Coverage必須基準を満たすこと

### 19.3 実行Evidenceとの照合

一回のScenario実行後、実際のAPI呼出は次で対応表へ追跡できなければならない。

```text
runId
+ useCaseId
+ scenarioId
+ apiCallCode
+ apiId
```

実行成果物に存在する`scenarioId + apiCallCode`が対応表に存在しない場合は、未設計呼出としてErrorとする。

対応表に存在する条件付き呼出が実行されなかった場合は、実行成果物に`SKIPPED`と理由を記録する。

## 20. Review Checklist

### 20.1 位置付け

- [ ] 対応表がTraceability Viewであることを関係者が理解している。
- [ ] 対応表を第四のMasterまたはJava実行仕様として使用していない。
- [ ] 各値の正本が明確である。
- [ ] 不一致時に対応表を優先しない。

### 20.2 粒度・Identity

- [ ] 1行が1 API呼出実体になっている。
- [ ] `scenarioId + apiCallCode`が一意である。
- [ ] `apiCallCode`と`callSequence`を混同していない。
- [ ] 同一API複数回呼出を別`apiCallCode`で区別している。
- [ ] 廃止済み`apiCallCode`を別目的へ再利用していない。

### 20.3 参照整合性

- [ ] 全UseCase、Scenario、APIが各Masterに存在する。
- [ ] Scenarioの親UseCaseが双方向に一致する。
- [ ] 全API呼出実体がScenario詳細設計と一致する。
- [ ] 有効Scenarioが無効UseCaseまたは無効APIを参照していない。
- [ ] Orphanが0件である。

### 20.4 責務境界

- [ ] Input値、Expected値、Context項目が混入していない。
- [ ] `resultKey`、Business Check、Response Diffが混入していない。
- [ ] `IGNORE_FIELD`、`IGNORE_VALUE`が混入していない。
- [ ] Base URL、Credential、Runtime値が混入していない。
- [ ] 廃止済みMasterへの依存がない。

### 20.5 Coverage・変更

- [ ] UseCase Scenario Coverageが100%である。
- [ ] Scenario API Coverageが100%である。
- [ ] Call Trace Completenessが100%である。
- [ ] API未使用理由を確認している。
- [ ] 変更影響先と回帰試験を確認している。
- [ ] 無効化後も過去Runから追跡できる。

## 21. 完了条件

本設計書は、次をすべて満たした時点で初版完成とする。

1. 対応表がTraceability Viewであり、正本ではないことが承認されている。
2. 1行1 API呼出実体の粒度が承認されている。
3. 正式14表示項目と各導出元が承認されている。
4. `apiCallCode`、`callSequence`および`apiId`の責務が分離されている。
5. 同一API複数回呼出、条件付き呼出、途中終了および無効関係の扱いが確認されている。
6. Validation RuleとCoverage基準がレビュー済みである。
7. API／UseCase／Scenario三設計書との責務境界に矛盾がない。
8. 廃止済みのContext／Verification／Policy／Compare Policy Masterへの依存が存在しない。
9. 対応表からJava実行仕様を推測しないことが合意されている。
10. 約24 API、7業務Flow、最大10 UseCaseを本モデルで追跡できることが確認されている。

## 22. 決定事項

| Decision ID | 決定事項 | 理由 |
|---|---|---|
| `TRC-DEC-001` | 対応表はTraceability Viewとする。 | 重複正本と不一致を防止する。 |
| `TRC-DEC-002` | 1行を`scenarioId + apiCallCode`単位とする。 | 同一APIの複数回呼出を識別する。 |
| `TRC-DEC-003` | `callSequence`を対応表へ表示する。 | レビュー時に経路順を確認可能にする。ただし正本はScenario詳細設計とする。 |
| `TRC-DEC-004` | `apiCallCode`を対応表へ表示する。 | Runtime成果物まで一貫した呼出Identityを提供する。 |
| `TRC-DEC-005` | Javaは対応表だけでScenarioを実行しない。 | 業務分岐、値引継ぎ、CheckをViewへ重複定義しない。 |
| `TRC-DEC-006` | Response比較除外定義を対応表へ置かない。 | `apiId`または`apiCallCode`単位のJava比較定義に責務を限定する。 |

## 23. 現行Blocker

| Blocker ID | 内容 | 解除条件 |
|---|---|---|
| `TRC-BLOCK-001` | 正式UseCase、ScenarioおよびAPIが0件である。 | 正式Master登録後にScenario詳細設計から対応表を生成する。 |
| `TRC-BLOCK-002` | 正式な`scenarioId + apiCallCode`集合が存在しない。 | Scenario詳細設計と対応表を同一Change Setで作成・照合する。 |
| `TRC-BLOCK-003` | 正式API契約、DTOおよびJava Build Traceが存在しない。 | API詳細設計とJava実装の完全Validationを通過させる。 |

## 24. 次工程

1. 正式Business、API、UseCaseおよびScenarioを登録する。
2. 正式Scenarioが参照するAPIの利用可否を確定し、Cross-Master Errorを0件にする。
3. Scenario詳細設計変更時に対応表を再生成し、`scenarioId + apiCallCode`集合を継続照合する。
4. Java実行Evidenceの`scenarioId + apiCallCode + apiId`と対応表を照合するBuild Validationを設計する。
5. Cross-Master Validation Errorが0件になった後、Traceability ViewのRelease Reviewを実施する。
