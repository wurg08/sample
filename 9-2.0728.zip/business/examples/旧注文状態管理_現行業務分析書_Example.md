---
title: 旧注文状態管理 現行業務分析書 Example
document_id: EX-BA-E6-LEGACY-ORDER-STATUS-902
version: 1.0.0
status: EXAMPLE
document_type: Business Analysis Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 旧注文状態管理 現行業務分析書 Example

## 1. Example宣言

本書は無効化されたBusinessと旧APIの記録方法を説明する架空Exampleである。実在するE6業務を表さず、正式成果物またはRuntimeから参照してはならない。

## 2. 業務概要

| 項目 | Example値 |
|---|---|
| Business ID | `BUS-E6-902` |
| 業務名 | 旧注文状態管理業務 |
| 状態 | 廃止済みExample |
| 旧目的 | 旧検索方式で注文を特定し、旧更新方式で状態を変更する。 |
| 廃止理由 | 後継の`BUS-E6-901`へ移行した想定。 |
| 新規参照 | 禁止 |

## 3. 旧Flow

1. 旧注文検索APIで対象を取得する。
2. 旧形式の更新要求を生成する。
3. 旧注文状態更新を実行する。
4. 旧Responseで結果を確認する。

## 4. 移行上の注意

- 過去RunのTraceability維持に必要なIDを再利用しない。
- `enabled=false`をOrphanやBroken Referenceの隠蔽に使用しない。
- 後継Business、UseCaseおよびAPIへの対応は明示的な移行表で管理する。

## 5. 関連Example

- `system/02_master/examples/Business_Master_Example.md`
- `system/02_master/examples/E6_API_Master_Example.md`
- `system/03_api_design/examples/API-903設計書_Example.md`
