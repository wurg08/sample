# Local Runtime Data

本DirectoryはLocal実行時の既定Runtime Data Rootである。

`execution-state/`、`baseline/`、`runs/`および`batches/`は実行時に生成し、Gitへ登録しない。Linux／EC2ではRepository外の`/var/lib/e6-api-verifier/`へ切り替える。

