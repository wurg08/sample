# Smoke Contract

Smoke Testは、承認済みRelease Unitについて次を確認する。

1. OpenJDK 21で起動でき、OpenJDK 21／`release=21`で生成したRelease Artifactと一致する。
2. Plain Java CLIとして起動し、Application ContextまたはServlet Containerを開始しない。
3. `validate-registry`が外部E6 APIを呼び出さず完了する。
4. 外部ConfigおよびRuntime Data RootがSource／Releaseから分離されている。
5. Release Artifact内にSpring Boot／Spring Framework Classおよび`META-INF/maven/**`が存在しない。
6. 未対応Commandが終了Code`2`、予期しない内部Errorが終了Code`3`を返す。
