---
title: API設計書 Template
document_id: E6-API-VAL-API-DESIGN-TEMPLATE
version: 2.0.0-draft.3
status: DRAFT
document_type: API Detail Design Template
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# API設計書 Template

> 本Templateを複製し、`API-{NNN}設計書.md`として使用する。  
> `<>`内のPlaceholder、説明文および不要な記入例は、Review依頼前に置換または削除する。

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | `<API正式名称> API設計書` |
| 文書ID | `<E6-API-VAL-API-NNN-DESIGN>` |
| API ID | `<API-NNN>` |
| 対象システム | `<Provider System ID>` |
| 文書種別 | API詳細設計書 |
| 版数 | `<1.0.0-draft.1>` |
| 文書状態 | `<DRAFT / REVIEW / APPROVED / FROZEN>` |
| 最終更新日 | `<YYYY-MM-DD>` |
| 作成責任 | `<Author / Team>` |
| レビュー責任 | `<API Owner / Runtime Lead / Business Analyst>` |
| 承認責任 | `<System Owner>` |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更区分 | 作成者 | 承認状態 |
|---|---|---|---|---|---|
| `<1.0.0-draft.1>` | `<YYYY-MM-DD>` | `<初版作成>` | `<NEW>` | `<Name>` | `<DRAFT>` |

変更区分は`NEW`、`COMPATIBLE`、`INCOMPATIBLE`、`DOCUMENT_ONLY`のいずれかとする。

## 3. 目的

本書は、`<API-NNN>`の通信契約、Request／Response項目、HTTP Status、Error、DTO、Security、検証観点およびJava実装要求を定義する。

本書は次の問いに回答できなければならない。

1. APIのProvider、目的、MethodおよびEndpointは何か。
2. Requestの各項目はどこに設定され、どの契約を満たす必要があるか。
3. Responseの各項目はどの型、必須性および業務意味を持つか。
4. 成功、業務エラー、技術エラーをどう識別するか。
5. Java DTO、Client、Contract CheckおよびCompare Definitionへ何を実装するか。
6. Sensitive DataをどこでMaskし、何をEvidenceへ保存できるか。

## 4. 適用範囲

### 4.1 対象

- `<本APIの処理範囲>`
- Request Header／Path／Query／Body
- Response Header／Body／HTTP Status
- 正常Response、業務エラーResponse、技術エラーResponse
- Java Request／Response DTO
- API単体Contract Check
- API既定Compare Definitionの設計要求

### 4.2 対象外

| 対象外 | 正式な定義・実装先 |
|---|---|
| Scenario内の呼出順序、`apiCallCode`、分岐、Skip | Scenario詳細設計書、Java Scenario Class |
| 前段Responseから本API RequestへのMapping | Scenario詳細設計書、Java Scenario Class |
| Scenario初期値 | Scenario Input JSON |
| Scenarioごとの期待結果、`resultKey` | Scenario Expected、Java Check |
| Previous／Baseline選定 | Execution State・Baseline管理設計 |
| Runtime Field Diff処理 | APIレスポンスDiff設計書、Java Comparator |
| Environment別Base URL、Credential実値 | Environment設定、Secret Store |
| Scheduler、実行頻度、Run状態 | 運用設計、RunContext |

## 5. 根拠資料

| Source ID | 資料名 | 種別 | Reference | 対象版 | 確認状態 |
|---|---|---|---|---|---|
| `<SRC-001>` | `<API分析書>` | API Analysis | `<business/API分析書/...>` | `<version/date>` | `<CONFIRMED / OPEN>` |
| `<SRC-002>` | `<現行API仕様>` | As-Is Specification | `<reference>` | `<version/date>` | `<CONFIRMED / OPEN>` |
| `<SRC-003>` | `API_Master.md` | Master | `system/02_master/API_Master.md` | `<version>` | `<CONFIRMED>` |
| `<SRC-004>` | `<Java DTO / OpenAPI>` | Implementation | `<class/path>` | `<build/commit>` | `<CONFIRMED / OPEN>` |

未確認情報は確定値として記載せず、31章のOpen Issuesへ登録する。

## 6. API Master整合

`API_Master.md`の対象レコードを転記する。転記値は本書単独で変更せず、差異がある場合はMasterまたは本書の誤りとして解消する。

| apiId | apiName | systemId | method | endpointPath | requestDto | responseDto | apiDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|
| `<API-NNN>` | `<API名称>` | `<System ID>` | `<GET/POST/...>` | `</path>` | `<RequestDto/NONE>` | `<ResponseDto/NONE>` | `system/03_api_design/API-<NNN>設計書.md` | `<true/false>` | `<概要>` |

### 6.1 整合性判定

| 確認項目 | 判定 | Evidence／Issue |
|---|---|---|
| `apiId`とFile名が一致 | `<PASS / ERROR>` | `<reference>` |
| Methodが一致 | `<PASS / ERROR>` | `<reference>` |
| Endpoint Pathが一致 | `<PASS / ERROR>` | `<reference>` |
| DTOが一致 | `<PASS / ERROR>` | `<reference>` |
| `apiDesignRef`が本書を参照 | `<PASS / ERROR>` | `<reference>` |
| `enabled=true`の実行条件を満たす | `<PASS / BLOCKED / ERROR>` | `<reference>` |

## 7. API概要

| 項目 | 内容 |
|---|---|
| API ID | `<API-NNN>` |
| API名称 | `<正式名称>` |
| Provider | `<System / Component>` |
| Consumer | `<Verification Platform / Other>` |
| 業務目的 | `<何を取得・登録・更新・取消するAPIか>` |
| 処理方式 | `<同期 / 非同期受付 / 状態照会>` |
| HTTP Method | `<POST>` |
| Endpoint Path | `</api/...>` |
| Content-Type | `<application/json>` |
| Character Set | `<UTF-8>` |
| 認証方式 | `<認証Profile名。Secret実値は禁止>` |
| 冪等性 | `<IDEMPOTENT / NON_IDEMPOTENT / CONDITIONAL>` |
| 業務データ更新 | `<READ_ONLY / CREATE / UPDATE / DELETE>` |

## 8. 処理概要

### 8.1 正常処理

1. `<Requestを受信する。>`
2. `<契約Validationを実施する。>`
3. `<業務処理を実施する。>`
4. `<Responseを返却する。>`

### 8.2 処理Flow

```mermaid
flowchart TD
    A["Request受信"]
    B["契約Validation"]
    C["業務処理"]
    D["Response返却"]
    E["Error Response"]

    A --> B
    B -->|Valid| C
    B -->|Invalid| E
    C -->|Success| D
    C -->|Failure| E
```

本FlowにScenario固有の前後API、Skipまたは分岐を記載しない。

## 9. Endpoint設計

| 項目 | 設計値 | 備考 |
|---|---|---|
| Method | `<POST>` | API Masterと一致必須 |
| Endpoint Path | `</api/v1/...>` | Scheme／Hostを含めない |
| Path Parameter | `<NONE / {id}>` | 実値を含めない |
| Query Parameter | `<NONE / 定義あり>` | 10章参照 |
| Request Body | `<Required / Optional / None>` | 11章参照 |
| Success Status | `<200>` | 15章参照 |
| Protocol | `<HTTPS>` | Environment設定で解決 |

### 9.1 URL組立

```text
Environment connectionConfigRef
    → Base URL
        + API Master.endpointPath
            + Javaが設定するPath／Query Parameter
```

API Masterまたは本書へEnvironment別Hostを記載しない。

## 10. Request Header／Path／Query

### 10.1 Header

| No. | Header名 | 必須 | 型／形式 | 設定元 | Sensitive | Validation | 備考 |
|---:|---|:---:|---|---|:---:|---|---|
| 1 | `<Content-Type>` | `<Yes>` | `<application/json>` | `<API Client>` | No | `<完全一致>` | `<備考>` |
| 2 | `<Authorization>` | `<Yes>` | `<Bearer Profile>` | `<Auth Provider>` | Yes | `<存在確認のみ>` | 実値保存禁止 |
| 3 | `<X-Correlation-Id>` | `<Yes/No>` | `<String>` | `<RunContext>` | No | `<Pattern>` | `<追跡ID>` |

### 10.2 Path Parameter

| No. | Parameter | Java Field | 型 | 必須 | Null | 制約 | Encode | Sensitive | 備考 |
|---:|---|---|---|:---:|:---:|---|:---:|:---:|---|
| 1 | `<memberId>` | `<memberId>` | `<String>` | `<Yes>` | `<No>` | `<length/pattern>` | `<Yes>` | `<No>` | `<NONEの場合は行を削除>` |

### 10.3 Query Parameter

| No. | Parameter | Java Field | 型 | 必須 | Null | Multiple | Default | 制約 | Sensitive |
|---:|---|---|---|:---:|:---:|:---:|---|---|:---:|
| 1 | `<detail>` | `<detail>` | `<Boolean>` | `<No>` | `<No>` | `<No>` | `<false>` | `<true/false>` | No |

## 11. Request Body

### 11.1 Request DTO

| 項目 | 内容 |
|---|---|
| DTO Class | `<fully.qualified.RequestDto / NONE>` |
| JSON Root Type | `<OBJECT / ARRAY / NONE>` |
| Serialization | `<Jackson設定／命名規則>` |
| Unknown Field | `<REJECT / IGNORE。根拠必須>` |
| Null Serialization | `<INCLUDE / EXCLUDE>` |

### 11.2 Request項目定義

| No. | JSON Path | JSON名 | Java Field | Java型 | JSON型 | 必須 | Null | 長さ／桁 | Pattern／Format | Enum／固定値 | 入力元 | Sensitive | Contract Check |
|---:|---|---|---|---|---|:---:|:---:|---|---|---|---|:---:|---|
| 1 | `<$.memberId>` | `<memberId>` | `<memberId>` | `<String>` | `<STRING>` | `<Yes>` | `<No>` | `<1..20>` | `<pattern/NONE>` | `<NONE>` | `<Scenario Java>` | `<No>` | `<check class/method>` |

### 11.3 Request項目規則

1. `JSON Path`はRootを`$`で表す。
2. `必須`と`Null`を別に定義する。
3. String、Number、Boolean、Object、Array、Nullを混同しない。
4. Length、Digit、Scale、Pattern、Enum、固定値を省略する場合は`NONE`と記載する。
5. Scenario固有の実値を本表へ記載しない。
6. Request値の生成・MappingはJava Scenario Classへ明示する。
7. Sensitive項目はMask方式を21章に定義する。

### 11.4 Request JSON Sample

```json
{
  "memberId": "EXAMPLE-001"
}
```

Sampleは架空値を使用し、実顧客情報またはSecretを記載しない。

## 12. Request生成責務

| 値の種別 | 正本／生成元 | Java責務 |
|---|---|---|
| Scenario初期値 | Scenario Input | 型検証してRequestへ設定 |
| Environment値 | Environment設定 | Client構成へ注入 |
| 認証情報 | Secret Store／Auth Provider | Headerへ設定し保存しない |
| 前段Response値 | ScenarioContext | DTO／JSONから明示Mapping |
| Runtime ID | RunContext | Correlation Header等へ設定 |
| 固定技術値 | API Client／DTO | Codeで明示設定 |

本書へMapping式言語または任意Scriptを記載しない。

## 13. Request Validation

| Validation ID | 対象Path | 観点 | 条件 | Failure分類 | HTTP期待 | Java Check |
|---|---|---|---|---|---|---|
| `<REQ-V001>` | `<$.memberId>` | `<必須>` | `<存在する>` | `<CONTRACT>` | `<400>` | `<Class#method>` |
| `<REQ-V002>` | `<$.memberId>` | `<長さ>` | `<1..20>` | `<CONTRACT>` | `<400>` | `<Class#method>` |

Provider側ValidationとVerification Platform側事前Validationを区別し、同じ規則を異なる値で重複実装しない。

## 14. Response Header

| No. | Header名 | 必須 | 型／形式 | 用途 | Sensitive | Evidence保存 |
|---:|---|:---:|---|---|:---:|---|
| 1 | `<Content-Type>` | `<Yes>` | `<application/json>` | `<形式>` | No | `<Yes>` |
| 2 | `<X-Correlation-Id>` | `<Yes/No>` | `<String>` | `<追跡>` | No | `<Yes>` |
| 3 | `<Set-Cookie>` | `<No>` | `<String>` | `<NONE>` | Yes | `<No>` |

## 15. HTTP Status

| HTTP Status | API結果区分 | Response Schema | 発生条件 | Retry候補 | Verification上の取扱い |
|---:|---|---|---|:---:|---|
| `<200>` | `<SUCCESS>` | `<SuccessResponse>` | `<正常完了>` | No | `<Response Contract／Business Check実施>` |
| `<400>` | `<BUSINESS_OR_CONTRACT_ERROR>` | `<ErrorResponse>` | `<入力不正>` | No | `<Scenario Expectedに従う>` |
| `<401>` | `<AUTH_ERROR>` | `<ErrorResponse>` | `<認証失敗>` | No | `<Scenario Expected、Execution StatusおよびReason Codeに従う>` |
| `<500>` | `<SYSTEM_ERROR>` | `<ErrorResponse>` | `<Provider障害>` | `<設計に従う>` | `<Scenario Expected、Execution／Recovery StatusおよびReason Codeに従う>` |

HTTP StatusだけでBusiness PASS／FAILを確定しない。Scenario ExpectedとJava Checkが最終Verification Resultを生成する。

## 16. Success Response

### 16.1 Response DTO

| 項目 | 内容 |
|---|---|
| DTO Class | `<fully.qualified.ResponseDto / NONE>` |
| JSON Root Type | `<OBJECT / ARRAY / NONE>` |
| Unknown Field | `<REJECT / ACCEPT_AND_CAPTURE>` |
| Empty Body | `<Allowed / Not Allowed>` |

### 16.2 Response項目定義

| No. | JSON Path | JSON名 | Java Field | Java型 | JSON型 | 必須 | Null | 長さ／桁 | Pattern／Format | Enum／固定値 | 業務意味 | Sensitive | Contract Check |
|---:|---|---|---|---|---|:---:|:---:|---|---|---|---|:---:|---|
| 1 | `<$.memberId>` | `<memberId>` | `<memberId>` | `<String>` | `<STRING>` | `<Yes>` | `<No>` | `<1..20>` | `<NONE>` | `<NONE>` | `<会員識別子>` | `<No>` | `<Class#method>` |
| 2 | `<$.status>` | `<status>` | `<status>` | `<String>` | `<STRING>` | `<Yes>` | `<No>` | `<1..10>` | `<NONE>` | `<ACTIVE/INACTIVE>` | `<会員状態>` | `<No>` | `<Class#method>` |

### 16.3 Array設計

Arrayが存在する場合は、次を必ず定義する。

| 項目 | 設計内容 |
|---|---|
| JSON Path | `<$.members>` |
| 要素型 | `<Member>` |
| 最小／最大件数 | `<0..N / 上限根拠>` |
| 順序保証 | `<YES / NO / UNKNOWN>` |
| 一意Key | `<memberId / NONE>` |
| Duplicate許可 | `<YES / NO>` |
| Diff対応 | `<INDEX / KEY / CUSTOM>` |

順序保証がないArrayを汎用Comparatorが自動Sortしてはならない。必要なNormalizer／ComparatorをJavaへ明示実装する。

### 16.4 Success Response JSON Sample

```json
{
  "memberId": "EXAMPLE-001",
  "status": "ACTIVE"
}
```

## 17. Error Response

### 17.1 Error Schema

| No. | JSON Path | JSON名 | JSON型 | 必須 | Null | 内容 | Sensitive |
|---:|---|---|---|:---:|:---:|---|:---:|
| 1 | `<$.code>` | `<code>` | `<STRING>` | `<Yes>` | `<No>` | `<Error Code>` | No |
| 2 | `<$.message>` | `<message>` | `<STRING>` | `<Yes>` | `<No>` | `<安全なMessage>` | `<確認>` |
| 3 | `<$.details>` | `<details>` | `<ARRAY>` | `<No>` | `<No>` | `<Field Error>` | `<確認>` |

### 17.2 Error Code

| Error Code | HTTP Status | 発生条件 | 業務／技術 | Retry | Scenario上の想定 |
|---|---:|---|---|:---:|---|
| `<E0001>` | `<400>` | `<条件>` | `<BUSINESS>` | No | `<Expectedで明示>` |
| `<E9001>` | `<500>` | `<条件>` | `<TECHNICAL>` | `<Yes/No>` | `<Execution／Recovery StatusとReason Codeで記録>` |

### 17.3 Error Response JSON Sample

```json
{
  "code": "EXAMPLE_ERROR",
  "message": "Example error message"
}
```

## 18. Business／Contract Check設計要求

本章はCheckの要求を定義する。Scenarioごとの`resultKey`、期待値および実行順序はScenario詳細設計、ExpectedおよびJavaへ定義する。

| Check Requirement ID | 対象 | 観点 | 要求 | 適用Response | Java実装責務 |
|---|---|---|---|---|---|
| `<API-CHK-001>` | `<$.memberId>` | `<必須／非空>` | `<値が存在し空でない>` | `<Success>` | `<Contract Check>` |
| `<API-CHK-002>` | `<$.status>` | `<Enum>` | `<許容値内>` | `<Success>` | `<Business Check>` |

### 18.1 標準観点

- 項目存在性
- 必須／Optional
- Null／Non-null
- JSON型／Java型
- String長
- Number桁／Scale／範囲
- Date／Timestamp Format
- Pattern
- Enum
- 固定値
- Array件数
- Object／Array要素必須
- API内相関
- Error Schema

Diff Ignoreが設定される項目も、本章のContract／Business Check対象であれば通常どおり検証する。

## 19. API既定Compare Definition要求

Compare Definitionの実体はAPI別Java定義に実装する。本表は設計要求と実装Traceを保持する。

| No. | Pattern Path | Mode | 変更種別への効果 | 理由 | Java Definition | Review Owner |
|---:|---|---|---|---|---|---|
| 1 | `<$.updatedAt>` | `<IGNORE_VALUE>` | 値変更だけ非有効化 | `<実行日時>` | `<Class#method>` | `<Owner>` |
| 2 | `<$.requestId>` | `<IGNORE_FIELD>` | 追加・削除・型・値を非有効化 | `<毎回採番>` | `<Class#method>` | `<Owner>` |

### 19.1 Mode

| Mode | 無視する変化 | 無視しない変化 |
|---|---|---|
| `IGNORE_FIELD` | ADD、REMOVE、TYPE_CHANGE、VALUE_CHANGE | なし |
| `IGNORE_VALUE` | VALUE_CHANGE | ADD、REMOVE、TYPE_CHANGE |
| `STANDARD` | なし | 全Change |
| `CUSTOM` | Java実装に明示 | Java実装に明示 |

同一Pathを`IGNORE_FIELD`と`IGNORE_VALUE`の両方へ登録してはならない。

### 19.2 Scenario固有上書き

Scenario内の特定`apiCallCode`だけに必要な差異は、Scenario詳細設計と呼出別Java Compare Definitionへ定義する。本書のAPI既定定義を暗黙変更しない。

## 20. DTO／Java実装

| Component | Class／Interface | 責務 | 実装状態 |
|---|---|---|---|
| Request DTO | `<FQCN>` | Request契約 | `<TODO / DONE>` |
| Response DTO | `<FQCN>` | Response契約 | `<TODO / DONE>` |
| Error DTO | `<FQCN>` | Error契約 | `<TODO / DONE>` |
| API Client | `<FQCN>` | HTTP呼出 | `<TODO / DONE>` |
| Contract Validator | `<FQCN>` | 構造・型・制約確認 | `<TODO / DONE>` |
| Default Compare Definition | `<FQCN>` | API既定Diff定義 | `<TODO / DONE>` |
| Sensitive Path Definition | `<FQCN>` | Mask対象Path | `<TODO / DONE>` |

### 20.1 Java実装原則

1. DTO FieldとJSON名の差異をAnnotationで明示する。
2. `Map<String, Object>`を標準DTOの代替として使用しない。
3. Unknown Fieldの扱いをAPI単位で曖昧にしない。
4. Request生成、前後値MappingおよびScenario分岐をAPI Clientへ混入させない。
5. API Clientは`apiCallCode`を生成しない。
6. Compare DefinitionはExpectedまたはMasterから動的Scriptとして実行しない。

## 21. Security／Mask

### 21.1 Sensitive項目

| JSON／Header Path | 分類 | Request保存 | Response保存 | Log | Report | Mask方式 |
|---|---|---:|---:|---:|---:|---|
| `<Authorization>` | `<TOKEN>` | No | N/A | No | No | `<DROP>` |
| `<$.customer.email>` | `<PERSONAL_DATA>` | `<Masked>` | `<Masked>` | `<Masked>` | `<Masked>` | `<PARTIAL/HASH>` |

### 21.2 禁止事項

- Secret実値をSampleへ記載する。
- CredentialをEnvironment Masterへ記載する。
- Mask前Payloadを通常Logへ出力する。
- DiffのPrevious／CurrentへSensitive実値を保存する。
- Error Messageへ内部StacktraceまたはCredentialを含める。

## 22. Timeout／Retry／Idempotency要求

API固有の事実とRuntime設定を区別する。

| 項目 | API契約上の事実 | Runtime設定Reference | 備考 |
|---|---|---|---|
| Provider Timeout | `<値／UNKNOWN>` | `<config key>` | `<根拠>` |
| Client Timeout | `<本書では固定しない>` | `<config key>` | Environment別設定 |
| Retry可否 | `<Allowed / Forbidden / Conditional>` | `<framework reference>` | 更新APIは副作用確認 |
| Retry対象 | `<status/error>` | `<config key>` | `<条件>` |
| Idempotency Key | `<header/path/NONE>` | `<Java implementation>` | `<再送条件>` |

実行時Timeout秒数またはRetry回数をAPI Masterへ追加しない。

## 23. Logging／Evidence

| Event | 必須情報 | 保存禁止 | Severity |
|---|---|---|---|
| API開始 | `runId`、`scenarioId`、`apiCallCode`、`apiId` | Secret | INFO |
| API終了 | Status、Duration、Payload Hash | Sensitive実値 | INFO |
| Contract違反 | Path、Rule、安全なActual概要 | 全Payload | WARN／ERROR |
| 通信Error | Error Code、Cause分類 | Credential、内部秘密情報 | ERROR |

Run成果物は`runs/{runId}/api-calls/{apiCallCode}/`へ出力する。物理RootはFile I/O設計で確定する。

## 24. Scenario連携

| 項目 | API設計側 | Scenario側 |
|---|---|---|
| API Identity | `apiId` | `apiCallCode → apiId` |
| 通信契約 | 本書 | 参照 |
| 呼出順序 | 対象外 | Scenario詳細設計 |
| Request初期値 | 対象外 | Input |
| Request Mapping | Field契約だけ定義 | Javaで実装 |
| Response保持 | DTO／JSON契約 | ScenarioContext.ApiExchange |
| Expected | 対象外 | Expected JSON |
| API既定Diff | 設計要求 | Java API定義 |
| 呼出固有Diff | 対象外 | Java call definition |

## 25. Traceability

| Trace先 | Reference／ID | 整合性 |
|---|---|---|
| API Master | `<API-NNN>` | `<PASS / ERROR>` |
| API分析書 | `<reference>` | `<PASS / OPEN>` |
| 利用Scenario | `<SC-... / NONE>` | `<対応表で確認>` |
| Java Client | `<FQCN>` | `<BUILD PASS / OPEN>` |
| Request DTO | `<FQCN>` | `<BUILD PASS / OPEN>` |
| Response DTO | `<FQCN>` | `<BUILD PASS / OPEN>` |
| API単体Test | `<test class/spec>` | `<PASS / OPEN>` |

利用Scenario一覧はTraceability Viewから導出し、本書を関係の正本にしない。

## 26. Validation

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `API-DES-V001` | File名、文書内`apiId`、API Masterが一致する。 | ERROR |
| `API-DES-V002` | Method、Endpoint、DTOがAPI Masterと一致する。 | ERROR |
| `API-DES-V003` | Request／Response全項目に型、必須、Nullがある。 | ERROR |
| `API-DES-V004` | StatusとResponse Schemaの対応が完全である。 | ERROR |
| `API-DES-V005` | Java DTO FieldとJSON名を追跡できる。 | ERROR |
| `API-DES-V006` | Sensitive PathとMask方式が定義される。 | ERROR |
| `API-DES-V007` | Compare要求がJava Definitionへ追跡可能である。 | ERROR |
| `API-DES-V008` | Ignore項目もContract Checkから除外されていない。 | ERROR |
| `API-DES-V009` | SampleにSecret／実個人情報がない。 | ERROR |
| `API-DES-V010` | Scenario固有の順序、分岐、Expectedを保持しない。 | ERROR |
| `API-DES-V011` | 全SourceとOpen IssueにOwner／状態がある。 | WARNING |
| `API-DES-V012` | `enabled=true`の場合、設計・DTO・Clientが解決可能である。 | ERROR |

## 27. API単体Test観点

### 27.1 Request

- [ ] 必須項目あり／なし
- [ ] Null／空文字
- [ ] 最小／最大長
- [ ] 最小／最大値、桁、Scale
- [ ] Pattern、Format、Enum
- [ ] Unknown Field
- [ ] Header、Path、Query、Body組合せ
- [ ] Sensitive Data非出力

### 27.2 Response

- [ ] Success StatusとSchema
- [ ] 全必須項目
- [ ] JSON型／DTO型
- [ ] Array 0件／1件／複数／上限
- [ ] Error StatusとError Schema
- [ ] 固定値／Enum
- [ ] Unknown Field
- [ ] Correlation ID

### 27.3 Diff

- [ ] `STANDARD`の追加／削除／型／値変化
- [ ] `IGNORE_FIELD`の全Change
- [ ] `IGNORE_VALUE`の値変化と型変化
- [ ] Array順序／Key
- [ ] Sensitive値のMask

## 28. Review Checklist

### 28.1 契約

- [ ] API Masterと一致する。
- [ ] Request／Response／Errorが完全である。
- [ ] 必須とNullを分けている。
- [ ] StatusだけでBusiness判定していない。

### 28.2 Java

- [ ] DTO、Client、Validator、Comparatorへ追跡できる。
- [ ] Request MappingをAPI Clientへ混入させていない。
- [ ] `apiCallCode`をAPI定義へ保持していない。
- [ ] Compare DefinitionがJava Firstである。

### 28.3 Security

- [ ] Secret実値がない。
- [ ] Sensitive PathがRequest／Response／Errorを網羅する。
- [ ] EvidenceとReportのMask方針が一致する。

### 28.4 変更影響

- [ ] 利用Scenarioを対応表で確認した。
- [ ] 非互換変更のID継続可否を判断した。
- [ ] DTO、Test、Expected、Compare Definitionの影響を確認した。

## 29. 完了条件

1. 根拠資料が確認済みである。
2. API Masterとの全項目整合がPASSである。
3. Request／Response／Error契約が完全である。
4. DTO、Client、ValidatorおよびCompare Definitionを解決できる。
5. Sensitive DataとMaskが承認されている。
6. `API-DES-V001～V012`の`ERROR`が0件である。
7. API単体Testの必須観点が実施可能である。
8. 利用Scenarioへの変更影響が確認されている。

## 30. Release Blocker

| Block ID | 内容 | 解除条件 | Owner | 状態 |
|---|---|---|---|---|
| `<API-DES-BLOCK-001>` | `<未確認仕様>` | `<正式仕様確認>` | `<Owner>` | `<OPEN>` |

Blockerが1件以上ある場合、API Masterを`enabled=true`へ変更または維持できるかを明示的に再判定する。

## 31. Open Issues

| Issue ID | 確認事項 | 影響 | 確認元 | Owner | 期限 | 状態 |
|---|---|---|---|---|---|---|
| `<API-DES-ISSUE-001>` | `<確認事項>` | `<影響>` | `<Source>` | `<Owner>` | `<YYYY-MM-DD>` | `<OPEN>` |

## 32. 禁止事項

1. API Masterと異なるMethod／Endpointを根拠なく記載する。
2. Scenario固有の`apiCallCode`、呼出順序または分岐を定義する。
3. Input実値、Expected実値またはBaselineを保存する。
4. Compare Policy MasterまたはVerification Policy Masterを参照する。
5. Ignore設定によりContract／Business Checkを自動PASSにする。
6. Secret、Token、Passwordまたは実個人情報をSampleへ記載する。
7. 未確認項目を推測して`CONFIRMED`にする。
8. Java Method名、JSON行番号または表示順をIdentityにする。

## 33. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 最新5 Master、Java First、Expected／Diff／Baseline責務分離に基づき全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | Framework横断再走査によりError Responseの取扱いをCanonical四結果軸とReason Codeへ統一 | DRAFT |
| `2.0.0-draft.3` | 2026-07-29 | `REP-MIG-002／003`によるAPI Master／Exampleの最終File名移行に伴い、Current Referenceを同期。文書固有の責務と業務内容は変更なし。 | DRAFT |
