---
title: 注文情報取得API設計書（Example）
document_id: EX-API-901-DESIGN
version: 1.0.0-draft.4
status: DRAFT
document_type: API Detail Design Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 注文情報取得API設計書（Example）

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 注文情報取得API設計書（Example） |
| 文書ID | `EX-API-901-DESIGN` |
| API ID | `API-901` |
| 対象システム | `EXAMPLE` |
| 文書種別 | API詳細設計書記入例 |
| 版数 | `1.0.0-draft.4` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Example Design Team |
| レビュー責任 | API Owner / Verification Lead / Java Lead |
| 承認責任 | Example System Owner |

本書のAPI、Endpoint、DTO、Field、Codeおよび業務値はすべて架空である。正式E6 API、正式Master、Java実装またはRuntime設定へコピーしてはならない。

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更区分 | 承認状態 |
|---|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | API詳細設計Templateに基づく900番台記入例を新規作成 | NEW | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | API-902およびSC-E6-901 Input／Expected Exampleの作成状態を同期 | UPDATE | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | Framework横断再走査によりProvider Error時のVerificationを`NOT_EVALUATED`とExecution／Reason Codeへ分離 | UPDATE | DRAFT |
| `1.0.0-draft.4` | 2026-07-29 | `REP-MIG-002／003`によるAPI Master／Exampleの最終File名移行に伴い、Current Referenceを同期。文書固有の責務と業務内容は変更なし。 | DRAFT |

## 3. 目的

本書は、注文IDを指定して注文情報を一件取得する架空APIについて、API固定契約、Request、Response、Error、Contract Check、Business Check、Compare Definition、Java責務およびScenario連携の記入粒度を示す。

Exampleとして特に次の境界を明示する。

1. API固定契約とScenario固有Expectedを分離する。
2. 同一APIを複数回呼び出してもAPI定義を複製しない。
3. `IGNORE_VALUE`でDiff対象外としたFieldにもContract Checkを適用する。
4. 未確認値を仮の正式値として記載しない。
5. API Master、API詳細設計、Scenario詳細設計、ExpectedおよびJava Checkの責務を混在させない。

## 4. 適用範囲

### 4.1 対象

- `API-901`のMethod、Endpoint PathおよびDTO
- Request Header、Path ParameterおよびQuery Parameter
- Success／Error Response契約
- API共通Contract CheckおよびBusiness Check候補
- API既定Compare Definition
- Timeout、Retry、Security、MaskおよびEvidence
- Java DTO／Client／ValidatorとのTrace
- `SC-E6-901`の`CALL-001`および`CALL-003`からの参照例

### 4.2 対象外

| 対象外 | 正式な定義先 |
|---|---|
| Environment別Scheme、Host、Port | Environment設定 |
| Credential、Token実値 | Secret Provider |
| 注文状態変更Request | `API-902`詳細設計 |
| API呼出順序、分岐、Mapping | Scenario詳細設計 |
| Scenario Input実値 | Scenario Input JSON |
| Scenario固有Expected | Scenario Expected JSON、Java Check |
| Previous／Baseline選択 | Execution State・Baseline管理設計 |
| Runtime結果、Evidence実体 | Runtime Artifact |

## 5. 根拠資料

| Source ID | 資料名 | Reference | 確認状態 |
|---|---|---|---|
| API901-SRC-001 | API Master記入例 | `system/02_master/examples/API_Master_Example.md` | CONFIRMED |
| API901-SRC-002 | Scenario Master記入例 | `system/02_master/examples/Scenario_Master_Example.md` | CONFIRMED |
| API901-SRC-003 | API・UseCase・Scenario対応表記入例 | `system/02_master/examples/API_UseCase_Scenario対応表_Example.md` | CONFIRMED |
| API901-SRC-004 | API設計書Template | `system/03_api_design/API設計書_Template.md` | CONFIRMED |
| API901-SRC-005 | 架空Provider OpenAPI | `EXAMPLE://order-api/openapi` | EXAMPLE ONLY |

## 6. API Master整合

| apiId | apiName | systemId | method | endpointPath | requestDto | responseDto | enabled |
|---|---|---|---|---|---|---|:---:|
| API-901 | 注文情報取得API | EXAMPLE | GET | `/api/v1/orders/{orderId}` | `NONE` | `OrderDetailResponse` | true |

### 6.1 整合性判定

| Check | 判定 | 根拠 |
|---|:---:|---|
| API ID | PASS | `API-901`で一致する。 |
| Method | PASS | `GET`で一致する。 |
| Endpoint Path | PASS | Hostを含まない相対Pathで一致する。 |
| Request DTO | PASS | Request Bodyを使用しないため`NONE`。 |
| Response DTO | PASS | `OrderDetailResponse`で一致する。 |
| Example分離 | PASS | 900番台かつ`examples/`配下である。 |

本判定はExample文書間の整合だけを示し、正式APIの存在または実行可能性を示さない。

## 7. API概要

| 項目 | 内容 |
|---|---|
| API ID | `API-901` |
| API名称 | 注文情報取得API |
| Provider System | `EXAMPLE` |
| Method | `GET` |
| Endpoint Path | `/api/v1/orders/{orderId}` |
| Request Body | なし |
| Success Response | `OrderDetailResponse` |
| 認証 | Bearer Token（Example。実値記載禁止） |
| 副作用 | なし |
| 冪等性 | 読取APIとして同一条件の再送による業務更新なし |

## 8. 処理概要

### 8.1 正常処理

1. ClientがEnvironment ContextからBase URLを解決する。
2. Request Builderが承認済みInput Referenceから`orderId`を取得する。
3. Path ParameterをRFC 3986に従ってEncodeする。
4. 認証情報をSecret Providerから取得しHeaderへ設定する。
5. Providerへ`GET` Requestを送信する。
6. HTTP StatusとResponse Bodyを受領する。
7. Bodyを`OrderDetailResponse`へDeserializeする。
8. Contract Checkを実行し、Scenario固有Checkへ引き渡す。

### 8.2 処理Flow

```mermaid
flowchart TD
    A["Environment・Input解決"]
    B["GET Request生成"]
    C["Provider呼出"]
    D["Response Deserialize"]
    E["Contract Check"]
    X["Error記録"]

    A -->|PASS| B --> C
    A -->|非PASS| X
    C -->|Response受信| D --> E
    C -->|Timeout／通信Error| X
```

## 9. Endpoint設計

| 項目 | 設計 |
|---|---|
| Method | `GET` |
| Relative Path | `/api/v1/orders/{orderId}` |
| Content-Type | Response受信時`application/json` |
| Accept | `application/json` |
| Scheme／Host／Port | Environment設定から取得 |
| Query String | なし |
| Fragment | 使用禁止 |

### 9.1 URL組立

```text
resolvedBaseUrl + "/api/v1/orders/" + encodePathSegment(orderId)
```

Base URLの末尾SlashとPath先頭SlashはClient共通部品が正規化する。文字列連結により二重Slashを生成してはならない。

## 10. Request Header／Path／Query

### 10.1 Header

| Header | 必須 | Source | Validation | Evidence |
|---|:---:|---|---|---|
| `Authorization` | Yes | Secret Provider | `Bearer ` Prefixを持つ。実値は記録しない。 | `***`へMask |
| `Accept` | Yes | API Client固定値 | `application/json` | 記録可 |
| `X-Correlation-Id` | Yes | Run Context | 空でないUUID形式 | 記録可 |

### 10.2 Path Parameter

| Parameter | 型 | 必須 | Null | 長さ | Pattern | Source |
|---|---|:---:|:---:|---|---|---|
| `orderId` | String | Yes | No | 1～32 | `^[A-Z0-9-]+$` | Scenario Inputの承認済みReference |

`orderId`の具体値を本設計書へ固定しない。

### 10.3 Query Parameter

なし。未定義Query Parameterを動的Mapから追加してはならない。

## 11. Request Body

### 11.1 Request DTO

`NONE`。本APIはRequest Bodyを使用しない。

### 11.2 Request項目定義

該当なし。Path Parameterは10.2節で定義する。

### 11.3 Request項目規則

- `GET` Requestへ空JSON `{}`を付与しない。
- Scenario Input全体を自動Serializeしない。
- `orderId`以外の業務値をPathまたはQueryへ推測追加しない。

### 11.4 Request Sample

```http
GET /api/v1/orders/ORD-EX-0001 HTTP/1.1
Accept: application/json
Authorization: Bearer ***
X-Correlation-Id: 00000000-0000-4000-8000-000000000001
```

Sample値は架空値であり、実行データとして利用してはならない。

## 12. Request生成責務

| 責務 | Owner | 禁止事項 |
|---|---|---|
| Base URL解決 | Environment Resolver | 文書またはSourceへHostを直書きしない。 |
| `orderId`解決 | Scenario Request Builder | 未承認値を生成しない。 |
| Header生成 | API Client Interceptor | SecretをLogへ出力しない。 |
| Encode | HTTP Client共通部品 | 手作業の文字列置換を行わない。 |

## 13. Request Validation

| Rule ID | 対象 | 条件 | 不成立時 |
|---|---|---|---|
| API901-REQ-001 | `orderId` | 存在しNullでない。 | API未呼出、`BLOCKED` |
| API901-REQ-002 | `orderId` | 長さ1～32。 | API未呼出、`FAIL` |
| API901-REQ-003 | `orderId` | Pattern一致。 | API未呼出、`FAIL` |
| API901-REQ-004 | Correlation ID | UUID形式かつRun内一貫。 | API未呼出、`ERROR` |
| API901-REQ-005 | Authorization | Secret Providerから解決済み。 | API未呼出、`BLOCKED` |

## 14. Response Header

| Header | 必須 | Check | 取扱い |
|---|:---:|---|---|
| `Content-Type` | Yes | `application/json`互換 | Contract Check |
| `X-Correlation-Id` | Yes | Request値と一致 | Contract Check |
| `Date` | No | 存在時にHTTP-date形式 | Diffは`IGNORE_VALUE` |

## 15. HTTP Status

| Status | 意味 | Body | Verification取扱い |
|---:|---|---|---|
| 200 | 注文情報取得成功 | `OrderDetailResponse` | Success Contractへ進む。 |
| 400 | Path Parameter不正 | `ApiErrorResponse` | Error Contractを確認する。 |
| 401 | 認証不正 | `ApiErrorResponse` | Executionは完了、Verificationは原則FAIL。 |
| 404 | 対象注文不存在 | `ApiErrorResponse` | Scenario契約に従う。自動でPASSにしない。 |
| 500 | Provider内部Error | `ApiErrorResponse` | Execution `INCOMPLETE`、Verification `NOT_EVALUATED`、Provider Error Reason Code。 |

未定義Statusを受信した場合、既知Statusへ丸めずContract Errorとする。

## 16. Success Response

### 16.1 Response DTO

| 項目 | 内容 |
|---|---|
| DTO | `OrderDetailResponse` |
| Java FQCN | `com.example.e6.api.order.dto.OrderDetailResponse` |
| Root Type | Object |
| Unknown Field | 記録後Contract Error。黙って破棄しない。 |

### 16.2 Response項目定義

| JSONPath | Java型 | 必須 | Null | 制約 | Check分類 |
|---|---|:---:|:---:|---|---|
| `$.orderId` | String | Yes | No | 1～32、`^[A-Z0-9-]+$` | EXISTS／TYPE／LENGTH／FORMAT |
| `$.customerId` | String | Yes | No | 1～32 | EXISTS／TYPE／NOT_EMPTY |
| `$.orderStatus` | String | Yes | No | `RECEIVED`,`PROCESSING`,`SHIPPED`,`CANCELLED` | TYPE／ENUM |
| `$.orderVersion` | Long | Yes | No | 1以上 | TYPE／RANGE |
| `$.currency` | String | Yes | No | 固定値`JPY` | TYPE／FIXED_VALUE |
| `$.totalAmount` | Decimal | Yes | No | 0以上、小数2桁以内 | TYPE／RANGE／SCALE |
| `$.updatedAt` | String | Yes | No | RFC 3339 Date-Time | TYPE／FORMAT |
| `$.items` | Array | Yes | No | 1件以上 | TYPE／MIN_ITEMS |
| `$.items[*].lineNo` | Integer | Yes | No | 1以上、配列内一意 | TYPE／RANGE／UNIQUE |
| `$.items[*].productCode` | String | Yes | No | 1～40 | TYPE／LENGTH／NOT_EMPTY |
| `$.items[*].quantity` | Integer | Yes | No | 1～999 | TYPE／RANGE |

### 16.3 Array設計

| 観点 | 規則 |
|---|---|
| `items`存在 | Field自体が必須。 |
| Null | 許可しない。 |
| Empty | 許可しない。 |
| 順序 | `lineNo`昇順。 |
| 一意性 | `lineNo`はResponse内で重複不可。 |
| Diff Identity | `lineNo`を要素Keyとする。 |

### 16.4 Success Response JSON Sample

```json
{
  "orderId": "ORD-EX-0001",
  "customerId": "CUS-EX-0001",
  "orderStatus": "PROCESSING",
  "orderVersion": 3,
  "currency": "JPY",
  "totalAmount": 1200.00,
  "updatedAt": "2026-07-27T10:15:30+09:00",
  "items": [
    {
      "lineNo": 1,
      "productCode": "PRODUCT-EX-01",
      "quantity": 2
    }
  ]
}
```

## 17. Error Response

### 17.1 Error Schema

| JSONPath | 型 | 必須 | Null | 制約 |
|---|---|:---:|:---:|---|
| `$.errorCode` | String | Yes | No | 定義済みCode |
| `$.message` | String | Yes | No | 1～200、機密値を含まない。 |
| `$.correlationId` | String | Yes | No | Request Correlation IDと一致 |
| `$.occurredAt` | String | Yes | No | RFC 3339 Date-Time |

### 17.2 Error Code

| HTTP Status | errorCode | 意味 |
|---:|---|---|
| 400 | `ORDER_ID_INVALID` | 注文ID形式不正 |
| 401 | `AUTHENTICATION_FAILED` | 認証失敗 |
| 404 | `ORDER_NOT_FOUND` | 対象注文不存在 |
| 500 | `ORDER_API_INTERNAL_ERROR` | Provider内部Error |

### 17.3 Error Response JSON Sample

```json
{
  "errorCode": "ORDER_NOT_FOUND",
  "message": "The requested order was not found.",
  "correlationId": "00000000-0000-4000-8000-000000000001",
  "occurredAt": "2026-07-27T10:15:30+09:00"
}
```

## 18. Business／Contract Check設計要求

| Check ID | 種別 | 条件 | 失敗時 |
|---|---|---|---|
| API901-CHK-001 | CONTRACT | 200時にSuccess Response全必須項目が存在する。 | FAIL |
| API901-CHK-002 | CONTRACT | 全Fieldが定義型、Null、長さ、Formatを満たす。 | FAIL |
| API901-CHK-003 | CONTRACT | `currency=JPY`である。 | FAIL |
| API901-CHK-004 | CONTRACT | `items`が1件以上で`lineNo`が一意である。 | FAIL |
| API901-CHK-005 | BUSINESS | Response `orderId`がRequest `orderId`と一致する。 | FAIL |
| API901-CHK-006 | BUSINESS | `totalAmount`が0以上である。 | FAIL |
| API901-CHK-007 | ERROR_CONTRACT | Error時にStatusと`errorCode`の組合せが定義済みである。 | FAIL |

### 18.1 標準観点

`EXISTS`、`REQUIRED`、`TYPE`、`NULL`、`LENGTH`、`FORMAT`、`ENUM`、`FIXED_VALUE`、`RANGE`、`ARRAY_SIZE`およびBusiness相関を独立Resultとして保持する。複数観点を一つのBooleanへ潰してはならない。

## 19. API既定Compare Definition要求

| JSONPath | Mode | 理由 | Contract／Business Check |
|---|---|---|---|
| `$.orderId` | `EXACT` | 同一注文の比較Identity | 実行する。 |
| `$.customerId` | `EXACT` | 業務主体の同一性 | 実行する。 |
| `$.orderStatus` | `EXACT` | 状態変更検知対象 | 実行する。 |
| `$.orderVersion` | `EXACT` | Version変化検知対象 | 実行する。 |
| `$.currency` | `EXACT` | 固定値 | 実行する。 |
| `$.totalAmount` | `DECIMAL` | Scale差を正規化して比較 | 実行する。 |
| `$.updatedAt` | `IGNORE_VALUE` | 実行時刻で変化し得る。 | 存在、型、Null、Formatは実行する。 |
| `$.items` | `KEYED_ARRAY` | `lineNo`で要素対応する。 | 要素Contractは実行する。 |

`IGNORE_VALUE`は「差分をChangeとして扱わない」指定であり、Field不存在、Null違反、型違反またはFormat違反を許可する指定ではない。

### 19.1 Mode

| Mode | 意味 |
|---|---|
| `EXACT` | 正規化後の値を完全一致比較する。 |
| `DECIMAL` | 数値として比較し、表現上のScale差を吸収する。 |
| `IGNORE_VALUE` | Field値の差をChange判定から除外する。 |
| `KEYED_ARRAY` | 指定KeyでArray要素を対応付ける。 |

### 19.2 Scenario固有上書き

Scenario固有の更新前後比較では、`orderStatus`および`orderVersion`にAPI既定とは異なるBusiness期待を設定できる。上書きはScenario専用Java CheckまたはCompare Definitionで明示し、API固定契約を変更しない。

## 20. DTO／Java実装

| Component | Example FQCN | 責務 |
|---|---|---|
| Response DTO | `com.example.e6.api.order.dto.OrderDetailResponse` | Success Body保持 |
| Item DTO | `com.example.e6.api.order.dto.OrderItemResponse` | Item要素保持 |
| Error DTO | `com.example.e6.api.common.dto.ApiErrorResponse` | Error Body保持 |
| API Client | `com.example.e6.api.order.OrderQueryApiClient` | HTTP呼出 |
| Validator | `com.example.e6.api.order.OrderDetailContractValidator` | API固定契約Check |

### 20.1 Java実装原則

- DTOはMapではなく型付きClassとする。
- Unknown Fieldを黙って破棄しない。
- Request、Response、HTTP MetaおよびCheck Resultを同一Objectへ混在させない。
- Scenario固有ExpectedをAPI Clientへ埋め込まない。
- Java Class名はExampleであり、正式Source Root確定には使用しない。

## 21. Security／Mask

| 対象 | 保存 | Mask |
|---|:---:|---|
| Authorization Header | No | 全体を`***` |
| `orderId` | Yes | Exampleでは末尾4桁以外をMaskする想定 |
| `customerId` | Yes | 末尾4桁以外をMask |
| Response Body | 条件付き | Field別Mask後に保存 |
| Error Message | Yes | Secret／個人情報検査後 |

Sampleの架空値であっても、正式Logへ無加工転記しない。

## 22. Timeout／Retry／Idempotency要求

| 項目 | 設計 |
|---|---|
| Connect Timeout | Example設定Referenceから取得。文書へ秒数を固定しない。 |
| Read Timeout | Example設定Referenceから取得。文書へ秒数を固定しない。 |
| 自動Retry | Scenarioおよび共通Policyに従う。更新APIと同一Policyにしない。 |
| 冪等性 | 読取API。再送しても業務更新は発生しない。 |
| Timeout結果 | HTTP Statusを推測せず、Response未受信として記録する。 |

## 23. Logging／Evidence

| Artifact | 必須 | 内容 |
|---|:---:|---|
| Request Meta | Yes | Method、Mask済Path、Header名、開始時刻 |
| Response Meta | Yes | Status、Header、終了時刻、Duration |
| Mask済Body | Response受信時 | SuccessまたはError Body |
| Contract Result | Yes | Rule ID、結果、Evidence Reference |
| Transport Error | 発生時 | Error分類、Stack Trace Reference |

## 24. Scenario連携

| scenarioId | apiCallCode | 目的 | Compare Identity |
|---|---|---|---|
| SC-E6-901 | CALL-001 | 変更前注文情報取得 | `SC-E6-901 + CALL-001` |
| SC-E6-901 | CALL-003 | 変更後注文情報再取得 | `SC-E6-901 + CALL-003` |

CALL-001とCALL-003は同じAPIを使用するが、Baseline、ExpectedおよびEvidenceを共有しない。

## 25. Traceability

```text
API-901
├─ API Master Example
├─ API-901 Detail Design Example
├─ OrderDetailResponse
├─ OrderQueryApiClient
└─ SC-E6-901
   ├─ CALL-001
   └─ CALL-003
```

## 26. Validation

| Rule ID | 確認内容 | 期待 |
|---|---|---|
| API901-V001 | Front Matterと文書情報が一致する。 | PASS |
| API901-V002 | API Master Exampleの8固定項目と一致する。 | PASS |
| API901-V003 | 900番台かつ`examples/`に配置される。 | PASS |
| API901-V004 | Request Bodyなしを`NONE`で明示する。 | PASS |
| API901-V005 | Success／Error Contractが機械判定可能である。 | PASS |
| API901-V006 | `IGNORE_VALUE`がContract免除になっていない。 | PASS |
| API901-V007 | Scenario固有値をAPI固定契約へ混入していない。 | PASS |

## 27. API単体Test観点

### 27.1 Request

- 正常な`orderId`
- Null、空文字、33桁、Pattern不一致
- Authorization未解決
- Correlation ID不正
- 未定義Query Parameter混入

### 27.2 Response

- 全必須Field正常
- Field不足、Null、型違反、長さ違反
- 未定義Enum
- `currency`固定値違反
- `items`空、`lineNo`重複
- StatusとError Code不整合

### 27.3 Diff

- `updatedAt`だけが変化した場合はChangeなし
- `updatedAt`が不存在またはFormat不正の場合はContract FAIL
- `items`順序だけが変化した場合のKey比較
- `orderStatus`変化をScenario固有Checkで評価

## 28. Review Checklist

### 28.1 契約

- [ ] Method、Path、DTOがAPI Master Exampleと一致する。
- [ ] Request／Response Fieldが一意に定義される。
- [ ] StatusとError Codeの対応が定義される。

### 28.2 Java

- [ ] DTO、Client、Validatorの責務が分離される。
- [ ] Unknown Fieldの取扱いが明示される。
- [ ] Scenario固有ExpectedがClientへ混入しない。

### 28.3 Security

- [ ] Credential実値が存在しない。
- [ ] Mask対象とEvidence保存可否が明示される。

### 28.4 変更影響

- [ ] Field追加・削除・型変更時の影響先を追跡できる。
- [ ] API既定Compare変更時にScenarioへの影響を確認できる。

## 29. 完了条件

1. Example内のMaster、ScenarioおよびAPI設計が整合する。
2. Request、Response、Error、CheckおよびCompareの記入例が揃う。
3. Example値が正式MasterおよびRuntimeから分離される。
4. `document_id`がRepository内で一意である。
5. Markdown構造Validationを通過する。

## 30. Release Blocker

ExampleはRelease対象外であり、正式Runtimeへ投入できない。次を満たしても正式APIとしてReleaseしてはならない。

- 文書ValidationがPASS
- 架空Java Class名が解決可能
- Sample JSONがSchemaに適合

## 31. Open Issues

| Issue ID | 内容 | 影響 | Owner | 状態 |
|---|---|---|---|---|
| API901-OI-001 | `API-902`詳細設計Exampleが未作成 | SC-E6-901全体のExample Traceが未完 | Example Design Team | CLOSED |
| API901-OI-002 | Example Input／Expected JSONが未作成 | Scenario資産の記入例が未完 | Example Design Team | CLOSED |

## 32. 禁止事項

- 本Exampleを正式E6 API仕様として引用する。
- `API-901`を正式API Masterへ登録する。
- SampleのID、Token、Hostまたは時刻を実行値として利用する。
- `IGNORE_VALUE`をContract／Business Check免除として実装する。
- CALL-001とCALL-003を同一Compare Identityとして扱う。
- Exampleの`enabled=true`を実行許可と解釈する。

## 33. 次工程

1. `system/04_usecase_design/examples/scenario/SC-E6-902設計書_Example.md`
2. `system/04_usecase_design/examples/input/SC-E6-902-input_Example.json`
3. `system/04_usecase_design/examples/expected/SC-E6-902-expected_Example.json`
