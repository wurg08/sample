---
title: 旧注文検索API設計書 Example
document_id: EX-E6-API-VAL-API-903-DESIGN
version: 1.0.1
status: EXAMPLE
document_type: API Detail Design Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 旧注文検索API設計書 Example

## 1. Example宣言

本書は、無効化・廃止予定APIの詳細設計Referenceを成立させるための架空Exampleである。実在するEndpoint、DTOまたはProvider契約を表さず、正式API MasterやRuntimeから参照してはならない。

## 2. API概要

| 項目 | Example値 |
|---|---|
| API ID | `API-903` |
| API名 | 旧注文検索API |
| Method | `POST` |
| Endpoint Path | `/api/v0/orders/search` |
| Request DTO | `LegacyOrderSearchRequest` |
| Response DTO | `LegacyOrderSearchResponse` |
| Master状態 | `enabled=false` |
| 利用方針 | 新規Scenarioから参照禁止 |

## 3. Request Example

| JSON Path | Type | Required | 説明 |
|---|---|:---:|---|
| `$.legacyOrderKey` | String | Yes | 旧方式の注文検索Key。 |
| `$.includeClosed` | Boolean | No | 完了済み注文を含むか。 |

## 4. Response Example

| JSON Path | Type | Required | 説明 |
|---|---|:---:|---|
| `$.resultCode` | String | Yes | 旧方式の結果Code。 |
| `$.orders` | Array | Yes | 注文検索結果。 |
| `$.orders[*].orderId` | String | Yes | 注文ID。 |
| `$.orders[*].status` | String | Yes | 注文状態。 |

## 5. 廃止・移行規則

1. 新規UseCaseまたはScenarioから参照しない。
2. 過去設計のTraceability維持に必要な場合だけ`enabled=false`で保持する。
3. 後継APIへの移行はAPI ID置換ではなく、Scenario詳細設計と影響分析を伴う。
4. API IDを再利用しない。

## 6. 関連Example

- `system/02_master/examples/API_Master_Example.md`
- `business/examples/旧注文状態管理_現行業務分析書_Example.md`

## 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `1.0.0` | 2026-07-27 | 初版。 |
| `1.0.1` | 2026-07-29 | `REP-MIG-002／003`によるAPI Master／Exampleの最終File名移行に伴い、Current Referenceを同期。文書固有の責務と業務内容は変更なし。 |
