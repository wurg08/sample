---
title: DiffReport Template
document_id: E6-API-VAL-DIFF-REPORT-TEMPLATE
version: 1.0.0-draft.3
status: DRAFT
document_type: API Response Diff Report Template
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# DiffReport Template

> 本TemplateはRun／Scenario／API Call単位のResponse差分を表示する。差分事実の正本は`response-field-diff.json`であり、本Reportは再比較、再分類またはIgnore判定を行わない。

## 1. Report情報

| 項目 | 内容 |
|---|---|
| Report ID | `<reportId>` |
| Run ID | `<runId>` |
| Batch ID | `<batchId / NONE>` |
| Environment | `<environmentId>` |
| Business ID | `<businessId>` |
| UseCase ID | `<useCaseId>` |
| Scenario ID | `<scenarioId>` |
| Input Set ID | `<inputSetId>` |
| Execution Status | `<COMPLETED / INCOMPLETE / REJECTED / UNKNOWN_OUTCOME>` |
| Verification Status | `<PASS / FAIL / NOT_EVALUATED>` |
| Change Status | `<UNCHANGED / CHANGED / NOT_COMPARED>` |
| Recovery Status | `<NOT_REQUIRED / REQUIRED / IN_PROGRESS / RESOLVED>` |
| Generated At | `<generatedAt>` |
| Generator Version | `<generatorVersion>` |
| Report Status | `<COMPLETE / INCOMPLETE>` |

## 2. 判定軸

| 軸 | Current Result | Source |
|---|---|---|
| Execution | `<executionStatus>` | `scenario-execution.json`／Run Meta |
| Verification | `<verificationStatus>` | `verification-result.json` |
| Change | `<changeStatus>` | `response-field-diff.json`集合 |
| Recovery | `<recoveryStatus>` | `verification-result.json`／Recovery Artifact |

### 2.1 重要な解釈

- Change StatusはVerification Resultではない。
- `CHANGED + PASS`は有効な組合せである。
- `UNCHANGED + FAIL`も有効な組合せである。
- Ignored Diffは差異が存在した事実を保持する。
- Compare Errorは全項目追加／削除またはNo Changeではない。
- Current Responseが存在しない場合、空Objectとして比較しない。

## 3. 比較元

| 項目 | Current | Comparison Source |
|---|---|---|
| Run ID | `<runId>` | `<previousRunId / baselineRunId / NONE>` |
| Selection Type | `CURRENT` | `<PREVIOUS / BASELINE / NONE>` |
| Environment | `<environmentId>` | `<environmentId / NONE>` |
| UseCase | `<useCaseId>` | `<useCaseId / NONE>` |
| Scenario | `<scenarioId>` | `<scenarioId / NONE>` |
| Input Set | `<inputSetId>` | `<inputSetId / NONE>` |
| Test Data | `<testDataId@version>` | `<testDataId@version / NONE>` |
| Expected | `<version/hash>` | `<version/hash / NONE>` |
| Java Build | `<buildIdentity>` | `<buildIdentity / NONE>` |
| Selected By | `<executionStateRef>` | `<selectionReason>` |

Execution Identity不一致時は比較せず、Change Statusを`NOT_COMPARED`、表示Categoryを`COMPARE_ERROR`とする。

## 4. 全体Summary

| 指標 | 件数 |
|---|---:|
| API Call総数 | `<apiCallCount>` |
| Compare Completed | `<completedCompareCount>` |
| Not Compared | `<notComparedCount>` |
| Compare Error | `<compareErrorCount>` |
| Checked Item | `<checkedItemCount>` |
| Effective Diff | `<effectiveDiffCount>` |
| Ignored Diff | `<ignoredDiffCount>` |
| Added | `<addedCount>` |
| Removed | `<removedCount>` |
| Type Changed | `<typeChangedCount>` |
| Value Changed | `<valueChangedCount>` |
| Null／Missing Changed | `<nullMissingChangedCount>` |
| Truncated API Call | `<truncatedApiCallCount>` |

## 5. API Call一覧

| Seq | API Call | API ID | HTTP | Comparison | Change | Checked | Effective | Ignored | Error | Baseline／Previous | Detail |
|---:|---|---|---:|---|---|---:|---:|---:|---:|---|---|
| `<10>` | `<apiCallCode>` | `<apiId>` | `<status / N/A>` | `<COMPLETED / NOT_COMPARED / ERROR>` | `<changeStatus>` | `<count>` | `<count>` | `<count>` | `<count>` | `<runId / NONE>` | `<section/link>` |

同じ`apiId`を複数回呼ぶ場合も、`apiCallCode`別に表示する。`apiId`だけで差分を統合しない。

## 6. Compare Error

| API Call | API ID | Error Code | Phase | Safe Message | Current Ref | Compare Source Ref | 対応 |
|---|---|---|---|---|---|---|---|
| `<apiCallCode>` | `<apiId>` | `<errorCode>` | `<LOAD / VALIDATE / COMPARE / WRITE>` | `<maskedMessage>` | `<relativeReference>` | `<relativeReference / NONE>` | `<requiredAction>` |

Compare Errorがない場合：

```text
NONE
```

Error発生API Callの未生成Diffを0件と解釈しない。

## 7. Effective Diff

| API Call | Path | Change Type | Previous／Baseline | Current | Previous Type | Current Type | Handling | Reason | Evidence |
|---|---|---|---|---|---|---|---|---|---|
| `<apiCallCode>` | `<concreteJsonPath>` | `<ADDED / REMOVED / TYPE_CHANGED / VALUE_CHANGED / NULL_CHANGED / ARRAY_CHANGED>` | `<maskedValue>` | `<maskedValue>` | `<jsonType / MISSING>` | `<jsonType / MISSING>` | `COMPARED` | `<reason / NONE>` | `<relativeReference>` |

### 7.1 表示順

1. `TYPE_CHANGED`
2. `REMOVED`
3. `ADDED`
4. `NULL_CHANGED`
5. `VALUE_CHANGED`
6. `ARRAY_CHANGED`

同一区分では`apiCallCode`、Concrete JSON Pathの昇順とする。

### 7.2 Value表示

| Value種別 | 表示 |
|---|---|
| 一般Scalar | Mask方針に従い表示可 |
| 個人情報 | MaskまたはHash |
| Credential／Token | `[REDACTED]` |
| Object／Array | 安全な要約、HashまたはEvidence Ref |
| Binary／巨大文字列 | Type、Length、Hash |
| Missing | `<MISSING>` |
| JSON Null | `<NULL>` |

`<MISSING>`、`<NULL>`および空文字を同一表示にしない。

## 8. Ignored Diff

| API Call | Path | Detected Change | Previous／Baseline | Current | Ignore Mode | Definition Ref | Reason | Effective |
|---|---|---|---|---|---|---|---|:---:|
| `<apiCallCode>` | `<concreteJsonPath>` | `<changeType>` | `<maskedValue>` | `<maskedValue>` | `<IGNORE_FIELD / IGNORE_VALUE>` | `<javaClass#method or definitionId>` | `<business/technical reason>` | `false` |

Ignored Diffがない場合：

```text
NONE
```

### 8.1 Ignore Modeの意味

| Mode | Ignored | Effectiveとして残す |
|---|---|---|
| `IGNORE_FIELD` | 追加、削除、型変化、値変化を含むField全体の変化 | 定義不正またはPath不一致 |
| `IGNORE_VALUE` | 同一Field・同一Typeの値変化 | 追加、削除、型変化 |

### 8.2 禁止表示

| 実際 | 禁止表示 | 正しい表示 |
|---|---|---|
| Ignored 2件 | 完全一致 | `IGNORED_ONLY (2)` |
| `IGNORE_VALUE`対象Field削除 | Ignored | `REMOVED / EFFECTIVE` |
| `IGNORE_VALUE`対象Type変更 | Ignored | `TYPE_CHANGED / EFFECTIVE` |
| Ignore Definition不正 | No Change | `COMPARE_ERROR` |

## 9. Not Compared

| API Call | API ID | Reason Code | Current Response | Compare Source | Verification | 対応 |
|---|---|---|---|---|---|---|
| `<apiCallCode>` | `<apiId>` | `<INITIAL_EXECUTION / CURRENT_RESPONSE_UNAVAILABLE / COMPARISON_SOURCE_UNAVAILABLE / CALL_NOT_REACHED / OTHER>` | `<available / unavailable>` | `<runId / NONE>` | `<result>` | `<action>` |

Not Comparedがない場合：

```text
NONE
```

### 9.1 Reason規則

| Reason | Change Status | 備考 |
|---|---|---|
| `INITIAL_EXECUTION` | `NOT_COMPARED` | Baseline候補化はBaseline管理に従う。 |
| `CURRENT_RESPONSE_UNAVAILABLE` | `NOT_COMPARED` | Responseなしを空Objectと比較しない。 |
| `COMPARISON_SOURCE_UNAVAILABLE` | `NOT_COMPARED`または`COMPARE_ERROR` | 必須性に従う。 |
| `CALL_NOT_REACHED` | `NOT_COMPARED` | Scenario Flow状態を別途表示する。 |
| `IDENTITY_MISMATCH` | `COMPARE_ERROR` | 比較禁止。 |

## 10. Field追加

| API Call | Path | Current Type | Current Value | Effective | Ignore Mode | Evidence |
|---|---|---|---|:---:|---|---|
| `<apiCallCode>` | `<path>` | `<type>` | `<maskedValue>` | `<true / false>` | `<mode / NONE>` | `<reference>` |

Field追加を自動的に契約違反としない。API Contract Checkまたは専用Business CheckのResultをVerification軸で表示する。

## 11. Field削除

| API Call | Path | Previous Type | Previous Value | Effective | Ignore Mode | Evidence |
|---|---|---|---|:---:|---|---|
| `<apiCallCode>` | `<path>` | `<type>` | `<maskedValue>` | `<true / false>` | `<mode / NONE>` | `<reference>` |

Required Field削除の契約判定はJava CheckのVerification Resultを参照する。Diff ReportがRequired判定を再実行しない。

## 12. Type変更

| API Call | Path | Previous Type | Current Type | Previous | Current | Effective | Evidence |
|---|---|---|---|---|---|:---:|---|
| `<apiCallCode>` | `<path>` | `<type>` | `<type>` | `<maskedValue>` | `<maskedValue>` | `true` | `<reference>` |

型変更を文字列表現へNormalizeして隠さない。

## 13. Value変更

| API Call | Path | Previous | Current | Comparator | Tolerance | Handling | Evidence |
|---|---|---|---|---|---|---|---|
| `<apiCallCode>` | `<path>` | `<maskedValue>` | `<maskedValue>` | `<EXACT / API_SPECIFIC>` | `<value / NONE>` | `<COMPARED / IGNORED>` | `<reference>` |

ToleranceまたはNormalizeをReport Template内で新規適用しない。Java Compare Definitionが返した結果だけを表示する。

## 14. Array差分

| API Call | Array Path | Match Method | Element Identity | Previous Count | Current Count | Effective | Detail |
|---|---|---|---|---:|---:|---:|---|
| `<apiCallCode>` | `<path>` | `<INDEX / KEY / API_SPECIFIC>` | `<keyPath / INDEX>` | `<count>` | `<count>` | `<count>` | `<reference>` |

標準比較がIndex順である場合、Report側でOrder-insensitive比較へ変更しない。API固有Comparatorを使用した場合はDefinition Referenceを明示する。

## 15. Unchanged Summary

| API Call | Checked | Unchanged | Effective | Ignored | 備考 |
|---|---:|---:|---:|---:|---|
| `<apiCallCode>` | `<count>` | `<count>` | `<count>` | `<count>` | `<note>` |

Unchanged Field全件をMarkdownへ展開する必要はないが、Summary件数とJSON正本が一致しなければならない。

## 16. Verificationとの関係

| Verification | Change | 解釈 |
|---|---|---|
| PASS | UNCHANGED | Expected成立、有効変化なし。Ignored件数は別表示 |
| PASS | CHANGED | Expected成立だが有効変化あり |
| FAIL | UNCHANGED | 前回同様でもExpected不成立 |
| FAIL | CHANGED | Expected不成立かつ有効変化あり |
| NOT_EVALUATED | NOT_COMPARED | 前提不足またはExecution Errorで評価・比較不能 |

Reportはこの組合せを事実として表示し、一つのResultへ潰さない。

## 17. Contract／Business Check Reference

| API Call | Result Key | Check Type | Verification | 関連Diff Path | Result Reference |
|---|---|---|---|---|---|
| `<apiCallCode>` | `<resultKey>` | `<REQUIRED / TYPE / ENUM / FIXED / BUSINESS / API_RESPONSE_COMPARE>` | `<NOT_EVALUATED / PASS / FAIL>` | `<path list / NONE>` | `<relativeReference>` |

Diffに関連するCheckが設計されていない場合、Reportが新しいCheck Resultを生成しない。

## 18. Compare Definition

| API Call | API ID | Java Definition | Build Identity | Ignore Field数 | Ignore Value数 | Validation |
|---|---|---|---|---:|---:|---|
| `<apiCallCode>` | `<apiId>` | `<class#method>` | `<buildIdentity>` | `<count>` | `<count>` | `<VALID / ERROR>` |

Compare DefinitionはAPI別／`apiCallCode`別Java実装を正本とする。外部YAML PolicyまたはCompare Policy Masterを参照しない。

## 19. Truncation／Resource制限

| API Call | Items Truncated | Reported | Total Detected | Limit | Full Evidence | Result |
|---|:---:|---:|---:|---:|---|---|
| `<apiCallCode>` | `<true / false>` | `<count>` | `<count / UNKNOWN>` | `<limit>` | `<relativeReference / NONE>` | `<COMPLETE / INCOMPLETE / ERROR>` |

TruncateしてもSummary件数を0へ戻さない。完全明細が保持できない場合、Report Statusと調査手順を明示する。

## 20. Security／Mask

| 確認 | Result | Detail |
|---|---|---|
| Previous Value Mask | `<PASS / ERROR>` | `<detail / NONE>` |
| Current Value Mask | `<PASS / ERROR>` | `<detail / NONE>` |
| Secret Value Omitted | `<PASS / ERROR>` | `<detail / NONE>` |
| Path Safety | `<PASS / ERROR>` | `<detail / NONE>` |
| Evidence Access | `<classification>` | `<detail>` |

Mask済表示が同一でも、`effectiveChanged`等の正本結果を変更しない。

## 21. Source Reference

| Source | Reference | Hash／Version | Status |
|---|---|---|---|
| Current Run Meta | `<relativeReference>` | `<hash>` | `<VALID / INVALID / MISSING>` |
| Verification Result | `<relativeReference>` | `<hash>` | `<status>` |
| Response Field Diff | `<relativeReference pattern>` | `<hash summary>` | `<status>` |
| Current Response | `<relativeReference pattern>` | `<hash summary>` | `<status>` |
| Comparison Response | `<baseline/previous reference pattern>` | `<hash summary>` | `<status>` |
| Execution State | `<reference>` | `<version/hash>` | `<status>` |
| Artifact Manifest | `<relativeReference>` | `<hash>` | `<status>` |

## 22. API Call詳細Template

### 22.1 `<apiCallCode>` — `<apiId>`

| 項目 | 内容 |
|---|---|
| Sequence | `<callSequence>` |
| API Call Code | `<apiCallCode>` |
| API ID | `<apiId>` |
| HTTP Status | `<status / N/A>` |
| Call Status | `<callStatus>` |
| Comparison Status | `<COMPLETED / NOT_COMPARED / ERROR>` |
| Change Status | `<changeStatus>` |
| Previous／Baseline Run | `<runId / NONE>` |
| Compare Definition | `<javaReference>` |
| Diff JSON | `<relativeReference>` |

#### Summary

| Checked | Unchanged | Effective | Ignored | Error | Truncated |
|---:|---:|---:|---:|---:|:---:|
| `<count>` | `<count>` | `<count>` | `<count>` | `<count>` | `<true / false>` |

#### Effective

| Path | Change | Previous | Current | Type Change | Evidence |
|---|---|---|---|---|---|
| `<path>` | `<changeType>` | `<maskedValue>` | `<maskedValue>` | `<previousType -> currentType / NONE>` | `<reference>` |

#### Ignored

| Path | Change | Previous | Current | Mode | Reason |
|---|---|---|---|---|---|
| `<path>` | `<changeType>` | `<maskedValue>` | `<maskedValue>` | `<IGNORE_FIELD / IGNORE_VALUE>` | `<reason>` |

#### Error／Not Compared

```text
<NONE or reason code and safe message>
```

このSectionをAPI Callごとに反復する。

## 23. 生成時Validation

| Validation ID | 確認内容 | 失敗時 |
|---|---|---|
| `DR-V001` | Run、Scenario、Input Set Identityが一致する。 | `INCOMPLETE` |
| `DR-V002` | `apiCallCode`と`apiId`がScenario設計と一致する。 | 生成`ERROR` |
| `DR-V003` | Summary件数とDiff Item件数が一致する。 | 生成`ERROR` |
| `DR-V004` | Ignored Itemの`effectiveChanged=false`である。 | 生成`ERROR` |
| `DR-V005` | `IGNORE_VALUE`の追加、削除、型変更がEffectiveである。 | 生成`ERROR` |
| `DR-V006` | Initial ExecutionをNo Changeと表示しない。 | 生成`ERROR` |
| `DR-V007` | Responseなしを空Object比較として表示しない。 | 生成`ERROR` |
| `DR-V008` | VerificationとChangeを独立表示する。 | 生成`ERROR` |
| `DR-V009` | Secretおよび未Mask個人情報を含まない。 | 公開禁止 |
| `DR-V010` | Referenceが許可Root内で解決する。 | 公開禁止 |
| `DR-V011` | Markdownと`diff-report.json`が一致する。 | `INCOMPLETE` |
| `DR-V012` | 表示順が決定的である。 | 生成`ERROR` |
| `DR-V013` | Truncationが明示される。 | `INCOMPLETE` |
| `DR-V014` | Compare DefinitionがJava Buildへ追跡できる。 | `INCOMPLETE` |

## 24. Template置換規則

1. `<...>` Placeholderをすべて置換する。
2. 値が存在しない場合、空欄でなく`NONE`、`N/A`または標準Reason Codeを使用する。
3. 0件Sectionは削除せず`NONE`と表示してよい。
4. JSON PathはConcrete Pathを表示し、Patternは別列で示す。
5. PreviousとCurrentの表示順を逆転させない。
6. ReferenceはRun RootまたはReport Rootからの相対Pathとする。
7. MarkdownとJSONのIdentity、Statusおよび件数を一致させる。
8. 全Validation後にReport一式を原子的に公開する。

## 25. 禁止事項

- Report Template内でResponseを再比較する。
- Compare DefinitionをReport側で補完する。
- Effective DiffをVerification `FAIL`へ自動変換する。
- Ignored Diffを削除またはNo Changeへ変換する。
- `IGNORE_VALUE`で追加、削除または型変更を隠す。
- Current Responseなしを全Field削除と表示する。
- 初回実行を一致と表示する。
- 同一APIの複数Callを`apiId`だけで統合する。
- Mask前Value、Secret、Token、CredentialまたはInternal Hostを表示する。
- Compare Policy Master、YAML Policyまたは未承認Registryを参照する。
- Report生成によりBaseline、Previous RunまたはExecution Stateを変更する。

## 26. Template改訂履歴

| Version | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | Current Architecture、API Call Identity、Java Compare DefinitionおよびEffective／Ignored分離に基づく初版作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | Front Matter `title`とH1を文書作成規約に従い一致させた。Report内容および判定規則の変更なし。 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | Framework横断Reviewにより四結果軸、Canonical Statusおよび表示Category分離へ統一 | DRAFT |
