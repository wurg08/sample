---
title: DailySummary Template
document_id: E6-API-VAL-DAILY-SUMMARY-TEMPLATE
version: 1.0.0-draft.4
status: DRAFT
document_type: Verification Daily Summary Template
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# DailySummary Template

> 本TemplateはBatch／日次実行の承認者向けSummaryである。`batch-verification-result.json`、各RunのVerification Result、DiffおよびArtifact Manifestから決定的に生成する。生成時にこの説明Blockは削除してよいが、判定軸、件数定義およびReferenceを変更してはならない。

## 1. Report情報

| 項目 | 内容 |
|---|---|
| Report ID | `<reportId>` |
| Batch ID | `<batchId>` |
| Environment | `<environmentId>` |
| Execution Spec | `<executionSpecId / version / hash>` |
| Target Business | `<businessId list>` |
| Target UseCase | `<useCaseId list>` |
| Scheduled Window | `<scheduledStart> - <scheduledEnd>` |
| Started At | `<startedAt>` |
| Finished At | `<finishedAt>` |
| Generated At | `<generatedAt>` |
| Generator Version | `<generatorVersion>` |
| Report Status | `<COMPLETE / INCOMPLETE>` |
| Artifact Manifest | `<relativeReference>` |

## 2. Executive Result

| 判定軸 | Result | 意味 | 詳細 |
|---|---|---|---|
| Execution | `<COMPLETED / INCOMPLETE / REJECTED / UNKNOWN_OUTCOME>` | Batch実行と必須成果物の成立状態 | `<reason or NONE>` |
| Verification | `<PASS / FAIL / NOT_EVALUATED>` | Expected／Checkに対する業務・契約判定 | `<primary reason or NONE>` |
| Change | `<UNCHANGED / CHANGED / NOT_COMPARED>` | Previous／Baselineに対する変化 | `<primary reason or NONE>` |
| Recovery | `<NOT_REQUIRED / REQUIRED / IN_PROGRESS / RESOLVED>` | 運用介入の必要性と進行 | `<primary reason or NONE>` |

### 2.1 承認者向け結論

```text
<自動生成された事実ベースの短い結論。
例：7 Scenario中5件PASS、1件FAIL、1件NOT_EVALUATED。
有効差異を2 Scenarioで検出。Ignored Diffのみは1 Scenario。
承認判断に必要なBlockerが2件存在する。>
```

### 2.2 判定上の注意

- Effective Diffは自動的にVerification `FAIL`を意味しない。
- Ignored Diffは主FAIL件数へ加算しないが、変化として表示する。
- 初回または比較不能を「変化なし」と表示しない。
- Execution、Verification、ChangeおよびRecoveryを一つの成功／失敗列へ統合しない。
- Report Generatorは入力Resultを再判定または補正しない。

## 3. Release／承認Blocker

| No. | Severity | Scope | Code | 内容 | Owner | 対応 | Evidence |
|---:|---|---|---|---|---|---|---|
| `<1>` | `<CRITICAL / HIGH>` | `<Batch / Run / Scenario / API Call>` | `<blockerCode>` | `<事実>` | `<owner>` | `<requiredAction>` | `<relativeReference>` |

Blockerがない場合：

```text
NONE
```

## 4. Verification集計

| 指標 | 件数 | 対象総数との整合 |
|---|---:|---|
| Scenario総数 | `<scenarioCount>` | `PASS + FAIL + NOT_EVALUATED` |
| PASS | `<passCount>` |  |
| FAIL | `<failCount>` |  |
| NOT_EVALUATED | `<notEvaluatedCount>` |  |

### 4.1 集約優先順位

```text
FAIL
  > NOT_EVALUATED
      > PASS
```

本Templateは既に確定したScenario Resultを集約する。Check明細から独自に再計算しない。

## 5. Execution集計

| 指標 | 件数 |
|---|---:|
| 対象Run | `<runCount>` |
| COMPLETED | `<completedCount>` |
| INCOMPLETE | `<incompleteCount>` |
| REJECTED | `<rejectedCount>` |
| UNKNOWN_OUTCOME | `<unknownOutcomeCount>` |
| NOT EXECUTED | `<notExecutedCount>` |
| 必須Artifact欠落Run | `<artifactMissingRunCount>` |
| Cleanup Error Run | `<cleanupErrorRunCount>` |

`NOT EXECUTED`は実行対象に選択されたがRunが開始されなかった事実であり、Verification Resultの`SKIP`ではない。

## 6. Change集計

| 指標 | Scenario件数 | Diff Item件数 |
|---|---:|---:|
| CHANGED | `<changedScenarioCount>` | `<effectiveDiffCount>` |
| UNCHANGED | `<unchangedScenarioCount>` | `<unchangedOrIgnoredDiffCount>` |
| NOT_COMPARED | `<notComparedScenarioCount>` | `-` |

### 6.1 Change集約順

```text
CHANGED
  > NOT_COMPARED
      > UNCHANGED
```

`NOT_COMPARED`が存在しても同一GroupにEffective Changeがある場合、Group Changeは`CHANGED`とし、未比較件数を別列で保持する。Ignored OnlyとCompare Errorは別表示Category／Reasonとして保持する。

## 7. Scenario一覧

| Business | UseCase | Scenario | Input Set | Run ID | Execution | Verification | Change | Recovery | Effective | Ignored | Not Compared | Duration | Detail |
|---|---|---|---|---|---|---|---|---|---:|---:|---:|---:|---|
| `<BUS-E6-NNN>` | `<UC-E6-NNN>` | `<SC-E6-NNN>` | `<inputSetId>` | `<runId>` | `<status>` | `<result>` | `<changeStatus>` | `<recoveryStatus>` | `<count>` | `<count>` | `<count>` | `<ms>` | `<relativeReference>` |

### 7.1 表示順

1. Execution `UNKNOWN_OUTCOME`
2. Recovery `REQUIRED`
3. Execution `INCOMPLETE`／`REJECTED`
4. Verification `FAIL`
5. Verification `NOT_EVALUATED`
6. Change `CHANGED`
7. その他

同一区分では`businessId`、`useCaseId`、`scenarioId`、`inputSetId`の昇順とする。

## 8. FAIL明細

| Scenario | Result Key | Check Type | API Call | Expected | Actual | Message | Evidence |
|---|---|---|---|---|---|---|---|
| `<scenarioId>` | `<resultKey>` | `<resultType>` | `<apiCallCode / SCENARIO>` | `<maskedExpected>` | `<maskedActual>` | `<message>` | `<relativeReference>` |

FAILがない場合：

```text
NONE
```

## 9. NOT_EVALUATED明細

| Scenario | Result Key／Phase | 未成立前提 | 依存Reference | 必要対応 | Owner | Evidence |
|---|---|---|---|---|---|---|
| `<scenarioId>` | `<resultKey / phase>` | `<precondition>` | `<reference>` | `<action>` | `<owner>` | `<relativeReference>` |

NOT_EVALUATEDをFAILへ置換しない。原因はExecution／Recovery StatusとReason Codeで表示する。

## 10. Execution Problem明細

| Scope | Run／Scenario／API Call | Error Code | Phase | Safe Message | Retry | Owner | Evidence |
|---|---|---|---|---|---|---|---|
| `<scope>` | `<identity>` | `<errorCode>` | `<phase>` | `<maskedMessage>` | `<YES / NO / CONDITIONAL>` | `<owner>` | `<relativeReference>` |

Stacktrace、Token、CredentialおよびInternal Hostを本Reportへ埋め込まない。

## 11. Effective Change

| Scenario | API Call | API ID | Change Status | Effective | Ignored | Diff Report | Verification |
|---|---|---|---|---:|---:|---|---|
| `<scenarioId>` | `<apiCallCode>` | `<apiId>` | `CHANGED` | `<count>` | `<count>` | `<relativeReference>` | `<PASS / FAIL / NOT_EVALUATED>` |

有効差異が0件の場合：

```text
NONE
```

## 12. Ignored Diff

| Scenario | API Call | Ignored件数 | Ignore Mode | 主なPath | Reason | Diff Report |
|---|---|---:|---|---|---|---|
| `<scenarioId>` | `<apiCallCode>` | `<count>` | `<IGNORE_FIELD / IGNORE_VALUE / MIXED>` | `<maskedPath summary>` | `<reason>` | `<relativeReference>` |

Ignored Diffを「完全一致」または「変化なし」と表示しない。

## 13. Not Compared

| Scenario | API Call | Reason Code | Baseline／Previous | Verification | 対応 |
|---|---|---|---|---|---|
| `<scenarioId>` | `<apiCallCode>` | `<INITIAL_EXECUTION / CURRENT_RESPONSE_UNAVAILABLE / BASELINE_UNAVAILABLE / OTHER>` | `<runId / NONE>` | `<result>` | `<action>` |

初回実行でExpected Checkが成立した場合、VerificationはPASS／FAILを独立して表示できる。

## 14. Compare Error

| Scenario | API Call | Error Code | Safe Message | Diff Evidence | Owner |
|---|---|---|---|---|---|
| `<scenarioId>` | `<apiCallCode>` | `<errorCode>` | `<maskedMessage>` | `<relativeReference>` | `<owner>` |

Compare ErrorをEffective Diff、全項目削除またはNo Changeとして表示しない。

## 15. API呼出集計

| API ID | Call数 | Success | Business Error Response | Transport Error | Timeout | Verification FAIL | Effective Change |
|---|---:|---:|---:|---:|---:|---:|---:|
| `<API-NNN>` | `<count>` | `<count>` | `<count>` | `<count>` | `<count>` | `<count>` | `<count>` |

同じAPIがScenario内で複数回呼ばれる場合、明細Identityは`scenarioId + apiCallCode`を使用する。

## 16. Test Data／Input Summary

| Scenario | Input Set | Test Data ID | Version | Hash | Approval At Execution | Cleanup |
|---|---|---|---|---|---|---|
| `<scenarioId>` | `<inputSetId>` | `<testDataId>` | `<version>` | `<hash>` | `<APPROVED / BLOCKED>` | `<COMPLETED / NOT_REQUIRED / FAILED / UNKNOWN>` |

Test Data値そのもの、Secretまたは未Mask個人情報を本Reportへ複製しない。

## 17. Baseline／Previous Summary

| Scenario | Input Set | Previous Run | Baseline Run | Selection Status | Version Difference | Evidence |
|---|---|---|---|---|---|---|
| `<scenarioId>` | `<inputSetId>` | `<runId / NONE>` | `<runId / NONE>` | `<SELECTED / NOT_FOUND / ERROR>` | `<testData / expected / build difference summary>` | `<relativeReference>` |

DateまたはDirectory順からPrevious Runを推測しない。Execution Stateに記録されたIdentityとReferenceだけを使用する。

## 18. Artifact完全性

| Artifact | Expected | Available | Valid | Hash Verified | 欠落／異常 |
|---|---:|---:|---:|---:|---|
| Run Meta | `<count>` | `<count>` | `<count>` | `<count>` | `<detail / NONE>` |
| Scenario Execution | `<count>` | `<count>` | `<count>` | `<count>` | `<detail / NONE>` |
| Verification Result | `<count>` | `<count>` | `<count>` | `<count>` | `<detail / NONE>` |
| API Call Meta | `<count>` | `<count>` | `<count>` | `<count>` | `<detail / NONE>` |
| Response Field Diff | `<count>` | `<count>` | `<count>` | `<count>` | `<detail / NONE>` |
| Scenario Summary | `<count>` | `<count>` | `<count>` | `<count>` | `<detail / NONE>` |
| Evidence Index | `<count>` | `<count>` | `<count>` | `<count>` | `<detail / NONE>` |

必須Artifact欠落時は`reportStatus=INCOMPLETE`とし、欠落をPASSとして集約しない。

## 19. Security確認

| 確認 | Result | Detail |
|---|---|---|
| Secret Scan | `<PASS / ERROR>` | `<detail / NONE>` |
| PII Mask | `<PASS / ERROR>` | `<detail / NONE>` |
| Link Root Validation | `<PASS / ERROR>` | `<detail / NONE>` |
| Report Access Classification | `<classification>` | `<detail>` |

## 20. 前回Batchとの状況比較

| 指標 | Current | Previous Batch | Delta | 注記 |
|---|---:|---:|---:|---|
| PASS Scenario | `<count>` | `<count / N/A>` | `<delta / N/A>` | `<note>` |
| FAIL Scenario | `<count>` | `<count / N/A>` | `<delta / N/A>` | `<note>` |
| NOT_EVALUATED Scenario | `<count>` | `<count / N/A>` | `<delta / N/A>` | `<note>` |
| Effective Change Scenario | `<count>` | `<count / N/A>` | `<delta / N/A>` | `<note>` |

前回Batchが同一対象集合、EnvironmentおよびExecution仕様でない場合、単純な増減を品質改善／悪化と表現しない。

## 21. 未実行対象

| UseCase | Scenario | Input Set | 選択状態 | 未実行理由 | Owner | 対応 |
|---|---|---|---|---|---|---|
| `<useCaseId>` | `<scenarioId>` | `<inputSetId>` | `<SELECTED / NOT_SELECTED>` | `<reason>` | `<owner>` | `<action>` |

対象外と実行失敗を区別する。Execution仕様で選択されていないScenarioは分母へ含めず、選択済みだが開始されなかったScenarioは未実行として明示する。

## 22. 承認記録

| 項目 | 内容 |
|---|---|
| 自動生成結果 | `<COMPLETE / INCOMPLETE>` |
| Review Status | `<NOT_REVIEWED / IN_REVIEW / REVIEWED>` |
| 承認判断 | `<PENDING / APPROVED / REJECTED / CONDITIONAL>` |
| 承認者 | `<stableApproverId>` |
| 承認日時 | `<approvedAt>` |
| 条件／Comment | `<comment / NONE>` |

人による承認記録はRuntime Resultを変更しない。Report再生成時に既存承認を無条件で引き継がない。

## 23. Source Reference

| Source | Reference | Hash／Version | Status |
|---|---|---|---|
| Batch Verification Result | `<relativeReference>` | `<hash>` | `<VALID / INVALID / MISSING>` |
| Execution Spec | `<reference>` | `<version/hash>` | `<status>` |
| Run Artifact Manifest | `<reference pattern>` | `<hash summary>` | `<status>` |
| Verification Result | `<reference pattern>` | `<hash summary>` | `<status>` |
| Diff Report | `<reference pattern>` | `<hash summary>` | `<status>` |
| Evidence Index | `<reference pattern>` | `<hash summary>` | `<status>` |

## 24. 生成時Validation

| Validation ID | 確認内容 | 失敗時 |
|---|---|---|
| `DS-V001` | Batch Identityが全入力で一致する。 | `INCOMPLETE` |
| `DS-V002` | Scenario総数とResult別件数が一致する。 | `INCOMPLETE` |
| `DS-V003` | Execution件数と対象Runが一致する。 | `INCOMPLETE` |
| `DS-V004` | Effective／Ignored／Error件数がDiff Summaryと一致する。 | `INCOMPLETE` |
| `DS-V005` | 各Scenario Detail Referenceが解決する。 | `INCOMPLETE` |
| `DS-V006` | 必須ArtifactとHashが検証済みである。 | `INCOMPLETE` |
| `DS-V007` | Secretおよび未Mask個人情報がない。 | 公開禁止 |
| `DS-V008` | 初回をNo Changeと表示していない。 | 生成`ERROR` |
| `DS-V009` | Ignored DiffがFAIL件数に混入していない。 | 生成`ERROR` |
| `DS-V010` | Execution／Verification／Change／Recoveryの四結果軸が独立している。 | 生成`ERROR` |
| `DS-V011` | Report内Linkが許可Root外へ出ない。 | 公開禁止 |
| `DS-V012` | 表示順が決定的である。 | 生成`ERROR` |

## 25. Template置換規則

1. `<...>` Placeholderをすべて解決する。
2. 値が存在しない場合は空欄でなく`NONE`、`N/A`または標準Reason Codeを使用する。
3. 件数0のSectionは削除せず`NONE`を表示してよい。
4. 表示値をMaskし、元値をMarkdownへ埋め込まない。
5. ReferenceはReport RootまたはBatch Rootからの相対Pathとする。
6. Markdownと`daily-summary.json`のIdentity、Resultおよび件数を一致させる。
7. Report一式のValidation後に原子的に公開する。

## 26. 禁止事項

- Effective Diffを自動的にVerification `FAIL`へ変換する。
- Ignored Diffを「変化なし」と表示する。
- NOT_EVALUATED、Execution Problemまたは未実行をPASSへ集約する。
- `WARN`、`SKIP`または`IGNORED`をVerification Resultへ追加する。
- Check明細からScenario Resultを再判定する。
- 欠落Artifactを補完推測する。
- Secret、Credential、Internal Host、未Mask個人情報を表示する。
- Runtime成果物のOS絶対PathまたはSigned URLを表示する。
- 日付順からPrevious Runを選定する。
- Report生成によりBaselineまたはExecution Stateを更新する。

## 27. Template改訂履歴

| Version | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | Current Architecture、三判定軸、Artifact完全性および承認者向け表示に基づく初版作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | Front Matter `title`とH1を文書作成規約に従い一致させた。Report内容および判定規則の変更なし。 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | Framework横断Reviewにより四結果軸、Canonical集約、未評価およびRecovery表示へ統一 | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | 横断再走査によりValidation文言を四結果軸へ同期 | DRAFT |
