---
title: Evidence Report Template
document_id: E6-API-VAL-EVIDENCE-REPORT-TEMPLATE
version: 1.0.0-draft.4
status: DRAFT
document_type: Evidence Index Report Template
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Evidence Report Template

> 本Templateは、Run単位のArtifactを安全に追跡するためのEvidence Indexを生成する。Evidence本文を本Reportへ複製せず、Artifact Manifestに記録された相対Path、Hash、Size、Media Type、Mask状態および可用性を表示する。

## 1. Report情報

| 項目 | 内容 |
|---|---|
| Report ID | `<reportId>` |
| Run ID | `<runId>` |
| Batch ID | `<batchId / NONE>` |
| Environment ID | `<environmentId>` |
| Business ID | `<businessId>` |
| UseCase ID | `<useCaseId>` |
| Scenario ID | `<scenarioId>` |
| Input Set ID | `<inputSetId>` |
| Test Data | `<testDataId>@<dataSetVersion>` |
| Generated At | `<generatedAt>` |
| Generator Version | `<generatorVersion>` |
| Report Status | `<COMPLETE / INCOMPLETE / FAILED>` |
| Access Classification | `<classification>` |
| Retention Class | `<retentionClass>` |

## 2. Templateの責務

本Templateは、Repository上では`EvidenceReport_Template.md`として管理し、Runtimeでは次の2成果物を生成する。

| 形式 | Runtime File | 責務 |
|---|---|---|
| JSON | `evidence-index.json` | 機械処理可能なEvidence Index正本 |
| Markdown | `EvidenceIndex.md` | 人間向け表示 |

本Templateは次を実施する。

1. `runId`からRun内のArtifactを索引する。
2. Artifact Manifestと実Fileの存在・Hash・Sizeを照合した結果を表示する。
3. Input、Expected、Build、Verification、DiffおよびReportの再現Traceを表示する。
4. Artifact欠落、破損、Mask不備およびAccess制限を明示する。
5. Execution Problemまたは前提不成立時にも取得済みEvidenceを追跡可能にする。

本Templateは次を実施しない。

- Request／Response、Expected、ActualまたはLog本文の複製
- Expectedに対するCheckの再実行
- Responseの再比較またはIgnore判定
- Verification Result、Change StatusまたはExecution Statusの再計算
- Artifact Manifestの補完推測
- Baseline、Previous RunまたはExecution Stateの更新
- Retention、Access権限またはMask Policyの新規決定

## 3. Source of Truth

| 情報 | 正本 | Evidence Indexでの扱い |
|---|---|---|
| Run Identity | `run-meta.json` | Identityを表示し、全Artifactと照合する。 |
| Scenario実行状態 | `scenario-execution.json` | 参照のみ。再判定しない。 |
| Verification Result | `verification-result.json` | `resultKey`単位で参照する。 |
| Response差分 | `response-field-diff.json` | `apiCallCode`単位で参照する。 |
| Artifact一覧・Hash | `artifact-manifest.json` | 索引生成の主Sourceとする。 |
| Input | Input SnapshotおよびScenario Input Reference | 版・Hash・参照だけを表示する。 |
| Test Data | 承認済みTest Data Asset | `testDataId + dataSetVersion + contentHash`を表示する。 |
| Expected | Expected Snapshot／Expected JSON | 版・Hash・参照だけを表示する。 |
| Build | Run MetaのBuild Identity | Build識別子を表示する。 |
| Baseline／Previous | Execution State／Baseline Meta | 選定済み参照を表示する。 |
| Evidence本文 | 各Artifact File | 本Indexへ複製しない。 |

## 4. 判定軸

| 軸 | Current Result | Source |
|---|---|---|
| Execution | `<NOT_STARTED / RUNNING / COMPLETED / INCOMPLETE / REJECTED / UNKNOWN_OUTCOME>` | `scenario-execution.json`／Run Meta |
| Verification | `<NOT_EVALUATED / PASS / FAIL>` | `verification-result.json` |
| Change | `<NOT_COMPARED / UNCHANGED / CHANGED>` | `response-field-diff.json`集合 |
| Recovery | `<NOT_REQUIRED / REQUIRED / IN_PROGRESS / RESOLVED>` | Recovery Artifact／Run Result |
| Report | `<COMPLETE / INCOMPLETE / FAILED>` | Report生成結果 |

これらを一つの総合Statusへ変換しない。Evidence欠落によりReportが`INCOMPLETE`でも、SourceのVerification Resultを書き換えない。

## 5. Evidence完全性Summary

| 指標 | 件数 |
|---|---:|
| Manifest登録Artifact | `<manifestArtifactCount>` |
| 必須Artifact | `<requiredArtifactCount>` |
| Available | `<availableCount>` |
| Unavailable | `<unavailableCount>` |
| Hash Verified | `<hashVerifiedCount>` |
| Hash Mismatch | `<hashMismatchCount>` |
| Size Mismatch | `<sizeMismatchCount>` |
| Schema Valid | `<schemaValidCount>` |
| Schema Invalid | `<schemaInvalidCount>` |
| Mask Confirmed | `<maskConfirmedCount>` |
| Mask Error | `<maskErrorCount>` |
| Access Restricted | `<accessRestrictedCount>` |
| Orphan File | `<orphanFileCount>` |
| Unmanifested Required Artifact | `<unmanifestedRequiredCount>` |

### 5.1 完全性判定

| Report Status | 条件 |
|---|---|
| `COMPLETE` | 全必須ArtifactがManifestに存在し、Identity、Hash、Size、PathおよびMask確認が成立する。 |
| `INCOMPLETE` | 欠落または検証不能があるが、安全なIndexと原因を生成できる。 |
| `FAILED` | Source Identity不一致、Path違反、Secret露出等により安全なIndexを公開できない。 |

`INCOMPLETE`または`FAILED`をVerification `FAIL`へ自動変換しない。

## 6. Reproducibility Chain

```mermaid
flowchart TD
    A["Run Identity"] --> B["Input／Test Data"]
    B --> C["Expected／Build"]
    C --> D["API Call Artifact"]
    D --> E["Verification／Diff"]
    E --> F["Manifest"]
    F --> G["Evidence Index"]
```

| 要素 | Identity／Version | Reference | Hash | Status |
|---|---|---|---|---|
| Run Meta | `<runId>` | `<relativeReference>` | `<hash>` | `<VALID / INVALID / MISSING>` |
| Scenario Design | `<scenarioId>@<version>` | `<repositoryReference>` | `<hash / NONE>` | `<status>` |
| Scenario Input | `<inputSetId>@<version>` | `<reference>` | `<hash>` | `<status>` |
| Test Data | `<testDataId>@<dataSetVersion>` | `<reference>` | `<contentHash>` | `<status>` |
| Expected | `<scenarioId>@<version>` | `<reference>` | `<hash>` | `<status>` |
| Java Build | `<buildIdentity>` | `<buildReference>` | `<hash>` | `<status>` |
| Compare Definition | `<definitionReference>` | `<javaReference>` | `<buildHash>` | `<status>` |
| Baseline／Previous | `<runId / NONE>` | `<executionStateReference>` | `<hash / NONE>` | `<status>` |
| Artifact Manifest | `<runId>` | `<relativeReference>` | `<hash>` | `<status>` |

不存在を空欄で表現せず、`NONE`または標準Reason Codeを使用する。

## 7. 必須Artifact Matrix

| Artifact Type | 必須条件 | Expected Path Pattern | Available | Integrity | Mask | 備考 |
|---|---|---|:---:|---|---|---|
| `RUN_META` | 常時 | `run-meta.json` | `<true / false>` | `<VALID / INVALID / UNKNOWN>` | `N/A` | Run Identity正本 |
| `SCENARIO_EXECUTION` | 常時 | `scenario-execution.json` | `<true / false>` | `<status>` | `<status>` | Execution状態 |
| `DEFINITION_SNAPSHOT` | 常時 | `run-meta.json`内 | `<true / false>` | `<status>` | `<status>` | Input／Expectedを含むBundle Version、Hash、Source Revision |
| `VERIFICATION_RESULT` | Check実行時 | `verification-result.json` | `<true / false>` | `<status>` | `<status>` | Verification正本 |
| `API_CALL_META` | API到達時 | `api-calls/{apiCallCode}/api-meta.json` | `<true / false>` | `<status>` | `<status>` | API Call Identity |
| `REQUEST` | Request生成時 | `api-calls/{apiCallCode}/request.json` | `<true / false>` | `<status>` | `<status>` | 保存禁止項目除外済み |
| `RESPONSE` | Response受信時 | `api-calls/{apiCallCode}/response.json` | `<true / false>` | `<status>` | `<status>` | 保存禁止項目除外済み |
| `API_CALL_META` | Plan上のAPI Call | `api-calls/{apiCallCode}/api-meta.json` | `<true / false>` | `<status>` | `<status>` | Call Identity、Disposition、安全なFailure Metadata |
| `FIELD_DIFF` | 比較実施時 | `api-calls/{apiCallCode}/response-field-diff.json` | `<true / false>` | `<status>` | `<status>` | Diff正本 |
| `RUN_LOG` | Runtime規則で必須時 | `logs/run.log` | `<true / false>` | `<status>` | `<status>` | Secret非出力 |
| `ARTIFACT_MANIFEST` | 常時 | `artifact-manifest.json` | `<true / false>` | `<status>` | `N/A` | Index Source |

具体的な必須条件は実行設計とArtifact Manifest設計に従う。本Templateが新しい必須Artifactを独自に追加しない。

API Call Metaの正本名は`api-meta.json`とする。Manifestはこの相対Pathを保持し、Aliasまたは二重Fileを生成してはならない。

## 8. Artifact Index

| Seq | Artifact Type | Scope Key | Relative Path | Media Type | Size | Hash | Integrity | Masked | Available | Detail |
|---:|---|---|---|---|---:|---|---|:---:|:---:|---|
| `<1>` | `<artifactType>` | `<runId / resultKey / apiCallCode>` | `<relativePath>` | `<mediaType>` | `<sizeBytes>` | `<algorithm:value>` | `<VALID / INVALID / UNKNOWN>` | `<true / false / N/A>` | `<true / false>` | `<section/link / NONE>` |

### 8.1 表示順

1. Run共通Artifact
2. Input／Expected
3. Verification Result
4. `apiCallCode`昇順のAPI Call Artifact
5. Diff
6. Log
7. Report
8. Artifact Manifest

同一区分では`relativePath`昇順とする。

### 8.2 Scope Key

| Artifact | Scope Key |
|---|---|
| Run共通 | `runId` |
| Check | `runId + resultKey` |
| API Call | `runId + apiCallCode` |
| Field Diff | `runId + apiCallCode + concretePath` |
| Report | `runId + reportType` |

`apiId`だけでAPI Call Artifactを統合しない。

## 9. API Call Evidence

| Seq | API Call | API ID | Call Status | HTTP | Request | Response | Error | Diff | Meta | Completeness |
|---:|---|---|---|---:|---|---|---|---|---|---|
| `<10>` | `<apiCallCode>` | `<apiId>` | `<callStatus>` | `<status / N/A>` | `<ref / UNAVAILABLE>` | `<ref / UNAVAILABLE>` | `<ref / NONE>` | `<ref / NOT_COMPARED>` | `<ref>` | `<COMPLETE / INCOMPLETE>` |

### 9.1 API Call詳細Template

#### `<apiCallCode>` — `<apiId>`

| 項目 | 内容 |
|---|---|
| Call Sequence | `<callSequence>` |
| Call Status | `<callStatus>` |
| Started／Finished | `<startedAt>`／`<finishedAt>` |
| Request Ref | `<relativeReference / UNAVAILABLE>` |
| Response Ref | `<relativeReference / UNAVAILABLE>` |
| Error Ref | `<relativeReference / NONE>` |
| Diff Ref | `<relativeReference / NOT_COMPARED>` |
| Compare Source Run | `<runId / NONE>` |
| Evidence Completeness | `<COMPLETE / INCOMPLETE>` |
| Incomplete Reason | `<reasonCode / NONE>` |

このSectionをAPI Callごとに反復する。

## 10. Check Evidence

| Result Key | Check Type | Required | Verification | Expected Ref | Actual／Result Ref | Supporting Evidence | Integrity |
|---|---|:---:|---|---|---|---|---|
| `<resultKey>` | `<checkType>` | `<true / false>` | `<NOT_EVALUATED / PASS / FAIL>` | `<relativeReference>` | `<relativeReference>` | `<artifact refs / NONE>` | `<VALID / INVALID / UNKNOWN>` |

### 10.1 Trace規則

```text
resultKey
→ Expected Snapshot／Expected JSON
→ Java Check
→ verification-result.json
→ Supporting Evidence
```

Evidence IndexがExpected値、Actual値またはCheck Logicを再掲しない。Check結果の解釈は`検証結果・Expected設計書.md`に従う。

## 11. Diff Evidence

| API Call | Comparison | Change | Effective | Ignored | Diff Ref | Compare Source | Integrity |
|---|---|---|---:|---:|---|---|---|
| `<apiCallCode>` | `<COMPLETED / NOT_COMPARED / ERROR>` | `<changeStatus>` | `<count>` | `<count>` | `<relativeReference / NONE>` | `<runId / NONE>` | `<status>` |

Field明細は`DiffReport.md`および`response-field-diff.json`を参照し、本Indexへ複製しない。

## 12. Unavailable Evidence

| Artifact Type | Scope Key | Expected Path | Reason Code | Safe Detail | Required | 影響 | 対応 |
|---|---|---|---|---|:---:|---|---|
| `<artifactType>` | `<scopeKey>` | `<relativePath>` | `<reasonCode>` | `<safeDetail>` | `<true / false>` | `<report impact>` | `<requiredAction>` |

### 12.1 Reason Code

| Reason Code | 意味 |
|---|---|
| `NOT_GENERATED` | 実行経路上で生成されなかった。 |
| `CALL_NOT_REACHED` | 分岐または前段停止によりAPI Callへ到達しなかった。 |
| `RESPONSE_UNAVAILABLE` | Responseを受信できなかった。 |
| `NOT_COMPARED` | 初回、Source不存在等により比較しなかった。 |
| `MANIFEST_ENTRY_MISSING` | 必須ArtifactのManifest Entryがない。 |
| `FILE_MISSING` | Manifest EntryはあるがFileがない。 |
| `HASH_MISMATCH` | Content Hashが一致しない。 |
| `SIZE_MISMATCH` | File Sizeが一致しない。 |
| `SCHEMA_INVALID` | Schema Validationに失敗した。 |
| `IDENTITY_MISMATCH` | Run／Scenario／API Call Identityが一致しない。 |
| `MASK_VALIDATION_FAILED` | MaskまたはSecret検査に失敗した。 |
| `ACCESS_RESTRICTED` | 権限上、利用者へ公開できない。 |
| `RETENTION_EXPIRED` | 保持期限により正規手順で削除済み。 |
| `REPORT_GENERATION_ERROR` | Report生成中に安全な参照を作成できなかった。 |

原因不明を`NOT_GENERATED`で隠さず、標準Error CodeとSafe Detailを残す。

## 13. Integrity Verification

| Check | Result | Evidence／Detail |
|---|---|---|
| Manifest Parse | `<PASS / ERROR>` | `<detail>` |
| Run Identity Match | `<PASS / ERROR>` | `<detail>` |
| Scenario Identity Match | `<PASS / ERROR>` | `<detail>` |
| API Call Identity Match | `<PASS / ERROR / N/A>` | `<detail>` |
| Relative Path Safety | `<PASS / ERROR>` | `<detail>` |
| File Existence | `<PASS / ERROR>` | `<count summary>` |
| Content Hash | `<PASS / ERROR / UNKNOWN>` | `<count summary>` |
| File Size | `<PASS / ERROR / UNKNOWN>` | `<count summary>` |
| Media Type | `<PASS / ERROR / UNKNOWN>` | `<count summary>` |
| Schema Validation | `<PASS / ERROR / UNKNOWN>` | `<count summary>` |
| Duplicate Path | `<PASS / ERROR>` | `<detail>` |
| Orphan Detection | `<PASS / ERROR / UNKNOWN>` | `<detail>` |

Hash AlgorithmはArtifact Manifestに記録された承認済み値を表示し、Template内で独自Algorithmへ置換しない。

## 14. Security／Mask

| 確認 | Result | Detail |
|---|---|---|
| Authorization Header非保存 | `<PASS / ERROR>` | `<detail / NONE>` |
| Token／Cookie非保存 | `<PASS / ERROR>` | `<detail / NONE>` |
| Credential非保存 | `<PASS / ERROR>` | `<detail / NONE>` |
| 個人情報Mask | `<PASS / ERROR / N/A>` | `<detail / NONE>` |
| Error Message Safe表示 | `<PASS / ERROR>` | `<detail / NONE>` |
| Internal Host非表示 | `<PASS / ERROR>` | `<detail / NONE>` |
| Access Classification | `<PASS / ERROR>` | `<classification>` |
| Retention Class | `<PASS / ERROR / UNKNOWN>` | `<retentionClass>` |

### 14.1 表示禁止

- Authorization Header
- Access Token、Refresh Token、Cookie、API Key
- Password、Secret、Credential実値
- Mask前個人情報
- Internal Host、IP、Mount Path
- Signed URL
- 無制限PayloadまたはStacktrace

Mask検査に失敗したArtifactへLinkを公開せず、Report Statusを`FAILED`または`INCOMPLETE`とする。SourceのVerification Resultは変更しない。

## 15. Access／Retention

| Artifact Group | Classification | Access Role | Retention Class | Expiry／Review | Owner |
|---|---|---|---|---|---|
| `<artifactGroup>` | `<classification>` | `<role>` | `<retentionClass>` | `<date / policyRef>` | `<owner>` |

AccessまたはRetentionの正式規則が未確定の場合、推測値を記載せず`BLOCKED`または`UNKNOWN`を表示する。

## 16. Execution Problem／Precondition Evidence

| Type | Scope Key | Reason Code | Phase | Safe Message | Available Evidence | Missing Evidence | Required Action |
|---|---|---|---|---|---|---|---|
| `<REJECTED / INCOMPLETE / UNKNOWN_OUTCOME / NOT_EVALUATED>` | `<runId / resultKey / apiCallCode>` | `<code>` | `<phase>` | `<safeMessage>` | `<refs / NONE>` | `<artifact types / NONE>` | `<action>` |

Execution Problemまたは前提不成立であっても、正常に取得できたRun Meta、Input、Request、ErrorおよびLog等を索引する。取得できなかったArtifactを推測生成しない。

## 17. Manifest Reconciliation

| Reconciliation Type | Relative Path | Manifest | File | Required | Result | Action |
|---|---|:---:|:---:|:---:|---|---|
| `<MATCH / MANIFEST_ONLY / FILE_ONLY / DUPLICATE>` | `<relativePath>` | `<true / false>` | `<true / false>` | `<true / false>` | `<VALID / INVALID>` | `<action / NONE>` |

`FILE_ONLY`を自動的にManifestへ追加せず、`MANIFEST_ONLY`を自動的に削除しない。

## 18. Report Reference

| Report | Reference | Hash | Status |
|---|---|---|---|
| Scenario Summary JSON | `<relativeReference>` | `<hash>` | `<VALID / INVALID / MISSING>` |
| Scenario Summary Markdown | `<relativeReference>` | `<hash>` | `<status>` |
| Diff Report JSON | `<relativeReference>` | `<hash>` | `<status>` |
| Diff Report Markdown | `<relativeReference>` | `<hash>` | `<status>` |
| Evidence Index JSON | `evidence-index.json` | `<hash>` | `<status>` |
| Evidence Index Markdown | `EvidenceIndex.md` | `<hash>` | `<status>` |

自己参照Hashの生成順序はReport公開設計に従う。未確定の自己参照方式を本Templateで固定しない。

## 19. Source Reference

| Source | Reference | Hash／Version | Status |
|---|---|---|---|
| Run Meta | `<relativeReference>` | `<hash>` | `<VALID / INVALID / MISSING>` |
| Scenario Execution | `<relativeReference>` | `<hash>` | `<status>` |
| Verification Result | `<relativeReference>` | `<hash>` | `<status>` |
| API Call Meta | `<relativeReference pattern>` | `<hash summary>` | `<status>` |
| Response Field Diff | `<relativeReference pattern>` | `<hash summary>` | `<status>` |
| Artifact Manifest | `<relativeReference>` | `<hash>` | `<status>` |
| Execution State | `<externalReference>` | `<version/hash>` | `<status>` |
| Baseline Meta | `<externalReference / NONE>` | `<version/hash / NONE>` | `<status>` |

## 20. JSON出力例

```json
{
  "schemaVersion": "1.0",
  "runId": "RUN-20260727-150000-550e8400",
  "scenarioId": "SC-E6-001",
  "inputSetId": "INPUT-DEFAULT",
  "reportStatus": "COMPLETE",
  "summary": {
    "manifestArtifactCount": 12,
    "requiredArtifactCount": 10,
    "availableCount": 12,
    "unavailableCount": 0,
    "hashMismatchCount": 0,
    "maskErrorCount": 0
  },
  "artifacts": [
    {
      "artifactType": "RESPONSE",
      "scopeKey": "CALL-001",
      "relativePath": "../api-calls/CALL-001/response.json",
      "mediaType": "application/json",
      "sizeBytes": 2048,
      "contentHash": "sha256:<masked-example>",
      "integrity": "VALID",
      "masked": true,
      "available": true,
      "unavailableReason": null
    }
  ]
}
```

例示Hashを正式値として再利用しない。

## 21. Path／Link規則

1. Artifactの永続ReferenceはRun Root基準の`relativePath`とする。
2. Report内LinkはReport RootまたはRun Rootからの相対Pathとする。
3. `..`で許可されたRun Root外へ遷移しない。
4. Symbolic Link等によるRoot外参照を許可しない。
5. OS絶対Path、Mount Path、Host、IP、Signed URLを永続化しない。
6. Link先不存在時はLinkを生成せず`UNAVAILABLE`とReason Codeを表示する。
7. `apiCallCode`をPathへ使用する前に命名規則を検証する。
8. Pathの大文字小文字差を別Artifactとして黙認しない。

## 22. Truncation／Large Artifact

| Artifact | Original Size | Indexed | Preview | Full Evidence | Result |
|---|---:|:---:|:---:|---|---|
| `<relativePath>` | `<sizeBytes>` | `<true / false>` | `<NONE / SAFE_SUMMARY>` | `<relativeReference>` | `<COMPLETE / INCOMPLETE / ERROR>` |

Evidence IndexはArtifact本文を展開しない。巨大ArtifactでもIndex Entry、Hash、SizeおよびAccess情報を保持する。

## 23. 生成時Validation

| Validation ID | 確認内容 | 失敗時 |
|---|---|---|
| `ER-V001` | Run、Environment、UseCase、Scenario、Input Set Identityが全Sourceで一致する。 | 生成`ERROR` |
| `ER-V002` | Manifest内`relativePath`が一意である。 | 生成`ERROR` |
| `ER-V003` | 必須ArtifactがManifestに登録されている。 | `INCOMPLETE` |
| `ER-V004` | Manifest Entryと実Fileの存在が一致する。 | `INCOMPLETE` |
| `ER-V005` | HashとSizeが一致する。 | `INCOMPLETE`または公開禁止 |
| `ER-V006` | Media TypeとArtifact Typeが適合する。 | `INCOMPLETE` |
| `ER-V007` | Schema対象ArtifactがValidation済みである。 | `INCOMPLETE` |
| `ER-V008` | Request／Response／Error／LogのMask確認が成立する。 | 公開禁止 |
| `ER-V009` | Secret、Credential、Token、Cookieおよび未Mask個人情報がない。 | 公開禁止 |
| `ER-V010` | Linkが許可Run Root外へ出ない。 | 公開禁止 |
| `ER-V011` | `resultKey`からExpected、Result、Evidenceへ逆Traceできる。 | `INCOMPLETE` |
| `ER-V012` | `apiCallCode`からMeta、Request／Response／Error／Diffへ追跡できる。 | `INCOMPLETE` |
| `ER-V013` | Artifact欠落に標準Reason Codeがある。 | 生成`ERROR` |
| `ER-V014` | Markdownと`evidence-index.json`のIdentity、件数、Statusが一致する。 | 生成`ERROR` |
| `ER-V015` | Artifact本文をMarkdownへ複製していない。 | 公開禁止 |
| `ER-V016` | Access ClassificationとRetention Classが表示される。 | `INCOMPLETE` |
| `ER-V017` | Evidence Index生成がSource Artifactを変更していない。 | 生成`ERROR` |
| `ER-V018` | 表示順が決定的である。 | 生成`ERROR` |

## 24. Template置換規則

1. `<...>` Placeholderをすべて解決する。
2. 値不存在時は空欄にせず`NONE`、`N/A`、`UNAVAILABLE`または標準Reason Codeを使用する。
3. 0件Sectionは削除せず`NONE`と表示してよい。
4. Evidence本文をMarkdownへ埋め込まない。
5. ReferenceはRun RootまたはReport Root基準の相対Pathとする。
6. MarkdownとJSONのIdentity、Statusおよび件数を一致させる。
7. Mask、Path、Hash、Linkおよび件数Validation後にReport一式を原子的に公開する。
8. Source ArtifactをRead Onlyとして扱う。

## 25. 禁止事項

- Artifact本文をEvidence Indexへ複製する。
- Request／Responseを再実行または再生成する。
- Expected Check、Business CheckまたはResponse Compareを再実行する。
- Evidence欠落をVerification `FAIL`または`PASS`へ変換する。
- Error／Blocked時の取得済みEvidenceを削除する。
- Manifest Entry、Hash、SizeまたはMask状態を推測補完する。
- `FILE_ONLY` Artifactを自動的に正本化する。
- Mask前Value、Secret、Token、Credential、CookieまたはInternal Hostを表示する。
- OS絶対Path、Mount PathまたはSigned URLを永続Referenceにする。
- `apiId`だけで同一APIの複数Callを統合する。
- Report生成によりBaseline、Previous Run、Execution StateまたはSource Artifactを更新する。
- 未承認のEvidence Master、Artifact Registry、SchemaまたはPolicy Fileを追加する。

## 26. Template改訂履歴

| Version | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | Current Architecture、Artifact Manifest、再現Trace、MaskおよびEvidence完全性に基づく初版作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | Front Matter `title`とH1を文書作成規約に従い一致させた。Evidence Index内容および判定規則の変更なし。 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | Framework横断再走査によりAPI Call Metaの正本名を`api-meta.json`へ統一 | DRAFT |
| `1.0.0-draft.4` | 2026-07-28 | Snapshot／Evidence設計に合わせ、Input／Expected別Snapshotと未定義Error ArtifactをDefinition SnapshotおよびAPI Call Metaへ統合 | DRAFT |
