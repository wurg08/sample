---
title: APIレスポンスDiff設計書
document_id: E6-API-VAL-RESPONSE-DIFF-DESIGN
version: 1.0.0-draft.7
status: DRAFT
document_type: API Response Diff Design
system_name: E6 API Verification Platform
updated: 2026-07-29
---

# APIレスポンスDiff設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | APIレスポンスDiff設計書 |
| 文書ID | `E6-API-VAL-RESPONSE-DIFF-DESIGN` |
| 対象 | Previous／Baseline ResponseとCurrent ResponseのJSON Field Diff |
| 配置 | `system/06_verification_assets/` |
| 文書種別 | Diff共通設計書 |
| 版数 | `1.0.0-draft.7` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-29 |
| 作成責任 | Verification Runtime Team |
| レビュー責任 | System Architect / API Design Lead / Runtime Lead / Test Lead |

## 2. 目的

本書は、同一Execution Identityおよび同一`apiCallCode`におけるPrevious／Baseline ResponseとCurrent Responseを比較し、JSON項目の追加、削除、型変化および値変化を検出する方式を定義する。

本書の中心原則は次のとおりである。

```text
実際に変化したか
≠
その変化を有効差異として扱うか
≠
業務検証がPASSかFAILか
```

Ignored Diffを「一致した」と偽装せず、変化を記録したうえで`effectiveChanged=false`とする。

## 3. 適用範囲

### 3.1 対象

- JSON ResponseのObject、ArrayおよびScalar
- 項目追加、削除、型変化および値変化
- `IGNORE_FIELD`および`IGNORE_VALUE`
- API標準比較定義と`apiCallCode`固有比較定義
- 初回実行、Baselineなし、ResponseなしおよびParse Error
- `response-field-diff.json`
- Verification ResultおよびReportとの連携

### 3.2 対象外

| 対象外 | 正式な管理先 |
|---|---|
| 必須、Null、型、長さ、桁数、Pattern、Enum、固定値 | API詳細設計書＋Java Business／Contract Check |
| API間値引継ぎ、状態遷移 | Scenario詳細設計書＋Java Check |
| Baseline選択・復旧・更新 | `ExecutionState・Baseline管理設計書.md` |
| Expected | Scenario Expected |
| Result集約 | `検証結果・Expected設計書.md` |
| Report表示 | `Report設計書.md` |
| 全局Compare Policy | 設けない。 |

## 4. 用語

| 用語 | 定義 |
|---|---|
| Previous Response | Current Runが比較対象とする前回完全RunのResponse |
| Baseline Response | 固定Baseline領域から読込んだPrevious Response |
| Current Response | Current Runで実際に取得し保存したResponse |
| Detected Change | JSON Tree上で検出した事実上の変化 |
| Effective Diff | Ignore適用後も有効と判定された変化 |
| Ignored Diff | 変化は存在するが、Java比較定義により非有効化された変化 |
| Compare Definition | API別または呼出別にJavaで定義する比較対象外Path |
| Concrete Path | `$.members[0].updatedAt`等の実際の要素位置を含むPath |
| Pattern Path | `$.members[*].updatedAt`等の一致規則を含むPath |

## 5. 基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `DIF-P001` | 同一Identity比較 | 異なるEnvironment、UseCase、ScenarioまたはInput Setを比較しない。 |
| `DIF-P002` | 呼出実体比較 | API比較単位は`scenarioId + apiCallCode`とする。 |
| `DIF-P003` | 推測禁止 | Previousを日付、更新時刻または最新Directoryから推測しない。 |
| `DIF-P004` | Java定義 | Ignore PathはAPI別／呼出別Java比較定義が保持する。 |
| `DIF-P005` | 変化事実保持 | Ignored Diffでも変化種別、Pathおよび安全な値表示を保存する。 |
| `DIF-P006` | Null／Missing分離 | JSON Nullと項目不存在を同一視しない。 |
| `DIF-P007` | 型変化検出 | String、Number、Boolean、Object、Array、Nullの差を検出する。 |
| `DIF-P008` | 業務判定分離 | Diff単体でBusiness CheckをPASS／FAILにしない。 |
| `DIF-P009` | 決定性 | 同じ入力、BaselineおよびCompare Definitionから同じDiffを生成する。 |
| `DIF-P010` | Secret保護 | Secret、認証情報およびMask対象値をDiffへ平文保存しない。 |

## 6. 比較Identity

### 6.1 Execution Identity

```text
environmentId
+
useCaseId
+
scenarioId
+
inputSetId
```

### 6.2 API Call Identity

```text
Execution Identity
+
apiCallCode
```

`apiId`はAPI定義Identityであり、同一Scenarioで同じAPIを複数回呼ぶ場合があるため、Diffの主Keyには使用しない。

例：

```text
CALL-001 → API-001 → 更新前照会
CALL-003 → API-001 → 更新後照会
```

`CALL-001`と`CALL-003`は同じ`API-001`でも相互に比較しない。

## 7. 入出力

### 7.1 入力

| 入力 | 取得元 |
|---|---|
| Previous Response JSON | Baseline Context |
| Current Response JSON | ScenarioContextの`ApiExchange.responseJson` |
| Execution Identity | ScenarioContext |
| `apiCallCode`、`apiId` | Scenario詳細設計＋ApiExchange |
| Compare Definition | Java Compare Definition Resolver |
| Sensitive Path定義 | Security／API Java定義 |

### 7.2 出力

```text
runs/{runId}/api-calls/{apiCallCode}/response-field-diff.json
```

Diffは一つのAPI呼出実体につき一つ作成する。

## 8. Compare Definition

### 8.1 保持場所

Ignore定義は次へ保存しない。

- Master
- `input.json`
- `expected.json`
- Environment設定
- 外部Compare Policy YAML

API専用Java定義またはScenario内呼出専用Java定義として保持する。

### 8.2 Javaモデル

```java
public interface ResponseCompareDefinition {

    Set<String> ignoreFieldPaths();

    Set<String> ignoreValuePaths();
}
```

API標準例：

```java
public final class MemberSearchResponseCompareDefinition
        implements ResponseCompareDefinition {

    @Override
    public Set<String> ignoreFieldPaths() {
        return Set.of(
                "$.requestId",
                "$.updatedAt",
                "$.traceId");
    }

    @Override
    public Set<String> ignoreValuePaths() {
        return Set.of(
                "$.processingTime",
                "$.sequenceNumber");
    }
}
```

### 8.3 解決優先順位

```text
apiCallCode固有定義が存在
    → その固有定義を使用

存在しない
    → apiId標準定義を使用

どちらも存在しない
    → Empty Definitionで全項目を通常比較
```

固有定義と標準定義を暗黙Mergeしない。固有定義側が標準定義を継承または合成する場合はJava Codeへ明示する。

### 8.4 定義不整合

同じPattern Pathを`IGNORE_FIELD`と`IGNORE_VALUE`の両方へ登録してはならない。検出時は起動前Validation Errorとする。

## 9. Ignore Mode

### 9.1 `IGNORE_FIELD`

対象FieldまたはSubtree全体を比較結果上のIgnored Diffとする。

| 変化 | detectedChangeType | comparisonStatus | effectiveChanged |
|---|---|---|:---:|
| 項目追加 | `ITEM_ADDED` | `IGNORED` | false |
| 項目削除 | `ITEM_REMOVED` | `IGNORED` | false |
| 型変化 | `TYPE_CHANGED` | `IGNORED` | false |
| 値変化 | `VALUE_CHANGED` | `IGNORED` | false |

ObjectまたはArray Rootが`IGNORE_FIELD`に一致した場合、その配下を個別のEffective Diffとして再計上しない。

### 9.2 `IGNORE_VALUE`

Fieldの存在と型を検証対象として残し、同一型の値変化だけをIgnored Diffとする。

| 変化 | detectedChangeType | comparisonStatus | effectiveChanged |
|---|---|---|:---:|
| 項目追加 | `ITEM_ADDED` | `COMPARED` | true |
| 項目削除 | `ITEM_REMOVED` | `COMPARED` | true |
| 型変化 | `TYPE_CHANGED` | `COMPARED` | true |
| 値変化 | `VALUE_CHANGED` | `IGNORED` | false |

### 9.3 通常Field

| 変化 | comparisonStatus | effectiveChanged |
|---|---|:---:|
| 変化なし | `COMPARED` | false |
| 追加／削除／型変化／値変化 | `COMPARED` | true |

## 10. Change Type

| Change Type | 条件 |
|---|---|
| `UNCHANGED` | 両方に存在し、型と値が等しい。 |
| `ITEM_ADDED` | Previousで不存在、Currentで存在。 |
| `ITEM_REMOVED` | Previousで存在、Currentで不存在。 |
| `TYPE_CHANGED` | 両方に存在するがJSON型が異なる。 |
| `VALUE_CHANGED` | 両方に存在し、同一型だが値が異なる。 |

JSON Nullは`PRESENT_NULL`、不存在は`MISSING`として区別する。

## 11. JSON型および値比較

### 11.1 JSON型

標準型は次の七つとする。

```text
OBJECT
ARRAY
STRING
NUMBER
BOOLEAN
NULL
MISSING
```

### 11.2 Scalar比較

| 型 | 標準比較 |
|---|---|
| String | Unicode文字列の完全一致 |
| Number | `BigDecimal.compareTo`相当の数値一致 |
| Boolean | `true`／`false`完全一致 |
| Null | 両方Nullなら一致 |

数値`1`と`1.0`は標準では同一数値として扱う。表記差自体を検出するAPIは専用Java比較定義または専用Checkを実装する。

### 11.3 Object比較

1. Key集合を比較する。
2. 追加Key、削除Keyを検出する。
3. 共通Keyを再帰比較する。
4. Object Key順序は差異にしない。

### 11.4 Array比較

標準はIndex順比較とする。

```text
Previous[0] ↔ Current[0]
Previous[1] ↔ Current[1]
```

配列順が業務上無関係なAPI、またはElement Keyによる対応付けが必要なAPIは、API専用Java Normalizer／Comparatorで順序またはKeyを明示する。汎用Comparatorが配列を自動Sortしてはならない。

## 12. JSON Path

### 12.1 Concrete Path

Diff明細には実際のPathを出力する。

```text
$.members[0].updatedAt
```

### 12.2 Pattern Path

Java Compare DefinitionはArray通配を使用できる。

```text
$.members[*].updatedAt
```

Concrete Path `$.members[0].updatedAt`は上記Patternへ一致する。

### 12.3 Matching規則

1. Rootは`$`で開始する。
2. Object Fieldは`.`区切りとする。
3. Array Indexは`[n]`とする。
4. Array通配は`[*]`だけを許可する。
5. 部分文字列一致を禁止する。
6. `$.id`は`$.customerId`へ一致しない。
7. 不正Patternは起動前Errorとする。

## 13. 比較処理Flow

```mermaid
flowchart TD
    A["IdentityとBaseline確認"] --> B{"比較可能か"}
    B -- No --> C["NOT_COMPAREDを出力"]
    B -- Yes --> D["Compare Definition解決"]
    D --> E["JSON Treeを再帰走査"]
    E --> F["Change Type検出"]
    F --> G["Ignore Mode適用"]
    G --> H["Summary集計"]
    H --> I["Diffを原子的に保存"]
```

### 13.1 詳細手順

1. Execution Identityを照合する。
2. Baseline Run IDを確認する。
3. 同一`apiCallCode`のPrevious Responseを取得する。
4. Current Responseの存在とParse状態を確認する。
5. Compare Definitionを解決・検証する。
6. Previous／CurrentをJSON Treeへ変換する。
7. Path単位でChange Typeを検出する。
8. Pattern Pathを照合しIgnore Modeを適用する。
9. Effective／Ignored／Unchanged件数を集約する。
10. `response-field-diff.json`を一時Fileへ出力する。
11. SchemaおよびSummaryを検証する。
12. 原子的に確定する。

## 14. `response-field-diff.json`

### 14.1 全体例

```json
{
  "schemaVersion": "1.0",
  "runId": "RUN-20260727-150000-550e8400",
  "environmentId": "ENV-STAGING",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "inputSetId": "INPUT-DEFAULT",
  "apiCallCode": "CALL-001",
  "apiId": "API-001",
  "baselineRunId": "RUN-20260726-150000-11335577",
  "comparisonStatus": "COMPLETED",
  "changeStatus": "CHANGED",
  "diffDisplayCategory": "EFFECTIVE_CHANGE",
  "compareDefinitionId": "MemberSearchResponseCompareDefinition",
  "summary": {
    "checkedItemCount": 4,
    "unchangedCount": 1,
    "effectiveChangedCount": 1,
    "ignoredCount": 2,
    "errorCount": 0
  },
  "items": [
    {
      "path": "$.memberId",
      "previousState": "PRESENT",
      "currentState": "PRESENT",
      "previousType": "STRING",
      "currentType": "STRING",
      "previousValue": "M001",
      "currentValue": "M001",
      "detectedChangeType": "UNCHANGED",
      "comparisonStatus": "COMPARED",
      "ignoreMode": null,
      "effectiveChanged": false,
      "ignoreReason": null
    },
    {
      "path": "$.memberStatus",
      "previousState": "PRESENT",
      "currentState": "PRESENT",
      "previousType": "STRING",
      "currentType": "STRING",
      "previousValue": "ACTIVE",
      "currentValue": "SUSPENDED",
      "detectedChangeType": "VALUE_CHANGED",
      "comparisonStatus": "COMPARED",
      "ignoreMode": null,
      "effectiveChanged": true,
      "ignoreReason": null
    },
    {
      "path": "$.updatedAt",
      "previousState": "PRESENT",
      "currentState": "PRESENT",
      "previousType": "STRING",
      "currentType": "STRING",
      "previousValue": "2026-07-26T15:00:01+09:00",
      "currentValue": "2026-07-27T15:00:01+09:00",
      "detectedChangeType": "VALUE_CHANGED",
      "comparisonStatus": "IGNORED",
      "ignoreMode": "IGNORE_FIELD",
      "effectiveChanged": false,
      "ignoreReason": "実行ごとに変化する更新日時。"
    },
    {
      "path": "$.processingTime",
      "previousState": "PRESENT",
      "currentState": "PRESENT",
      "previousType": "NUMBER",
      "currentType": "NUMBER",
      "previousValue": 120,
      "currentValue": 135,
      "detectedChangeType": "VALUE_CHANGED",
      "comparisonStatus": "IGNORED",
      "ignoreMode": "IGNORE_VALUE",
      "effectiveChanged": false,
      "ignoreReason": "処理時間の値変化だけを比較対象外とする。"
    }
  ]
}
```

### 14.2 Summary整合式

```text
checkedItemCount
=
unchangedCount
+ effectiveChangedCount
+ ignoredCount
+ errorCount
```

同一Itemを複数Countへ重複加算しない。

### 14.3 Document Level Status

| comparisonStatus | 意味 |
|---|---|
| `COMPLETED` | 比較処理が完了した。 |
| `NOT_COMPARED` | 初回、Baselineなし、Responseなし等で未比較。 |
| `ERROR` | Parse、Identity、定義またはI/O Error。 |

| changeStatus | 条件 |
|---|---|
| `UNCHANGED` | 比較完了かつEffective 0。Ignoredの有無を問わない。 |
| `CHANGED` | 比較完了かつEffective 1以上 |
| `NOT_COMPARED` | Document Levelが未比較 |

Report表示用の`diffDisplayCategory`は原結果を変更せず、次のように導出する。

| diffDisplayCategory | 条件 |
|---|---|
| `NO_CHANGE` | `changeStatus=UNCHANGED`かつIgnored 0 |
| `IGNORED_ONLY` | `changeStatus=UNCHANGED`かつIgnored 1以上 |
| `EFFECTIVE_CHANGE` | `changeStatus=CHANGED` |
| `NOT_COMPARED` | `changeStatus=NOT_COMPARED` |
| `COMPARE_ERROR` | `comparisonStatus=ERROR`。Change軸は`NOT_COMPARED` |

### 14.4 Response Field Diff Schema境界

`response-field-diff.schema.json`はDiff観測結果だけを対象とし、Verification `PASS／FAIL`、API契約の必須判定またはBusiness判定を保持しない。

| 検証対象 | JSON Schema | Semantic Validator／Java |
|---|:---:|:---:|
| 必須項目、型、ID Pattern、未知Property | Yes | - |
| Document／Item Level StatusのEnum分離 | Yes | - |
| `NOT_COMPARED`時のReason、空Items、Change `NOT_COMPARED` | Yes | - |
| `COMPLETED`時のCompare Definitionと表示Category | Yes | - |
| Ignored ItemのIgnore Mode、Reason、`effectiveChanged=false` | Yes | - |
| `checkedItemCount`の算術一致 | - | Yes |
| Concrete Path単位一意性 | - | Yes |
| Previous／Current State、Type、Value、Change Typeの相互整合 | - | Yes |
| Ignore Definitionとの一致 | - | Yes |
| Mask後Valueの安全性と許可`valueStorage` Catalog | - | Yes |

`valueStorage`はMask／Redaction／Hash等の安全な保存表現を示す任意Codeであり、Diff意味またはIgnore Modeではない。SchemaはCode形式を検証し、許可値、Mask ProfileおよびArtifact安全性との一致はSemantic Validatorが検証する。

## 15. 追加・削除・型変化例

### 15.1 Ignore Fieldの追加

```json
{
  "path": "$.requestId",
  "previousState": "MISSING",
  "currentState": "PRESENT",
  "previousType": "MISSING",
  "currentType": "STRING",
  "previousValue": null,
  "currentValue": "REQ-999",
  "detectedChangeType": "ITEM_ADDED",
  "comparisonStatus": "IGNORED",
  "ignoreMode": "IGNORE_FIELD",
  "effectiveChanged": false,
  "ignoreReason": "追跡用IDのためField全体を比較対象外とする。"
}
```

### 15.2 通常Fieldの追加

```json
{
  "path": "$.newBusinessField",
  "previousState": "MISSING",
  "currentState": "PRESENT",
  "previousType": "MISSING",
  "currentType": "STRING",
  "previousValue": null,
  "currentValue": "A",
  "detectedChangeType": "ITEM_ADDED",
  "comparisonStatus": "COMPARED",
  "ignoreMode": null,
  "effectiveChanged": true,
  "ignoreReason": null
}
```

### 15.3 Ignore Valueの型変化

```json
{
  "path": "$.processingTime",
  "previousState": "PRESENT",
  "currentState": "PRESENT",
  "previousType": "NUMBER",
  "currentType": "STRING",
  "previousValue": 120,
  "currentValue": "120",
  "detectedChangeType": "TYPE_CHANGED",
  "comparisonStatus": "COMPARED",
  "ignoreMode": "IGNORE_VALUE",
  "effectiveChanged": true,
  "ignoreReason": "IGNORE_VALUEは型変化を無視しない。"
}
```

## 16. 初回および比較不能

### 16.1 初回実行

Baselineが存在しない初回は、空JSONと比較しない。

```json
{
  "schemaVersion": "1.0",
  "runId": "RUN-20260727-150000-550e8400",
  "environmentId": "ENV-STAGING",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "inputSetId": "INPUT-DEFAULT",
  "apiCallCode": "CALL-001",
  "apiId": "API-001",
  "baselineRunId": null,
  "comparisonStatus": "NOT_COMPARED",
  "changeStatus": "NOT_COMPARED",
  "notComparedReason": "INITIAL_EXECUTION",
  "summary": {
    "checkedItemCount": 0,
    "unchangedCount": 0,
    "effectiveChangedCount": 0,
    "ignoredCount": 0,
    "errorCount": 0
  },
  "items": []
}
```

初回を`UNCHANGED`、`NO_CHANGE`または`PASS`と表示してはならない。

### 16.2 Responseなし

| 状況 | Diff |
|---|---|
| 想定されたSkip | `NOT_COMPARED`、`EXPECTED_SKIP` |
| Transport Error | `NOT_COMPARED`、`CURRENT_RESPONSE_UNAVAILABLE` |
| Parse Error | `ERROR`、`CURRENT_RESPONSE_PARSE_ERROR` |
| Baseline Response欠落 | `ERROR`、`BASELINE_RESPONSE_MISSING` |
| Baseline Call自体が想定Skip | `NOT_COMPARED`、`BASELINE_CALL_NOT_EXECUTED` |

Responseなしを空Objectとして比較して全項目削除扱いにしてはならない。

## 17. Java処理モデル

### 17.1 Comparator

```java
public interface ResponseDiffComparator {

    ResponseFieldDiff compare(
            ExecutionIdentity identity,
            String apiCallCode,
            String apiId,
            JsonNode previous,
            JsonNode current,
            ResponseCompareDefinition definition);
}
```

### 17.2 Resolver

```java
public interface ResponseCompareDefinitionResolver {

    ResponseCompareDefinition resolve(
            String scenarioId,
            String apiCallCode,
            String apiId);
}
```

### 17.3 Result Model

```java
public record FieldDiffItem(
        String path,
        JsonState previousState,
        JsonState currentState,
        JsonType previousType,
        JsonType currentType,
        Object previousValue,
        Object currentValue,
        ChangeType detectedChangeType,
        ItemComparisonStatus comparisonStatus,
        IgnoreMode ignoreMode,
        boolean effectiveChanged,
        String ignoreReason) {
}
```

## 18. Business Checkとの境界

| 観点 | Response Diff | Java Business／Contract Check |
|---|---|---|
| 項目追加／削除 | 検出 | 必須仕様に応じ判定 |
| 型変化 | 検出 | API仕様に応じ判定 |
| 値変化 | 検出 | 固定値・Enum・業務値に応じ判定 |
| `IGNORE_FIELD` | 変化をIgnored化 | Check対象なら通常評価 |
| `IGNORE_VALUE` | 同一型の値変化だけIgnored化 | 必須・型・範囲を通常評価 |
| 状態遷移 | 変化として観測 | 業務意味を判定 |

例として`updatedAt`を`IGNORE_FIELD`にしても、API仕様が`updatedAt`必須である場合、Required Checkは削除をFAILにできる。DiffのIgnoreはAPI仕様を無効化しない。

## 19. Verification Result連携

`verification-result.json`にはDiff Summaryと参照だけを記録する。

```json
{
  "resultKey": "CALL-001_RESPONSE_COMPARE",
  "resultType": "API_RESPONSE_COMPARE",
  "apiCallCode": "CALL-001",
  "status": "PASS",
  "expectedDisplay": "UNCHANGED",
  "actualDisplay": "UNCHANGED (IGNORED_ONLY=2)",
  "message": "有効差異0件、Ignored Diff 2件。",
  "reasonCodes": [],
  "evidenceRefs": [],
  "fieldDiffRef": "api-calls/CALL-001/response-field-diff.json"
}
```

DiffにEffective Changeがあっても、専用Checkの設計がなければChange Statusだけを`CHANGED`とし、Business Verification Statusを自動FAILにしない。

## 20. Report連携

Reportは次を区別して表示する。

- Effective Change件数
- Ignored Diff件数
- 初回または未比較API呼出数
- Compare Error件数
- Diff File参照

Ignored DiffをDaily Summaryの主FAIL件数へ加算しない。ただし「変化なし」と表示せず、Ignored件数を明示する。

## 21. SecurityおよびMask

### 21.1 Value保存方針

| 対象 | 保存方法 |
|---|---|
| 一般項目 | Previous／Current Valueを保存可 |
| 個人情報 | Mask済値またはHash |
| Credential／Token | 値を保存せず`[REDACTED]` |
| Binary／巨大文字列 | Hash、LengthおよびEvidence Ref |

### 21.2 Mask項目例

```json
{
  "path": "$.customer.email",
  "previousValue": "w***@example.com",
  "currentValue": "n***@example.com",
  "valueStorage": "MASKED",
  "detectedChangeType": "VALUE_CHANGED",
  "comparisonStatus": "COMPARED",
  "effectiveChanged": true
}
```

Mask後の表示値が偶然同一でも、内部の安全な比較結果を失わない。

## 22. 性能およびResource

1. JSON TreeはAPI呼出単位で処理し、全Run Responseを一括保持しない。
2. 最大Response SizeはRuntime設定で制限する。
3. 巨大Arrayは必要に応じStreaming比較またはAPI専用Comparatorを実装する。
4. Diff Item上限超過時もSummaryを正しく保持し、`itemsTruncated=true`を記録する。
5. Truncate時は完全DiffのEvidence Refまたは再調査手順を提供する。
6. Parallel Run間でComparator Stateを共有しない。

## 23. Error Code

| Error Code | 内容 | 処理 |
|---|---|---|
| `DIFF_IDENTITY_MISMATCH` | PreviousとCurrentのIdentity不一致 | 比較中止、`ERROR` |
| `DIFF_API_CALL_MISMATCH` | `apiCallCode`不一致 | 比較中止、`ERROR` |
| `DIFF_BASELINE_RESPONSE_MISSING` | 必須Baseline Responseなし | `ERROR` |
| `DIFF_CURRENT_RESPONSE_UNAVAILABLE` | Current Responseなし | `NOT_COMPARED` |
| `DIFF_RESPONSE_PARSE_ERROR` | JSON Parse失敗 | `ERROR` |
| `DIFF_DEFINITION_INVALID` | Ignore定義不正 | 起動前にExecution `REJECTED` |
| `DIFF_IGNORE_MODE_CONFLICT` | 同一Pathが二Modeに重複 | 起動前にExecution `REJECTED` |
| `DIFF_PATH_PATTERN_INVALID` | Pattern不正 | 起動前にExecution `REJECTED` |
| `DIFF_WRITE_ERROR` | Diff保存失敗 | Execution `INCOMPLETE` |
| `DIFF_SUMMARY_MISMATCH` | SummaryとItems不一致 | Execution `INCOMPLETE` |

## 24. Validation

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `DIF-V001` | Previous／CurrentのExecution Identityが一致する。 | ERROR |
| `DIF-V002` | 同一`apiCallCode`を比較している。 | ERROR |
| `DIF-V003` | `apiCallCode`と`apiId`がScenario詳細設計と一致する。 | ERROR |
| `DIF-V004` | Compare DefinitionがJavaで一意に解決できる。 | ERROR |
| `DIF-V005` | 同一PatternにIgnore Mode重複がない。 | ERROR |
| `DIF-V006` | Concrete PathとPattern Pathが仕様どおり一致する。 | ERROR |
| `DIF-V007` | `IGNORE_FIELD`の全変化がIgnoredになる。 | ERROR |
| `DIF-V008` | `IGNORE_VALUE`の追加・削除・型変化がEffectiveになる。 | ERROR |
| `DIF-V009` | Ignored Itemの`effectiveChanged=false`である。 | ERROR |
| `DIF-V010` | Summary件数とItemsが一致する。 | ERROR |
| `DIF-V011` | 初回を`NOT_COMPARED`として扱う。 | ERROR |
| `DIF-V012` | Responseなしを空Object比較しない。 | ERROR |
| `DIF-V013` | Secret実値がDiffへ出力されない。 | ERROR |
| `DIF-V014` | Diff Fileが一時Fileから原子的に確定される。 | ERROR |

## 25. Test観点

- [ ] 通常Fieldの追加、削除、型変化および値変化を検出できる。
- [ ] `IGNORE_FIELD`の全変化がIgnoredになる。
- [ ] `IGNORE_VALUE`の値変化だけがIgnoredになる。
- [ ] `IGNORE_VALUE`の削除と型変化がEffectiveになる。
- [ ] NullとMissingを区別できる。
- [ ] Object Key順序を差異にしない。
- [ ] Arrayを標準ではIndex順に比較する。
- [ ] `[*]` PatternがConcrete Indexへ一致する。
- [ ] 同じAPIの`CALL-001`と`CALL-003`を混同しない。
- [ ] 呼出固有定義がAPI標準定義より優先される。
- [ ] 初回実行が`NOT_COMPARED`になる。
- [ ] Transport Error時に全項目削除Diffを生成しない。
- [ ] Ignored DiffをReportで確認できる。
- [ ] Business CheckがIgnoreとは独立して実行される。
- [ ] Mask対象の平文が成果物へ残らない。

## 26. 未確定事項

| Issue ID | 未確定事項 | 暫定方針 | 確定先 |
|---|---|---|---|
| `DIF-ISSUE-001` | APIごとの配列順序・Key比較 | 標準Index比較。必要APIだけ専用Java Comparatorを実装する。 | 各API詳細設計／Java |
| `DIF-ISSUE-002` | Diff Item最大出力件数 | Runtime設定とし、Truncateを明示する。 | 共通Framework／File I/O設計 |
| `DIF-ISSUE-003` | Sensitive Path一覧 | API別Java定義と共通Security規則を使用する。 | Security／API詳細設計 |

## 27. 現行Release阻断

| 阻断ID | 内容 | 影響 |
|---|---|---|
| `DIF-BLOCK-001` | 正式APIが0件 | API別Response契約、配列比較およびSensitive Pathを確定できない。 |
| `DIF-BLOCK-002` | 正式Scenarioが0件 | `scenarioId + apiCallCode`単位のCompare Definitionを作成できない。 |
| `DIF-BLOCK-003` | Base Package、Java Source Root／Moduleおよび共通Scaffoldは承認・実装済みで現行Java基線もOpenJDK 21へ訂正済みだが、正式APIが0件でCompare Definition未実装、Build Validationも未完了 | 正式API設計後にCompare Definitionを実装し、OpenJDK 21でBuild／Runtime比較を検証する。 |
| `DIF-BLOCK-004` | `response-field-diff.schema.json`正文・機械Validationは完了したが、正式Role ReviewとRuntime Comparator／Writer Contract Testが未実施 | 正式Release契約として承認できない。 |

## 28. 改訂履歴

| Version | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | `apiCallCode`比較、`IGNORE_FIELD`／`IGNORE_VALUE`、Ignored Diff可視化およびBusiness Check分離に基づく初版作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | 横断ReviewによりChange軸を`UNCHANGED／CHANGED／NOT_COMPARED`へ統一し、表示CategoryとExecution Failureを分離 | DRAFT |
| `1.0.0-draft.3` | 2026-07-28 | `response-field-diff.schema.json`正文に合わせ、Document／Item状態、初回／比較Error、Ignore、`valueStorage`およびSchema／Semantic Validation境界を明確化 | DRAFT |
| `1.0.0-draft.4` | 2026-07-29 | 第10バッチのJava Source Root／Module候補を反映し、残存BlockerをTop Level承認、Base PackageおよびCompare Definition実装へ更新 | DRAFT |
| `1.0.0-draft.5` | 2026-07-29 | Java Base Packageを`jp.co.mufg.e6.verifier`へ確定し、残存BlockerをTop Level承認とCompare Definition実装へ限定 | DRAFT |
| `1.0.0-draft.6` | 2026-07-29 | `REP-CR-010`承認と共通Scaffold実装を反映し、残存Blockerを正式Compare DefinitionおよびJava 21 Buildへ更新 | DRAFT |
| `1.0.0-draft.7` | 2026-07-29 | `REP-CR-011`によるJava 17互換基線を反映し、残存Blockerを正式Compare DefinitionおよびJDK 17 Buildへ更新 | DRAFT |
| `1.0.0-draft.8` | 2026-07-31 | `REP-CR-014`により現行Compare DefinitionのBuild／Runtime比較基線をOpenJDK 21へ訂正 | DRAFT |
