---
title: TestData設計書
document_id: E6-API-VAL-TEST-DATA-DESIGN
version: 1.0.0-draft.6
status: DRAFT
document_type: Verification Test Data Design
system_name: E6 API Verification Platform
updated: 2026-07-29
---

# TestData設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | TestData設計書 |
| 文書ID | `E6-API-VAL-TEST-DATA-DESIGN` |
| 対象 | API単体Test、UseCase／Scenario Testおよび日次回帰で使用するTest Data |
| 配置 | `system/06_verification_assets/test_data/` |
| 文書種別 | Test Data共通設計書 |
| 版数 | `1.0.0-draft.6` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-29 |
| 作成責任 | Verification Design Team / Test Data Owner |
| レビュー責任 | System Architect / Test Lead / Security Lead / Environment Owner |
| 承認責任 | Test Owner / Environment Owner |

## 2. 目的

本書は、E6 API Verification Platformで使用するTest Dataについて、次を一貫して管理するための共通契約を定義する。

1. Test Dataの分類、Identityおよび参照方式
2. Scenario Input、Expected、Actual、Baselineとの責務分離
3. Environmentごとの利用可否と承認
4. 生成、準備、利用、更新、Cleanupおよび廃棄のLifecycle
5. 更新系API、並行Runおよび再実行に対する安全性
6. 個人情報、Secretおよび本番Dataの保護
7. API単体Test、UseCase Test、Execution仕様およびEvidenceへのTrace
8. 日次回帰結果を再現するために必要なVersionおよびHash

Test Dataは期待結果または判定ロジックの正本ではない。Test Dataの存在だけでTest成功を保証せず、Java Check、ExpectedおよびRuntime Resultを置き換えない。

## 3. 適用範囲

### 3.1 対象

- API単体Test用Request Data
- Scenario起動時の外部入力候補
- Mock／Stub Response Fixture
- 更新系APIの事前投入Data
- 参照系APIの検索対象Data
- 境界値、異常値および契約違反Data
- File Upload等で使用する外部Payload
- Cleanupおよび事後確認に必要なData Identity
- 日次回帰で承認済みの固定Data Profile
- Test DataのManifest、Version、Hashおよび生成根拠

### 3.2 対象外

| 対象外 | 正式な管理先 |
|---|---|
| Scenarioの外部入力契約 | `system/04_usecase_design/Scenario入力データ設計書.md` |
| Scenario Input実体 | `system/04_usecase_design/input/{scenarioId}-input.json` |
| `resultKey`ごとの期待値 | `system/04_usecase_design/expected/{scenarioId}-expected.json` |
| Expected／Check Result契約 | `system/06_verification_assets/検証結果・Expected設計書.md` |
| API契約 | `system/03_api_design/API-{NNN}設計書.md` |
| Scenario呼出順、Mapping、分岐 | Scenario詳細設計およびJava |
| Previous／Baseline選定 | `system/05_framework/ExecutionState・Baseline管理設計書.md` |
| Compare Definition | API別／`apiCallCode`別Java実装 |
| Runtime Actual／Evidence | Run Root配下のRuntime成果物 |
| Secret実値 | Secret StoreまたはEnvironment Credential |

## 4. 基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `TD-P001` | Purpose Bound | 各Data Setは用途、対象TestおよびEnvironmentを明示する。 |
| `TD-P002` | Reference, not Copy | Input、Expected、API契約をTest Dataへ重複定義しない。 |
| `TD-P003` | Stable Identity | File名ではなく`testDataId`と`dataSetVersion`で識別する。 |
| `TD-P004` | Reproducible | 同一Versionと準備条件から同じ論理状態を再現できるようにする。 |
| `TD-P005` | Environment Safe | 承認されていないEnvironmentへDataを投入しない。 |
| `TD-P006` | Minimum Data | Test目的に必要な最小Dataだけを保持する。 |
| `TD-P007` | No Secret | Token、Password、API Key等をData Assetへ保存しない。 |
| `TD-P008` | No Unapproved PII | 実個人情報を無承認で使用または保存しない。 |
| `TD-P009` | Isolated | 並行Run間で更新対象、Cleanupおよび生成Keyを衝突させない。 |
| `TD-P010` | Observable | 準備、使用、Cleanupおよび残存確認をEvidence化する。 |
| `TD-P011` | Fail Closed | DataのIdentity、承認または安全条件が不明な場合は実行しない。 |
| `TD-P012` | Immutable Version | 使用済みVersionを上書きせず、新Versionとして変更する。 |
| `TD-P013` | No Runtime Mutation | Report生成やDiff処理がTest Data正本を変更しない。 |
| `TD-P014` | Explicit Cleanup | 更新系DataはCleanup責務と事後確認を必須とする。 |

## 5. 用語と責務分離

| 用語 | 内容 | 正本 |
|---|---|---|
| Scenario Input | Scenario開始時に外部から与える論理入力 | `04_usecase_design/input/` |
| Test Data | Testを成立させるために準備・参照するData Set | 本書および承認済みTest Data Asset |
| Expected | `resultKey`ごとの期待値または期待状態 | `04_usecase_design/expected/` |
| Actual | 実行により観測されたRequest、Response、ContextおよびCheck Result | Run成果物 |
| Previous | 同一Execution Identityの直前Complete Run | Execution State |
| Baseline | 承認済み比較元 | Baseline管理 |
| Fixture | Mock／Stub等へ与える固定Responseまたは外部File | Test Data Asset |
| Seed Data | Test前に対象Systemへ投入するData | Test Data Asset＋準備処理 |
| Cleanup | Test後に生成・更新したDataを安全な状態へ戻す処理 | Java／運用処理＋Evidence |
| Data Profile | Dataの目的、性質、条件を表す定義 | Test Spec内Reference |

### 5.1 禁止される混同

- Scenario InputへExpected値を埋め込まない。
- Test DataへActual Responseを手作業で転記しない。
- Baseline ResponseをTest Dataとして再利用しない。
- Test Dataの値からJava Checkを自動的に推測しない。
- Fixture一致を実Environmentの契約確認済みとみなさない。
- Cleanup済みでないDataを「再利用可能」と表示しない。

## 6. Test Data体系

### 6.1 分類

| Data Type | 用途 | 例 |
|---|---|---|
| `REQUEST_INPUT` | API単体またはScenario入口Request | 顧客番号、検索条件 |
| `REFERENCE_DATA` | 対象Systemに事前存在する参照Data | 有効顧客、契約0件顧客 |
| `SEED_DATA` | Test前に作成するData | 一時受付、検証用申請 |
| `MUTATION_TARGET` | 更新／削除対象 | 更新前Version付きRecord |
| `MOCK_RESPONSE` | Mock／Stub Response | 200、404、Timeout相当Fixture |
| `FILE_PAYLOAD` | UploadまたはFile連携用Asset | JSON、CSV、PDF |
| `BOUNDARY_DATA` | 最大、最小、Null、Empty等 | 最大桁数文字列 |
| `INVALID_DATA` | 契約違反確認 | 型不正、Enum外、必須欠落 |
| `CLEANUP_DATA` | Cleanup対象識別 | 作成Record ID、Correlation Key |

### 6.2 利用形態

| 利用形態 | 説明 |
|---|---|
| `STATIC` | Version管理された固定Assetを読込む。 |
| `GENERATED` | Seedと決定的RuleからRun開始時に生成する。 |
| `DISCOVERED` | 承認済みQueryで既存Dataを選定する。 |
| `PROVISIONED` | Setup API／Toolで専用Dataを作成する。 |
| `MOCKED` | 実Environmentへ接続せずFixtureを返す。 |

`DISCOVERED`は「最初に見つかったRecord」を無条件使用してはならない。選定条件、安定性、占有、再確認およびMask方針を定義する。

## 7. Identity

### 7.1 必須Identity

| 属性 | 必須 | 内容 |
|---|:---:|---|
| `testDataId` | Yes | Test DataのStable ID |
| `dataSetVersion` | Yes | Immutable Version |
| `dataType` | Yes | 6.1の分類 |
| `useCaseId` | 条件 | UseCase固有Dataの場合 |
| `scenarioId` | 条件 | Scenario固有Dataの場合 |
| `apiId` | 条件 | API単体Dataの場合 |
| `inputSetId` | 条件 | Scenario Input Setとの対応 |
| `environmentScope` | Yes | 利用可能Environment集合 |
| `contentHash` | Yes | 使用内容のHash |
| `approvalStatus` | Yes | 利用承認状態 |

### 7.2 ID Pattern

現時点では次を文書内Stable ID Patternとして使用する。

```text
TD-{systemCode}-{NNN}
```

例：

```text
TD-E6-001
TD-E6-002
```

このPatternはTestData MasterまたはRegistryの新設を意味しない。採番重複を避ける正式な管理方式はRepository治理に従い、未承認の中央Registryを作成しない。

### 7.3 Execution Identityとの関係

```text
environmentId
+ useCaseId
+ scenarioId
+ inputSetId
= Execution Identity
```

`testDataId`はExecution Identityそのものではない。同じData Setを複数Scenarioが利用する場合も、各Runは自身のExecution Identity、`runId`および使用Versionを記録する。

## 8. 論理Metadata契約

次はTest Data Assetに付随する論理Metadataの例である。物理Schema Fileは`common/schemas/`の設計完了後に確定する。

```json
{
  "schemaVersion": "1.0",
  "testDataId": "TD-E6-001",
  "dataSetVersion": "1.0.0",
  "name": "顧客照会正常系Data",
  "dataType": "REFERENCE_DATA",
  "usageMode": "STATIC",
  "businessId": "BUS-E6-001",
  "useCaseId": "UC-E6-001",
  "scenarioIds": [
    "SC-E6-001"
  ],
  "apiIds": [
    "API-001"
  ],
  "inputSetIds": [
    "INPUT-DEFAULT"
  ],
  "environmentScope": [
    "ENV-STAGING"
  ],
  "classification": "INTERNAL_TEST",
  "containsPersonalData": false,
  "containsSecret": false,
  "updateMode": "READ_ONLY",
  "cleanupRequired": false,
  "approvalStatus": "APPROVED",
  "contentHash": "<sha256>",
  "sourceRef": "<approved-source-reference>",
  "owner": "Verification Test Data Owner",
  "approvedBy": "<approver-id>",
  "approvedAt": "2026-07-27T15:00:00+09:00"
}
```

### 8.1 Metadata禁止事項

- Secret実値をMetadataへ記載しない。
- Internal Host、IPまたはCredential Profileの実値を記載しない。
- `approvedBy`を自由記述の表示名だけで管理しない。
- `contentHash`なしでVersionの同一性を主張しない。
- `approvalStatus=APPROVED`を生成処理が自動付与しない。

## 9. Reference方式

### 9.1 Test SpecからのReference

| Test Spec | 必須Reference |
|---|---|
| API単体Test | `testDataId`、Version、対象Case、準備条件 |
| UseCase Test | `testDataId`、`inputSetId`、Scenario、Cleanup条件 |
| Execution仕様 | 承認済みData Set選択、Environment、実行Window |
| Verification仕様 | Check Coverageに必要なData条件 |

### 9.2 Runtime記録

Run MetaまたはArtifact Manifestへ次を記録する。

- `testDataId`
- `dataSetVersion`
- `contentHash`
- `inputSetId`
- `preparationExecutionId`
- `cleanupExecutionId`
- `approvalStatusAtExecution`
- Mask済Data Summary
- Asset Reference

RuntimeはRepository内Assetを参照しても、使用時点のVersionとHashを記録しなければならない。

## 10. 配置方針

### 10.1 設計書

```text
system/06_verification_assets/test_data/
└── TestData設計書.md
```

### 10.2 Test Data Asset

UseCase単位の検証資産は、Repository Structureで承認済みの次の範囲に所属する。

```text
system/06_verification_assets/usecases/{useCaseId}/
```

本書は、その配下の詳細Subdirectory、File名PatternまたはSchema File名を先行確定しない。`usecases/`構造、File I/OおよびSchema設計の承認前に、新しい物理配置を正本として作成してはならない。

### 10.3 Runtime Data

生成Data、実行時展開FileおよびCleanup Evidenceを`system/`へ保存しない。Runtime物理Rootは未確定であり、設計上はRun Root相対Referenceだけを使用する。

## 11. Lifecycle

```mermaid
flowchart TD
    A["要件・Test Case"] --> B["Data設計"]
    B --> C["生成・取得"]
    C --> D["Security・Quality確認"]
    D --> E["Environment承認"]
    E --> F["Version固定"]
    F --> G["準備・占有"]
    G --> H["Test実行"]
    H --> I["事後確認"]
    I --> J["Cleanup"]
    J --> K["Evidence・利用履歴"]
```

### 11.1 状態

| 状態 | 意味 | 実行可否 |
|---|---|:---:|
| `DRAFT` | 設計中 | No |
| `READY_FOR_REVIEW` | 内容確認可能 | No |
| `APPROVED` | Environment利用承認済み | Yes |
| `SUSPENDED` | 一時利用停止 | No |
| `RETIRED` | 新規利用終了 | No |
| `REVOKED` | Security／品質理由で失効 | No |

既存Runの再現では使用時点の状態をEvidenceとして保持するが、`REVOKED` Dataを新規Runへ使用しない。

## 12. Data準備

### 12.1 Precondition

| 確認項目 | 内容 |
|---|---|
| Environment | `environmentId`がScope内でEnabled |
| Approval | 実行時点で`APPROVED` |
| Version | Test Spec指定Versionと一致 |
| Hash | Asset内容とMetadataが一致 |
| API／Scenario | 対象がEnabledかつReference解決済み |
| Isolation | 専用Key、NamespaceまたはLeaseが確保済み |
| Update Safety | 更新可否、Rollback、Cleanupが承認済み |
| Security | Secret／PII検査済み |

### 12.2 準備処理Result

| Result | 意味 | 後続 |
|---|---|---|
| `PREPARED` | 必要Data準備完了 | Test実行可 |
| `ALREADY_VALID` | 既存Dataが条件を満たす | Test実行可 |
| `BLOCKED` | 前提、承認またはData不足 | Test開始禁止 |
| `ERROR` | 準備処理異常 | 起動前はExecution `REJECTED`、起動後は`INCOMPLETE` |

このResultはVerification Resultではない。`SKIP`または`WARN`をVerification Resultへ追加しない。

## 13. 生成Data

### 13.1 決定性

生成方式では次を保存する。

- Generator IdentityおよびBuild Version
- Seed
- Locale／Time Zone
- Clock固定有無
- Character Set
- 生成件数
- 生成Rule Version
- 生成結果Hash

Random生成を使用する場合もSeedなしで再現性を主張しない。

### 13.2 一意Key

生成Keyは、業務制約の範囲内で`runId`または安全な派生Suffixを用い、並行Runで衝突しないようにする。PID、Thread IDまたは秒単位時刻だけを一意Keyとして使用しない。

## 14. 更新系Test Data

### 14.1 必須設計

| 項目 | 必須内容 |
|---|---|
| 更新対象 | Stable Business KeyとVersion |
| 初期状態 | 実行前の期待状態 |
| 更新内容 | Testで変更する範囲 |
| 冪等性 | 再送時の期待挙動 |
| 排他 | Lease、Versionまたは専有方式 |
| Timeout後確認 | 更新成立可否の照会方法 |
| Rollback | 戻せる場合の処理 |
| Cleanup | 削除／復元／失効方法 |
| 残存確認 | Cleanup完了の判定 |
| Owner | 異常時の対応責任 |

### 14.2 禁止条件

- 本番Environmentで無承認更新を行う。
- 他Testまたは業務利用中の共有Recordを占有せず更新する。
- Timeoutを即時失敗と決め、実際の更新成立有無を確認しない。
- Cleanup失敗を隠してRunを完全成功と表示する。
- 削除不能Dataを生成しながらRetentionとOwnerを定義しない。

## 15. Cleanup

### 15.1 Cleanup Result

| Result | 意味 |
|---|---|
| `COMPLETED` | 対象Dataの削除／復元と残存確認完了 |
| `NOT_REQUIRED` | Read Only等でCleanup不要 |
| `PARTIAL` | 一部だけ完了 |
| `FAILED` | Cleanup処理失敗 |
| `UNKNOWN` | 状態確認不能 |

### 15.2 判定への影響

- Cleanup `FAILED`または`UNKNOWN`は運用上の`ERROR`としてReportへ明示する。
- 業務CheckがPASSでも、Cleanup未完了を隠して全体正常と表示しない。
- Cleanup Resultから既存Verification Resultを上書きしない。
- Baseline更新はComplete Run条件とCleanup条件を満たした場合だけ許可する。

## 16. 並行実行

| 観点 | 要求 |
|---|---|
| Data Namespace | RunまたはWorker単位に分離 |
| Shared Data | Read OnlyまたはLease制御 |
| Update Target | 同時更新を禁止またはVersion制御 |
| Cleanup | 自Runが作成したDataだけを対象 |
| Context | Run間でMutable Stateを共有しない |
| Output | Run専用Rootへ出力 |
| Baseline | Test Data準備が直接更新しない |

## 17. Environment適用

| Environment Type | 原則 |
|---|---|
| Local | Synthetic／Mock中心。実Credentialを保存しない。 |
| Staging | 承認済みSyntheticまたは匿名化Dataを使用する。 |
| Production | 原則禁止。個別承認、安全Gate、Read Onlyおよび監査が成立する場合だけ例外検討する。 |

`Environment_Master.enabled=true`だけでは更新系Test Dataの利用承認にならない。

## 18. SecurityとData Classification

### 18.1 Classification

| 分類 | 内容 | Repository保存 |
|---|---|:---:|
| `PUBLIC_TEST` | 公開可能なSynthetic Data | 条件付き可 |
| `INTERNAL_TEST` | 社内検証用Synthetic Data | 可 |
| `CONFIDENTIAL_TEST` | 保護が必要な匿名化／限定Data | 承認とAccess制御必須 |
| `PRODUCTION_DERIVED` | 本番由来の加工Data | 原則不可。個別承認必須 |
| `SECRET` | Credential等 | 不可 |

### 18.2 必須Control

1. Data最小化
2. Synthetic Data優先
3. 匿名化または仮名化
4. Repository投入前Secret Scan
5. EvidenceおよびReportのMask
6. Access Control
7. Retentionおよび廃棄
8. 利用目的外再利用禁止

### 18.3 Mask

Mask表示と内部比較を混同しない。Mask後表示が同じでも、内部の安全な比較結果を失わない。Token、PasswordおよびAPI KeyはMaskではなく保存禁止とする。

## 19. File Payload

| 属性 | 内容 |
|---|---|
| Media Type | 期待Content Type |
| Character Set | Textの場合 |
| Original File Name | 安全化済み名称 |
| Size | Bytes |
| Content Hash | Hash |
| Structure Version | JSON／CSV等の版 |
| Malicious Content Check | 必要時のScan結果 |
| Expected Handling | API契約Reference |

巨大File、Binaryまたは著作権・機密上の制約があるAssetをMarkdownへBase64埋込みしない。

## 20. API単体Testとの連携

| Test観点 | Data要件 |
|---|---|
| Required | 欠落、Null、Emptyを区別 |
| Type | JSON Type違反を明示 |
| Length | `min-1`、`min`、`max`、`max+1` |
| Pattern | 有効／無効文字列 |
| Enum | 全許容値＋範囲外 |
| Fixed | 一致／不一致 |
| Status／Error | Provider契約に沿う条件 |
| DTO | Serialize／Deserialize Fixture |
| Compare | Field追加、削除、型変化、値変化Fixture |

Ignore対象FieldでもRequired、Type、FixedおよびBusiness Check用Dataを省略しない。

## 21. UseCase／Scenario Testとの連携

| 観点 | Data要件 |
|---|---|
| Normal Flow | 全APIが成立する一貫Data |
| Alternative | 分岐条件を成立させるData |
| Exception | Business ErrorとTechnical Errorを分離 |
| Mapping | 前段値と後段Requestの対応が確認可能 |
| Stop／Skip | 前提不成立を意図的に作れるData |
| Retry | 同一Data再送時の状態を管理 |
| Recovery | Crash前後のData状態を確認 |
| Concurrency | Run間衝突を検出できるData |
| Baseline | 同一Execution Identityで比較可能 |

## 22. Expectedとの整合

1. `inputSetId`はScenario Input、ExpectedおよびRun Metaで一致させる。
2. Test DataはExpected Valueを内包せず、`expectedRef`を参照する。
3. Expectedの`resultKey`はJava Checkと一致させる。
4. Data状態不足でCheck不能の場合、Verificationを`NOT_EVALUATED`とし、Execution StatusおよびReason Codeで起動拒否または処理異常を区別する。
5. Test Data変更時、Expected変更が必要かをImpact Analysisする。

## 23. Baseline／Diffとの整合

- Test Data Version差だけで生じたResponse差も、Diff上は事実として記録する。
- ReportはCurrentとBaselineのTest Data Version差を明示する。
- Execution Identityが異なる場合、比較してはならない。
- Test Data変更を理由にEffective Diffを自動Ignoreしない。
- IgnoreはJava Compare Definitionで明示する。
- BaselineをTest Dataの代替として使用しない。

## 24. Evidence

### 24.1 保存するEvidence

| Evidence | 内容 |
|---|---|
| Data Reference | ID、Version、Hash |
| Approval Snapshot | 実行時承認状態 |
| Preparation Result | 開始／終了、処理結果 |
| Selection Result | Discovered Dataの安全なIdentity |
| Mutation Record | 作成／更新／削除の安全なSummary |
| Cleanup Result | 結果、残存確認 |
| Generator Meta | Version、Seed、Rule |

### 24.2 保存禁止

- Secret実値
- 未Mask個人情報
- 全DB Dump
- 不要なRequest／Response複製
- OS絶対Path
- Signed URL
- Environment Credential

## 25. Error Code

| Error Code | 内容 | 処理 |
|---|---|---|
| `TEST_DATA_REFERENCE_MISSING` | Test Data Referenceなし | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `TEST_DATA_NOT_APPROVED` | 未承認Data | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `TEST_DATA_ENVIRONMENT_DENIED` | Environment Scope外 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `TEST_DATA_VERSION_MISMATCH` | 指定Version不一致 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `TEST_DATA_HASH_MISMATCH` | 内容改変 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `TEST_DATA_PREPARATION_FAILED` | 準備失敗 | 起動前はExecution `REJECTED`、起動後は`INCOMPLETE` |
| `TEST_DATA_NOT_FOUND` | 必要Dataなし | Execution `REJECTED`、またはCase定義上の`NOT_EVALUATED` |
| `TEST_DATA_CONFLICT` | 並行Run衝突 | Execution `REJECTED`または`INCOMPLETE` |
| `TEST_DATA_CLEANUP_FAILED` | Cleanup失敗 | Report `ERROR`、運用対応 |
| `TEST_DATA_RESIDUE_FOUND` | 残存Data検出 | Report `ERROR` |
| `TEST_DATA_SECRET_DETECTED` | Secret検出 | 使用禁止、Security対応 |
| `TEST_DATA_PII_UNAPPROVED` | 未承認個人情報 | 使用禁止、Security対応 |

## 26. Validation

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `TD-V001` | `testDataId`とVersionが存在する。 | ERROR |
| `TD-V002` | ID、Version、Hashの組合せが一意である。 | ERROR |
| `TD-V003` | Environment Scope内である。 | ERROR |
| `TD-V004` | 実行時点で承認済みである。 | ERROR |
| `TD-V005` | Test SpecのCaseと双方向Traceできる。 | ERROR |
| `TD-V006` | Input SetとScenario Identityが一致する。 | ERROR |
| `TD-V007` | AssetにSecretが含まれない。 | ERROR |
| `TD-V008` | 個人情報の承認とMaskが成立する。 | ERROR |
| `TD-V009` | 更新系DataにCleanupとOwnerがある。 | ERROR |
| `TD-V010` | 並行Runの衝突防止がある。 | ERROR |
| `TD-V011` | Generator VersionとSeedが追跡可能である。 | ERROR |
| `TD-V012` | Runtimeが使用VersionとHashを記録する。 | ERROR |
| `TD-V013` | Test DataにExpected／Actual／Baselineを混在させていない。 | ERROR |
| `TD-V014` | Retired／Revoked Dataを新規実行に使用しない。 | ERROR |
| `TD-V015` | Cleanup Resultと残存確認がEvidence化される。 | ERROR |

## 27. Review Checklist

- [ ] Test目的とData条件が対応している。
- [ ] Scenario InputとTest Dataの責務が分離されている。
- [ ] Expected、ActualおよびBaselineを保持していない。
- [ ] ID、Version、HashおよびOwnerが明確である。
- [ ] Environment Scopeと承認者が明確である。
- [ ] Synthetic Dataを優先している。
- [ ] Secretおよび未承認個人情報を含まない。
- [ ] 更新系の初期状態、排他、冪等性、Timeout後確認がある。
- [ ] Cleanupと残存確認が自動化または明示されている。
- [ ] 並行RunでDataが衝突しない。
- [ ] API単体／UseCase Test Caseへ追跡できる。
- [ ] Runtime使用VersionがEvidenceへ残る。
- [ ] Test Data変更のExpected／Baseline影響を確認した。
- [ ] 未承認Directory、SchemaまたはRegistryを新設していない。

## 28. Release Blocker

- 有効なTest Caseが未承認または未解決Test Dataを参照する。
- Environment Scope外のDataを実行対象に含める。
- Secretまたは未承認個人情報がAssetに含まれる。
- 更新系DataにCleanup、排他、Ownerまたは事後確認がない。
- Test Data VersionまたはHashがRunへ記録されない。
- Scenario Input、ExpectedまたはExecution Identityと不一致である。
- 必須Dataを「実行時に探す」とだけ記載し、選定条件がない。
- Cleanup失敗後も安全な再実行を保証できない。
- Test Data Assetの正式配置またはSchemaを未承認のまま固定する。

## 29. Current Architecture適用時の既知Blocker

| Blocker | 現状 | 必要処置 |
|---|---|---|
| 正式Business／UseCase／Scenario | 0件 | 業務分析とScenario設計後にData Requirementを定義 |
| 正式Input／Expected | 0件 | Scenario単位でIdentityと必要Dataを確定 |
| Test Data Asset | 未完成 | Test Case確定後にData設計・承認 |
| `usecases/{useCaseId}/`詳細構造 | 要再設計 | 検証資産構造をArchitecture Review |
| Test Data Schema | 未完成 | `common/schemas/`設計時に確定 |
| File I/O | 未確定 | Runtime読込、Hash、Atomicityを設計 |

## 30. Open Issues

| Issue ID | 論点 | 暫定方針 | 確定先 |
|---|---|---|---|
| `TD-ISSUE-001` | Test Data Assetの詳細Path | `usecases/{useCaseId}/`範囲だけを使用する。 | Repository／File I/O設計 |
| `TD-ISSUE-002` | Metadata Schema File名 | 論理契約だけを使用する。 | Schema設計 |
| `TD-ISSUE-003` | Retention期間 | 実値を推測しない。 | Operations／Security |
| `TD-ISSUE-004` | Production Data承認Flow | 実行禁止をDefaultとする。 | Environment／Security |
| `TD-ISSUE-005` | Test Data ID採番管理 | 文書内Stable IDを使用しRegistryは新設しない。 | Repository Governance |

## 31. 禁止事項

- TestData Master、Policy MasterまたはRegistryを無断で新設する。
- Test DataへExpected、Actual、PreviousまたはBaselineを保存する。
- Secret、Token、Password、API Keyまたは実Credentialを保存する。
- 本番DataをコピーしただけのAssetを使用する。
- File名、行番号またはDirectory順をIdentityにする。
- 使用済みVersionを内容だけ上書きする。
- Data変更を自動的にDiff Ignore理由にする。
- Cleanup失敗を`PASS`、`WARN`または`SKIP`で隠す。
- 無効Environmentまたは無効Scenario向けDataを実行可能と表示する。
- 未承認の物理Root、Java PackageまたはSchemaを正本化する。

## 32. 変更管理

| 変更 | 必須対応 |
|---|---|
| Data値変更 | 新Version、Hash更新、Impact Analysis |
| 利用Environment追加 | Environment Owner／Security承認 |
| Classification変更 | Security Review |
| Generator変更 | Generator Version、Seed互換性Test |
| Cleanup変更 | Recovery／残存Test |
| Scenario追加 | Trace、Input Set、Expected整合確認 |
| API契約変更 | Boundary／Invalid Data再生成 |
| Data廃止 | 新規利用停止、既存Run Trace保持 |

## 33. 改訂履歴

| Version | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | Current Architecture、5類Master、Java First、Data安全性および三軸判定に基づく初版作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | SC-E6-001 Input／Expected作成後のTest Data未解決状態を同期 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | SC-E6-002／003 Input／Expected作成後の不存在Data、Timeout、RecoveryおよびCleanup未解決状態を同期 | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | Execution State・Baseline設計Referenceを`system/05_framework/`へ同期 | DRAFT |
| `1.0.0-draft.5` | 2026-07-27 | Framework横断再走査によりTest Data起因の起動拒否、準備失敗および未評価CheckをCanonical四結果軸へMapping | DRAFT |
| `1.0.0-draft.6` | 2026-07-29 | Production-like環境区分を廃止し、本番Dataの禁止Default、個別承認、安全Gateおよび監査要件へ統一 | DRAFT |
