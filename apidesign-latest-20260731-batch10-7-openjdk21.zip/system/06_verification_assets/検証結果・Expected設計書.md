---
title: 検証結果・Expected設計書
document_id: E6-API-VAL-VERIFICATION-EXPECTED-DESIGN
version: 1.0.0-draft.10
status: DRAFT
document_type: Verification Result and Expected Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# 検証結果・Expected設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 検証結果・Expected設計書 |
| 文書ID | `E6-API-VAL-VERIFICATION-EXPECTED-DESIGN` |
| 対象 | Scenario Expected、Check Result、Scenario／Batch検証結果 |
| 配置 | `system/06_verification_assets/` |
| 文書種別 | Verification共通設計書 |
| 版数 | `1.0.0-draft.10` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | Verification Team |
| レビュー責任 | System Architect / Scenario Design Lead / Runtime Lead / Test Lead |

## 2. 目的

本書は、E6 API Verification Platformにおいて、Scenarioごとの期待結果を表すExpected、Java Checkが生成する検証明細、Scenario単位の`verification-result.json`およびBatch単位の集約結果を定義する。

本書では、次の三つを分離する。

1. Expectedは「何を期待するか」を表す実行入力資産である。
2. Check Resultは「Javaが何を確認し、どう判定したか」を表す実行結果である。
3. Response Field Diffは「前回から何が変化したか」を表す観測結果である。

Expectedまたは検証結果をMasterとして管理してはならない。

## 3. 適用範囲

### 3.1 対象

- `Scenario_Master.md.expectedRef`から参照するExpected JSON
- HTTP Status、Response仕様、業務値、API間整合性および終了状態のCheck Result
- Scenario単位の`verification-result.json`
- 複数ScenarioをまとめたBatch Result
- Reportへ渡す検証結果契約

### 3.2 対象外

| 対象外 | 正式な管理先 |
|---|---|
| API Request／Response項目仕様 | API詳細設計書、Request／Response DTO |
| API呼出順序、分岐、Mapping | Scenario詳細設計書、Java Scenario Class |
| 初期入力値 | Scenario Input |
| 実行中Request／Response | ScenarioContext |
| Previous／Baseline選択・更新 | `ExecutionState・Baseline管理設計書.md` |
| Response Field Diffの比較方式 | `APIレスポンスDiff設計書.md` |
| `IGNORE_FIELD`／`IGNORE_VALUE` | API別または`apiCallCode`別Java比較定義 |
| Report表示、集計レイアウト | `Report設計書.md` |
| Secret実値 | Secret Store、Environment設定 |

## 4. 正本および物理配置

### 4.1 設計と実行資産の分離

| 成果物 | 物理配置 | 役割 |
|---|---|---|
| 本設計書 | `system/06_verification_assets/検証結果・Expected設計書.md` | Expectedおよび検証結果の共通設計 |
| Scenario Expected | `system/04_usecase_design/expected/{scenarioId}-expected.json` | Scenarioが参照する実行入力資産 |
| Scenario検証結果 | `runs/{runId}/verification-result.json` | 一回のScenario実行結果 |
| Batch検証結果 | `batches/{batchId}/batch-verification-result.json` | 複数Scenarioの集約結果 |

ExpectedはScenario実行資産であるため`04_usecase_design/expected/`に配置する。共通設計書が`06_verification_assets/`にあることを理由に、Expected実体を`06`へ移動してはならない。

### 4.2 参照関係

```text
Scenario Master.expectedRef
    → Scenario Expected
        → resultKey
            ↔ Java Check
                → Check Result
                    → verification-result.json
                        → Report
```

`resultKey`はExpectedとJava Checkの安定した契約Keyである。Java Method名、表示順または行番号をIdentityとして使用しない。

## 5. 基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `VER-P001` | Java First | Checkロジック、値抽出、分岐および判定はJavaへ明示的に実装する。 |
| `VER-P002` | Expected非Policy化 | Expectedへ式言語、任意Scriptまたは比較Policyを記載しない。 |
| `VER-P003` | 結果再現性 | Expected版、Input、Actual、Java BuildおよびBaselineを追跡できるようにする。 |
| `VER-P004` | 判定軸分離 | Execution、Verification、Change、Recoveryの四結果軸を混在させない。 |
| `VER-P005` | 推測禁止 | Expected欠落時にAPI設計、前回結果または別Scenarioから値を推測しない。 |
| `VER-P006` | 全明細保持 | PASSだけでなくFAIL、NOT_EVALUATEDおよびReason Codeを保存する。 |
| `VER-P007` | Secret非保持 | Expectedおよび結果へCredential、Token、Password実値を保存しない。 |
| `VER-P008` | Diff非直結 | Effective Diffが存在するだけでBusiness Checkを自動FAILにしない。 |
| `VER-P009` | Ignore非免責 | Diffで無視した項目も、必須・型・固定値等のBusiness Check対象なら通常どおり検証する。 |
| `VER-P010` | 原子的確定 | 検証結果は一時Fileへ作成し、Schema・整合性確認後に確定する。 |

## 6. 判定軸

### 6.1 Execution Status

Execution Statusは「必須処理と成果物がどこまで成立したか」を表す。正式Enumは`共通Identity・Resultモデル設計書.md`を正本とする。

| Status | 意味 |
|---|---|
| `NOT_STARTED` | 実行実体は生成済みだが処理未開始。 |
| `RUNNING` | 処理中。 |
| `COMPLETED` | 必須処理と成果物生成が完了した。Business CheckがFAILでもよい。 |
| `INCOMPLETE` | API Error、Parse Error、中断または成果物欠落により完全Runにならなかった。 |
| `REJECTED` | Preflight不成立により外部API呼出前に拒否された。 |
| `UNKNOWN_OUTCOME` | 更新API Timeout等により外部結果を断定できない。 |

### 6.2 Verification Result

Verification Resultは「期待に対する検証判定」を表す。

| Result | 意味 |
|---|---|
| `NOT_EVALUATED` | 前提不成立、対象外またはExecution Errorにより評価していない。Reason必須。 |
| `PASS` | 対象Checkが期待を満たした。 |
| `FAIL` | 実行と評価はできたが、期待を満たさなかった。 |

前提不足と実装異常はどちらもVerification `NOT_EVALUATED`とし、`reasonCodes`およびExecution／Recovery軸で区別する。`BLOCKED`および`ERROR`をVerification Statusへ追加しない。

### 6.3 Change Status

Change StatusはPrevious／Baselineとの差分観測を表す。

| Status | 意味 |
|---|---|
| `UNCHANGED` | 比較を完了し、有効差異が0件。Ignored Diffは存在してよい。 |
| `CHANGED` | 比較を完了し、有効差異が1件以上。 |
| `NOT_COMPARED` | 初回、Baselineなし、Responseなし等により比較未実施。 |

Change StatusをVerification Resultへ自動変換してはならない。変化を業務上FAILとする場合は、Scenario詳細設計とJava Checkに専用`resultKey`を定義する。

### 6.4 Recovery Status

| Status | 意味 |
|---|---|
| `NOT_REQUIRED` | 運用介入不要。 |
| `REQUIRED` | 状態確認、補償または手動判断が必要。 |
| `IN_PROGRESS` | Recovery作業中。 |
| `RESOLVED` | Recovery記録が確定。元Runの他軸は変更しない。 |

## 7. Expected設計

### 7.1 Expectedの役割

Expectedは、Scenario実行時にJava Checkが参照する次の情報だけを保持する。

- Execution Identity
- Scenarioの期待終了状態
- 各`resultKey`の期待判定
- Scenario固有の期待値または許容値
- ExpectedのSchema版および内容版

Expectedは次を保持しない。

- Java Class名、Method名または任意Script
- JSONPath抽出式の実行ロジック
- API呼出順序または分岐
- `IGNORE_FIELD`／`IGNORE_VALUE`
- Previous／Baseline実値
- Current Actual
- Check Result
- Credential、Token、Password

### 7.2 Expected Identity

Expected Identityは次の組合せとする。

```text
environmentId
+
useCaseId
+
scenarioId
+
inputSetId
```

Environmentに依存しないExpectedでも`environmentId`を省略しない。共通Expectedを再利用する場合は、Java Loaderが明示的に解決した結果をExecution Identityへ固定する。

`expectedSetId`は現行Expected契約へ追加しない。Scenario Masterの`expectedRef`は一つのExpected Fileを一意に解決し、Expectedは`inputSetId`によって対応Inputを固定する。Expected内容の改訂追跡には`expectedVersion`を使用する。

### 7.3 ファイル命名

基本形は次のとおりとする。

```text
system/04_usecase_design/expected/{scenarioId}-expected.json
```

複数Input Setを運用する場合の物理命名はRepository Structureで確定するまでは独自拡張せず、Expected内部の`inputSetId`でIdentityを確認する。

### 7.4 Expected JSON全体構造

```json
{
  "schemaVersion": "1.0",
  "expectedVersion": "1.0.0",
  "environmentId": "ENV-STAGING",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "inputSetId": "INPUT-DEFAULT",
  "expectedExecutionStatus": "COMPLETED",
  "expectedVerificationStatus": "PASS",
  "expectedRecoveryStatus": "NOT_REQUIRED",
  "checks": [
    {
      "resultKey": "CALL-001_HTTP_STATUS",
      "resultType": "HTTP_STATUS",
      "apiCallCode": "CALL-001",
      "expectedResult": "PASS",
      "expectedValue": 200,
      "valueType": "INTEGER",
      "required": true,
      "description": "更新前照会がHTTP 200で完了すること。"
    },
    {
      "resultKey": "CALL-003_MEMBER_STATUS",
      "resultType": "BUSINESS_VALUE",
      "apiCallCode": "CALL-003",
      "expectedResult": "PASS",
      "expectedValue": "SUSPENDED",
      "valueType": "STRING",
      "required": true,
      "description": "更新後会員状態が想定値であること。"
    },
    {
      "resultKey": "SCENARIO_FINAL_STATE",
      "resultType": "SCENARIO_STATE",
      "apiCallCode": null,
      "expectedResult": "PASS",
      "expectedValue": "COMPLETED",
      "valueType": "STRING",
      "required": true,
      "description": "Scenarioが想定終了状態へ到達すること。"
    }
  ]
}
```

### 7.5 Expected項目定義

| No | JSON Path | Type | 必須 | 内容 |
|---:|---|---|:---:|---|
| 1 | `$.schemaVersion` | String | Yes | Expected Schema版 |
| 2 | `$.expectedVersion` | String | Yes | Expected内容版 |
| 3 | `$.environmentId` | String | Yes | Environment Identity |
| 4 | `$.useCaseId` | String | Yes | UseCase Identity |
| 5 | `$.scenarioId` | String | Yes | Scenario Identity |
| 6 | `$.inputSetId` | String | Yes | Input Set Identity |
| 7 | `$.expectedExecutionStatus` | Enum | Yes | 期待する終端Execution Status。`NOT_STARTED`／`RUNNING`は禁止 |
| 8 | `$.expectedVerificationStatus` | Enum | Yes | `NOT_EVALUATED / PASS / FAIL` |
| 9 | `$.expectedRecoveryStatus` | Enum | Yes | 元Run確定時の`NOT_REQUIRED / REQUIRED` |
| 10 | `$.checks` | Array | Yes | Expected Check一覧 |
| 11 | `$.checks[*].resultKey` | String | Yes | Java Checkとの契約Key |
| 12 | `$.checks[*].resultType` | Enum | Yes | Check種別 |
| 13 | `$.checks[*].apiCallCode` | String／Null | Yes | API呼出に属する場合の呼出実体ID |
| 14 | `$.checks[*].expectedResult` | Enum | Yes | 期待判定 |
| 15 | `$.checks[*].expectedValue` | Any／Null | No | Scenario固有の期待値 |
| 16 | `$.checks[*].valueType` | Enum | No | Expected Valueの型 |
| 17 | `$.checks[*].required` | Boolean | Yes | 結果欠落を許可しないか |
| 18 | `$.checks[*].description` | String | Yes | 人向け説明 |

### 7.6 `resultType`

標準`resultType`は次のとおりとする。

| resultType | 用途 |
|---|---|
| `HTTP_STATUS` | HTTP Status確認 |
| `RESPONSE_CONTRACT` | 必須、型、Null、長さ、形式、Enum等 |
| `FIXED_VALUE` | API仕様上の固定値確認 |
| `INPUT_MATCH` | Input／RequestとResponseの一致 |
| `API_CHAIN_MATCH` | 前段と後段API間の値整合性 |
| `BUSINESS_VALUE` | Scenario固有業務値 |
| `BUSINESS_TRANSITION` | 更新前後の状態遷移 |
| `API_RESPONSE_COMPARE` | Response Diffの利用結果 |
| `SCENARIO_STATE` | Scenario終了状態 |
| `API_CALL_OUTCOME` | API CallのTimeout、通信Errorまたは業務Error等の結果 |
| `EXECUTION_TRACE` | 宣言Call、実行回数、Retry、Skipまたは未計画Callの確認 |
| `BUSINESS_OUTCOME` | Alternative／Business Error経路の業務結果区分 |
| `BASELINE_CONTROL` | Baseline作成、維持または更新禁止の確認 |
| `RECOVERY_CONTROL` | 状態確認、再送判断、Cleanup等のRecovery引渡し確認 |
| `EVIDENCE_COMPLETENESS` | 必須Evidence生成確認 |

標準Enumを増やすだけでCheckロジックを動的生成してはならない。実装はJava Classに明示する。

### 7.7 Expected Valueの扱い

| 区分 | 管理元 | Expectedへの記載 |
|---|---|---|
| API共通固定値 | API詳細設計書 | 重複を避ける。Scenario固有条件がある場合だけ記載する。 |
| Scenario固有値 | Scenario Expected | 記載する。 |
| Inputと同一 | Java Check＋Scenario設計 | 実値を複製せず、CheckがInputを参照する。 |
| 前段Responseと同一 | Java Check＋Scenario設計 | Expectedへ前段実値を保存しない。 |
| 前回との差異 | Diff成果物 | ExpectedへPrevious／Baseline実値を保存しない。 |

### 7.8 `valueType`

`expectedValue`を記載する場合は`valueType`も必須とし、`valueType`を記載する場合は`expectedValue`も必須とする。

| valueType | JSON Type | 備考 |
|---|---|---|
| `STRING` | string | Enum、Code、日時表現を含む。形式の意味検証はJava Checkが担当する。 |
| `INTEGER` | integer | 小数部を持たない数値。 |
| `NUMBER` | number | 小数を含む数値。金額等の精度規則はJava Checkが担当する。 |
| `BOOLEAN` | boolean | `true / false`。 |
| `OBJECT` | object | 業務固有Object。Field契約はScenario設計とJava Checkが担当する。 |
| `ARRAY` | array | 業務固有Array。順序、要素Keyおよび集合規則はJava Checkが担当する。 |
| `NULL` | null | Null自体を期待値として明示する場合に使用する。 |

Schemaは上表のJSON Type対応を検証する。`"1"`を`INTEGER`へ暗黙変換する等の型補正をLoaderで行ってはならない。

### 7.9 Expected Status制約

ExpectedはRun終了時の期待結果を表すため、`expectedExecutionStatus`に`NOT_STARTED`または`RUNNING`を指定してはならない。`expectedRecoveryStatus`は元Run確定時の介入要否だけを表し、Recovery Caseの進行状態である`IN_PROGRESS`または`RESOLVED`を指定してはならない。

`expectedExecutionStatus=UNKNOWN_OUTCOME`の場合、`expectedRecoveryStatus`は必ず`REQUIRED`とする。Recovery完了後も元RunのExpectedおよび四結果軸を書き換えない。

### 7.10 SchemaとSemantic Validationの境界

| 検証対象 | JSON Schema | Semantic Validator／Java |
|---|:---:|:---:|
| 必須Property、未知Property、ID形式、Enum | Yes | 補助確認 |
| `expectedValue`と`valueType`のJSON Type対応 | Yes | 業務精度・形式を確認 |
| `UNKNOWN_OUTCOME → REQUIRED` | Yes | Runtime結果でも確認 |
| `resultKey`完全一致重複 | `uniqueItems`で一部検出 | Yes |
| `resultKey`のKey単位一意性 | No | Yes |
| Master存在、親子関係、Scenario Call集合 | No | Yes |
| Java Check Registryとの双方向完全性 | No | Yes |
| `resultType`とCheck実装責務の一致 | No | Yes |
| Secret／個人情報の実値検出 | No | Yes |

JSON Schemaを通過したことだけでExpectedを実行可能と判定してはならない。

## 8. Expected LoadおよびValidation

### 8.1 Load順序

1. Scenario Masterの`expectedRef`を解決する。
2. UTF-8 JSONとして読込む。
3. Schemaを検証する。
4. Execution IdentityをInputおよびScenarioContextと照合する。
5. `resultKey`一意性を確認する。
6. Java Check Registryとの完全性を照合する。
7. Secret実値が含まれていないことを確認する。
8. 読取専用ObjectとしてScenarioContextへ渡す。

### 8.2 Expected Validation

| Validation ID | 確認内容 | 不一致時 |
|---|---|---|
| `EXP-V001` | JSONが構文上有効である。 | Execution `REJECTED`、Reason記録 |
| `EXP-V002` | Schema版をRuntimeがサポートする。 | Execution `REJECTED`、Reason記録 |
| `EXP-V003` | Execution IdentityがInput／Contextと一致する。 | Execution `REJECTED`、Reason記録 |
| `EXP-V004` | `resultKey`がExpected内で一意である。 | Execution `REJECTED`、Reason記録 |
| `EXP-V005` | 必須`resultKey`がJava Check Registryに存在する。 | Execution `REJECTED`、Reason記録 |
| `EXP-V006` | Javaの必須CheckがExpectedに存在する。 | Execution `REJECTED`、Reason記録 |
| `EXP-V007` | `apiCallCode`がScenario詳細設計で解決できる。 | Execution `REJECTED`、Reason記録 |
| `EXP-V008` | `expectedValue`と`valueType`が同時に存在し、JSON Typeおよび業務型が一致する。 | Execution `REJECTED`、Reason記録 |
| `EXP-V009` | Secret実値を含まない。 | Execution `REJECTED`、Security Reason記録 |
| `EXP-V010` | Ignore定義、BaselineまたはActualが混入していない。 | Execution `REJECTED`、Reason記録 |

## 9. Java Check契約

### 9.1 Check Interface

```java
public interface VerificationCheck {

    String resultKey();

    CheckResult execute(
            ScenarioContext context,
            ExpectedCheck expected);
}
```

### 9.2 Check Registry

```java
public final class MemberUpdateCheckRegistry {

    public List<VerificationCheck> checks() {
        return List.of(
                new Call001HttpStatusCheck(),
                new Call003MemberStatusCheck(),
                new ScenarioFinalStateCheck());
    }
}
```

ExpectedはRegistryを置き換えない。Expectedに未定義の任意Class名を記載し、Reflectionで実行してはならない。

### 9.3 Check実行順序

Check表示順はScenario詳細設計で定義する。依存関係があるCheckはJavaで明示し、前提Checkが成立しない場合は`NOT_EVALUATED`とReason Codeを返す。

`resultKey`の文字列Sortを実行順序として使用しない。

## 10. Check Result設計

### 10.1 Javaモデル

```java
public record CheckResult(
        String resultKey,
        String resultType,
        String apiCallCode,
        VerificationStatus status,
        String expectedDisplay,
        String actualDisplay,
        String message,
        List<String> reasonCodes,
        List<String> evidenceRefs,
        String fieldDiffRef) {
}
```

Secretまたは個人情報を`expectedDisplay`、`actualDisplay`および`message`へ直接設定してはならない。必要な場合はMask済表示またはHashを使用する。

### 10.2 Check Result JSON例

```json
{
  "resultKey": "CALL-003_MEMBER_STATUS",
  "resultType": "BUSINESS_VALUE",
  "apiCallCode": "CALL-003",
  "status": "FAIL",
  "expectedDisplay": "SUSPENDED",
  "actualDisplay": "ACTIVE",
  "message": "更新後会員状態が期待値と一致しない。",
  "reasonCodes": [
    "VERIFY_VALUE_MISMATCH"
  ],
  "evidenceRefs": [
    "api-calls/CALL-003/response.json"
  ],
  "fieldDiffRef": null
}
```

### 10.3 `NOT_EVALUATED`とExecution Failure

| 状況 | 判定 |
|---|---|
| 前段APIが業務想定により後続Check対象外 | Verification `NOT_EVALUATED`、対象外Reasonを明示 |
| 必要ResponseがTransport Errorで取得不能 | Verification `NOT_EVALUATED`、Execution `INCOMPLETE` |
| `apiCallCode`がContextに存在しない | Verification `NOT_EVALUATED`、Execution `INCOMPLETE` |
| DTO型がCheck想定と一致しない | Verification `NOT_EVALUATED`、Execution `INCOMPLETE` |
| Expected必須値が欠落 | PreflightでExecution `REJECTED`、Verification `NOT_EVALUATED` |
| 業務値が期待と不一致 | `FAIL` |

同じ`NOT_EVALUATED`でも原因は`reasonCodes`で区別し、実装異常を業務不一致`FAIL`へ変換しない。

## 11. `verification-result.json`

### 11.1 配置

```text
runs/{runId}/verification-result.json
```

### 11.2 全体例

```json
{
  "schemaVersion": "1.0",
  "resultId": "RESULT-RUN-20260727-150000-550e8400",
  "runId": "RUN-20260727-150000-550e8400",
  "ownerType": "SCENARIO",
  "ownerExecutionId": "SCEXEC-550e8400",
  "batchId": "BATCH-20260727-DAILY",
  "environmentId": "ENV-STAGING",
  "businessId": "BUS-E6-001",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "inputSetId": "INPUT-DEFAULT",
  "startedAt": "2026-07-27T15:00:00+09:00",
  "finishedAt": "2026-07-27T15:00:12+09:00",
  "executionStatus": "COMPLETED",
  "verificationStatus": "FAIL",
  "changeStatus": "CHANGED",
  "recoveryStatus": "NOT_REQUIRED",
  "severity": "ERROR",
  "reasonCodes": [
    "VERIFY_VALUE_MISMATCH"
  ],
  "childResultRefs": [],
  "expectedVersion": "1.0.0",
  "baselineRunId": "RUN-20260726-150000-11335577",
  "summary": {
    "totalCount": 6,
    "passCount": 5,
    "failCount": 1,
    "notEvaluatedCount": 0,
    "effectiveChangedCount": 1,
    "ignoredDiffCount": 2,
    "notComparedApiCallCount": 0
  },
  "checks": [
    {
      "resultKey": "CALL-003_MEMBER_STATUS",
      "resultType": "BUSINESS_VALUE",
      "apiCallCode": "CALL-003",
      "status": "FAIL",
      "expectedDisplay": "SUSPENDED",
      "actualDisplay": "ACTIVE",
      "message": "更新後会員状態が期待値と一致しない。",
      "reasonCodes": [
        "VERIFY_VALUE_MISMATCH"
      ],
      "evidenceRefs": [
        "api-calls/CALL-003/response.json"
      ],
      "fieldDiffRef": "api-calls/CALL-003/response-field-diff.json"
    }
  ],
  "artifactRefs": {
    "runMeta": "run-meta.json",
    "definitionSnapshot": "run-meta.json#/definitionSnapshot",
    "reportDirectory": "reports/"
  },
  "finalizedAt": "2026-07-27T15:00:12+09:00"
}
```

### 11.3 必須項目

| 区分 | 必須項目 |
|---|---|
| Schema | `schemaVersion` |
| Identity／Owner | `resultId`、`runId`、`ownerType`、`ownerExecutionId`、`environmentId`、`useCaseId`、`scenarioId`、`inputSetId` |
| 時刻 | `startedAt`、`finishedAt` |
| 判定 | `executionStatus`、`verificationStatus`、`changeStatus`、`recoveryStatus` |
| 重要度／理由 | `severity`、`reasonCodes` |
| 集約根拠 | `childResultRefs` |
| Version | `expectedVersion` |
| Previous | `baselineRunId`。初回はNull。 |
| 集計 | `summary` |
| 明細 | `checks` |
| 追跡 | `artifactRefs` |
| 確定 | `finalizedAt` |

### 11.4 Summary整合式

```text
totalCount
=
passCount
+ failCount
+ notEvaluatedCount
```

Ignored DiffはCheck件数とは別軸であり、`ignoredDiffCount`を`passCount`へ加算しない。

### 11.5 Verification Result Schema境界

`verification-result.schema.json`はScenario Run単位のResultだけを対象とし、`batch-verification-result.json`を受理しない。

| 検証対象 | JSON Schema | Semantic Validator／Java |
|---|:---:|:---:|
| 必須項目、型、ID Pattern、未知Property | Yes | - |
| 終端Execution Status、四結果軸Enum | Yes | - |
| `UNKNOWN_OUTCOME + Recovery REQUIRED` | Yes | - |
| `INCOMPLETE／REJECTED + Verification NOT_EVALUATED` | Yes | - |
| Check `NOT_EVALUATED`時のReason必須 | Yes | - |
| Scenario Result ID、Owner、Severity、Reason、Child Reference | Yes | - |
| `resultKey`単位一意性 | - | Yes |
| Summary算術一致 | - | Yes |
| Expected／Registryとの双方向完全性 | - | Yes |
| Evidence／Diff Referenceの存在、Hash、Owner一致 | - | Yes |
| `startedAt <= finishedAt <= finalizedAt` | - | Yes |
| Parent SeverityがChild最大値以上 | - | Yes |

元Runの`recoveryStatus`は確定時の`NOT_REQUIRED／REQUIRED`だけを保存する。Recovery Caseの`IN_PROGRESS／RESOLVED`は別IdentityのAppend Only記録であり、Published Verification Resultを更新しない。

## 12. Scenario集約規則

### 12.1 Verification Status優先順位

```text
FAIL
  > NOT_EVALUATED
      > PASS
```

ただし、必須Checkと任意Checkを区別する。

| 条件 | Scenario Result |
|---|---|
| 必須Checkに`FAIL`が1件以上 | `FAIL` |
| 必須Checkに`NOT_EVALUATED`が1件以上、かつFAILなし | `NOT_EVALUATED` |
| 全必須Checkが`PASS` | `PASS` |

任意Checkの非PASSはScenario詳細設計に定義した重要度でReportへ表示するが、本書だけで自動的にScenario Resultへ昇格させない。

### 12.2 Execution Statusとの組合せ

| Execution Status | Verification Result | 意味 |
|---|---|---|
| `COMPLETED` | `PASS` | 完全実行かつ期待成立 |
| `COMPLETED` | `FAIL` | 完全実行だが業務期待不成立 |
| `COMPLETED` | `NOT_EVALUATED` | 必須Checkが対象外等で未評価。Reasonと必須性の妥当性確認が必要 |
| `INCOMPLETE` | `NOT_EVALUATED` | Runtime／API／Parse／中断等により評価不能 |
| `REJECTED` | `NOT_EVALUATED` | Preflight不成立で未実行 |
| `UNKNOWN_OUTCOME` | `NOT_EVALUATED`または評価済み値 | 外部結果不明。Recovery `REQUIRED`を独立保持 |

`COMPLETED + FAIL`はComplete Runであり得る。Baseline更新可否は本書ではなく`ExecutionState・Baseline管理設計書.md`に従う。

## 13. Response Diffとの連携

### 13.1 連携方式

各API呼出のDiffは次のPathに保存する。

```text
runs/{runId}/api-calls/{apiCallCode}/response-field-diff.json
```

検証結果は`fieldDiffRef`で参照し、Diff明細を`verification-result.json`へ複製しない。

### 13.2 Ignoreとの境界

| 対象 | Diff | Business Check |
|---|---|---|
| `IGNORE_FIELD`項目の値変化 | `IGNORED` | 対象Checkがあれば通常どおり評価 |
| `IGNORE_FIELD`項目の追加／削除／型変化 | `IGNORED` | API仕様上の必須・型Checkは通常どおり評価 |
| `IGNORE_VALUE`項目の値変化 | `IGNORED` | 必須・型・範囲Checkは通常どおり評価 |
| `IGNORE_VALUE`項目の削除／型変化 | Effective Diff | Business Checkも仕様に従い評価 |

「DiffでIgnoredになった」ことを理由に、Business Checkを無条件PASSにしてはならない。

### 13.3 Effective Diffの結果化

Effective Diffを検証対象にする場合、Java Checkは専用`resultKey`を出力する。

```json
{
  "resultKey": "CALL-001_RESPONSE_COMPARE",
  "resultType": "API_RESPONSE_COMPARE",
  "apiCallCode": "CALL-001",
  "status": "PASS",
  "expectedDisplay": "UNCHANGED",
  "actualDisplay": "UNCHANGED (IGNORED_ONLY=2)",
  "message": "有効差異は0件。Ignored Diffは2件。",
  "reasonCodes": [],
  "evidenceRefs": [],
  "fieldDiffRef": "api-calls/CALL-001/response-field-diff.json"
}
```

このCheckを必須とするか、Effective ChangeをFAILとするかはScenario詳細設計とJava Checkで決定する。

## 14. Batch Result

### 14.1 配置

```text
batches/{batchId}/batch-verification-result.json
```

### 14.2 論理構造

```json
{
  "schemaVersion": "1.0",
  "batchResultId": "BRESULT-BATCH-20260727-DAILY",
  "batchId": "BATCH-20260727-DAILY",
  "environmentId": "ENV-STAGING",
  "executionStatus": "INCOMPLETE",
  "verificationStatus": "FAIL",
  "changeStatus": "CHANGED",
  "recoveryStatus": "REQUIRED",
  "reasonCode": "BATCH_SCENARIO_INCOMPLETE",
  "summary": {
    "scenarioCount": 7,
    "passCount": 5,
    "failCount": 1,
    "notEvaluatedCount": 1,
    "effectiveChangeScenarioCount": 2,
    "ignoredOnlyScenarioCount": 1,
    "notComparedScenarioCount": 1
  },
  "scenarioResults": [
    {
      "runId": "RUN-20260727-150000-550e8400",
      "resultId": "RESULT-RUN-20260727-150000-550e8400",
      "useCaseId": "UC-E6-001",
      "scenarioId": "SC-E6-001",
      "inputSetId": "INPUT-DEFAULT",
      "executionStatus": "COMPLETED",
      "verificationStatus": "FAIL",
      "changeStatus": "CHANGED",
      "recoveryStatus": "NOT_REQUIRED",
      "reasonCode": "VERIFY_VALUE_MISMATCH",
      "verificationResultRef": "../../runs/RUN-20260727-150000-550e8400/verification-result.json"
    }
  ],
  "startedAt": "2026-07-27T15:00:00+09:00",
  "finishedAt": "2026-07-27T15:30:00+09:00",
  "finalizedAt": "2026-07-27T15:31:00+09:00"
}
```

Batch ResultはScenario Resultを再判定せず集約する。各Scenarioの明細正本は各Runの`verification-result.json`とする。

`verification-result.schema.json`はRun／BaselineのScenario Result、`batch-verification-result.schema.json`はBatch集約を対象とする。両者を同じSchemaの曖昧なVariantへ混在させない。BatchのSummary件数、Scenario Source一意性、四軸優先順位および時刻順序はSemantic Validatorが検証する。

## 15. Error Code

| Error Code | 内容 | 処理 |
|---|---|---|
| `EXPECTED_NOT_FOUND` | Expected参照先なし | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `EXPECTED_PARSE_ERROR` | JSON構文不正 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `EXPECTED_SCHEMA_ERROR` | Schema不一致 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `EXPECTED_ID_MISMATCH` | Execution Identity不一致 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `EXPECTED_RESULT_KEY_DUPLICATE` | `resultKey`重複 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `EXPECTED_CHECK_NOT_IMPLEMENTED` | Java Checkなし | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `CHECK_CONTEXT_NOT_FOUND` | 必要Contextなし | Check `NOT_EVALUATED`、Execution `INCOMPLETE` |
| `CHECK_TYPE_MISMATCH` | DTO／Value型不一致 | Check `NOT_EVALUATED`、Execution `INCOMPLETE` |
| `RESULT_AGGREGATION_ERROR` | 件数または優先順位不整合 | Execution `INCOMPLETE`、Verificationを確定しない |
| `RESULT_WRITE_ERROR` | 結果保存失敗 | Execution `INCOMPLETE` |

## 16. SecurityおよびEvidence

1. ExpectedへSecret実値を保存しない。
2. `actualDisplay`へ個人情報を無条件出力しない。
3. Request／Response全体はEvidence参照とし、Resultへ複製しない。
4. Mask対象値はMask済表示、Hashまたは`[REDACTED]`を使用する。
5. Error MessageへToken、HeaderまたはCredentialを連結しない。
6. Evidence PathはRun Rootからの相対Pathとし、Root外参照を禁止する。

## 17. Versionおよび変更管理

| 変更 | 変更対象 | 影響 |
|---|---|---|
| `resultKey`追加 | Expected、Java Check、Test、Report | 互換追加 |
| `resultKey`削除 | Expected、Java Check、Test、Report | 破壊的変更 |
| Expected Value変更 | Expected | 業務承認が必要 |
| Checkロジック変更 | Java、Scenario詳細設計、Test | Build版更新が必要 |
| Schema変更 | Loader、Writer、Report | `schemaVersion`更新 |
| Result集約規則変更 | 本設計、Java、Test、Report | 全体回帰が必要 |

Run成果物にはExpected内容版とJava Build Identityを記録し、後日同じ判定根拠を追跡できるようにする。

## 18. Test観点

- [ ] Expected IdentityがInputおよびScenarioContextと一致する。
- [ ] ExpectedとJava Check Registryの`resultKey`が双方向に一致する。
- [ ] `scenario-expected.schema.json`が3 Exampleを受理し、未知Property、型不一致、非終端Statusおよび不正なRecovery組合せを拒否する。
- [ ] 必須Check欠落時に起動を停止できる。
- [ ] Business FAILでもExecution Statusを`COMPLETED`にできる。
- [ ] API Error時にExecution Statusを`INCOMPLETE`、Verificationを`NOT_EVALUATED`にできる。
- [ ] `FAIL > NOT_EVALUATED > PASS`で集約される。
- [ ] 更新APIの結果不明時にExecution `UNKNOWN_OUTCOME`とRecovery `REQUIRED`を保持できる。
- [ ] Ignored Diffだけの場合にBusiness Checkを自動FAILにしない。
- [ ] Effective Diffを必要に応じ専用Checkへ変換できる。
- [ ] `verification-result.json`のSummary件数が明細と一致する。
- [ ] 初回実行で`baselineRunId=null`かつ`changeStatus=NOT_COMPARED`になる。
- [ ] Secretおよび個人情報がResult表示へ露出しない。
- [ ] Batch ResultからScenario正本へ追跡できる。

## 19. Validation Checklist

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `VER-V001` | Expectedの全Identityが一致する。 | ERROR |
| `VER-V002` | `resultKey`が一意かつJavaで解決できる。 | ERROR |
| `VER-V003` | Check ResultのStatusが標準Enumである。 | ERROR |
| `VER-V004` | 必須Checkがすべて結果に存在する。 | ERROR |
| `VER-V005` | Summary件数と明細件数が一致する。 | ERROR |
| `VER-V006` | Execution StatusとVerification Resultの組合せが有効である。 | ERROR |
| `VER-V007` | `fieldDiffRef`が同一Run内で解決できる。 | ERROR |
| `VER-V008` | Ignored DiffがEffective Countへ加算されていない。 | ERROR |
| `VER-V009` | ExpectedへIgnore、BaselineまたはActualが混入していない。 | ERROR |
| `VER-V010` | ResultへSecret実値が含まれない。 | ERROR |
| `VER-V011` | Batch集計がScenario結果と一致する。 | ERROR |
| `VER-V012` | 成果物が一時Fileから原子的に確定される。 | ERROR |

## 20. 未確定事項

| Issue ID | 未確定事項 | 暫定方針 | 確定先 |
|---|---|---|---|
| `VER-ISSUE-001` | 複数Input SetのExpected物理命名 | 1 Scenario 1基本Expectedを維持し内部Identityで確認する。 | Repository Structure／File I/O設計 |
| `VER-ISSUE-002` | 任意CheckのSeverity標準 | 必須CheckのみScenario集約へ直接使用する。 | Scenario詳細設計／Report設計 |
| `VER-ISSUE-003` | 正式Scenarioの業務結果区分 | Business RuleとScenario終了条件から承認値を定義する。 | 業務担当／Scenario詳細設計 |
| `VER-ISSUE-004` | Timeout後Recoveryの共通契約 | 自動RetryをDefaultにせず、結果不明時の状態確認をRecovery設計へ委譲する。 | API仕様／共通Framework／Scenario詳細設計 |

## 21. 現行Release阻断

| 阻断ID | 内容 | 影響 |
|---|---|---|
| `VER-BLOCK-001` | 正式Scenario／Expectedが0件 | 実行対象の期待結果と必須Checkを構成できない。 |
| `VER-BLOCK-002` | Java Check Registryの正式配置と実装契約が未確定 | Expectedとの双方向完全性照合ができない。 |
| `VER-BLOCK-003` | `verification-result.schema.json`正文・機械Validationは完了したが、正式Role ReviewとRuntime Writer／Reader Contract Testが未実施 | 正式Release契約として承認できない。 |
| `VER-BLOCK-004` | Batch Result Schema正文・機械Validationは完了したが、Batch Aggregator／WriterとScenario SourceのCross-Artifact Contract Testが未実施 | Batch集約の端到端正当性を正式保証できない。 |

## 22. 改訂履歴

| Version | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | Java First、Expected／Actual／Diff分離、4段階検証結果およびScenario／Batch集約に基づく初版作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | SC-E6-001 Expected DRAFT作成後のReference解決と残存Java照合Blockerを同期 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | SC-E6-002 Expected DRAFTのReference解決、6 resultKeyおよび最終業務結果未決Blockerを同期 | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | SC-E6-003 Expected DRAFTのReference解決、9 resultKey、FAILED／ERRORおよびTimeout／Recovery Blockerを同期 | DRAFT |
| `1.0.0-draft.5` | 2026-07-27 | 横断ReviewによりExecution、Verification、Change、Recoveryの四結果軸、Reason Codeおよび集約規則へ統一 | DRAFT |
| `1.0.0-draft.6` | 2026-07-28 | Snapshot／Evidence設計に合わせ、実行時Input／Expected別Copy Referenceを`run-meta.json`内Definition Snapshotへ統合 | DRAFT |
| `1.0.0-draft.7` | 2026-07-28 | 第8バッチCoverage ReviewによりScenario Verification ResultとBatch ResultのSchema境界、残りSchema BlockerおよびFile I/O Draft完成を同期 | DRAFT |
| `1.0.0-draft.8` | 2026-07-28 | `scenario-expected.schema.json`正文に合わせ、Expected Identity、終端Status、`valueType`対応およびSchema／Semantic Validation境界を明確化 | DRAFT |
| `1.0.0-draft.9` | 2026-07-28 | `verification-result.schema.json`正文に合わせ、Scenario Result／Batch Result分離、四結果軸合法組合せ、Check Reason、SummaryおよびSchema／Semantic Validation境界を明確化 | DRAFT |
| `1.0.0-draft.10` | 2026-07-28 | `batch-verification-result.schema.json`正文を反映し、Batch Result Identity、Source Scenario Result、完全Summary、時刻およびSchema／Semantic集約境界を同期 | DRAFT |
