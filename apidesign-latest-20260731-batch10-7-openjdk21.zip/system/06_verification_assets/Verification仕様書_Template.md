---
title: Verification仕様書 Template
document_id: E6-API-VAL-VERIFICATION-SPEC-TEMPLATE
version: 2.0.0-draft.5
status: DRAFT
document_type: Verification Specification Template
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Verification仕様書 Template

> 本TemplateをUseCase単位のVerification仕様書作成に使用する。  
> `<>`内のPlaceholder、説明文および不要な記入例は、Review依頼前に置換または削除する。  
> 本Template自体はExpected、Test Data、Java Check、Compare Definitionまたは実行結果の正本ではない。

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | `<UseCase正式名称> Verification仕様書` |
| 文書ID | `<E6-API-VAL-UC-E6-NNN-VERIFICATION-SPEC>` |
| Verification Scope ID | `<VER-UC-E6-NNN>` |
| Business ID | `<BUS-E6-NNN>` |
| UseCase ID | `<UC-E6-NNN>` |
| 対象Environment | `<ENV-XXX / 複数の場合は一覧参照>` |
| 文書種別 | Verification仕様書 |
| 版数 | `<1.0.0-draft.1>` |
| 文書状態 | `<DRAFT / REVIEW / APPROVED / FROZEN>` |
| 最終更新日 | `<YYYY-MM-DD>` |
| 作成責任 | `<Verification Design Owner>` |
| レビュー責任 | `<System Architect / API Design Lead / Scenario Design Lead / Runtime Lead / Test Lead>` |
| 承認責任 | `<System Owner / Business Owner>` |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更理由 | 影響対象 | 担当 |
|---|---|---|---|---|---|
| `<1.0.0-draft.1>` | `<YYYY-MM-DD>` | `<初版作成>` | `<新規UseCase>` | `<Scenario / Expected / Java / Test>` | `<担当>` |

## 3. 目的

本書は、`<UC-E6-NNN>`に属するScenarioについて、どの業務期待、API契約、Flow、Context、ErrorおよびChange観測を、どの`resultKey`とJava Checkで評価し、どのEvidenceへ追跡するかを定義する。

本書は「何を検証するか」と「Coverageが十分か」を正本化し、Expected値、Check実装およびRuntime Resultを重複保持しない。

## 4. 適用範囲

### 4.1 対象

| 分類 | 対象有無 | 対象概要 | 正本 |
|---|:---:|---|---|
| Request契約 | `<Yes / No>` | `<Header／Path／Query／Body>` | API設計、Java Check |
| Response契約 | `<Yes / No>` | `<HTTP Status／Header／Body>` | API設計、Java Check |
| Flow | `<Yes / No>` | `<順序／分岐／Skip／Stop>` | Scenario詳細設計、Java |
| Context | `<Yes / No>` | `<抽出／Mapping／引継ぎ>` | Scenario詳細設計、Java |
| Business Result | `<Yes / No>` | `<固定値／状態遷移／不変条件>` | Scenario設計、Expected、Java Check |
| Error | `<Yes / No>` | `<Business Error／Transport Error／Timeout>` | API／Scenario設計、Java |
| Response Diff | `<Yes / No>` | `<Previous／Baselineとの差分観測>` | Java Compare Definition、Diff設計 |
| Evidence | `Yes` | `<Request／Response／Check／Diff>` | Runtime Artifact |
| Report | `Yes` | `<Scenario／Daily／Diff／Evidence>` | Report設計 |

### 4.2 対象外

| 対象外 | 理由 | 別成果物／Owner |
|---|---|---|
| E6 Provider内部Logic | 外部System責務 | `<Provider Design / NONE>` |
| Performance負荷試験 | 本Verification Scope外 | `<Performance Test Plan / NONE>` |
| 画面表示 | API Platform Scope外 | `<UI Test / NONE>` |
| `<その他>` | `<理由>` | `<Reference / Owner>` |

対象外を単に削除せず、利用者が誤ってCoverage済みと判断しないよう明示する。

## 5. 本書の責務境界

### 5.1 本書が正本とするもの

- Verification Scope ID
- 対象Business、UseCase、ScenarioおよびEnvironment
- Verification CategoryとCoverage
- Check意図、`resultKey`、必須性、重要度、Java Check Reference
- CheckとExpected、Evidence、Test仕様のTrace
- 集約への影響
- Verification Scope単位の完了条件とBlocker

### 5.2 本書が正本としないもの

| 内容 | 正本 |
|---|---|
| API Method、Path、Request／Response Field契約 | API Master、API詳細設計 |
| UseCaseの業務目的、範囲、Scenario構成 | UseCase Master、UseCase設計 |
| API呼出順序、分岐、Mapping、Skip | Scenario詳細設計、Java Scenario Class |
| Scenario実行値 | Scenario Input |
| Scenario固有Expected値 | Expected JSON |
| Check Logic | Java `VerificationCheck` |
| Ignore定義 | API別／`apiCallCode`別Java `ResponseCompareDefinition` |
| Previous／Baseline実値 | Runtime Baseline |
| Actual、Check Result、Diff | Run Artifact |
| Report表示・集約Logic | `Report設計書.md`、Report Generator |

## 6. 参照成果物

| 分類 | ID／File | Version | 参照目的 | 解決状態 |
|---|---|---|---|---|
| Business Analysis | `<businessAnalysisRef>` | `<version>` | 業務目的、現行Flow | `<VALID / BLOCKED / BROKEN>` |
| Business Master | `system/02_master/Business_Master.md` | `<version>` | Business ID | `<status>` |
| Environment Master | `system/02_master/Environment_Master.md` | `<version>` | Environment ID | `<status>` |
| API Master | `system/02_master/API_Master.md` | `<version>` | API ID | `<status>` |
| UseCase Master | `system/02_master/UseCase_Master.md` | `<version>` | UseCase ID、Scenario所属 | `<status>` |
| Scenario Master | `system/02_master/Scenario_Master.md` | `<version>` | Scenario、Input、Expected、Class | `<status>` |
| UseCase設計 | `<useCaseDesignRef>` | `<version>` | Scope、Coverage | `<status>` |
| Scenario設計 | `<scenarioDesignRef>` | `<version>` | Call、Mapping、Check意図 | `<status>` |
| API設計 | `<apiDesignRef>` | `<version>` | 契約、Security | `<status>` |
| Input設計 | `system/04_usecase_design/Scenario入力データ設計書.md` | `<version>` | Input契約 | `<status>` |
| Expected設計 | `system/06_verification_assets/検証結果・Expected設計書.md` | `<version>` | Expected／Result契約 | `<status>` |
| Diff設計 | `system/06_verification_assets/APIレスポンスDiff設計書.md` | `<version>` | Field Diff契約 | `<status>` |
| Baseline設計 | `system/05_framework/ExecutionState・Baseline管理設計書.md` | `<version>` | Baseline選択・更新 | `<status>` |
| Report設計 | `system/07_report/Report設計書.md` | `<version>` | Report契約 | `<status>` |

必須Referenceが`BLOCKED`または`BROKEN`の場合、本書を`FROZEN`にしてはならない。

## 7. Verification基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `VS-P001` | Java First | Check、抽出、Mapping、分岐およびCompare DefinitionはJavaへ明示する。 |
| `VS-P002` | Expected非Logic化 | ExpectedへScript、Class、任意式またはIgnore Policyを記載しない。 |
| `VS-P003` | Axis Separation | Execution、Verification、Change、Recoveryを独立した判定軸として扱う。 |
| `VS-P004` | Ignore非免責 | Diff IgnoreをRequired、Type、FixedまたはBusiness Checkの免責にしない。 |
| `VS-P005` | Stable Trace | Expected、Java Check、Result、Reportを`resultKey`で接続する。 |
| `VS-P006` | No Guess | 欠落Expected、Field、ClassまたはBaselineを他Scenarioから推測しない。 |
| `VS-P007` | Full Evidence | PASSだけでなくFAIL、BLOCKED、ERRORのEvidenceを保持する。 |
| `VS-P008` | No Duplicate SSOT | 本書へExpected値、Diff明細またはJava Logicを複製しない。 |
| `VS-P009` | Security | Secretおよび個人情報の実値を本書、Sample、Result表示へ保存しない。 |
| `VS-P010` | Reproducibility | Input、Expected、Build、BaselineおよびArtifact版を追跡可能にする。 |

## 8. Verification対象概要

### 8.1 Business／UseCase

| 項目 | 内容 |
|---|---|
| Business ID | `<BUS-E6-NNN>` |
| Business名称 | `<正式名称>` |
| UseCase ID | `<UC-E6-NNN>` |
| UseCase名称 | `<正式名称>` |
| Verification目的 | `<何が仕様どおりであることを確認するか>` |
| 業務上の重要結果 | `<終了状態、不変条件、更新結果>` |
| 主利用者 | `<Business Owner / API Team / Operation>` |

### 8.2 Environment

| Environment ID | 適用 | Production相当 | 実行制約 | Master状態 |
|---|:---:|:---:|---|---|
| `<ENV-XXX>` | `<Yes / No>` | `<Yes / No>` | `<Data／Window／Permission>` | `<enabled>` |

有効UseCaseから無効Environmentを参照してはならない。Production相当Environmentは、明示的承認、Test Data、影響範囲およびCleanup統制を必要とする。

## 9. 対象Scenario

| No | Scenario ID | Scenario名称 | 種別 | Input Ref | Expected Ref | Java Class Ref | 対象 | 状態 |
|---:|---|---|---|---|---|---|:---:|---|
| 1 | `<SC-E6-NNN>` | `<名称>` | `<NORMAL / ALTERNATIVE / EXCEPTION / BOUNDARY>` | `<inputRef>` | `<expectedRef>` | `<executionClass / BLOCKED>` | `<Yes>` | `<VALID / BLOCKED / BROKEN>` |

### 9.1 Scenario選定理由

| Scenario ID | 業務分岐／状態 | 固有Input条件 | 期待終了状態 | 他Scenarioとの差 |
|---|---|---|---|---|
| `<SC-E6-NNN>` | `<条件>` | `<条件>` | `<状態>` | `<独立Scenarioとする理由>` |

単一Fieldの必須、型、桁数または固定値Checkだけを理由にScenarioを分割しない。

### 9.2 Coverage Gap

| Gap ID | 未Coverage条件 | 影響 | 対応方針 | Owner | Release影響 |
|---|---|---|---|---|---|
| `<VGAP-NNN>` | `<条件>` | `<影響>` | `<Scenario追加 / Test追加 / 対象外承認>` | `<owner>` | `<BLOCK / CONDITIONAL / NONE>` |

Gapがない場合も`NONE`と明記する。

## 10. Verification Category

| Category | Code | 説明 | 対象有無 |
|---|---|---|:---:|
| Request Contract | `REQUEST_CONTRACT` | Header、Parameter、Bodyの契約 | `<Yes / No>` |
| Response Contract | `RESPONSE_CONTRACT` | HTTP Status、Header、Bodyの契約 | `<Yes / No>` |
| Flow | `FLOW_CONTROL` | 順序、分岐、Skip、Stop、Retry | `<Yes / No>` |
| Context | `CONTEXT_MAPPING` | 抽出、引継ぎ、Binding | `<Yes / No>` |
| Business | `BUSINESS_RESULT` | 固定値、状態、不変条件、入力一致 | `<Yes / No>` |
| Error | `ERROR_BEHAVIOR` | Business Error、Transport Error、Timeout | `<Yes / No>` |
| Change Observation | `RESPONSE_CHANGE` | Previous／Baselineとの差分 | `<Yes / No>` |
| Artifact | `ARTIFACT_INTEGRITY` | Result、Diff、Evidenceの完全性 | `<Yes / No>` |

## 11. Check共通定義

### 11.1 Check属性

| 項目 | 必須 | 内容 |
|---|:---:|---|
| `resultKey` | Yes | Expected、Java、Result、Reportを接続するStable Key |
| Check名称 | Yes | 人が理解できる名称 |
| Category | Yes | Verification Category |
| Scenario ID | Yes | 対象Scenario |
| API Call Code | 条件付き | API呼出に属する場合必須 |
| API ID | 条件付き | API呼出に属する場合必須 |
| 必須性 | Yes | `REQUIRED`または`OPTIONAL` |
| 重要度 | Yes | `CRITICAL／HIGH／MEDIUM／LOW` |
| Expected Ref | Yes | Expected Fileと`resultKey` |
| Java Check Ref | Yes | 実装Reference。未確定は`BLOCKED` |
| Evidence要求 | Yes | 必須Artifact |
| 集約影響 | Yes | Scenario Verification Resultへの影響 |

### 11.2 Check Coverage Matrix

| No | resultKey | Scenario ID | Category | API Call Code | Check意図 | 必須性 | 重要度 | Expected Ref | Java Check Ref | Evidence |
|---:|---|---|---|---|---|---|---|---|---|---|
| 1 | `<CALL-001_HTTP_STATUS>` | `<SC-E6-NNN>` | `RESPONSE_CONTRACT` | `<CALL-001>` | `<期待HTTP Statusを満たす>` | `REQUIRED` | `HIGH` | `<expectedRef#resultKey>` | `<classRef / BLOCKED>` | `<response / check result>` |
| 2 | `<SCENARIO_FINAL_STATE>` | `<SC-E6-NNN>` | `BUSINESS_RESULT` | `NONE` | `<期待終了状態を満たす>` | `REQUIRED` | `HIGH` | `<expectedRef#resultKey>` | `<classRef / BLOCKED>` | `<context / check result>` |

### 11.3 Stable Key規則

```text
Scenario設計のCheck意図
→ Expected.checks[].resultKey
→ Java VerificationCheck.resultKey()
→ verification-result.json checks[].resultKey
→ Report
```

`resultKey`の表示順または文字SortをCheck実行順序として使用しない。

### 11.4 必須Checkと任意Check

| 必須性 | 定義 | 非PASS時 |
|---|---|---|
| `REQUIRED` | Scenarioの期待成立に必要 | 集約優先順位へ反映 |
| `OPTIONAL` | 観測、補助診断または移行確認 | 影響を本書へ明示し、暗黙昇格しない |

## 12. Request Contract Check

### 12.1 Request Header／Parameter

| resultKey | Scenario ID | API Call Code | 対象 | Check種別 | 仕様Reference | 必須性 | Evidence |
|---|---|---|---|---|---|---|---|
| `<resultKey>` | `<scenarioId>` | `<apiCallCode>` | `<Header／Path／Query>` | `<REQUIRED／TYPE／PATTERN／FIXED>` | `<apiDesignRef#section>` | `<REQUIRED>` | `<requestRef>` |

Authorization、Cookie、Token等は存在確認またはMask状態だけを評価し、実値をExpectedまたはResult表示へ保存しない。

### 12.2 Request Body

| resultKey | API Call Code | JSON Path | Check種別 | 期待仕様Ref | 値のSource | 必須性 | Java Check Ref |
|---|---|---|---|---|---|---|---|
| `<resultKey>` | `<CALL-NNN>` | `<$.field>` | `<REQUIRED / NULL / TYPE / LENGTH / RANGE / PATTERN / ENUM / FIXED>` | `<API設計Section>` | `<Input / Context / Fixed>` | `<REQUIRED>` | `<classRef>` |

本表へ具体的Test Input値を複製しない。値はInput、期待はExpected、契約はAPI設計を参照する。

### 12.3 Request Mapping

| resultKey | API Call Code | Target Request Path | Source | Source Path／Key | 変換 | 欠落時 | Evidence |
|---|---|---|---|---|---|---|---|
| `<resultKey>` | `<CALL-NNN>` | `<$.requestField>` | `<INPUT / CONTEXT / PREVIOUS_RESPONSE>` | `<path / key>` | `<NONE / 明示変換>` | `<BLOCKED / ERROR>` | `<request + context>` |

Mapping Logicの正本はScenario詳細設計とJavaであり、本表はVerification Coverageを表す。

## 13. Response Contract Check

### 13.1 HTTP Status

| resultKey | Scenario ID | API Call Code | API ID | Expected Ref | 許容条件 | 必須性 | Java Check Ref |
|---|---|---|---|---|---|---|---|
| `<resultKey>` | `<scenarioId>` | `<CALL-NNN>` | `<API-NNN>` | `<expectedRef#resultKey>` | `<API設計Ref>` | `REQUIRED` | `<classRef>` |

異常Scenarioで4xxを期待する場合、4xx受信自体をExecution Errorとせず、API／Scenario設計とExpectedに従ってCheckする。

### 13.2 Response Header

| resultKey | API Call Code | Header | Check種別 | 仕様Reference | Mask | 必須性 |
|---|---|---|---|---|:---:|---|
| `<resultKey>` | `<CALL-NNN>` | `<header>` | `<REQUIRED / TYPE / PATTERN>` | `<apiDesignRef>` | `<Yes / No>` | `<REQUIRED / OPTIONAL>` |

### 13.3 Response Body

| resultKey | API Call Code | JSON Path | Check種別 | 仕様／Expected Ref | 必須性 | 重要度 | Java Check Ref |
|---|---|---|---|---|---|---|---|
| `<resultKey>` | `<CALL-NNN>` | `<$.field>` | `<REQUIRED / NULL / TYPE / LENGTH / RANGE / PATTERN / ENUM / FIXED>` | `<reference>` | `<REQUIRED>` | `<HIGH>` | `<classRef>` |

### 13.4 Array／Collection

| resultKey | API Call Code | Collection Path | 観点 | Key／順序 | 期待Ref | Java Check Ref |
|---|---|---|---|---|---|---|
| `<resultKey>` | `<CALL-NNN>` | `<$.items>` | `<件数 / 空 / 重複 / Key存在 / 順序>` | `<itemId / ORDERED / UNORDERED>` | `<reference>` | `<classRef>` |

ArrayのDiff比較方式とBusiness上の件数・Key Checkを同一処理として扱わない。

## 14. Business Result Check

| resultKey | Scenario ID | API Call Code | 業務期待 | Expected Ref | Actual Source | 必須性 | Java Check Ref |
|---|---|---|---|---|---|---|---|
| `<resultKey>` | `<SC-E6-NNN>` | `<CALL-NNN / NONE>` | `<状態、固定値、不変条件>` | `<expectedRef#resultKey>` | `<response / context>` | `REQUIRED` | `<classRef>` |

### 14.1 Input一致

| resultKey | Response Path | Input／Request Source | 比較意図 | Null／Missing規則 | Java Check Ref |
|---|---|---|---|---|---|
| `<resultKey>` | `<$.customerId>` | `<input.request.customerId>` | `<同一IDである>` | `<明示>` | `<classRef>` |

### 14.2 状態遷移

| resultKey | Before Source | Action | After Source | 期待遷移 | 許可しない遷移 | Java Check Ref |
|---|---|---|---|---|---|---|
| `<resultKey>` | `<context / response>` | `<CALL-NNN>` | `<response>` | `<A → B>` | `<A → C>` | `<classRef>` |

### 14.3 Scenario終了状態

| resultKey | 終了条件 | 期待終了状態 | Actual Source | 必須性 | Java Check Ref |
|---|---|---|---|---|---|
| `<SCENARIO_FINAL_STATE>` | `<条件>` | `<状態>` | `<ScenarioContext>` | `REQUIRED` | `<classRef>` |

## 15. Flow Control Check

### 15.1 API呼出順序

| resultKey | Scenario ID | 期待Call Code列 | Actual Source | 必須性 | Java Check Ref |
|---|---|---|---|---|---|
| `<resultKey>` | `<SC-E6-NNN>` | `<CALL-001 → CALL-002>` | `<Execution Trace>` | `<REQUIRED>` | `<classRef>` |

期待Call Code列の正本はScenario詳細設計である。本書へ別の順序定義を作成しない。

### 15.2 分岐

| resultKey | 分岐ID | 条件Source | 期待Branch | 非選択Branch | Evidence | Java Check Ref |
|---|---|---|---|---|---|---|
| `<resultKey>` | `<BR-NNN>` | `<context key>` | `<branch>` | `<expected skip>` | `<execution trace>` | `<classRef>` |

### 15.3 Skip／Stop／Continue

| resultKey | 発生条件 | 対象Call | 期待制御 | 実行Status表現 | 不一致時Check Result |
|---|---|---|---|---|---|
| `<resultKey>` | `<条件>` | `<CALL-NNN>` | `<SKIP / STOP / CONTINUE>` | `<Scenario設計に従う>` | `<FAIL / ERROR>` |

想定SkipはVerification Resultの`SKIP`ではない。必要なFlow Checkが期待どおりであれば、そのCheckは`PASS`を返す。

### 15.4 Retry／Timeout

| resultKey | API Call Code | 発生条件 | 期待Retry／Timeout | Idempotency前提 | Evidence | Java Check Ref |
|---|---|---|---|---|---|---|
| `<resultKey>` | `<CALL-NNN>` | `<Timeout>` | `<回数／時間／停止>` | `<成立条件>` | `<execution trace / log>` | `<classRef>` |

## 16. Context Check

### 16.1 Context生成

| resultKey | Producer | Source Path | Context Key | Type | 必須性 | 欠落時 | Java Check Ref |
|---|---|---|---|---|---|---|---|
| `<resultKey>` | `<CALL-NNN / INPUT>` | `<$.field>` | `<memberId>` | `<STRING>` | `REQUIRED` | `<BLOCKED / ERROR>` | `<classRef>` |

### 16.2 Context利用

| resultKey | Context Key | Consumer | Target Path | 比較意図 | Evidence | Java Check Ref |
|---|---|---|---|---|---|---|
| `<resultKey>` | `<memberId>` | `<CALL-NNN>` | `<$.memberId>` | `<同一値でBinding>` | `<context + request>` | `<classRef>` |

### 16.3 Context Lifetime

| resultKey | Context Key | 生成時点 | 有効範囲 | 破棄時点 | 禁止される共有 |
|---|---|---|---|---|---|
| `<resultKey>` | `<key>` | `<CALL後>` | `<Current Run>` | `<Scenario終了>` | `<別runId>` |

Context Masterは使用しない。Context KeyとMappingはScenario設計およびJavaへ明示する。

## 17. Error Behavior Check

### 17.1 想定Business Error

| resultKey | Scenario ID | API Call Code | 発生条件 | Expected Status／Code Ref | 期待制御 | Java Check Ref |
|---|---|---|---|---|---|---|
| `<resultKey>` | `<scenarioId>` | `<CALL-NNN>` | `<業務条件>` | `<expectedRef>` | `<STOP / CONTINUE>` | `<classRef>` |

### 17.2 Transport／Runtime Error

| resultKey | 事象 | Execution Status | Verification Result | 後続制御 | Evidence |
|---|---|---|---|---|---|
| `<resultKey>` | `<Timeout / Parse / I/O>` | `<INCOMPLETE / UNKNOWN_OUTCOME>` | `<NOT_EVALUATED>` | `<STOP>` | `<reason + evidence>` |

### 17.3 NOT_EVALUATEDとExecution Failure

| 状況 | Check Result | 理由 |
|---|---|---|
| 前提Checkが成立せず対象Actualを得られない | `NOT_EVALUATED` | 評価前提不足Reason |
| 想定分岐により後続Checkが評価対象外 | `NOT_EVALUATED`またはFlow Checkで吸収 | Scenario設計に明示 |
| `apiCallCode`がContextに存在しない | `NOT_EVALUATED` | Execution `INCOMPLETE`、設計／実装Reason |
| DTO型とCheck想定が一致しない | `NOT_EVALUATED` | Execution `INCOMPLETE`、契約／実装Reason |
| Expected必須値が欠落 | `NOT_EVALUATED` | 起動前Execution `REJECTED` |
| Actual業務値が期待と不一致 | `FAIL` | 評価成立、期待不成立 |

## 18. Response Diff／Change Check

### 18.1 Diff観測

| Scenario ID | API Call Code | API ID | Compare Definition Ref | Baseline Mode Ref | Diff必須 | Report表示 |
|---|---|---|---|---|:---:|---|
| `<scenarioId>` | `<CALL-NNN>` | `<API-NNN>` | `<Java classRef / BLOCKED>` | `<baselineDesignRef>` | `<Yes / No>` | `<Yes>` |

Compare Definitionの正本はJavaである。本書にJSON PathごとのIgnore Listを複製しない。

### 18.2 IgnoreとBusiness Check

| 条件 | Diff側 | Verification側 |
|---|---|---|
| `IGNORE_FIELD`の追加／削除／型／値変化 | Ignored Diff | 対象Checkがあれば通常評価 |
| `IGNORE_VALUE`の同一型値変化 | Ignored Diff | Required／Type／Range等を通常評価 |
| `IGNORE_VALUE`の追加／削除／型変化 | Effective Diff | API／Business仕様に従い評価 |
| 通常Fieldの変化 | Effective Diff | 専用Checkがある場合だけ期待評価 |

### 18.3 Changeを期待として評価する場合

Effective DiffをBusiness上のFAILまたはPASS条件にする場合だけ、専用Compare Checkを定義する。

| resultKey | API Call Code | Expected Change Status | Expected Ref | 必須性 | Java Check Ref |
|---|---|---|---|---|---|
| `<CALL-001_RESPONSE_COMPARE>` | `<CALL-001>` | `<UNCHANGED>` | `<expectedRef#resultKey>` | `<REQUIRED>` | `<classRef>` |

専用Checkがない場合、`CHANGED`をVerification Statusの`FAIL`へ自動変換しない。

### 18.4 初回

Baselineがない初回は次とする。

```text
comparisonStatus = NOT_COMPARED
changeStatus     = NOT_COMPARED
reason           = INITIAL_EXECUTION
```

初回を空JSONと比較したり、`PASS`または`UNCHANGED`と表示したりしない。

## 19. Expected Trace

### 19.1 Expected File

| Scenario ID | Input Set ID | Environment ID | Expected Ref | Expected Version | 状態 |
|---|---|---|---|---|---|
| `<SC-E6-NNN>` | `<INPUT-DEFAULT>` | `<ENV-XXX>` | `<system/04_usecase_design/expected/...>` | `<version>` | `<VALID / BLOCKED / BROKEN>` |

### 19.2 `resultKey`整合

| resultKey | Verification仕様 | Expected | Java Check | Result出力 | 整合 |
|---|:---:|:---:|:---:|:---:|---|
| `<resultKey>` | `<Yes>` | `<Yes>` | `<Yes / BLOCKED>` | `<Testで確認>` | `<PASS / FAIL / BLOCKED>` |

### 19.3 Expected禁止内容

- Java Class名、Method名または任意Script
- CheckのJSONPath抽出Logic
- API呼出順序、分岐、Skip
- `IGNORE_FIELD`または`IGNORE_VALUE`
- Previous／Baseline実値
- Current Actual、Check Result、Diff
- Credential、Token、Password

## 20. Java Check Trace

| resultKey | Logical Component | Java Class Ref | Method／Interface | Unit Test Ref | 状態 |
|---|---|---|---|---|---|
| `<resultKey>` | `<HTTP Status Check>` | `<FQCN / BLOCKED>` | `VerificationCheck` | `<testRef / BLOCKED>` | `<VALID / BLOCKED / BROKEN>` |

Java Source RootおよびBase Packageが未確定の場合、仮のFQCNを正式Referenceとして登録しない。`BLOCKED`としてOwnerと決定成果物を記載する。

## 21. Verification実行順序

```mermaid
flowchart TD
    A["Static Validation"] --> B["Input / Expected Load"]
    B --> C["Scenario Execution"]
    C --> D["Java Checks"]
    D --> E["Response Diff"]
    E --> F["Result Aggregation"]
    F --> G["Report / Evidence"]
```

詳細なAPI呼出順序はScenario詳細設計とJavaの正本に従う。

### 21.1 Pre-Execution Validation

| Rule ID | 確認内容 | NG時 |
|---|---|---|
| `<VS-PRE-001>` | Business、UseCase、Scenario、Environmentが有効である | `ERROR` |
| `<VS-PRE-002>` | API、Input、Expected Referenceが存在しIdentity一致する | `ERROR` |
| `<VS-PRE-003>` | 必須`resultKey`がExpectedとJavaで解決する | `BLOCKED / ERROR` |
| `<VS-PRE-004>` | Compare Definitionの重複Modeがない | `ERROR` |
| `<VS-PRE-005>` | Production実行承認とTest Data統制がある | `BLOCKED` |
| `<VS-PRE-006>` | Secret Referenceが解決し平文保存されていない | `ERROR` |

前処理Errorを実行後のBusiness FAILとして扱わない。

### 21.2 Check実行順

| Order | resultKey | 前提resultKey | 前提非PASS時 | 並列可否 |
|---:|---|---|---|:---:|
| 1 | `<resultKey>` | `NONE` | `NONE` | `<Yes / No>` |
| 2 | `<resultKey>` | `<resultKey>` | `<BLOCKED>` | `<Yes / No>` |

依存関係はJavaへ明示し、`resultKey`文字列Sortへ依存しない。

## 22. 判定軸

### 22.1 Execution Status

| Status | 意味 |
|---|---|
| `COMPLETED` | 必須処理とArtifact生成が完了した |
| `NOT_STARTED` | 実行実体は生成済みだが未開始 |
| `RUNNING` | 処理中 |
| `INCOMPLETE` | API、Parse、Context、I/Oまたは中断により完全Runにならなかった |
| `REJECTED` | Preflight不成立で実処理開始前に拒否 |
| `UNKNOWN_OUTCOME` | 更新API等の外部結果を断定不能 |

### 22.2 Verification Result

| Result | 意味 |
|---|---|
| `NOT_EVALUATED` | 前提不成立、対象外またはExecution Errorで未評価 |
| `PASS` | 評価でき、期待を満たした |
| `FAIL` | 評価できたが、期待を満たさなかった |

### 22.3 Change Status

| Status | 意味 |
|---|---|
| `UNCHANGED` | 比較完了かつEffective 0。Ignoredは存在可能 |
| `CHANGED` | 比較完了かつEffective 1以上 |
| `NOT_COMPARED` | 初回、Baselineなし、Responseなし等 |

### 22.4 Recovery Status

| Status | 意味 |
|---|---|
| `NOT_REQUIRED` | 運用介入不要 |
| `REQUIRED` | 状態確認、補償または手動判断が必要 |
| `IN_PROGRESS` | Recovery作業中 |
| `RESOLVED` | Recovery記録確定 |

四つの軸を一つの`overallStatus`へ潰してはならない。

## 23. Check Result集約

### 23.1 必須Check

```text
FAIL
  > NOT_EVALUATED
      > PASS
```

| 条件 | Scenario Verification Result |
|---|---|
| 必須Checkに`FAIL`が1件以上 | `FAIL` |
| 必須Checkに`NOT_EVALUATED`が1件以上、かつFAILなし | `NOT_EVALUATED` |
| 全必須Checkが`PASS` | `PASS` |

### 23.2 任意Check

| resultKey | 非PASS時の表示 | Scenario Resultへの影響 | 承認 |
|---|---|---|---|
| `<resultKey>` | `<Diagnostic Section>` | `<NONE / 明示Rule>` | `<owner>` |

任意Checkを使って未完成の必須Checkを回避してはならない。

### 23.3 合法な組合せ

| Execution | Verification | Change | Recovery | 例 |
|---|---|---|---|---|
| `COMPLETED` | `PASS` | `UNCHANGED` | `NOT_REQUIRED` | 業務期待成立、Ignored Fieldだけ変化 |
| `COMPLETED` | `PASS` | `CHANGED` | `NOT_REQUIRED` | 仕様追加を観測、専用FAIL Checkなし |
| `COMPLETED` | `FAIL` | `UNCHANGED` | `NOT_REQUIRED` | Baselineも同じだが期待自体に違反 |
| `INCOMPLETE` | `NOT_EVALUATED` | `NOT_COMPARED` | `NOT_REQUIRED` | Response取得不能 |
| `UNKNOWN_OUTCOME` | `NOT_EVALUATED` | `NOT_COMPARED` | `REQUIRED` | 更新APIの外部結果不明 |

## 24. Summary整合

```text
totalCount
=
passCount
+ failCount
+ notEvaluatedCount
```

Ignored Diff件数をCheckの`passCount`へ加算しない。

| Summary項目 | Source | 整合Rule |
|---|---|---|
| `totalCount` | Check Result | 4 Status合計 |
| `effectiveChangedCount` | Field Diff | 全API CallのEffective合計 |
| `ignoredDiffCount` | Field Diff | 全API CallのIgnored合計 |
| `notComparedApiCallCount` | Field Diff | NOT_COMPARED Call数 |
| `compareErrorCount` | Field Diff | ERROR Call数 |

## 25. Evidence要求

### 25.1 Check別Evidence

| resultKey | Evidence種別 | 必須 | Artifact Ref規則 | Mask | 欠落時 |
|---|---|:---:|---|:---:|---|
| `<resultKey>` | `<REQUEST / RESPONSE / CONTEXT / EXECUTION / DIFF / LOG>` | `<Yes / No>` | `<run root相対Path>` | `<Yes / No>` | `<ERROR / BLOCKED>` |

### 25.2 Status別Evidence

| Check Result | 必須Evidence |
|---|---|
| `PASS` | 評価対象とCheck Result |
| `FAIL` | Expected表示、Actual表示、根拠Artifact |
| `BLOCKED` | 未成立前提、依存Check、取得済みArtifact |
| `ERROR` | Error Code、Component、取得済みLog／Artifact |

### 25.3 Security

- Authorization、Token、Cookie、Passwordを保存しない。
- 個人情報は必要最小限とし、Mask済み表示を使用する。
- Java ExceptionへRequest／Response全体を無制限連結しない。
- DiffのPrevious／Current Valueにも同じMask定義を適用する。
- Mask失敗時に未Mask値へFallbackしない。

## 26. Test Trace

### 26.1 API単体Test

| Test ID | API ID | resultKey／契約観点 | Test Data Ref | Expected | Evidence | 状態 |
|---|---|---|---|---|---|---|
| `<TC-API-NNN>` | `<API-NNN>` | `<Required / Type / Status>` | `<testDataRef>` | `<testSpecRef>` | `<testResultRef>` | `<PASS / BLOCKED>` |

### 26.2 UseCase／Scenario Test

| Test ID | Scenario ID | Branch／Flow | 対象resultKey | Test Data Ref | Evidence | 状態 |
|---|---|---|---|---|---|---|
| `<TC-UC-NNN>` | `<SC-E6-NNN>` | `<Normal / Error / Boundary>` | `<resultKey list>` | `<testDataRef>` | `<testResultRef>` | `<PASS / BLOCKED>` |

### 26.3 Coverage Matrix

| Requirement／Design Ref | Scenario ID | resultKey | Java Check | Test ID | Coverage |
|---|---|---|---|---|---|
| `<reference>` | `<scenarioId>` | `<resultKey>` | `<classRef>` | `<testId>` | `<COVERED / GAP / BLOCKED>` |

## 27. Runtime Artifact Trace

| Artifact | 論理Path | Producer | Consumer | 必須 |
|---|---|---|---|:---:|
| Run Meta | `runs/{runId}/run-meta.json` | Runtime | Result／Report | Yes |
| Definition Snapshot | `runs/{runId}/run-meta.json`内 | Definition Resolver | Scenario／Check／Evidence | Yes |
| API Request | `runs/{runId}/api-calls/{apiCallCode}/request.json` | Executor | Check／Evidence | 条件付き |
| API Response | `runs/{runId}/api-calls/{apiCallCode}/response.json` | Executor | Check／Diff | 条件付き |
| Field Diff | `runs/{runId}/api-calls/{apiCallCode}/response-field-diff.json` | Comparator | Result／Report | 条件付き |
| Verification Result | `runs/{runId}/verification-result.json` | Aggregator | Report | Yes |
| Artifact Manifest | `runs/{runId}/artifact-manifest.json` | Artifact Publisher | Report／Baseline／Evidence | Yes |
| Reports | `runs/{runId}/reports/` | Report Generator | 利用者 | 条件付き |

物理Runtime RootはFile I/O設計で決定する。本書の論理PathをServer絶対Pathとして扱わない。

## 28. Report要求

| 表示項目 | Source | 必須 | 表示規則 |
|---|---|:---:|---|
| Execution Status | Verification Result | Yes | Verificationと別列 |
| Verification Result | Verification Result | Yes | Changeと別列 |
| Change Status | Field Diff／Verification Result | Yes | Ignoredを隠さない |
| Check Summary | Check Result | Yes | 4 Status別 |
| Effective Diff | Field Diff | Yes | Ignoredと分離 |
| Ignored Diff | Field Diff | Yes | 「変化なし」と表示しない |
| Initial／Not Compared Reason | Field Diff | 条件付き | Reasonを明示 |
| Evidence Link | Artifact | Yes | Run Root相対Reference |

Reportは本書やResultを再評価せず、既存結果を集約・表示する。

## 29. Baseline更新との境界

本書はBaselineを更新しない。更新可否は`ExecutionState・Baseline管理設計書.md`に従う。

| 条件 | 本書の扱い |
|---|---|
| Verification `PASS` | Baseline更新の必要条件候補であり十分条件ではない |
| Verification `FAIL` | 自動更新しない |
| Execution `INCOMPLETE／REJECTED／UNKNOWN_OUTCOME` | 更新禁止 |
| Artifact不完全 | 更新禁止 |
| Change `CHANGED` | 承認なしで自動固定しない |

## 30. Error Code

| Error Code | 発生条件 | Phase | Result／処理 |
|---|---|---|---|
| `VER-SPEC-001` | 必須Master Referenceが解決しない | Static Validation | Execution `REJECTED` |
| `VER-SPEC-002` | 有効Sourceが無効Targetを参照する | Static Validation | Execution `REJECTED` |
| `VER-SPEC-003` | Input／Expected Identity不一致 | Load | Execution `REJECTED` |
| `VER-SPEC-004` | 必須`resultKey`がExpectedにない | Load | Execution `REJECTED` |
| `VER-SPEC-005` | 必須Java Checkが解決しない | Pre-Execution | Execution `REJECTED` |
| `VER-SPEC-006` | `resultKey`重複 | Static Validation | Execution `REJECTED` |
| `VER-SPEC-007` | API Checkの`apiCallCode`がScenarioにない | Static Validation | Execution `REJECTED` |
| `VER-SPEC-008` | Compare Definitionが矛盾する | Pre-Execution | Execution `REJECTED` |
| `VER-SPEC-009` | 必須Evidenceが生成されない | Finalization | Execution `INCOMPLETE` |
| `VER-SPEC-010` | Secret／PII Maskに失敗する | Artifact Write | 保存停止、Execution `INCOMPLETE` |
| `VER-SPEC-011` | Summary式が成立しない | Finalization | Execution `INCOMPLETE` |
| `VER-SPEC-012` | ReportがSource Resultと不一致 | Report Validation | Report公開停止 |

Project共通Error Code体系が確定した場合はMigration Reviewを行い、無断Renameしない。

## 31. Static Validation

| Rule ID | 確認内容 | 判定 |
|---|---|---|
| `VS-V001` | Business、UseCase、Scenario、Environment IDがMasterへ解決する | ERROR |
| `VS-V002` | 有効UseCase／Scenarioが無効Targetを参照しない | ERROR |
| `VS-V003` | 対象ScenarioがUseCaseの完全な所属一覧と一致する | ERROR |
| `VS-V004` | `apiCallCode`がScenario内で一意でAPI Masterへ解決する | ERROR |
| `VS-V005` | Input、Expected Fileが存在しIdentity一致する | ERROR |
| `VS-V006` | Verification仕様の`resultKey`が一意である | ERROR |
| `VS-V007` | 必須`resultKey`がExpectedとJava Checkへ双方向解決する | ERROR／BLOCKED |
| `VS-V008` | API Call所属CheckのAPI Call Codeが存在する | ERROR |
| `VS-V009` | Check Category、必須性、重要度が許可Enumである | ERROR |
| `VS-V010` | Expectedへ禁止LogicまたはIgnore定義がない | ERROR |
| `VS-V011` | Compare DefinitionがJava Referenceである | BLOCKED |
| `VS-V012` | `IGNORE_FIELD`と`IGNORE_VALUE`に同一Patternが重複しない | ERROR |
| `VS-V013` | Evidence要求にSensitive Data統制がある | ERROR |
| `VS-V014` | Test Coverage GapにOwnerとRelease影響がある | BLOCKED |
| `VS-V015` | 廃止Masterまたは旧Policy Fileを参照しない | ERROR |

## 32. Review Checklist

### 32.1 Scope／Trace

- [ ] Verification目的がUseCaseの業務目的と一致する。
- [ ] 対象ScenarioがScenario Masterと一致する。
- [ ] 対象外が明示され、Coverage済みと誤解されない。
- [ ] 必須Referenceがすべて解決する。
- [ ] Current 5 Master以外をMasterとして参照していない。

### 32.2 Check

- [ ] 各Checkに一意な`resultKey`がある。
- [ ] 必須性、重要度、Expected Ref、Java Check Refがある。
- [ ] Request、Response、Flow、Context、Businessを混在させていない。
- [ ] Expected値を本書へ二重保持していない。
- [ ] Optional Checkで必須Gapを隠していない。

### 32.3 Diff／Result

- [ ] Diff IgnoreとBusiness Checkを分離している。
- [ ] `IGNORE_VALUE`の追加、削除、型変化をEffectiveとして扱う。
- [ ] Effective Changeを自動FAILにしていない。
- [ ] Execution、Verification、Change、Recoveryの4軸を分離している。
- [ ] 初回を`NOT_COMPARED`として扱う。

### 32.4 Java／Test

- [ ] Scenario Class、Check、Compare Definitionが解決する。
- [ ] Check実行順が文字Sortに依存しない。
- [ ] Unit／UseCase TestへTraceできる。
- [ ] Error、Blocked、BoundaryのTestがある。
- [ ] Java Source Root未確定時に仮ReferenceをPASS扱いしていない。

### 32.5 Evidence／Security

- [ ] `NOT_EVALUATED`、`PASS`、`FAIL`およびExecution／Recovery ProblemのEvidence要求がある。
- [ ] Secret、Token、Passwordを保存しない。
- [ ] PIIのMaskとRetention要求がある。
- [ ] Mask失敗時にArtifact公開を停止する。
- [ ] ReportがSource Resultを再判定しない。

## 33. 完了条件

本Verification仕様は次をすべて満たした場合に完成とする。

1. 対象Business、UseCase、ScenarioおよびEnvironmentが確定している。
2. 対象Scenarioの詳細設計、Input、Expectedが存在する。
3. 全必須Checkに`resultKey`、Expected Ref、Java Check RefおよびEvidence要求がある。
4. API契約、業務期待、Flow、Context、Errorおよび必要なDiff Coverageが説明される。
5. Coverage Gapが0件、またはOwnerとRelease判断が承認済みである。
6. Static Validationの`ERROR`および`BLOCKED`が0件である。
7. Security、Test、Runtime、Operation Reviewが完了している。
8. 廃止Master、YAML Compare Policyまたは未承認Registryへ依存しない。

## 34. Release Blocker

| Block ID | 内容 | 解消条件 | Owner |
|---|---|---|---|
| `<VER-BLOCK-NNN>` | `<必須Reference／Class／Test／承認の欠落>` | `<具体的条件>` | `<owner>` |

該当なしの場合は`NONE`と明記する。Blocker欄を削除して未解決事項を隠してはならない。

## 35. Open Issues

| Issue ID | 未決事項 | 暫定方針 | Owner | 決定成果物 | Release影響 |
|---|---|---|---|---|---|
| `<VER-ISSUE-NNN>` | `<事項>` | `<推測せず現状維持>` | `<owner>` | `<document>` | `<BLOCK / CONDITIONAL / NONE>` |

## 36. 禁止事項

- Verification仕様を新しいMasterとして扱う。
- Context、Verification、Verification Policy、Compare Policy Masterを復活させる。
- API呼出順序またはMappingの正本を本書へ移す。
- Expected値、Actual、Baseline実値またはDiff明細を本書へ複製する。
- ExpectedにJava Class、Script、式またはIgnore定義を記載する。
- Compare DefinitionをYAML、Masterまたは`common/policies/`へ保存する。
- Ignored Diffを削除し、変化がなかったように表示する。
- IgnoreをRequired、Type、Length、Fixed、EnumまたはBusiness Checkの免責にする。
- Verification Resultへ`WARN／SKIP／IGNORED`を追加する。
- 初回Diffを`PASS`または`UNCHANGED`にする。
- 未確定Java ClassまたはArtifact Pathを存在するものとして記載する。
- Secret、Token、Passwordまたは個人情報を平文で記載する。

## 37. Template利用手順

1. 対象UseCaseと全ScenarioをMasterから確定する。
2. Business Analysis、API設計、UseCase／Scenario設計のReferenceを解決する。
3. Verification CategoryとCoverage Gapを整理する。
4. Check Coverage Matrixへ`resultKey`と必須性を定義する。
5. Expected、Java Check、Test、EvidenceへのTraceを確定する。
6. Diff対象API CallとJava Compare Definition Referenceを確認する。
7. Static Validationを実行する。
8. `レビュー観点一覧.md`と本書ChecklistでReviewする。
9. Blockerが0件になった後、承認・Freeze手続を行う。

## 38. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | Current 5 Master、Java First、Expected／Diff分離および3判定軸に基づき全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | Baseline設計Referenceを`system/05_framework/`へ同期 | DRAFT |
| `2.0.0-draft.3` | 2026-07-27 | Framework横断Reviewにより四結果軸、Canonical Status、ReasonおよびBaseline境界へ統一 | DRAFT |
| `2.0.0-draft.4` | 2026-07-28 | Snapshot／Evidence設計に合わせ、Runtime Artifact TraceをDefinition Snapshot、Artifact Manifestおよび後生成Reportへ統一 | DRAFT |
| `2.0.0-draft.5` | 2026-07-29 | `REP-MIG-002／003`によるAPI Master／Exampleの最終File名移行に伴い、Current Referenceを同期。文書固有の責務と業務内容は変更なし。 | DRAFT |
