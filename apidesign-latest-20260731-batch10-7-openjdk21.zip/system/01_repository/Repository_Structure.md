---
title: Repository Structure
document_id: E6-API-VAL-REPOSITORY-STRUCTURE
version: 4.0.6
status: FROZEN
structure_status: FROZEN
migration_status: IN_PROGRESS
document_type: Repository Governance
system_name: E6 API Verification Platform
updated: 2026-07-31
---

# Repository Structure

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Repository Structure |
| 文書ID | `E6-API-VAL-REPOSITORY-STRUCTURE` |
| 対象システム | E6 API Verification Platform |
| 対象Root | Repository Root |
| 文書種別 | Repository構成・配置規約 |
| 版数 | `4.0.6` |
| 構成状態 | `FROZEN` |
| 移行状態 | `IN_PROGRESS` |
| 最終更新日 | 2026-07-31 |
| 作成責任 | Verification Platform Team |
| レビュー責任 | System Architect / Repository Owner / Runtime Lead |
| 承認責任 | System Owner |

## 2. 目的

本書は、E6 API Verification Platformにおける業務分析、Master、API／UseCase／Scenario設計、Framework設計、検証資産およびReport設計の**最終目標構成**を定義する。

本書は次の事項の正本である。

1. Repository内成果物の唯一の配置先
2. 業務分析、To-Be設計、実行資産およびRuntime成果物の責務境界
3. 5 Masterと詳細設計の関係
4. `05_framework`、`06_verification_assets`、`07_report`の責務分離
5. Example、Recoveryおよび正式成果物の識別
6. 旧構成から最終目標構成への移行規則
7. Directory追加・変更時のArchitecture Review条件

本書の`status: FROZEN`は、**目標構造と配置責務を凍結したこと**を示す。現在の物理Directoryおよび全Fileが移行済みであることは示さない。移行完了までは`migration_status: IN_PROGRESS`とする。

## 3. 設計判断の基準

本構成は、次の判断を統合して決定した。

| 判断ID | 判断 |
|---|---|
| `REP-D001` | MasterはBusiness、Environment、API、UseCase、Scenarioの5種類だけとする。 |
| `REP-D002` | API呼出順序、Mapping、分岐、CheckおよびCompare DefinitionはJava Firstとする。 |
| `REP-D003` | Scenario InputとExpectedはScenario単位の静的実行資産として管理する。 |
| `REP-D004` | Context、Baseline、Identity、Snapshot、File I/O、Recovery等の横断責務は`05_framework`へ統合する。 |
| `REP-D005` | Field Diffの検証責務は`06_verification_assets`、Report生成・表示責務は`07_report`へ分離する。 |
| `REP-D006` | Report TemplateはReport設計と同じ`07_report/templates`へ配置する。 |
| `REP-D007` | Runtime成果物、BaselineおよびExecution Stateの実体を`system/`へ保存しない。 |
| `REP-D008` | 旧Framework文書は移行入力であり、原文のまま現行正本へ復元しない。 |
| `REP-D009` | 架空Exampleと正式E6成果物をID、DirectoryおよびReferenceで分離する。 |
| `REP-D010` | Java source Root、Runtime物理RootおよびDeployment構成は関連設計の承認前に固定しない。 |

## 4. 適用範囲

### 4.1 対象

- `business/`
- `system/01_repository/`
- `system/02_master/`
- `system/03_api_design/`
- `system/04_usecase_design/`
- `system/05_framework/`
- `system/06_verification_assets/`
- `system/07_report/`
- `recovery/`の移行統制
- 上記設計が参照する論理Runtime成果物構造

### 4.2 本書で未確定とする対象

| 未確定対象 | 決定成果物 |
|---|---|
| `REP-CR-010`によるTop Level追加 | 2026-07-29に承認済み。第10バッチ第2段階で物理DirectoryとJava Scaffoldを作成。 |
| Java組織Base Package | `jp.co.mufg.e6.verifier`として入力確定済み。`システム設計書.md`を正本とする。 |
| Runtime物理Data Root | `ファイル入出力設計書.md`、`環境・Runtime構成設計書.md` |
| ContainerおよびDeployment配置 | `環境・Runtime構成設計書.md`、Deployment設計。Tomcatは非採用。 |
| Scheduler、Cronおよび運用Job配置 | 運用設計 |
| Retention、ArchiveおよびBackup期間 | 運用・監査設計 |
| Secret StoreおよびCredential実体 | Environment／Security設定 |

未確定項目を解決するために、未承認Directoryまたは仮の本番Pathを先行作成してはならない。

## 5. Repository構成原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `REP-P001` | 正本一意 | 同じ定義を複数Directoryへ複製しない。 |
| `REP-P002` | 責務分離 | As-Is分析、To-Be設計、静的実行資産、Runtime結果を分離する。 |
| `REP-P003` | Java First | 実行ロジックと判定ロジックはJava実装との双方向Traceを持つ。 |
| `REP-P004` | Runtime分離 | Run結果、BaselineおよびExecution Stateの実体をRepository設計領域へ保存しない。 |
| `REP-P005` | Relative Reference | Repository内ReferenceはRepository Root基準の相対Pathとする。 |
| `REP-P006` | 固定ID | File名、表示順、Directory名または更新日時を業務Identityとして使用しない。 |
| `REP-P007` | 変更統制 | Top Levelおよび`system/`直下DirectoryはArchitecture Reviewなしに追加・改名しない。 |
| `REP-P008` | 機密分離 | Secret、Token、Passwordおよび実CredentialをRepositoryへ保存しない。 |
| `REP-P009` | 生成物分離 | Build生成物およびRuntime出力を設計文書Directoryへ混在させない。 |
| `REP-P010` | 移行明示 | 旧Pathを暗黙利用せず、移行元、移行先、状態および完了条件を明示する。 |
| `REP-P011` | Example分離 | Exampleは900番台と`_Example`を使用し、正式Masterから参照しない。 |
| `REP-P012` | Recovery非正本 | `recovery/`の文書を設計、Master、JavaまたはRuntimeの正本として参照しない。 |

## 6. 凍結した最終目標構成

```text
repository/
├── business/
│   ├── README.md
│   ├── templates/
│   │   ├── 現行業務分析書_Template.md
│   │   ├── BA分析書×シナリオ一覧_Template.md
│   │   └── API分析書_Template.md
│   ├── flows/
│   │   └── {businessCode}/
│   │       ├── 現行業務分析書.md
│   │       └── BA分析書×シナリオ一覧.md
│   ├── API分析書/
│   │   ├── API一覧.md
│   │   ├── API依存関係一覧.md
│   │   ├── API呼出シーケンス一覧.md
│   │   ├── API共通仕様一覧.md
│   │   ├── APIエラーコード一覧.md
│   │   ├── API認証方式一覧.md
│   │   ├── APIレスポンスコード一覧.md
│   │   └── API-{NNN}分析書.md
│   └── examples/
│
├── system/
│   ├── 01_repository/
│   │   ├── Repository_Structure.md
│   │   ├── 文書作成規約.md
│   │   ├── 命名規約.md
│   │   ├── トレーサビリティ規約.md
│   │   ├── レビュー観点一覧.md
│   │   └── 用語集.md
│   │
│   ├── 02_master/
│   │   ├── README.md
│   │   ├── Business_Master.md
│   │   ├── Environment_Master.md
│   │   ├── API_Master.md
│   │   ├── UseCase_Master.md
│   │   ├── Scenario_Master.md
│   │   ├── API_UseCase_Scenario対応表.md
│   │   ├── design/
│   │   │   ├── Master共通設計書.md
│   │   │   ├── Business_Master設計書.md
│   │   │   ├── Environment_Master設計書.md
│   │   │   ├── API_Master設計書.md
│   │   │   ├── UseCase_Master設計書.md
│   │   │   ├── Scenario_Master設計書.md
│   │   │   └── API・UseCase・Scenario対応表設計書.md
│   │   ├── guide/
│   │   │   ├── Master作成・更新ガイド.md
│   │   │   └── Master_ID・Reference記述ガイド.md
│   │   ├── checklist/
│   │   │   ├── MasterレビューChecklist.md
│   │   │   └── Master整合性Checklist.md
│   │   └── examples/
│   │       ├── Business_Master_Example.md
│   │       ├── Environment_Master_Example.md
│   │       ├── API_Master_Example.md
│   │       ├── UseCase_Master_Example.md
│   │       ├── Scenario_Master_Example.md
│   │       └── API_UseCase_Scenario対応表_Example.md
│   │
│   ├── 03_api_design/
│   │   ├── API設計書_Template.md
│   │   ├── API-{NNN}設計書.md
│   │   └── examples/
│   │       └── API-{9NN}設計書_Example.md
│   │
│   ├── 04_usecase_design/
│   │   ├── UseCase設計書_Template.md
│   │   ├── Scenario入力データ設計書.md
│   │   ├── UC-{systemCode}-{NNN}設計書.md
│   │   ├── scenario/
│   │   │   └── SC-{systemCode}-{NNN}設計書.md
│   │   ├── input/
│   │   │   └── SC-{systemCode}-{NNN}-input.json
│   │   ├── expected/
│   │   │   └── SC-{systemCode}-{NNN}-expected.json
│   │   └── examples/
│   │       ├── UC-{systemCode}-{9NN}設計書_Example.md
│   │       ├── scenario/
│   │       │   └── SC-{systemCode}-{9NN}設計書_Example.md
│   │       ├── input/
│   │       │   └── SC-{systemCode}-{9NN}-input_Example.json
│   │       └── expected/
│   │           └── SC-{systemCode}-{9NN}-expected_Example.json
│   │
│   ├── 05_framework/
│   │   ├── Framework設計入力・決定事項一覧.md
│   │   ├── システム設計書.md
│   │   ├── 共通Identity・Resultモデル設計書.md
│   │   ├── 共通Framework設計書.md
│   │   ├── Framework・業務定義連携設計書.md
│   │   ├── ScenarioContext設計書.md
│   │   ├── ExecutionState・Baseline管理設計書.md
│   │   ├── Snapshot・Evidence設計書.md
│   │   ├── ファイル入出力設計書.md
│   │   ├── ログ・例外・Recovery設計書.md
│   │   └── 環境・Runtime構成設計書.md
│   │
│   ├── 06_verification_assets/
│   │   ├── 検証結果・Expected設計書.md
│   │   ├── APIレスポンスDiff設計書.md
│   │   ├── Verification仕様書_Template.md
│   │   ├── execution_spec/
│   │   │   └── Execution仕様書_Template.md
│   │   ├── api_test_spec/
│   │   │   └── API単体テスト仕様書_Template.md
│   │   ├── usecase_test_spec/
│   │   │   └── UseCaseテスト仕様書_Template.md
│   │   ├── test_data/
│   │   │   └── TestData設計書.md
│   │   └── common/
│   │       └── schemas/
│   │           ├── scenario-input.schema.json
│   │           ├── scenario-expected.schema.json
│   │           ├── verification-result.schema.json
│   │           ├── response-field-diff.schema.json
│   │           ├── execution-state.schema.json
│   │           ├── baseline-meta.schema.json
│   │           ├── artifact-manifest.schema.json
│   │           ├── definition-bundle.schema.json
│   │           ├── run-meta.schema.json
│   │           ├── scenario-execution.schema.json
│   │           ├── api-meta.schema.json
│   │           ├── batch-verification-result.schema.json
│   │           ├── scenario-summary.schema.json
│   │           ├── diff-report.schema.json
│   │           ├── evidence-index.schema.json
│   │           └── daily-summary.schema.json
│   │
│   └── 07_report/
│       ├── Report設計書.md
│       └── templates/
│           ├── DailySummary_Template.md
│           ├── DiffReport_Template.md
│           └── EvidenceReport_Template.md
│
└── recovery/
    └── legacy_05_framework/
        ├── 05_framework移行判定表.md
        └── （旧05_framework設計書群）
```

`{NNN}`、`{9NN}`、`{systemCode}`および`{businessCode}`は説明用Placeholderであり、物理File名またはDirectory名へ波括弧を残してはならない。

## 7. Top Level責務

| Directory | 責務 | 正本性 | 保存禁止 |
|---|---|---|---|
| `project/` | 要件、WBS、Schedule、QA、Issue／Risk | Project管理正本 | Java Source、Build生成物、Runtime結果 |
| `business/` | As-Is業務、現行API分析、調査結果 | 業務分析正本 | To-Be実行ロジック、Runtime結果 |
| `system/` | To-Be設計、Master、Template、静的Scenario／検証資産 | システム設計正本 | Secret、Build生成物、Runtime結果 |
| `runtime/` | Java Source、Test、Maven Descriptor、非Web Batch Application | 実装正本 | Runtime結果、Environment Secret |
| `build/` | Release組立、Checksum、SBOM、Build Report | Build定義正本 | E6 API接続、永続Runtime Data |
| `staging/` | 同一Release Unitの本番リリース前検証定義 | Staging定義正本 | 再Compile、実Credential、実Run Data |
| `outputs/` | Local Runtime Data Root | 非正本の可変実行Data | Java Source、Release、Git登録 |
| `recovery/` | 旧成果物の移行入力と移行判定 | 非正本 | 現行Reference、Runtime参照、新規正式設計 |

Java Source、Build、StagingおよびLocal Runtime DataのTop Level構成は、`REP-CR-010`として承認済みであり、第10バッチ第2段階で物理Directoryを作成した。

### 7.1 第10バッチTop Level承認構成

本候補は、初期Repository設計の`project / runtime / build / staging / outputs`責務を、現行の5 Master、Java First、Immutable Release、Runtime Data外置および5段階Trace Gateへ適合させたものである。

```text
repository/
├── project/
│   ├── README.md
│   ├── 要件定義書.md
│   ├── WBS.md
│   ├── スケジュール.md
│   ├── QA一覧.md
│   └── 課題・リスク管理表.md
├── business/
├── system/
├── runtime/
│   ├── README.md
│   ├── pom.xml
│   ├── mvnw
│   ├── mvnw.cmd
│   ├── .mvn/wrapper/
│   └── modules/
│       ├── verifier-core/
│       ├── verifier-definition/
│       ├── verifier-verification/
│       ├── verifier-adapters/
│       ├── verifier-scenarios-e6/
│       ├── verifier-app/
│       └── verifier-contract-tests/
├── build/
│   ├── README.md
│   ├── scripts/
│   ├── docker/
│   ├── work/
│   ├── reports/
│   └── release/
├── staging/
│   ├── README.md
│   ├── compose/
│   ├── config-template/
│   ├── smoke/
│   └── fixtures/
├── outputs/
│   ├── README.md
│   ├── execution-state/
│   ├── baseline/
│   ├── runs/
│   └── batches/
└── recovery/
```

| Directory | 追加後の責務 | Git境界 |
|---|---|---|
| `project/` | 要件、WBS、Schedule、QA、Issue／RiskのProject管理正本 | Markdown管理対象 |
| `runtime/` | Java source、test、Build descriptorおよび実行Applicationの正本 | Source／Test／Wrapperを管理 |
| `build/` | Release組立、Docker Build、Checksum、SBOM、ProvenanceおよびBuild Report | Script／Docker定義だけを管理し、`work / reports / release`生成物は除外 |
| `staging/` | 同一Release Unitを使用する本番リリース前検証定義、Config Template、Smoke Contract | Secret、実Credential、実Run Dataを除外 |
| `outputs/` | Local実行時の`runtimePublishedRoot`既定Adapter Root | `README.md`とIgnore規則以外をGit対象外 |

`runtime/`はJava工程、`outputs/`は可変Runtime Dataであり、同じ「Runtime」という語を理由に統合してはならない。`staging/`はEnvironment定義であり、Build Pipelineの一時StageまたはRelease保管先として使用しない。

本変更要求IDを`REP-CR-010`、状態を`APPROVED / IMPLEMENTED`とする。Repository構造はMajor Version `4.0.0`へ更新し、Directory、`.gitignore`、Maven Descriptor、Java ScaffoldおよびRegistry Contract Test Sourceを同一Change Setで作成した。Java互換性基線は後続の`REP-CR-011`で17へ変更し、Directory構造を変更せずRepository Version `4.0.1`へ更新した。

### 7.2 JDK 17互換性変更

`REP-CR-011`の状態を`APPROVED / IMPLEMENTED`とし、次を同一Change Setで変更する。

| 項目 | 契約 |
|---|---|
| Java compile release | `17` |
| Build／CI最低JDK | `17` |
| Runtime最低JDK | `17` |
| 上位JDK | JDK 21等での実行を許可する |
| Source制約 | Java 18以降だけで利用可能なAPI／言語仕様を禁止する |
| 非変更対象 | Spring Boot 4.1.0、Maven Wrapper 3.9.16、7 Module、非Web、Tomcat非採用、第1段階Spring Batch非採用 |

`REP-CR-011`はDirectory追加、Module分割変更またはBase Package変更を含まない。

### 7.3 本番Environment区分変更

`REP-CR-012`の状態を`APPROVED / IMPLEMENTED`とし、次を同一Change Setで変更する。

| 項目 | 契約 |
|---|---|
| `ENV-PROD` | E6本番Environment |
| Environment Type | `PRODUCTION` |
| 廃止Type | `PRODUCTION_LIKE` |
| 廃止列 | `productionLike` |
| Environment Master | 固定10列から固定9列へ変更 |
| 本番実行可否 | 未承認。`ENV-PROD enabled=false`を維持 |
| Staging | 本番リリース前検証Environment。Production-like Environmentとして扱わない |

`REP-CR-012`はDirectory、Environment ID、Base URL Reference、Authentication ReferenceまたはJava Module構造を変更しない。

### 7.4 Maven＋Plain Java変更

`REP-CR-013`の状態を`APPROVED / IMPLEMENTED`とし、次を同一Change Setで変更する。

| 項目 | 契約 |
|---|---|
| Build Tool | Maven Wrapper 3.9.16を継続使用 |
| Java | compile release／最低Runtime Version 17 |
| Application Framework | なし。Plain Java CLI |
| Composition | Constructorと`VerifierComposition`による明示組立 |
| Entry Point | 普通の`main(String[] args)` |
| Logging | JDK標準`java.util.logging` |
| Packaging | Maven Shadeによる単一の実行可能JAR |
| Dependency Gate | Spring Boot／Spring Frameworkの直接・推移依存をMaven Enforcerで禁止 |
| Release情報境界 | Application JARから`META-INF/maven/**`を除外し、POM／Wrapper／Source／Testを本番Release Unitへ含めない |
| 非採用 | Spring Boot、Spring Framework、Spring Batch、Tomcat／Servlet Container |
| 非変更対象 | 7 Module、Base Package、明示Registry、Master、EnvironmentおよびRuntime Data契約 |

Spring Boot Parent、Starter、Boot Maven Plugin、Annotation、Application ContextおよびSpring専用Configを現行実装から削除する。過去Versionの改訂履歴とMigration Evidenceに残るSpring Boot記述は当時の事実として保持し、Current DependencyまたはCurrent Decisionとして解釈しない。

`REP-CR-013`はTop Level、`system/`直下Directory、Module分割、Base Package、Master列またはEnvironment IDを変更しない。

### 7.5 OpenJDK 21基線訂正

`REP-CR-014`の状態を`APPROVED / IMPLEMENTED`とし、現行Java基線を次のとおり訂正する。

| 項目 | 契約 |
|---|---|
| Java Distribution | 銀行承認済みOpenJDK Distribution |
| Java compile release | `21` |
| Build／CI JDK | OpenJDK 21 |
| Runtime最低JDK | OpenJDK 21 |
| Build許可Major | 21だけ。Maven Enforcerは`[21,22)`を要求する |
| Source制約 | Java 22以降だけで利用可能なAPI／言語仕様を禁止する |
| Build Gate | Release Build開始時にJava仕様Version 21とOpenJDK Runtime名を検査する |
| 非変更対象 | Maven Wrapper 3.9.16、7 Module、Plain Java CLI、Spring非採用、Base Package、Master、EnvironmentおよびRuntime Data契約 |

`REP-CR-011`のJDK 17基線は過去Versionの決定履歴として保持するが、現行Build／Runtime契約には適用しない。現行契約は`REP-CR-014`を優先する。

## 8. `business/`配置規則

### 8.1 構成

| 配置 | 責務 |
|---|---|
| `README.md` | 対象業務、作成順、Owner、更新規則 |
| `templates/` | 現行業務分析、BA×Scenario一覧、API分析のTemplate |
| `flows/{businessCode}/` | 7業務Flowごとの正式分析 |
| `API分析書/` | API横断一覧と1 API単位の現行分析 |
| `examples/` | 架空またはMask済みの作成例 |

### 8.2 Trace

```text
現行業務分析書
→ BA分析書×シナリオ一覧
→ Business／API／UseCase／Scenario Master
→ API／UseCase／Scenario詳細設計
→ Java実装
→ Verification Result／Evidence
```

`business/`のMarkdownをRuntimeが直接読み込んで実行してはならない。

## 9. `system/01_repository/`

| File | 責務 |
|---|---|
| `Repository_Structure.md` | Directory、配置、移行および変更統制 |
| `文書作成規約.md` | Markdown、Front Matter、表、Mermaid |
| `命名規約.md` | ID、File、Class、JSON Key |
| `トレーサビリティ規約.md` | BusinessからEvidenceまでのTrace |
| `レビュー観点一覧.md` | 成果物別Review観点 |
| `用語集.md` | 用語、略称、禁止同義語 |

本書と他のRepository規約が競合する場合、Directoryおよび配置については本書を優先し、競合文書を移行Taskとして修正する。

## 10. `system/02_master/`

### 10.1 正式Master

Masterは次の5種類だけとする。

1. Business Master
2. Environment Master
3. API Master
4. UseCase Master
5. Scenario Master

`API_UseCase_Scenario対応表.md`はMasterではなく、5 Masterから作成するTraceability Viewである。

### 10.2 API MasterのFile名

最終目標File名は次とする。

```text
system/02_master/API_Master.md
```

旧File名`E6_API_Master.md`からの移行は、`REP-MIG-002`および`REP-MIG-003`として完了した。Master設計書、Guide、Checklist、Example、Traceability規約、用語集および全Referenceを同一Change Setで更新し、文書IDとMasterの10列構造は維持した。

旧File名をCurrent Referenceとして再導入してはならない。

System差異はFile名ではなく、各Recordの`system_id`または対応する正式列で表現する。

### 10.3 復元禁止Master

- Context Master
- Verification Master
- Verification Policy Master
- Compare Policy Master

旧資料に名称またはPathが残っていても、新Fileまたは新Directoryを作成して復元してはならない。

### 10.4 `02_master`変更統制

`02_master`配下のDirectory、Master種別または正式列を変更する場合は、次を同一Change Setで更新する。

- `README.md`
- 対象Master
- `design/`
- `guide/`
- `checklist/`
- `examples/`
- 本書

## 11. `system/03_api_design/`

### 11.1 正式配置

```text
system/03_api_design/API-{NNN}設計書.md
```

1 APIにつき1詳細設計書を原則とする。Request／Responseが大きいことだけを理由に、未承認Subdirectoryを追加しない。

### 11.2 正式とExample

| 区分 | ID | 配置 | 正式Master参照 |
|---|---|---|---|
| 正式API | `API-001`等 | Root直下 | 可 |
| Example | `API-901`等 | `examples/` | 禁止 |

旧`API-001／002`の架空設計は`recovery/synthetic_001_member_model/`へ隔離済みであり、正式APIとして参照してはならない。

## 12. `system/04_usecase_design/`

### 12.1 責務

| 成果物 | 配置 | 正本責務 |
|---|---|---|
| UseCase詳細設計 | Root直下 | 業務目的、範囲、Actor、Trigger、共通前提 |
| Scenario詳細設計 | `scenario/` | API呼出順序、分岐、Skip、Mapping、Java Trace |
| Scenario Input | `input/` | 外部から与えるScenario初期値 |
| Scenario Expected | `expected/` | `result_key`単位の期待結果 |
| Example | `examples/` | 架空の設計・Input・Expected例 |

### 12.2 Expectedの確定配置

```text
system/04_usecase_design/expected/{scenarioId}-expected.json
```

Expectedの共通契約が`06_verification_assets/`にあることを理由に、Expected実体を`06`へ移動してはならない。

### 12.3 Reference

| Master項目 | Reference先 |
|---|---|
| `UseCase_Master.use_case_design_ref` | `system/04_usecase_design/UC-...設計書.md` |
| `Scenario_Master.scenario_design_ref` | `system/04_usecase_design/scenario/SC-...設計書.md` |
| `Scenario_Master.input_ref` | `system/04_usecase_design/input/SC-...-input.json` |
| `Scenario_Master.expected_ref` | `system/04_usecase_design/expected/SC-...-expected.json` |

既存Masterの列名がcamelCaseである場合は、Master設計の移行判断なしに本書の例だけを根拠として変更しない。

## 13. `system/05_framework/`

### 13.1 責務

`05_framework`は、API検証Platform全体を成立させる横断設計の正本である。旧`05_framework`を原文復元するDirectoryではなく、現行Java First契約に基づいて再設計する。

| File | 責務 |
|---|---|
| `Framework設計入力・決定事項一覧.md` | 設計入力、確定事項、未決事項、依存関係、決定Owner |
| `システム設計書.md` | Platform境界、Component、処理Flow、非機能、外部Interface |
| `共通Identity・Resultモデル設計書.md` | Run、Batch、Scenario、API Call、Check、Diff、ResultのIdentityと集約 |
| `共通Framework設計書.md` | Runner、Builder、Client、Registry、Lifecycle、Java Interface |
| `Framework・業務定義連携設計書.md` | Master、API、UseCase、Scenario、Java、Evidence間の連携 |
| `ScenarioContext設計書.md` | ScenarioContext、ApiExchange、Variable、Concurrency |
| `ExecutionState・Baseline管理設計書.md` | Execution Identity、Previous Run、Baseline選択・更新 |
| `Snapshot・Evidence設計書.md` | Request／Response Snapshot、Evidence、Artifact Manifest |
| `ファイル入出力設計書.md` | Path、Serialization、Atomic Write、Encoding、Integrity |
| `ログ・例外・Recovery設計書.md` | Log、Exception分類、Timeout、中断、再開、Recovery |
| `環境・Runtime構成設計書.md` | Environment差異、Runtime構成、Credential参照、実行前提 |

### 13.2 配置しない設計

- API Field Diff詳細は`06_verification_assets/APIレスポンスDiff設計書.md`
- Report生成・表示詳細は`07_report/Report設計書.md`
- Runtime実体は`{runtime_data_root}/`
- Java sourceは承認後のSource Root

### 13.3 旧文書の利用

`recovery/legacy_05_framework/`の文書は、各新設計書のRequirement Inputとして比較利用できる。ただし、新設計書から旧文書をNormative Referenceとして参照してはならない。

## 14. `system/06_verification_assets/`

### 14.1 責務

| 配置 | 責務 |
|---|---|
| `検証結果・Expected設計書.md` | Expected契約、Check Result、集約規則 |
| `APIレスポンスDiff設計書.md` | Current、Previous、Baseline間のField Diff |
| `Verification仕様書_Template.md` | Scenario／Release単位の検証仕様Template |
| `execution_spec/` | 実行条件とExecution仕様 |
| `api_test_spec/` | 1 API単位のTest仕様 |
| `usecase_test_spec/` | UseCase／Scenario連鎖のTest仕様 |
| `test_data/` | Test Data設計 |
| `common/schemas/` | Runtime契約JSON Schemaの正本 |

### 14.2 Schema

第8バッチの初期7 Schemaと、第9バッチ第2段階で責務Review後に追加した9 Schemaを合わせ、現行Platform共通Schemaは16種類とする。

| 順序 | Schema | 主対象 | 内容状態 |
|---:|---|---|---|
| 1 | `scenario-input.schema.json` | `04_usecase_design/input/`のScenario Input | 已给出内容／正式Review待办 |
| 2 | `scenario-expected.schema.json` | `04_usecase_design/expected/`のScenario Expected | 已给出内容／正式Review待办 |
| 3 | `verification-result.schema.json` | Run／BaselineのVerification Result | 已给出内容／机械验证通过／正式Review待办 |
| 4 | `response-field-diff.schema.json` | API Call単位のResponse Field Diff | 已给出内容／机械验证通过／正式Review待办 |
| 5 | `execution-state.schema.json` | Execution Identity単位のExecution State | 已给出内容／机械验证通过／正式Review待办 |
| 6 | `baseline-meta.schema.json` | Baseline Metadata／Artifact Inventory | 已给出内容／机械验证通过／正式Review待办 |
| 7 | `artifact-manifest.schema.json` | Core Run Artifact Manifest | 已给出内容／机械验证通过／正式Review待办 |
| 8 | `definition-bundle.schema.json` | Sealed Definition Bundle | 已给出内容／机械验证通过／正式Review待办 |
| 9 | `run-meta.schema.json` | Run Trace Metadata | 已给出内容／机械验证通过／正式Review待办 |
| 10 | `scenario-execution.schema.json` | Scenario実行・Branch・Call Disposition | 已给出内容／机械验证通过／正式Review待办 |
| 11 | `api-meta.schema.json` | API Call実行・Dispatch・Artifact Metadata | 已给出内容／机械验证通过／正式Review待办 |
| 12 | `batch-verification-result.schema.json` | Batch四軸集約とScenario Source | 已给出内容／机械验证通过／正式Review待办 |
| 13 | `scenario-summary.schema.json` | Scenario Summary Report JSON | 已给出内容／机械验证通过／正式Review待办 |
| 14 | `diff-report.schema.json` | Diff Report JSON | 已给出内容／机械验证通过／正式Review待办 |
| 15 | `evidence-index.schema.json` | Evidence Index JSON | 已给出内容／机械验证通过／正式Review待办 |
| 16 | `daily-summary.schema.json` | Daily Summary Report JSON | 已给出内容／机械验证通过／正式Review待办 |

Schema内容はFramework Draftとの横断整合、機械Validationおよび正式Role Reviewを分離する。現行16 Schemaの正文作成、Draft 2020-12 Compile、正反例Contract TestおよびSchema外Semantic境界Testは完了したが、正式承認、Java Writer／Reader実装またはRuntime Releaseを意味しない。File名だけを根拠に空Schemaを作成してはならない。

Schema共通契約は次のとおりとする。

| 項目 | 契約 |
|---|---|
| Dialect | JSON Schema Draft 2020-12 |
| File名 | Version非埋込みの凍結File名 |
| `$id` | `urn:e6-api-verification:schema:{artifact-name}:{major}.{minor}` |
| Instance Version | `schemaVersion`のMajor.Minor |
| Patch Trace | Source Revision、Release Digest、Content Hash |
| Java DTO | 永続JSONではSchemaを機械契約とし、DTO／Serializer／Loaderが緩和しない。 |

### 14.2.1 Runtime Artifact Coverage

現行16 Schemaと論理Runtime／Static／Report JSONのCoverageは次のとおりとする。

| Runtime／Static JSON | Schema | 方針 |
|---|---|---|
| Scenario Input | `scenario-input.schema.json` | 対象 |
| Scenario Expected | `scenario-expected.schema.json` | 対象 |
| `verification-result.json` | `verification-result.schema.json` | 対象 |
| `response-field-diff.json` | `response-field-diff.schema.json` | 対象 |
| `execution-state.json` | `execution-state.schema.json` | 対象 |
| `baseline-meta.json` | `baseline-meta.schema.json` | 対象 |
| `artifact-manifest.json` | `artifact-manifest.schema.json` | 対象 |
| Definition Bundle | `definition-bundle.schema.json` | Sealed Definition Projectionを対象 |
| `run-meta.json` | `run-meta.schema.json` | Run Trace Envelopeを対象 |
| `scenario-execution.json` | `scenario-execution.schema.json` | Scenario／Branch／Call Dispositionを対象 |
| `api-meta.json` | `api-meta.schema.json` | API Call実行事実を対象 |
| `batch-verification-result.json` | `batch-verification-result.schema.json` | Scenario Resultと分離したBatch集約を対象 |
| API固有`request.json`／`response.json` | 初期7の対象外 | API詳細設計／DTO／API固有Contractで検証する。 |
| `scenario-summary.json` | `scenario-summary.schema.json` | Scenario表示Projectionを対象 |
| `diff-report.json` | `diff-report.schema.json` | Diff表示Projectionを対象 |
| `evidence-index.json` | `evidence-index.schema.json` | Manifest／Artifact索引を対象 |
| `daily-summary.json` | `daily-summary.schema.json` | Batch表示Projectionを対象 |
| Recovery Case／Action／Audit | 初期7の対象外 | 外部Store契約と追加Schema要否をReviewする。 |

未対象Artifactを既存Schemaの`oneOf`へ便宜的に混在させてはならない。追加SchemaはProducer、Consumer、Identity、Version、MigrationおよびRepository影響を明示し、Freeze Change Controlに従って承認する。

### 14.2.2 Trace Validation Coverage

第9バッチのTrace Validationは新しいDirectory、Masterまたは専用Registry Fileを追加せず、既存正本とRuntime成果物からProjectionを導出する。

| Gate | 対象 | 現行Coverage |
|---|---|---|
| `TRACE-STATIC` | Master、03／04設計、Input／Expected、Schema | 契約定義済み。正式E6レコード0件のため正式Data検証は`BLOCKED`。 |
| `TRACE-BUILD` | Java Registry、Class、DTO、Build Identity | `runtime/`、7 Module、明示RegistryおよびContract Test Sourceを実装済み。OpenJDK 21基線への静的同期は通過したが、OpenJDK 21 Compiler／依存Repository環境GateによりMaven Build／Contract Testは未完。正式DTO／Scenarioは0件のため正式Class Traceも未完了。 |
| `TRACE-SEAL` | Definition Bundle、Run Request、Environment | Bundle Schema正文・機械Validation済み。Java Resolver／正式Data未実装のため`BLOCKED`。 |
| `TRACE-RUNTIME` | Run Meta、Result、Diff、Manifest、Core Artifact | 共通Metadata／Result／Diff／Manifest Schema Coverage完成。Java Writer／ReaderとRuntime Contract Test未実施のため`BLOCKED`。 |
| `TRACE-REPORT` | Report Set、Result／Diff／Manifestへの逆引き | Batch Resultと4 Report Schema正文・機械Validation済み。Report Generator／公開Contract Test未実施のため`BLOCKED`。 |

Schema未対象、Java未実装または正式Data不存在を`PASS`へ変換しない。各Gateの正本規則は`トレーサビリティ規約.md`、Bindingと段階別処理は`Framework・業務定義連携設計書.md`に従う。

### 14.3 復元しない旧構成

- `common/policies/`
- `common/registries/`
- `02_master/schemas/`
- `02_master/definitions/`

Compare DefinitionはJavaへ実装する。Registryが必要な場合は、用途、Owner、Schema、LifecycleおよびJavaとの正本関係を設計し、Architecture Review後に追加する。

## 15. `system/07_report/`

### 15.1 責務

| 配置 | 責務 |
|---|---|
| `Report設計書.md` | Report Model、生成、表示、Link、集約 |
| `templates/DailySummary_Template.md` | Batch／日次Summary表示Template |
| `templates/DiffReport_Template.md` | Diff表示Template |
| `templates/EvidenceReport_Template.md` | Evidence Index表示Template |

Report Templateは検証ロジックではなくReport表現契約であるため、`06_verification_assets/reports/`へ配置しない。

RunごとのReport実体またはDaily Report実体を`system/07_report/`へ保存してはならない。

## 16. `recovery/`統制

### 16.1 目的

`recovery/`は、旧成果物を失わずに現行設計へ移行するための一時的な比較領域である。

### 16.2 禁止事項

- Master、API、UseCase、ScenarioまたはJavaから参照する
- 旧Fileを更新して現行設計を継続する
- 旧Fileへ新しい正式要件だけを追記する
- Runtimeが読み込む
- `status: APPROVED`または`status: FROZEN`へ変更する

### 16.3 終了条件

旧文書ごとに次を満たした後、`recovery/`のArchiveまたは削除を別途判断する。

1. 有効要件が新設計書へ移行済み
2. 廃止要件の理由が移行判定表へ記録済み
3. 新旧Trace Review完了
4. Git履歴または代替保管が確認済み
5. Repository Ownerの承認済み

## 17. 論理Runtime構造

Runtime成果物の物理Rootは未確定である。設計間の共通語彙として、次の相対論理構造を使用する。

```text
{runtime_data_root}/
├── execution-state/
│   └── {environmentId}/{useCaseId}/{scenarioId}/{inputSetId}/
│       └── execution-state.json
├── baseline/
│   └── {environmentId}/{useCaseId}/{scenarioId}/{inputSetId}/
│       ├── baseline-meta.json
│       ├── verification-result.json
│       └── api-calls/{apiCallCode}/response.json
├── runs/
│   └── {runId}/
│       ├── run-meta.json
│       ├── scenario-execution.json
│       ├── verification-result.json
│       ├── artifact-manifest.json
│       ├── api-calls/{apiCallCode}/
│       │   ├── api-meta.json
│       │   ├── request.json
│       │   ├── response.json
│       │   └── response-field-diff.json
│       └── reports/
│           ├── scenario-summary.json
│           ├── ScenarioSummary.md
│           ├── diff-report.json
│           ├── DiffReport.md
│           ├── evidence-index.json
│           └── EvidenceIndex.md
└── batches/
    └── {batchId}/
        ├── batch-verification-result.json
        └── reports/
            ├── daily-summary.json
            └── DailySummary.md
```

本構造は論理契約であり、OS絶対Path、Mount Pathまたは保存Serviceを確定しない。

## 18. Runtime Path規則

1. Runtime Pathは固定Root配下で組み立てる。
2. User Inputを未検証のままPathへ連結しない。
3. `..`、絶対PathまたはSymbolic LinkによるRoot外参照を禁止する。
4. `runId`はRun専用Directoryへ一意に対応させる。
5. BaselineはExecution Identity固定Pathを使用する。
6. Directory走査、更新日時またはFile並び順をPrevious Run選定に使用しない。
7. Report LinkはRun RootまたはReport Root基準の相対Pathとする。
8. 一時Fileは確定先と同じFile System上に作成し、原子的に置換する。
9. Manifest確定前のArtifactを完了成果物として公開しない。

## 19. Reference記述規則

### 19.1 Repository内

```text
system/03_api_design/API-{NNN}設計書.md
```

- `/workspace/...`等の端末絶対Pathを記載しない。
- Master Referenceに`./`または`../`を使用しない。
- 区切りは`/`に統一する。
- File名の大文字・小文字および全角記号を実体と一致させる。
- `recovery/`をReference先にしない。

### 19.2 Runtime成果物

Runtime JSONはRun Root基準の相対Pathを保存する。

```json
{
  "relative_path": "api-calls/CALL-001/response.json"
}
```

OS絶対Path、Mount PathまたはSigned URLを永続Evidence Referenceとして保存しない。

## 20. File命名規則

| 種別 | Pattern | 例 |
|---|---|---|
| API設計書 | `API-{NNN}設計書.md` | `API-001設計書.md` |
| UseCase設計書 | `UC-{systemCode}-{NNN}設計書.md` | `UC-E6-001設計書.md` |
| Scenario設計書 | `SC-{systemCode}-{NNN}設計書.md` | `SC-E6-001設計書.md` |
| Scenario Input | `{scenarioId}-input.json` | `SC-E6-001-input.json` |
| Scenario Expected | `{scenarioId}-expected.json` | `SC-E6-001-expected.json` |
| Example | 正式Pattern＋`_Example` | `API-901設計書_Example.md` |

正式IDとFile名のIDは一致しなければならない。ただし、File名そのものをIdentityとして使用してはならない。

## 21. Front Matter

Markdown文書は次の`snake_case`形式を標準とする。

```yaml
---
title: API設計書
document_id: E6-API-VAL-API-001-DESIGN
version: 1.0.0-draft.1
status: DRAFT
document_type: API Detail Design
system_name: E6 API Verification Platform
updated: 2026-07-27
---
```

構造を凍結した文書は`status: FROZEN`を使用できる。個別設計の未承認内容を、Repository構造の凍結だけを理由に`FROZEN`へ変更してはならない。

## 22. Git管理境界

### 22.1 管理対象

- 承認対象Markdown
- Master正本
- TemplateおよびExample
- Scenario Input／Expected
- JSON Schema
- 移行中の`recovery/`と移行判定表
- 将来承認されたJava source、testおよび設定Template

### 22.2 管理対象外

- Secret、Token、PasswordおよびClient Secret
- 実Environment Credential
- `runs/`、`batches/`、`baseline/`および`execution-state/`実体
- Build生成物
- Temp File
- IDE個人設定
- Mask前の機密Evidence

具体的なIgnore PatternはJava／Build構成確定後に`.gitignore`で定義する。

## 23. 現行物理構成からの移行

### 23.1 移行原則

本章の状態は物理移行の進捗を示し、6章の凍結構造を変更しない。

| 移行ID | 現行 | 目標 | 状態 | 処置 |
|---|---|---|---|---|
| `REP-MIG-001` | `business/README.md`、3 Template、Example 2件を作成 | 6章の`business/` | 進行中 | 7 Flow、API横断一覧およびAPI個別分析を実資料に基づき順次作成する。 |
| `REP-MIG-002` | `E6_API_Master.md` | `API_Master.md` | 完了 | Master正本を改名し、設計書、Guide、Checklist、Traceability規約、用語集および全Current Referenceを同一Change Setで更新済み。 |
| `REP-MIG-003` | `E6_API_Master_Example.md` | `API_Master_Example.md` | 完了 | `REP-MIG-002`と同時にExampleを改名し、架空データ、文書IDおよび正式10項目を維持。 |
| `REP-MIG-004` | `system/05_run_context/` | `system/05_framework/` | 完了 | 現行2設計書を文書ID維持で移行し、現行Referenceを新Pathへ同期済み。中核3設計および周辺5設計の正文も作成済み。正式Role Reviewと承認は別Gateで管理する。 |
| `REP-MIG-005` | `06_verification_assets/reports/` | `07_report/templates/` | 未着手 | Report設計Referenceと同時更新する。 |
| `REP-MIG-006` | `06/common/schemas/`未作成 | 現行16 Schema | 正文作成・機械Validation完了（16/16）／正式Review待ち | 初期7と追加9 SchemaのCoverage Matrix完成。Recovery系追加要否は`FW-OI-018`、Java／Runtime Contract Testは`FW-OI-017／019`の後続条件とする。 |
| `REP-MIG-007` | 架空001系列が正式配置 | 正式E6事実とExampleの分離 | 完了 | 5 Masterと12実行／設計資産を正式領域から除外し、Recoveryへ隔離済み。 |
| `REP-MIG-008` | Example Reference切れ | Reference解決済みExample | 完了 | Business Analysis Example 2件とAPI-903 Exampleを補完済み。 |
| `REP-MIG-009` | `recovery/legacy_05_framework/` | 新`05_framework`への要件移行 | 完了 | 中核3設計、業務定義連携、Snapshot／Evidence、File I/O、Log／RecoveryおよびEnvironment／Runtime正文へ必要要件を移行済み。旧文書は現行正本として参照しない。 |

### 23.2 旧構成の最終判定

| 旧構成 | 判定 | 処置 |
|---|---|---|
| `system/00_repository/` | 廃止 | `system/01_repository/`を使用する。 |
| `system/01_business/` | 廃止 | Rootの`business/`へ整理する。 |
| 旧`system/05_framework/`本文 | 原文復元禁止 | `recovery/`から要件を抽出し、新設計書を作成する。 |
| 旧`RunContext設計書.md` | 分割継承 | `ScenarioContext`と`ExecutionState・Baseline`を基礎に再設計する。 |
| 旧`Diff設計書.md` | 置換 | `06_verification_assets/APIレスポンスDiff設計書.md`。 |
| 旧`Report設計書.md` | 置換 | `07_report/Report設計書.md`。 |
| 旧4種Master | 廃止 | 復元禁止。 |
| `02_master/definitions`／`schemas`／`samples` | 廃止 | `design`／`guide`／`checklist`／`examples`を使用する。 |

## 24. Directory追加・変更手順

```text
変更要求
→ 既存責務で収容可能か確認
→ 正本・Consumer・移行影響分析
→ Repository Structure変更案
→ Architecture Review
→ 承認
→ Directory／File作成
→ Reference更新
→ Validation
```

次の変更はArchitecture Reviewを必須とする。

- Top Level Directory追加
- `system/`直下Directory追加・番号変更
- `02_master`構成変更
- Scenario Input／Expected配置変更
- `05_framework`の責務分割
- Runtime論理Root変更
- 同一成果物の複数配置
- Policy／Registry Directory追加
- `recovery/`を正式Reference先へ変更する提案

## 25. Validation

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `REP-V001` | 必須DirectoryとFileが凍結構成に一致する。 | ERROR |
| `REP-V002` | Repository ReferenceがRoot基準相対Pathである。 | ERROR |
| `REP-V003` | Master Referenceの参照先が存在する。 | ERROR |
| `REP-V004` | Input／Expected内Scenario IDがFile名とMasterに一致する。 | ERROR |
| `REP-V005` | API／UseCase／Scenario設計書内IDがFile名とMasterに一致する。 | ERROR |
| `REP-V006` | Exampleが900番台を使用し、正式Masterから参照されない。 | ERROR |
| `REP-V007` | Runtime成果物が`system/`へ混在しない。 | ERROR |
| `REP-V008` | Secretまたは実CredentialがRepositoryに存在しない。 | ERROR |
| `REP-V009` | 未承認Directoryが追加されていない。 | ERROR |
| `REP-V010` | 旧4種MasterのFileまたはReferenceが残っていない。 | ERROR |
| `REP-V011` | Front Matter Keyが`snake_case`である。 | ERROR |
| `REP-V012` | Path TraversalまたはOS絶対PathがRuntime Referenceにない。 | ERROR |
| `REP-V013` | 正式成果物から`recovery/`へのReferenceがない。 | ERROR |
| `REP-V014` | Report Templateが`07_report/templates/`にある。 | ERROR |
| `REP-V015` | SchemaとJava DTOのVersion／互換関係が定義されている。 | ERROR |
| `REP-V016` | `runtime/` Source、`build/` Release、`staging/` Environmentおよび`outputs/` Dataの責務が混在しない。 | ERROR |
| `REP-V017` | Production Moduleが`verifier-contract-tests`へ依存せず、Module循環とSplit Packageがない。 | ERROR |
| `REP-V018` | StagingがReleaseを再Buildせず、承認済みDigestを使用する。 | ERROR |

`migration_status: IN_PROGRESS`の間、未実施の`REP-MIG-*`に起因するValidation Errorは移行Blockerとして記録する。Errorを無視してPASSへ書き換えてはならない。

## 26. Review Checklist

### 26.1 構成

- [ ] 成果物の正本Directoryが一つである。
- [ ] As-Is分析、To-Be設計、Template、Example、静的実行資産、Runtime結果が分離されている。
- [ ] 新規DirectoryにOwnerとLifecycleがある。
- [ ] 旧構成を暗黙継続していない。
- [ ] `recovery/`を正本として参照していない。

### 26.2 Reference

- [ ] 全Master ReferenceがRepository Root基準である。
- [ ] File名と内部IDが一致する。
- [ ] Input／Expectedの物理位置がScenario Masterと一致する。
- [ ] Report／Evidence LinkがRuntime Root外を参照しない。
- [ ] Exampleが正式Masterから参照されていない。

### 26.3 Java First

- [ ] API呼出順序とMappingを外部Policy Fileへ移していない。
- [ ] Expectedへ式言語またはScriptを置いていない。
- [ ] Compare Definitionを`common/policies/`へ外出ししていない。
- [ ] Java source構成をFramework設計承認前に固定していない。

### 26.4 Security

- [ ] Secret、CredentialおよびToken実値がない。
- [ ] Request／Response Exampleが架空値またはMask済みである。
- [ ] Runtime Pathが固定Root外へ出ない。
- [ ] Evidenceに永続Signed URLまたは端末絶対Pathがない。

## 27. Freeze範囲

### 27.1 本版で凍結する事項

1. 正式文書領域は`business/`、`system/01～07`で構成する。
2. 移行入力は`recovery/`へ隔離し、正本Referenceを禁止する。
3. Masterは5種類だけとする。
4. API Masterの最終File名は`API_Master.md`とする。
5. Scenario Input／Expected実体は`04_usecase_design`へ配置する。
6. 横断Framework設計は`05_framework`へ統合する。
7. API Response Diffは`06_verification_assets`へ配置する。
8. Report設計とReport Templateは`07_report`へ配置する。
9. Runtime契約Schemaは`06_verification_assets/common/schemas`へ配置する。
10. 旧4種Master、`policies/`および`registries/`を復元しない。
11. Runtime成果物を`system/`へ保存しない。
12. `project / runtime / build / staging / outputs`のTop Level責務とGit境界。
13. Java Source Root、7 Maven Module、Base Package `jp.co.mufg.e6.verifier`および明示Scenario Registry。
14. Maven Wrapper 3.9.16、OpenJDK 21、Java compile release／最低Runtime Version 21、Plain Java CLI、非Web Batch、およびSpring Boot／Spring Framework／Spring Batch／Tomcat非採用。
15. `ENV-PROD`は本番、Environment Typeは`PRODUCTION`とし、Production-like Environment、`PRODUCTION_LIKE`および`productionLike`列を廃止する。

### 27.2 本版で凍結しない事項

1. Runtime Dataの最終MountとStorage Service
2. ContainerおよびDeployment構成
3. 7業務の正式Business Codeと名称
4. 正式API、UseCase、Scenarioの件数とID
5. JSON Schema本文とVersion互換方式
6. Retention、Archive、Backupおよび運用Job

## 28. Migration Completion Gate

`migration_status`を`COMPLETED`へ変更するには、次をすべて満たす。

1. `REP-MIG-001～009`が完了または承認済み対象外である。
2. `REP-V001～V018`の`ERROR`が0件である。
3. Master内Referenceがすべて解決可能である。
4. 正式E6成果物とExampleが分離されている。
5. `05_framework`の11設計書が作成・Review済みである。
6. Report Templateが`07_report/templates/`へ移行済みである。
7. SchemaとJava DTOの正本・Version関係が承認済みである。
8. `recovery/`の各旧文書に移行判定がある。
9. Runtime物理Rootを本書の論理構造と混同していない。

## 29. 現行既知Blocker

| Block ID | 内容 | 影響 | 対応Batch |
|---|---|---|---|
| `REP-BLOCK-005` | Business分析Directoryと7 Flow正本が未作成 | 要件Trace未成立 | 第3バッチ |
| `REP-BLOCK-006` | `05_framework`の11設計書は正文作成済みだが、責任Role正式Review、製品／物理値／Capacity決定およびCapability Testが未実施 | Framework責務の正式承認と実装前提が未閉合 | 第7～10バッチ |
| `REP-BLOCK-007` | 現行16 Schemaは正文・機械Validation済みだが、Java Writer／Reader、Runtime／Report公開Contract Test、Recovery系Schema判断および正式Role Reviewが未完了 | 端到端Runtime／Report Traceを正式`PASS`にできない | 第9～10バッチ |
| `REP-BLOCK-009` | 現行Repository規約に旧Path記述が残る | 規約間不整合 | 第4バッチ |
| `REP-BLOCK-010` | `REP-CR-010／011／013／014`は承認・物理実装済みで、OpenJDK 21＋Maven＋Plain Java基線へ訂正済み。現環境にOpenJDK 21 Compilerと承認済み依存Repository接続がなくBuild／Test未完、かつ正式DTO／Scenarioが0件 | `TRACE-BUILD`全体を正式`PASS`にできない | 第10バッチ |

本書の凍結だけで、上記BlockerをPASSまたは解決済みに変更してはならない。

第2バッチで`REP-BLOCK-001～004`および`REP-BLOCK-008`は解消済みである。正式MasterはBusiness／API分析完了まで0件とし、Runtime実行対象を持たない。

## 30. 実施順序

| バッチ | 内容 | 主成果物 |
|---|---|---|
| 第1バッチ | 最終構造を凍結 | 本書 |
| 第2バッチ【完了】 | 架空001系列、`enabled`、Example参照切れを整理 | Master／API／UseCase／Scenario整合 |
| 第3バッチ | `business/`と7業務／API分析を構築 | Business Analysis正本 |
| 第4バッチ【完了】 | `05_run_context`を`05_framework`へ移行 | 既存2設計書の継承、現行Reference同期 |
| 第5バッチ【正文已给出・AI事前Review済・正式Review待ち】 | Framework設計入力・決定事項を整理 | 決定事項一覧 |
| 第6バッチ【正文已给出・AI事前Review済・正式Review待ち】 | System、Identity／Result、Framework全体を設計 | Framework中核3設計書 |
| 第7バッチ【5/5正文已给出・AI事前整合確認済・正式Review待ち】 | 業務定義連携、Snapshot、File I/O、Log／Recovery、Environmentを設計 | Framework周辺設計 |
| 第8バッチ【7/7正文已给出・機械検証済・正式Review待ち】 | JSON Schemaを作成しRuntime Artifact Coverageを確定 | `common/schemas/` |
| 第9バッチ【第2段階まで正文已给出・機械検証済・Build／Runtime／正式Review待ち】 | Master～Java～Evidence／Reportの双方向Traceと追加Schemaを検証 | 5段階Trace Gate、Definition／Runtime Meta／Batch／Report Schema |
| 第10バッチ【第2段階Scaffold作成済・JDK 17基線へ更新】 | `REP-CR-010`を承認してTop Level、7 Moduleおよび明示Registry Scaffoldを実装し、`REP-CR-011`でSpring Boot 4.1.0／Java 17非Web Batchへ互換性基線を更新 | `REP-CR-010`、`REP-CR-011`、Java Project構成 |
| 第10バッチ【第3段階API Master移行済】 | `REP-MIG-002／003`を同一Change Setで実施し、API Master正本、Exampleおよび全Current Referenceを最終File名へ移行 | `API_Master.md`、`API_Master_Example.md`、横断Reference |
| 第10バッチ【第4段階Master共通設計再作成済】 | Master共通設計を現行0件データ、Environment候補、Java 17非Web Batchおよび明示Registry契約で全面再作成し、旧実データ判定を除去 | `Master共通設計書.md`、状態分離、Release Gate |
| 第10バッチ【第5段階Environment区分確定済】 | `REP-CR-012`として`ENV-PROD`を本番へ確定し、Production-like Environment、Enumおよび属性を廃止。本番実行禁止Defaultは維持 | `Environment_Master.md`、Environment設計、Runtime安全Gate |
| 第10バッチ【第6段階Maven＋Plain Java移行済】 | `REP-CR-013`としてMaven／Java 17を維持し、Spring Boot／Spring FrameworkをApplication、POM、ConfigおよびCurrent設計から除去。Plain Java CLI、明示Composition、実行可能JARおよび依存禁止Gateへ移行 | POM、CLI Source、Contract Test、Build／Smoke、Current設計 |
| 第10バッチ【第7段階OpenJDK 21基線訂正済】 | `REP-CR-014`として現行Java基線をOpenJDK 21／`release=21`へ訂正し、POM、Build、Smoke、Trace、FrameworkおよびMaster Consumerを同期 | POM、OpenJDK Gate、Current設計、検証報告 |

## 31. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 5 Master、Java First、Scenario Input／Expected、Run／Baseline、Diff、Reportの責務に基づき全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | API／UseCase詳細設計作成後のBlockerを同期 | DRAFT |
| `2.0.0-draft.3` | 2026-07-27 | Scenario詳細設計、Input、Expected作成後のBlockerを同期 | DRAFT |
| `2.0.0-draft.4` | 2026-07-27 | 900番台Scenario Input／Expectedの命名をExample Masterと整合 | DRAFT |
| `3.0.0` | 2026-07-27 | 9件の一意な履歴分割、現行70件の成果物および旧05 Framework復元文書を統合評価し、`05_framework`、`07_report/templates`、`06/common/schemas`および移行統制を含む最終目標構成を凍結 | FROZEN |
| `3.0.1` | 2026-07-27 | 第2バッチ完了を反映。架空001系列をRecoveryへ隔離し、正式Masterを0件へ是正、Example Reference切れ3件を解消 | FROZEN |
| `3.0.2` | 2026-07-27 | 第3バッチ前半を反映。`business/`のREADMEおよび現行業務分析、BA×Scenario候補、API分析の3 Templateを作成 | FROZEN |
| `3.0.3` | 2026-07-27 | 第4バッチ完了を反映。`05_run_context`の2設計書を`05_framework`へ移行し、現行Referenceを同期。Framework設計入力・決定事項一覧の現行版を新規作成 | FROZEN |
| `3.0.4` | 2026-07-27 | 第5バッチ前半を反映。現行契約に基づく`05_framework/システム設計書.md`を新規作成し、Framework中核設計を開始 | FROZEN |
| `3.0.5` | 2026-07-27 | 第6バッチ第2成果物の正文を反映。Static／Runtime Identity、四結果軸、Severity、Reasonおよび決定的集約規則をReview候補として整理 | FROZEN |
| `3.0.6` | 2026-07-27 | 第6バッチ中核3設計の正文を反映。Component、Port、Execution Plan、Lifecycle、Fail Closed、RetryおよびArtifact／State境界は横断Review待ち | FROZEN |
| `3.0.7` | 2026-07-27 | 第7バッチ第1成果物の正文を反映。Definition Bundleと双方向Traceの契約は`PROPOSED`であり、構造Versionを進めず進捗表現だけを是正 | FROZEN |
| `3.0.8` | 2026-07-27 | 第5～7バッチの五視点AI横断事前Review、Consumer／Template再走査および重大指摘是正を反映。API Call Meta名を`api-meta.json`へ同期し、凍結Directory構造は変更せず正式Role Review待ちを明示 | FROZEN |
| `3.0.9` | 2026-07-28 | 第7バッチ第2成果物`Snapshot・Evidence設計書.md`の正文、関連Consumer整合、Baseline InventoryおよびCore Manifest／Report非循環境界を反映。凍結Directory構造は変更なし | FROZEN |
| `3.0.10` | 2026-07-28 | 第7バッチ第3成果物`ファイル入出力設計書.md`の正文、Run Create-Only、Baseline／Report Versioned Set＋CAS、State条件更新および`apiCallCode` Path統一を反映。凍結Directory構造は変更なし | FROZEN |
| `3.0.11` | 2026-07-28 | 第7バッチ第4成果物`ログ・例外・Recovery設計書.md`の正文、Failure／Reason Code分離、Dispatch State、Timeout／Retry／Cancellation、Audit、Immutable Recovery CaseおよびDiagnostic外部Sink境界を反映。凍結Directory構造は変更なし | FROZEN |
| `3.0.12` | 2026-07-28 | 第7バッチ第5成果物`環境・Runtime構成設計書.md`の正文、Target Environment／Runtime Profile分離、Immutable Release、External Config／Secret、Capability Gate、Deployment／Backup／DR境界を反映。凍結Directory構造は変更なし | FROZEN |
| `3.0.13` | 2026-07-28 | 第8バッチ第1成果物`scenario-input.schema.json`正文、Draft 2020-12／URN Version契約、7 Schema進捗およびRuntime Artifact Coverage境界を反映。凍結Directory構造は変更なし | FROZEN |
| `3.0.14` | 2026-07-28 | 第8バッチ第2成果物`scenario-expected.schema.json`正文、Expected Identity、終端Status、型付きExpected ValueおよびSchema／Semantic Validator境界を反映。凍結Directory構造は変更なし | FROZEN |
| `3.0.15` | 2026-07-28 | 第8バッチ残り5成果物を一括反映。Scenario Verification Result、Response Field Diff、Execution State、Baseline InventoryおよびCore Artifact Manifestの構造契約とSchema／Semantic境界を確定し、初期7 Schemaを正文・機械検証完了へ更新。凍結Directory構造は変更なし | FROZEN |
| `3.0.16` | 2026-07-28 | 第9バッチとして5段階Trace Gate、Master／Java Registry Binding、Runtime Artifact Trace EnvelopeおよびEvidence／Report逆引き契約を既存正本へ反映。凍結Directory構造は変更なし | FROZEN |
| `3.0.17` | 2026-07-28 | 第9バッチ第2段階としてDefinition Bundle、Runtime Meta 3種、Batch ResultおよびReport 4種の追加9 Schemaを受控追加。現行16 Schema CoverageとTrace Gate Blockerを同期し、凍結Top Level／Directory構造は変更なし | FROZEN |
| `3.0.18` | 2026-07-29 | 第10バッチ第1段階として初期`project / runtime / build / staging / outputs`思想を現行契約へ再接続し、`REP-CR-010`のTop Level変更候補、Maven Module、Git境界および承認Gateを追加。現行凍結構造自体は変更せず正式Architecture Review待ち | FROZEN |
| `3.0.19` | 2026-07-29 | Java組織Base Packageを`jp.co.mufg.e6.verifier`として入力確定し、残存Blockerを`REP-CR-010`のArchitecture ReviewとScaffold実装へ限定。現行凍結Directory構造は変更なし | FROZEN |
| `4.0.0` | 2026-07-29 | `REP-CR-010`を承認し、`project / runtime / build / staging / outputs`を凍結Top Levelへ追加。Spring Boot 4.1.0、Java 21、非Web Batch、Maven 7 Module、明示Scenario RegistryおよびContract Test Scaffoldを物理作成 | FROZEN |
| `4.0.1` | 2026-07-29 | `REP-CR-011`としてJava compile／runtime最低Levelを17へ変更し、POM、Smoke、Build／Trace Gateおよび関連設計を同期。Top LevelとModule構造は変更なし | FROZEN |
| `4.0.2` | 2026-07-29 | `REP-MIG-002／003`として`E6_API_Master.md`とExampleを最終File名へ改名し、設計、Guide、Checklist、Trace、用語、TemplateおよびExampleのCurrent Referenceを原子的に移行。凍結構造とMaster列は変更なし | FROZEN |
| `4.0.3` | 2026-07-29 | `Master共通設計書.md`を現行Repository、正式Master 0件、Environment候補3件、Java 17非Web Batchおよび明示Registry契約に基づき全面再作成。旧`SC-E6-001 → API-002`実データ判定を除去し、構造Validationと業務データ／Build Release Gateを分離。凍結Directory構造とMaster列は変更なし | FROZEN |
| `4.0.4` | 2026-07-29 | `REP-CR-012`として`ENV-PROD`を本番へ確定し、Production-like Environment、`PRODUCTION_LIKE` Enumおよび`productionLike`列を廃止。Environment Masterを固定9列へ変更し、本番実行可否は未承認のまま`enabled=false`を維持。凍結Directory構造は変更なし | FROZEN |
| `4.0.5` | 2026-07-31 | `REP-CR-013`としてMaven Wrapper 3.9.16／Java 17／7 Moduleを維持し、Spring Boot Parent、Starter、Plugin、Annotation、Application Contextおよび専用Configを廃止。Plain Java CLI、明示Composition、Maven Shade実行可能JAR、Spring依存禁止GateおよびRelease Maven情報除外へ移行。凍結Directory構造、Master列、EnvironmentおよびBase Packageは変更なし | FROZEN |
| `4.0.6` | 2026-07-31 | `REP-CR-014`として現行Java基線をOpenJDK 21、`maven.compiler.release=21`、Build許可Major 21へ訂正。POM、Release Build Gate、Smoke、Trace、FrameworkおよびMaster Consumerを同期し、Maven／Plain Java／7 Module／Spring非採用境界を維持。凍結Directory構造、Master列、EnvironmentおよびBase Packageは変更なし | FROZEN |
