---
title: ScenarioContext設計書
document_id: E6-API-VAL-SCN-CONTEXT-DESIGN
version: 1.0.0-draft.4
status: DRAFT
document_type: Runtime Context Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# ScenarioContext設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | ScenarioContext設計書 |
| 文書ID | `E6-API-VAL-SCN-CONTEXT-DESIGN` |
| 対象 | Java RuntimeのScenario実行Context |
| 配置 | `system/05_framework/` |
| 文書種別 | Runtime共通設計書 |
| 版数 | `1.0.0-draft.4` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | Runtime Team |
| レビュー責任 | System Architect / Scenario Design Lead / Runtime Lead / Test Lead |

## 2. 目的

本書は、一回のScenario実行中に使用する`ScenarioContext`の責務、Scope、データモデル、`ApiExchange`、Lifecycle、並行実行隔離、型安全、Snapshot連携およびError処理を定義する。

`ScenarioContext`はMasterではない。各Runで生成され、Scenario終了後に破棄されるRuntime Objectである。

## 3. 基本定義

```text
一つのScenario実行インスタンス
=
一つのScenarioContext
```

ContextのIdentityは次のとおりとする。

```text
runId
+
environmentId
+
useCaseId
+
scenarioId
+
inputSetId
```

同一Scenarioを同時に複数起動した場合も、`runId`ごとに別Contextを生成し、Object、Map、File Writerおよび一時領域を共有しない。

## 4. 適用範囲

本書が定義する対象は次のとおりである。

- Scenario実行Identity
- Input、ExpectedおよびBaselineの実行時参照
- `apiCallCode → ApiExchange`の保持
- Request／Response DTOおよびJSONの保持
- `resultKey → CheckResult`の保持
- Scenario固有の派生データ
- Lifecycleおよび破棄
- Run間のIsolation

対象外は次のとおりである。

| 対象外情報 | 正式な管理先 |
|---|---|
| Scenario一覧、`executionClass`、Input／Expected参照 | Scenario Master |
| API呼出順序、分岐、Skip | Scenario詳細設計書およびJava Scenario Class |
| API項目定義 | API詳細設計書、DTO |
| 初期入力値 | Scenario Input |
| Expected構造と判定 | `検証結果・Expected設計書.md` |
| Baseline選択、更新、復旧 | `ExecutionState・Baseline管理設計書.md` |
| Response Field Diff | `APIレスポンスDiff設計書.md` |
| Report Layout | `Report設計書.md` |
| Context全体の永続化 | 行わない。必要データをRun成果物として個別保存する。 |

## 5. 設計原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `CTX-P001` | Scenario Scope | ContextをScenario実行Scopeの外へ暗黙共有しない。 |
| `CTX-P002` | Run Isolation | 異なる`runId`のObjectおよび出力を共有しない。 |
| `CTX-P003` | 呼出単位Identity | API呼出は`apiCallCode`で識別する。 |
| `CTX-P004` | Exchange一体管理 | 同一呼出のRequestとResponseを一つの`ApiExchange`で管理する。 |
| `CTX-P005` | DTO／JSON併存 | Java処理用DTOと証跡・Diff用JSONを両方保持する。 |
| `CTX-P006` | API項目非重複 | Context内にAPI Request／Response項目定義を再定義しない。 |
| `CTX-P007` | 型安全 | DTO取得時に期待型を検証し、不一致を即時Errorとする。 |
| `CTX-P008` | Stable Result Key | Check結果を`resultKey`で識別する。 |
| `CTX-P009` | Mutation制限 | Input、ExpectedおよびBaseline参照を実行中に変更しない。 |
| `CTX-P010` | 明示的破棄 | Scenario終了後に大容量Response、Secret参照および一時Resourceを解放する。 |

## 6. 論理構造

```text
ScenarioContext
├── executionIdentity
│   ├── runId
│   ├── environmentId
│   ├── useCaseId
│   ├── scenarioId
│   └── inputSetId
├── input
├── expected
├── baseline
├── apiExchanges
│   └── apiCallCode → ApiExchange
├── checkResults
│   └── resultKey → CheckResult
├── scenarioData
├── lifecycleState
└── resourceRegistry
```

`baseline`は読取専用参照であり、ContextがBaselineを更新する責務を持たない。

## 7. Javaモデル

### 7.1 Execution Identity

```java
public record ExecutionIdentity(
        String runId,
        String environmentId,
        String useCaseId,
        String scenarioId,
        String inputSetId
) {
}
```

### 7.2 ScenarioContext

```java
public final class ScenarioContext {

    private final ExecutionIdentity identity;
    private final ScenarioInput input;
    private final ScenarioExpected expected;
    private final BaselineContext baseline;
    private final Map<String, ApiExchange<?, ?>> apiExchanges;
    private final LinkedHashMap<String, CheckResult> checkResults;
    private final Map<String, Object> scenarioData;
    private ContextLifecycleState lifecycleState;

    public ScenarioContext(
            ExecutionIdentity identity,
            ScenarioInput input,
            ScenarioExpected expected,
            BaselineContext baseline) {
        this.identity = Objects.requireNonNull(identity);
        this.input = Objects.requireNonNull(input);
        this.expected = Objects.requireNonNull(expected);
        this.baseline = Objects.requireNonNull(baseline);
        this.apiExchanges = new LinkedHashMap<>();
        this.checkResults = new LinkedHashMap<>();
        this.scenarioData = new HashMap<>();
        this.lifecycleState = ContextLifecycleState.CREATED;
    }
}
```

実装Class名およびPackageはRuntime詳細設計で確定する。本書では責務と契約を正本とする。

## 8. ApiExchange

### 8.1 目的

`ApiExchange`は、Scenario内の一回のAPI呼出に関するRequest、Responseおよび実行Metadataを一体として保持する。

```java
public record ApiExchange<REQ, RES>(
        String apiCallCode,
        String apiId,
        REQ requestObject,
        JsonNode requestJson,
        RES responseObject,
        JsonNode responseJson,
        Integer httpStatus,
        ApiCallStatus callStatus,
        Instant startedAt,
        Instant completedAt
) {
}
```

### 8.2 項目定義

| 項目 | 必須 | 内容 | 主用途 |
|---|:---:|---|---|
| `apiCallCode` | Yes | Scenario内API呼出実体ID | Context、Output、Diffの追跡 |
| `apiId` | Yes | API MasterのAPI ID | API固定定義の解決 |
| `requestObject` | Yes | 強型Request DTO | Java処理、送信 |
| `requestJson` | Yes | 実際に送信するJSON | Evidence、監査 |
| `responseObject` | 条件付 | 強型Response DTO | 後続Request、Business Check |
| `responseJson` | 条件付 | 実際のResponse JSON | Evidence、Field Diff |
| `httpStatus` | 条件付 | HTTP Status | API結果判定 |
| `callStatus` | Yes | 呼出状態 | 正常、Error、Skipの判別 |
| `startedAt` | Yes | 呼出開始時刻 | 監査、性能 |
| `completedAt` | 条件付 | 呼出終了時刻 | 監査、性能 |

Responseを取得できないError時は`responseObject`および`responseJson`をNullにできる。その場合、`callStatus`とError成果物で理由を明示する。

### 8.3 Status

| 値 | 意味 |
|---|---|
| `PLANNED` | Scenario上は定義済みで未開始 |
| `RUNNING` | API呼出中 |
| `SUCCEEDED` | Response受信、JSON保存およびDTO変換が完了 |
| `BUSINESS_ERROR_RESPONSE` | HTTP通信は完了し、仕様上の業務Error Responseを受信 |
| `SKIPPED` | Scenario条件により未実行 |
| `TIMEOUT` | Timeout |
| `TRANSPORT_ERROR` | 接続・TLS・通信Error |
| `PARSE_ERROR` | Responseを有効JSON／DTOとして解析できない |

## 9. `apiCallCode`と`apiId`

```text
apiId
    どのAPI定義を呼び出すか

apiCallCode
    現在のScenario内のどの呼出実体か
```

同じAPIを同一Scenario内で複数回呼び出せる。

```text
CALL-001 → API-001  更新前照会
CALL-002 → API-002  状態更新
CALL-003 → API-001  更新後照会
```

Contextを`apiId`だけでKey化してはならない。`API-001`の2回目のResponseが1回目を上書きするためである。

## 10. DTOとJSONの責務

| データ | 内容 | 用途 |
|---|---|---|
| Request DTO | Java型で表現したRequest | Request生成、API Client |
| Request JSON | 実際に送信するJSON項目名のTree | Evidence、送信内容確認 |
| Response DTO | Java型で表現したResponse | 後続API、Business Check |
| Response JSON | API実項目名のJSON Tree | Evidence、Previous／Current Diff |

Field DiffはJava Field名ではなく、`responseJson`のAPI実項目名を使用する。

例：

```text
Java DTO: memberStatus
API JSON: member_status
Diff Path: $.member_status
```

Java変数名の変更だけでAPI Field Diffを発生させてはならない。

## 11. 登録処理

### 11.1 Request確定

1. Java Request BuilderがInputと先行Response DTOからRequest DTOを生成する。
2. API Clientが送信直前のRequest DTOをJSONへSerializeする。
3. `apiCallCode`と`apiId`をScenario詳細設計と照合する。
4. Request Snapshotを書き込む。
5. 呼出状態を`RUNNING`にする。

### 11.2 Response確定

1. HTTP Responseを受信する。
2. Runtime Buffer上のResponseへ保存前Mask、Secret除去およびSize確認を適用する。
3. JSON TreeへParseする。
4. Response DTOへDeserializeする。
5. Mask済みCanonical Response ArtifactをTemporary領域へ書き込む。
6. `ApiExchange`を不変Objectとして完成させる。
7. `apiExchanges`へ一回だけ登録する。
8. Response ArtifactのSchema、HashおよびManifest登録候補を確認する。

同じ`apiCallCode`へ二回登録した場合は上書きせずErrorとする。

## 12. 取得API

推奨Interfaceは次のとおりとする。

```java
public <RES> RES response(
        String apiCallCode,
        Class<RES> responseType);

public JsonNode responseJson(
        String apiCallCode);

public <REQ> REQ request(
        String apiCallCode,
        Class<REQ> requestType);

public ApiExchange<?, ?> exchange(
        String apiCallCode);
```

取得時は次を検証する。

1. `apiCallCode`が存在する。
2. `callStatus`が要求操作を許可する。
3. Responseが存在する。
4. 実際のDTO型が要求型と一致する。
5. 取得対象Runが現在のContextと一致する。

型不一致をCastで黙認してはならない。

## 13. Check Result

### 13.1 管理方式

Check結果は`resultKey`で一意に管理する。

```text
resultKey → CheckResult
```

`LinkedHashMap`等を使用してJava実行順を維持するが、順序をIdentityとして使用しない。

### 13.2 登録規則

- 一つの独立Check関数は一つの`resultKey`を出力する。
- 同じ`resultKey`を二回登録してはならない。
- API Response比較とBusiness Checkを別`resultType`にする。
- Expectedとの照合は`resultKey`で行う。
- Batch集約結果は全Check確定後に計算する。

`CheckResult`の正式構造は`検証結果・Expected設計書.md`で定義する。

## 14. Scenario Data

`scenarioData`は、API DTOそのものでは表現できないScenario固有の派生値だけに使用する。

許可例：

- 複数Responseから算出した合計値
- 後続Checkで共有する正規化済み業務値
- Scenario内だけで使用する判定補助値

禁止例：

- API Response全項目の複製
- Secret
- 別Runとの共有値
- Baseline更新状態
- Global Context ID

KeyはScenario詳細設計で定義し、文字列の即席利用を避ける。可能な限り専用型を使用する。

## 15. Lifecycle

本節の値は`ContextLifecycleState`であり、四結果軸の`ExecutionStatus`ではない。Contextの内部状態からVerification、ChangeまたはRecoveryを推測しない。

```mermaid
stateDiagram-v2
    [*] --> CREATED
    CREATED --> LOADED: Input・Expected・Baseline
    LOADED --> ACTIVE: Scenario開始
    ACTIVE --> SEALED: Context確定
    ACTIVE --> ABORTED: 中断・Error
    SEALED --> RELEASED: 成果物引渡し後
    ABORTED --> RELEASED: Error Evidence引渡し後
    RELEASED --> [*]
```

| 状態 | 許可操作 |
|---|---|
| `CREATED` | Identity設定 |
| `LOADED` | Input／Expected／Baseline参照、起動前Validation |
| `ACTIVE` | ApiExchange、CheckResult、Scenario Dataの登録 |
| `SEALED` | 読取、Context内容の確定、Artifact Managerへの引渡し |
| `ABORTED` | 読取、取得済みEvidenceとReasonの引渡し |
| `RELEASED` | 操作不可 |

`SEALED`はExecution `COMPLETED`またはVerification `PASS`を意味しない。四結果軸とArtifact Package CompletenessはContext外で独立して確定する。

## 16. Run Isolation

### 16.1 複数Run

- ContextはDI ContainerのSingletonにしない。
- Static Mutable Fieldへ保存しない。
- ThreadLocalだけでIdentityを保証しない。
- Cache Keyに必ず`runId`とExecution Identityを含める。
- 出力WriterはRun専用Pathへ固定する。

### 16.2 同一Scenarioの同時起動

同一Execution Identityの同時実行は、Baseline更新競合を防ぐため排他制御対象とする。

```text
environmentId + useCaseId + scenarioId + inputSetId
```

異なるIdentityは並行実行できる。

Context自体は一つのScenario実行Threadが所有する。Scenario内部API呼出の並列化は現行同期Batchの対象外とし、将来導入時は`apiExchanges`の競合制御を別途設計する。

## 17. SnapshotおよびOutput連携

Contextは永続化の正本ではない。次の成果物をRun領域へ明示的に出力する。

```text
runs/{runId}/
├── run-meta.json
├── scenario-execution.json
├── verification-result.json
└── api-calls/
    └── {apiCallCode}/
        ├── api-meta.json
        ├── request.json
        ├── response.json
        └── response-field-diff.json
```

| Context情報 | 出力 |
|---|---|
| Execution Identity | `run-meta.json` |
| Scenario状態 | `scenario-execution.json` |
| Request JSON | `api-calls/{apiCallCode}/request.json` |
| Response JSON | `api-calls/{apiCallCode}/response.json` |
| Check Result | `verification-result.json` |
| Response Field Diff | `response-field-diff.json` |

DTO Object自体をJava Serializationで長期保存しない。JSON成果物を契約として保存する。

## 18. Baseline連携

Context生成時、Baseline Managerが読み込んだ読取専用`BaselineContext`を設定する。

```text
固定Baseline
    ↓
BaselineContext
    ↓
ScenarioContext.baseline
```

API比較は同一`apiCallCode`で行う。

```text
baseline.responseJson("CALL-003")
↔
context.responseJson("CALL-003")
```

Contextは次を行わない。

- Baseline Path探索
- 前回Runの推測
- Baselineの部分更新
- `previousRunId`更新
- `initialExecutionFlg`更新

これらは`ExecutionState・Baseline管理設計書.md`の責務である。

## 19. Error処理

| Error Code | 条件 | 処理 |
|---|---|---|
| `CTX_DUPLICATE_API_CALL` | 同じ`apiCallCode`を二回登録 | Contextを`ABORTED`、Executionを`INCOMPLETE`とし、既存値を保持 |
| `CTX_API_CALL_NOT_FOUND` | 未登録`apiCallCode`を取得 | 当該Checkを`NOT_EVALUATED`、Executionを`INCOMPLETE`としReasonを記録 |
| `CTX_API_ID_MISMATCH` | 設計上の`apiId`と登録値が不一致 | Contextを`ABORTED`、Executionを`INCOMPLETE`とする |
| `CTX_RESPONSE_NOT_AVAILABLE` | Responseなしで取得要求 | Call Statusに基づき`NOT_EVALUATED`とReasonを記録し、Execution影響を別判定 |
| `CTX_DTO_TYPE_MISMATCH` | 要求型と実型が不一致 | Contextを`ABORTED`、Executionを`INCOMPLETE`とする |
| `CTX_DUPLICATE_RESULT_KEY` | 同じ`resultKey`を二回登録 | Contextを`ABORTED`、Executionを`INCOMPLETE`とする |
| `CTX_INVALID_STATE` | Lifecycle上不正な更新 | Contextを`ABORTED`、Executionを`INCOMPLETE`とする |
| `CTX_CROSS_RUN_ACCESS` | 異なるRunのContext参照 | Security Failureとして停止し、Recovery要否を別判定 |
| `CTX_RESOURCE_RELEASE_ERROR` | Resource解放失敗 | Log／運用通知。主成果物状態を保持 |

Error時も既に取得したEvidenceを削除しない。

## 20. SecurityおよびMask

1. Authorization Header、Cookie、Tokenは`ApiExchange`の通常項目へ保存しない。
2. Request／Response JSON保存前に設計済みMask処理を行う。
3. DTOの`toString()`をLogへ無条件出力しない。
4. Context Dump機能を本番で既定有効にしない。
5. Error MessageへResponse全体を埋め込まない。
6. Context解放時にSecret参照および一時Bufferを破棄する。
7. Mask前Raw Dataの永続化はDefault禁止とする。監査上不可欠なPayloadを例外保存する場合も、Credentialは必ず除外し、専用の暗号化領域、独立権限、承認、短期RetentionおよびAccess AuditをSnapshot／Security設計で定義する。

## 21. 性能およびResource

- 大容量File ResponseをContextのHeapへ全量二重保持しない。
- JSONとDTOの同時保持によるMemory上限をAPI単位で確認する。
- Stream ResponseはEvidence保存後に必要なMetadataだけをContextへ保持する。
- Scenario終了時にHTTP Stream、Temporary FileおよびBufferを閉じる。
- Context Objectを次回Runへ再利用しない。
- 1 RunのContext Memory上限および最大Response Sizeは非機能設計で確定する。

## 22. Validation

| Validation ID | 確認内容 | Level |
|---|---|---|
| `CTX-V001` | Execution Identityの全項目が設定されている。 | ERROR |
| `CTX-V002` | InputのIdentityがContext Identityと一致する。 | ERROR |
| `CTX-V003` | ExpectedおよびBaselineが同じExecution Identityに属する。 | ERROR |
| `CTX-V004` | `apiCallCode`がScenario内で一意である。 | ERROR |
| `CTX-V005` | `apiCallCode + apiId`がScenario詳細設計と一致する。 | ERROR |
| `CTX-V006` | Request DTOとRequest JSONが同じ送信内容を表す。 | ERROR |
| `CTX-V007` | Response DTOとResponse JSONが同じ受信内容を表す。 | ERROR |
| `CTX-V008` | Response Field DiffがJSON実項目名を使用する。 | ERROR |
| `CTX-V009` | `resultKey`が重複しない。 | ERROR |
| `CTX-V010` | Lifecycle外の更新が拒否される。 | ERROR |
| `CTX-V011` | 異なるRun間でContextが共有されない。 | ERROR |
| `CTX-V012` | Scenario終了後にResourceが解放される。 | WARNING |

## 23. Test観点

- [ ] 同一APIを`CALL-001`と`CALL-003`で別々に保持できる。
- [ ] `apiId`をKeyにした上書きが発生しない。
- [ ] Request／ResponseのDTOとJSONを両方取得できる。
- [ ] DTO型不一致時に即時Errorとなる。
- [ ] 同じ`resultKey`の二重登録を拒否する。
- [ ] Business FAILでもContextを`SEALED`にでき、Verification `FAIL`を独立保持できる。
- [ ] API ErrorまたはParse Error時にContextを`ABORTED`にし、Execution `INCOMPLETE`等を独立記録できる。
- [ ] 複数Runを同時実行してもObjectとOutputが混在しない。
- [ ] BaselineをContextから更新できない。
- [ ] Context終了後に大容量ObjectとResourceを解放する。
- [ ] Secretおよび個人情報がLogへ漏れない。

## 24. 未確定事項

| Issue ID | 論点 | 暫定方針 | 確定先 |
|---|---|---|---|
| `CTX-ISSUE-001` | Java PackageおよびInterface名 | 本書の責務を満たすRuntime Packageへ配置する。 | 共通Framework設計 |
| `CTX-ISSUE-002` | Raw Response保存方式 | 通常EvidenceはMask済みCanonical JSONだけとする。Raw Bodyは例外承認されたProtected Raw Evidenceに限定し、Credentialは常に除去する。 | Snapshot／File I/O／Security設計 |
| `CTX-ISSUE-003` | Scenario内部のAPI並列実行 | 現行は同期逐次実行とする。 | 将来Runtime設計 |
| `CTX-ISSUE-004` | Context Memory上限 | API最大Response Size確定後に設定する。 | 非機能設計 |

## 25. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.4` | 2026-07-28 | Snapshot／Evidence設計に合わせ、Raw Responseの通常永続化を禁止し、保存前Mask、Canonical ArtifactおよびManifest候補確認へ登録順序を同期 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | 横断ReviewによりContext Lifecycleと四結果軸を分離し、Error処理およびRaw Data例外保存条件を是正 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | 凍結済Repository構造に従い`system/05_framework/`へ移行。文書IDと設計責務は継承 | DRAFT |
| `1.0.0-draft.1` | 2026-07-27 | Scenario Scope、`apiCallCode → ApiExchange`、DTO／JSON分離およびRun Isolationに基づく初版作成 | DRAFT |
