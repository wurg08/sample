---
title: 共通Identity・Resultモデル設計書
document_id: E6-API-VAL-IDENTITY-RESULT-DESIGN
version: 1.0.0-draft.7
status: DRAFT
document_type: Common Identity and Result Model Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# 共通Identity・Resultモデル設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 共通Identity・Resultモデル設計書 |
| 文書ID | `E6-API-VAL-IDENTITY-RESULT-DESIGN` |
| 対象 | Run、Batch、UseCase、Scenario、API Call、Check、Diff、ArtifactのIdentityと結果集約 |
| 配置 | `system/05_framework/` |
| 文書種別 | Framework共通モデル設計書 |
| 版数 | `1.0.0-draft.7` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | System Architecture / Runtime Team |
| レビュー責任 | System Architect / Runtime Lead / Verification Lead / Report Lead |
| 承認責任 | System Owner |

## 2. 目的

本書は、E6 API Verification Platformのすべての実行、検証、差分、証跡およびRecoveryを同じ意味で追跡するため、次を定義する。

1. 静的定義Identityと実行時Identityの分離
2. RunからArtifactまでの親子関係とCardinality
3. Execution、Verification、Change、Recoveryの四結果軸
4. `ReasonCode`、Severity、集約規則および表示用Summary
5. Result確定、Immutable化およびArtifact連携
6. Java Model、JSON SchemaおよびReport間の契約境界

本書は単一の総合`PASS / FAIL`を作るための設計ではない。四軸の原結果を保持したまま、利用目的別にSummaryを導出する。

## 3. 適用範囲と責務境界

| 対象 | 本書の責務 |
|---|---|
| Identity | 構造、親子関係、一意性、比較単位 |
| Result | 四軸状態、Reason、Severity、集約 |
| Trace | IdentityからDefinition、Result、Artifactへの追跡 |
| Java | 論理型と不変条件。Packageおよび物理Source Rootは対象外 |
| JSON | Schema化すべき共通項目とVersion境界 |

次は別文書を正本とする。

| 対象外 | 正式な管理先 |
|---|---|
| API／UseCase／Scenarioの正式一覧 | `system/02_master/` |
| API項目、呼出順序、Mapping | `system/03_api_design/`、`system/04_usecase_design/`、Java |
| Scenario実行中Object | `ScenarioContext設計書.md` |
| Previous／Baseline更新 | `ExecutionState・Baseline管理設計書.md` |
| Field Diff Algorithm | `system/06_verification_assets/APIレスポンスDiff設計書.md` |
| Expected別の判定仕様 | `system/06_verification_assets/検証結果・Expected設計書.md` |
| Report Layout | `system/07_report/Report設計書.md` |
| Artifact Manifest詳細 | `Snapshot・Evidence設計書.md` |

## 4. 設計原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `IR-P001` | Static／Runtime分離 | Master IDとRun時Instance IDを混同しない。 |
| `IR-P002` | Stable Identity | 時刻、Directory順、List位置をIdentityにしない。 |
| `IR-P003` | Run一意 | 一回の起動に一つの`runId`を発行し再利用しない。 |
| `IR-P004` | 比較単位固定 | Baselineは`ExecutionIdentity`単位で分離する。 |
| `IR-P005` | 呼出実体一意 | API呼出は`apiCallCode`で識別し、`apiId`だけをKeyにしない。 |
| `IR-P006` | Result Key一意 | 独立Checkは安定した`resultKey`を一つ持つ。 |
| `IR-P007` | 四軸保持 | Execution、Verification、Change、Recoveryを相互上書きしない。 |
| `IR-P008` | Reason必須 | 非正常、未評価、未比較およびRecovery要求にはReasonを必須とする。 |
| `IR-P009` | Fail Closed | 未知のStatus、Reasonまたは不整合Identityを正常値へ丸めない。 |
| `IR-P010` | Immutable Result | Finalize後のResultと公開Artifactを変更しない。 |
| `IR-P011` | Deterministic Aggregate | 同じChild Result集合から同じ親Resultを導出する。 |
| `IR-P012` | Summary非破壊 | 表示用Summaryから四軸原結果を逆算しない。 |

## 5. Identity分類

### 5.1 静的定義Identity

| Identity | 例 | Source | 意味 |
|---|---|---|---|
| `businessId` | `BUS-E6-001` | Business Master | 業務Flow |
| `environmentId` | `ENV-STAGING` | Environment Master | 実行環境定義 |
| `apiId` | `API-E6-001` | API Master | API定義 |
| `useCaseId` | `UC-E6-001` | UseCase Master | UseCase定義 |
| `scenarioId` | `SC-E6-001` | Scenario Master | Scenario定義 |
| `inputSetId` | `INPUT-001` | Scenario Input | 入力Data Set |

静的IDはMasterまたは静的資産のIdentityであり、同じ定義を複数回実行しても変化しない。

現行Expectedは独立した`expectedSetId`を持たない。`environmentId + useCaseId + scenarioId + inputSetId`で対応資産を一意に識別し、内容改訂を`expectedVersion`で追跡する。

### 5.2 実行時Identity

| Identity | Scope | 一意性 |
|---|---|---|
| `runId` | 一回のPlatform起動 | Platform全体で一意 |
| `batchExecutionId` | Run内の一つのBatch実体 | `runId`内で一意 |
| `useCaseExecutionId` | Batch内のUseCase実体 | `runId`内で一意 |
| `scenarioExecutionId` | UseCase内のScenario実体 | `runId`内で一意 |
| `apiCallExecutionId` | Scenario内API呼出実体 | `runId`内で一意 |
| `checkExecutionId` | 一回のCheck実体 | `runId`内で一意 |
| `diffExecutionId` | 一回の比較実体 | `runId`内で一意 |
| `artifactId` | 一つの公開／一時Artifact | Artifact Store内で一意 |

実行時IDは再実行時に新規発行する。Retry、RecoveryまたはReport再生成で同じ業務定義を扱っても、異なる実行実体を同一IDへ上書きしない。

## 6. `runId`とExecution Identity

### 6.1 `runId`

`runId`は一回の物理実行を一意に識別するOpaque IDである。

```text
RUN-{UUID}
```

- UUIDの具体VersionはRuntime設計で確定する。
- 日時を一意性の根拠にしない。
- PID、Thread IDまたはHost名だけで生成しない。
- IDから実行日時、環境またはScenarioを解析しない。
- 失敗したRunのIDを再利用しない。

### 6.2 Execution Identity

Baseline、Execution StateおよびPrevious比較の論理Slotは次で識別する。

```text
ExecutionIdentity
= environmentId
 + useCaseId
 + scenarioId
 + inputSetId
```

`runId`はExecution Identityに含めない。`runId`を含めると毎回別Slotとなり、Previous／Baselineを同一比較単位で保持できないためである。

### 6.3 Identity整合条件

1. Scenario Masterが`scenarioId → useCaseId`を一意に解決できる。
2. Scenario Inputの`scenarioId`と`inputSetId`が実行対象と一致する。
3. Expectedの`environmentId`、`useCaseId`、`scenarioId`および`inputSetId`がScenario Inputと一致し、`expectedVersion`を追跡できる。
4. BaselineのExecution IdentityがCurrent Runと完全一致する。
5. `environmentId`を跨いだBaseline比較を禁止する。

## 7. 実行階層とCardinality

```mermaid
flowchart TD
    R["Run 1"]
    B["Batch 0..N"]
    U["UseCase 0..N"]
    S["Scenario 0..N"]
    C["API Call / Check / Diff 0..N"]
    R --> B --> U --> S --> C
```

| Parent | Child | Cardinality | 備考 |
|---|---|---:|---|
| Run | Batch Execution | `0..N` | Preflight拒否時は0件を許容 |
| Batch | UseCase Execution | `0..N` | Filter対象外は作成しないか`SKIPPED`を明示 |
| UseCase Execution | Scenario Execution | `1..N` | 実行対象UseCaseでは最低1件 |
| Scenario Execution | API Call Execution | `0..N` | 起動前Error、分岐Skipを許容 |
| Scenario Execution | Check Execution | `0..N` | Execution Error時は未作成の場合あり |
| API Call Execution | Diff Execution | `0..N` | 初回、Responseなし、対象外では0件 |
| 各Execution | Artifact | `0..N` | 公開要件はArtifact設計で確定 |

## 8. Runtime ID構築規則

Runtime IDはOpaque値として扱う。ただし、Traceのため親IDを別項目として必ず保持する。

```text
ScenarioExecutionIdentity
├── runId
├── batchExecutionId
├── useCaseExecutionId
├── scenarioExecutionId
├── executionIdentity
└── definitionRefs
    ├── useCaseId
    ├── scenarioId
    ├── inputSetId
    └── expectedVersion
```

連結文字列だけを保存し、構成項目を失ってはならない。Path安全性のため、IDは許可文字と最大長をSchemaで検証する。

## 9. API Call Identity

### 9.1 `apiId`と`apiCallCode`

| 項目 | 意味 | 一意Scope |
|---|---|---|
| `apiId` | 呼び出すAPI定義 | API Master |
| `apiCallCode` | Scenario内の呼出位置・役割 | `scenarioId`内 |
| `apiCallExecutionId` | Current Run内の呼出実体 | `runId`内 |

```text
SC-E6-001 / CALL-001 → API-E6-010
SC-E6-001 / CALL-003 → API-E6-010
```

同じAPIを複数回呼ぶ場合、`apiId`は同じでも`apiCallCode`と`apiCallExecutionId`は異なる。

### 9.2 呼出Trace Key

Field DiffとBaseline Responseの対応Keyは次とする。

```text
ExecutionIdentity + scenarioId + apiCallCode
```

`apiCallExecutionId`はCurrent Runの実体追跡に使用し、Previousとの対応Keyには使用しない。

## 10. Check Identity

### 10.1 `resultKey`

`resultKey`はScenario定義内で安定したCheck定義Keyである。

```text
{apiCallCode}.{checkCategory}.{targetCode}
```

例：

```text
CALL-001.STATUS.HTTP_200
CALL-001.FIELD.customer_id.EXISTS
CALL-001.FIELD.customer_id.TYPE
SCENARIO.BUSINESS.order_state_transition
```

上記Formatは論理例であり、正式な文字制約はExpected設計とSchemaで確定する。

### 10.2 規則

1. 一つの独立判定は一つの`resultKey`を持つ。
2. 同一Scenario内で重複させない。
3. 実行順序やArray Indexを恒久Identityにしない。
4. 同じFieldでも存在、型、Null、値、構造を別Checkにできる。
5. `IGNORE_VALUE`は同一型の値変化をDiff Itemとして記録し、`comparisonStatus=IGNORED`、`effectiveChanged=false`とする。比較未実施を表す`NOT_COMPARED`へ変換せず、存在、追加、削除、型、Null、構造および子項目Checkを自動PASSまたは対象外にしない。
6. `checkExecutionId`は一回の実行実体であり、`resultKey`を置換しない。

## 11. Diff Identity

| 項目 | 内容 |
|---|---|
| `diffExecutionId` | Current Run内の比較実体ID |
| `comparisonSourceRunId` | 比較元Run |
| `currentRunId` | 比較先Run |
| `apiCallCode` | 対象呼出 |
| `jsonPath` | API実JSON項目Path |
| `diffType` | Added／Removed／Type／Value／Structure等 |

Array要素のIdentityはIndex固定とせず、API別のKey定義またはOrdered比較方式をDiff設計で指定する。比較方式が未定義のCollectionを推測対応させない。

## 12. Artifact Identity

Artifactは最低限、次を保持する。

| 項目 | 内容 |
|---|---|
| `artifactId` | Artifactの一意ID |
| `artifactType` | Request、Response、Result、Diff、Log、Manifest、Report等 |
| `runId` | 生成元Run |
| `ownerExecutionType` | Run／Scenario／API Call／Check等 |
| `ownerExecutionId` | 生成元実体ID |
| `definitionRefs` | API、UseCase、Scenario等の静的参照 |
| `schemaVersion` | 内容契約Version |
| `contentHash` | 公開内容Hash |
| `publicationStatus` | `TEMPORARY / PUBLISHED / QUARANTINED` |

File名またはPathだけをArtifact Identityにしない。Manifestから`artifactId`、OwnerおよびHashを一意に追跡できることを必須とする。

## 13. 四結果軸

| 軸 | 問い | 正式Status |
|---|---|---|
| Execution | 必須処理と成果物はどこまで成立したか | `NOT_STARTED / RUNNING / COMPLETED / INCOMPLETE / REJECTED / UNKNOWN_OUTCOME` |
| Verification | Expected／Contractに適合したか | `NOT_EVALUATED / PASS / FAIL` |
| Change | Previous／Baselineとの差分はあるか | `NOT_COMPARED / UNCHANGED / CHANGED` |
| Recovery | 運用介入または復旧が必要か | `NOT_REQUIRED / REQUIRED / IN_PROGRESS / RESOLVED` |

Statusは相互排他的な軸ではない。例えば、完全に実行され業務Checkが不一致で差分もある場合は次となる。

```text
Execution   = COMPLETED
Verification = FAIL
Change       = CHANGED
Recovery     = NOT_REQUIRED
```

## 14. Execution Status

| Status | 定義 | 終了状態 |
|---|---|:---:|
| `NOT_STARTED` | 実行実体は生成済みだが処理未開始 | No |
| `RUNNING` | 処理中 | No |
| `COMPLETED` | 必須処理、ResultおよびArtifact完全性が成立 | Yes |
| `INCOMPLETE` | 開始したが必須処理またはArtifactが成立しない | Yes |
| `REJECTED` | Definition／Schema／権限等のPreflight不成立で実処理を開始しない | Yes |
| `UNKNOWN_OUTCOME` | 更新API Timeout等により外部状態を断定できない | Yes |

`COMPLETED`はVerification `PASS`を意味しない。`UNKNOWN_OUTCOME`を`INCOMPLETE`へ丸めず、更新系APIの重複実行Riskを保持する。

Execution StatusとArtifact Package Completenessは別属性である。`INCOMPLETE`、`REJECTED`または`UNKNOWN_OUTCOME`でも、その終端Outcomeに必要な安全なEvidence一式が揃えばArtifact Packageは`COMPLETE`になり得るが、Execution Statusを`COMPLETED`へ昇格させてはならない。

## 15. Verification Status

| Status | 定義 |
|---|---|
| `NOT_EVALUATED` | 前提不成立、対象外またはExecution Errorにより判定していない |
| `PASS` | 対象Checkをすべて評価し、Expected／Contractに適合 |
| `FAIL` | 一つ以上の評価済みCheckが不適合 |

`NOT_EVALUATED`にはReasonが必須である。対象Checkが0件であることを自動的に`PASS`としない。

## 16. Change Status

| Status | 定義 |
|---|---|
| `NOT_COMPARED` | 初回、比較元欠失、対象外またはExecution Errorで比較していない |
| `UNCHANGED` | 対象比較を完了し、有意差分が0件 |
| `CHANGED` | 対象比較を完了し、有意差分が1件以上 |

Ignore規則適用後の有意差分をChange集約対象とする。ただし、IgnoreされたFieldの存在、型、Nullおよび構造Check結果はVerification軸に残る。

## 17. Recovery Status

| Status | 定義 |
|---|---|
| `NOT_REQUIRED` | 運用介入不要 |
| `REQUIRED` | 人または専用Recovery処理による確認・復旧が必要 |
| `IN_PROGRESS` | Recovery作業中 |
| `RESOLVED` | Recovery手順が完了し、結果と監査証跡が確定 |

`RESOLVED`は元Runを`COMPLETED`へ書き換える意味ではない。元RunはImmutableに保持し、Recovery Executionを別Identityで関連付ける。

## 18. Result共通構造

```json
{
  "schemaVersion": "1.0",
  "resultId": "RESULT-...",
  "runId": "RUN-...",
  "ownerType": "SCENARIO",
  "ownerExecutionId": "SCEXEC-...",
  "executionStatus": "COMPLETED",
  "verificationStatus": "FAIL",
  "changeStatus": "CHANGED",
  "recoveryStatus": "NOT_REQUIRED",
  "severity": "ERROR",
  "reasonCodes": [
    "VERIFY_VALUE_MISMATCH"
  ],
  "childResultRefs": [
    "RESULT-..."
  ],
  "finalizedAt": "2026-07-27T20:00:00+09:00"
}
```

| 項目 | 必須 | 内容 |
|---|:---:|---|
| `schemaVersion` | Yes | Result Schema版 |
| `resultId` | Yes | Result Artifact内一意ID |
| `runId` | Yes | Run Trace |
| `ownerType` | Yes | Resultの集約Level |
| `ownerExecutionId` | Yes | 対象実行実体 |
| 四軸Status | Yes | 原結果 |
| `severity` | Yes | 運用上の最大重要度 |
| `reasonCodes` | 条件付 | 非正常／未評価／未比較理由 |
| `childResultRefs` | 集約時 | 集約根拠 |
| `finalizedAt` | Yes | Result確定時刻。Identityには使用しない |

## 19. Severity

| Severity | 意味 | 例 |
|---|---|---|
| `INFO` | 正常または情報通知 | 初回`NOT_COMPARED` |
| `WARNING` | 実行継続可能だが確認推奨 | 非必須Fieldの変更 |
| `ERROR` | 検証不一致、実行不完全または修正必須 | Required Check FAIL |
| `CRITICAL` | 外部状態不明、Securityまたは整合性Risk | 更新API`UNKNOWN_OUTCOME` |

Severityは四軸Statusの代替ではない。同じ`FAIL`でもCheck定義により`WARNING`または`ERROR`となり得るが、Severityを下げて`FAIL`を`PASS`へ変更してはならない。

## 20. Reason Code

### 20.1 区分

| Prefix | 区分 | 例 |
|---|---|---|
| `DEF_*` | Definition／Preflight | `DEF_SCENARIO_NOT_FOUND` |
| `EXEC_*` | 実行 | `EXEC_REQUIRED_CALL_INCOMPLETE` |
| `HTTP_*` | HTTP／Transport | `HTTP_TIMEOUT` |
| `VERIFY_*` | Expected／Contract | `VERIFY_VALUE_MISMATCH` |
| `CHANGE_*` | 比較 | `CHANGE_INITIAL_EXECUTION` |
| `ARTIFACT_*` | 証跡 | `ARTIFACT_MANIFEST_INVALID` |
| `RECOVERY_*` | Recovery | `RECOVERY_MANUAL_CONFIRMATION_REQUIRED` |
| `SECURITY_*` | Security | `SECURITY_MASK_FAILURE` |

### 20.2 規則

1. Reason Codeは安定した機械可読値とする。
2. 人向けMessage、例外Class名、Stack TraceをCodeに埋め込まない。
3. 四軸ごとに複数Reasonを保持できる。
4. 未知Codeを`OTHER`へ無条件変換しない。
5. Message TemplateとLocaleはReport／Log層で解決する。
6. Secret、実Request値およびResponse値をReason Parameterへ保存しない。
7. Platform Error／Failure CodeはComponent障害の診断Codeであり、四軸を説明するReason Codeと別Fieldで保持する。
8. Failure CodeからReason Codeへの変換はLog Writerではなく、分類済みFailure PolicyとResult Finalizerが行う。

## 21. ChildからParentへの集約

### 21.1 Execution集約

優先順位は次とする。

```text
UNKNOWN_OUTCOME
> INCOMPLETE
> REJECTED
> RUNNING
> NOT_STARTED
> COMPLETED
```

ただし、Preflightで子Executionを一件も作成せずRun全体を拒否した場合、Runは`REJECTED`とする。Childが存在しないだけで`COMPLETED`にしない。

### 21.2 Verification集約

```text
FAIL
> NOT_EVALUATED
> PASS
```

すべての必須Checkが評価済みで、FAILが0件の場合だけ`PASS`とする。任意Checkの`NOT_EVALUATED`取扱いはCheck定義で明示する。

### 21.3 Change集約

```text
CHANGED
> NOT_COMPARED
> UNCHANGED
```

ただし、必須比較がすべて完了した場合に限り`UNCHANGED`とする。一部未比較を`UNCHANGED`へ丸めない。

### 21.4 Recovery集約

```text
REQUIRED
> IN_PROGRESS
> RESOLVED
> NOT_REQUIRED
```

未解決の`REQUIRED`が一件でも存在する場合、親を`RESOLVED`にしない。

### 21.5 Severity集約

```text
CRITICAL > ERROR > WARNING > INFO
```

親ResultはChildの最大Severityを保持する。親固有Errorがあれば、それも候補へ追加する。

## 22. 集約対象とSkip

| 状況 | Execution | Verification | Change | 備考 |
|---|---|---|---|---|
| 条件分岐による正当なSkip | `COMPLETED`の構成要素になり得る | 対象外Reason付き`NOT_EVALUATED` | 対象外Reason付き`NOT_COMPARED` | Skipの根拠を保存 |
| 前段失敗による未到達 | `INCOMPLETE` | `NOT_EVALUATED` | `NOT_COMPARED` | `NOT_REACHED`をReason化 |
| Filterによる実行対象外 | Run Planへ対象外として記録 | 集約母数から除外 | 集約母数から除外 | 暗黙欠落は禁止 |
| 初回比較 | `COMPLETED`可 | 通常評価 | `NOT_COMPARED` | `CHANGE_INITIAL_EXECUTION` |

`SKIPPED`および`NOT_REACHED`は四軸の第五軸として追加せず、Execution Plan上のDispositionとReasonで表現する。

## 23. 表示用Summary

Report、DashboardまたはExit Codeは四軸から目的別に導出する。

| Summary | 導出例 | 用途 |
|---|---|---|
| `executionSummary` | Execution Statusそのもの | 運用完了確認 |
| `qualitySummary` | Verification + Severity | 検証結果確認 |
| `changeSummary` | Change + Diff件数 | 変更検知 |
| `recoverySummary` | Recovery + Open Action数 | 運用Handoff |

単一Badgeが必要な場合の表示優先順位は次とする。

```text
CRITICAL_RECOVERY
→ EXECUTION_PROBLEM
→ VERIFICATION_FAILED
→ CHANGE_DETECTED
→ PASSED_UNCHANGED
```

このBadgeは表示専用であり、保存済み四軸Status、Baseline更新可否またはRetry可否を決定しない。

## 24. Baseline更新との関係

Baseline更新可否は次の論理条件を最低条件とする。

```text
executionStatus == COMPLETED
AND artifactCompleteness == COMPLETE
AND identityConsistency == VALID
```

- Verification `FAIL`はBaseline更新を自動禁止しない。
- Change `CHANGED`はBaseline更新を自動禁止しない。
- Recovery `REQUIRED`または`IN_PROGRESS`は原則更新禁止とし、例外は運用設計で明示承認する。
- `UNKNOWN_OUTCOME`、`INCOMPLETE`および`REJECTED`は更新禁止とする。

ここで`artifactCompleteness == COMPLETE`は終端Outcome別の必須Evidenceが完全であることを表す。Execution `COMPLETED`の代用ではない。終端Outcome別必須Artifact集合と判定Enumは`Snapshot・Evidence設計書.md`で定義する。

最終条件は`ExecutionState・Baseline管理設計書.md`とSnapshot／File I/O設計で整合させる。

## 25. RetryとRecovery Identity

| 処理 | Identity規則 |
|---|---|
| 全体再実行 | 新しい`runId`を発行 |
| Scenario再実行 | 新しい`runId`または明示的Recovery Runを発行 |
| Report再生成 | 元`runId`をSourceとして保持し、Report Artifactは新しい`artifactId` |
| Recovery Case | `recoveryCaseId`を発行し、`sourceRunId`および`sourceResultId`へ関連付け |
| Recovery操作 | `recoveryExecutionId`または`recoveryActionId`を発行し、`recoveryCaseId`へ関連付け |
| 更新APIの手動確認 | 元Runを変更せず、確認結果をRecovery Artifactへ追加 |

Retry回数を`apiCallCode`の上書きで表現しない。試行ごとにExecution IDを分離し、業務上同一操作であることを`attemptGroupId`で関連付ける。

Recovery Case、Action、Resolutionは元Runと別IdentityでAppend Onlyに記録する。Recovery `RESOLVED`はRecovery記録の確定を表し、元RunのExecution、VerificationまたはChangeを変更しない。

## 26. LifecycleとImmutable化

```mermaid
stateDiagram-v2
    [*] --> CREATED
    CREATED --> COLLECTING
    COLLECTING --> FINALIZING
    FINALIZING --> FINALIZED
    FINALIZING --> INVALID
    FINALIZED --> PUBLISHED
    PUBLISHED --> [*]
    INVALID --> [*]
```

| 状態 | 許可 |
|---|---|
| `CREATED` | Identity、Owner設定 |
| `COLLECTING` | Child ResultとReason追加 |
| `FINALIZING` | 集約、Schema、参照完全性検証 |
| `FINALIZED` | 読取のみ |
| `PUBLISHED` | Hash／Manifest付き公開、変更禁止 |
| `INVALID` | 隔離。正常Report／Baseline入力禁止 |

公開後の訂正は元Resultを編集せず、新しい訂正ArtifactまたはRecovery Resultとして関連付ける。

## 27. Java論理モデル

```java
public record ExecutionIdentity(
        String environmentId,
        String useCaseId,
        String scenarioId,
        String inputSetId) {
}

public record ResultAxes(
        ExecutionStatus execution,
        VerificationStatus verification,
        ChangeStatus change,
        RecoveryStatus recovery) {
}

public record CommonResult(
        String resultId,
        String runId,
        ResultOwner owner,
        ResultAxes axes,
        Severity severity,
        List<Reason> reasons,
        List<String> childResultRefs,
        Instant finalizedAt) {
}
```

上記は契約例であり、Class名、Package、Persistence AnnotationおよびFramework依存を先行固定しない。Mutable BuilderとFinalized Resultを分離し、公開後Resultを変更可能なSetterで保持しない。

## 28. Schema契約

最低限、次のSchemaへ本書のIdentity／Result契約を反映する。

| Schema | 主な反映内容 |
|---|---|
| `scenario-input.schema.json` | `scenarioId`、`inputSetId` |
| `scenario-expected.schema.json` | Expected Identity、`expectedVersion`、`resultKey` |
| `verification-result.schema.json` | 四軸、Severity、Reason、Owner |
| `response-field-diff.schema.json` | Run、Call、Path、Change Status |
| `execution-state.schema.json` | Execution Identity、`previousRunId` |
| `baseline-meta.schema.json` | Source Run、Execution Identity、Result Summary |
| `artifact-manifest.schema.json` | Artifact ID、Owner、Hash、Schema Version |

Schema VersionとJava DTO Versionは別々に管理するが、互換表を必須とする。未知のMajor Versionを読み飛ばしてはならない。

初期7 Schema正文・機械Validation完了時点で、`verification-result.schema.json`は本書の`resultId`、Owner、四結果軸、Severity、Reason、Child Referenceおよび`finalizedAt`を構造契約として保持する。Check Summary算術、Child Severity最大値、Reference解決および時刻順序はSemantic Validator／Result Finalizerで検証する。

## 29. Traceability

一つのCheck結果から最低限、次を双方向に追跡できること。

```text
Business
↔ UseCase
↔ Scenario
↔ Scenario Execution
↔ API Call
↔ Check / Diff
↔ Result
↔ Artifact
↔ Report
```

| Trace元 | 必須参照 |
|---|---|
| Run Result | Definition Hash、Child Execution、Manifest |
| Scenario Result | `scenarioId`、Input／Expected、API Call、Check |
| API Call Result | `apiCallCode`、`apiId`、Request／Response Artifact |
| Check Result | `resultKey`、Expected Rule、Target Path |
| Diff Result | Source／Current Run、`apiCallCode`、JSON Path |
| Report Item | Result ID、Artifact ID。表示文だけを根拠にしない |

## 30. Error Code

| Error Code | 条件 | 処理 |
|---|---|---|
| `IR_INVALID_RUN_ID` | `runId`欠失・形式不正 | Preflight拒否 |
| `IR_IDENTITY_MISMATCH` | Definition、Input、Expected、Baseline不一致 | API呼出前停止 |
| `IR_DUPLICATE_EXECUTION_ID` | 実行時ID重複 | Runを`REJECTED`または`INCOMPLETE` |
| `IR_DUPLICATE_RESULT_KEY` | Scenario内`resultKey`重複 | Scenarioを`INCOMPLETE` |
| `IR_UNKNOWN_STATUS` | 未知Enum | Fail Closed |
| `IR_REASON_REQUIRED` | Reason必須状態で未設定 | Finalize拒否 |
| `IR_CHILD_RESULT_MISSING` | 集約参照先欠失 | Resultを`INVALID` |
| `IR_AGGREGATION_INCONSISTENT` | 再計算結果と保存結果不一致 | 公開禁止 |
| `IR_RESULT_ALREADY_FINALIZED` | Finalize後更新 | 更新拒否 |
| `IR_CROSS_RUN_REFERENCE` | 許可されない別Run参照 | Security／Integrity Error |

## 31. Validation

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `IR-V001` | `runId`が全Runで一意である。 | ERROR |
| `IR-V002` | Execution Identityの4項目が設定される。 | ERROR |
| `IR-V003` | Static IDとRuntime IDを同じFieldで兼用しない。 | ERROR |
| `IR-V004` | `apiCallCode`がScenario内で一意である。 | ERROR |
| `IR-V005` | `resultKey`がScenario内で一意で安定している。 | ERROR |
| `IR-V006` | 四軸Statusがすべて保存される。 | ERROR |
| `IR-V007` | 未評価、未比較、非正常状態にReasonがある。 | ERROR |
| `IR-V008` | Child集約が定義済み優先順位と一致する。 | ERROR |
| `IR-V009` | Summaryが原結果を上書きしない。 | ERROR |
| `IR-V010` | `UNKNOWN_OUTCOME`が`INCOMPLETE`へ変換されない。 | ERROR |
| `IR-V011` | Complete条件がVerification `PASS`だけに依存しない。 | ERROR |
| `IR-V012` | Published ResultがImmutableである。 | ERROR |
| `IR-V013` | ResultからArtifactとDefinitionを追跡できる。 | ERROR |
| `IR-V014` | Cross-Environment Baseline比較を拒否する。 | ERROR |
| `IR-V015` | 未知Schema Major Versionを拒否する。 | ERROR |

## 32. Test観点

- [ ] 同一Scenarioの並行実行で異なる`runId`とExecution IDが生成される。
- [ ] 同じExecution IdentityのRunが同じBaseline Slotを参照する。
- [ ] 異なるEnvironmentまたはInput SetがBaselineを共有しない。
- [ ] 同じAPIを複数回呼び、`apiCallCode`別に追跡できる。
- [ ] `IGNORE_VALUE`でも存在／型／Null／構造Checkが独立する。
- [ ] Verification `FAIL`かつExecution `COMPLETED`を表現できる。
- [ ] 初回をChange `NOT_COMPARED`で表現できる。
- [ ] 更新API TimeoutをExecution `UNKNOWN_OUTCOME`、Recovery `REQUIRED`で表現できる。
- [ ] Child順序を変えても集約結果が変わらない。
- [ ] 欠落Child Resultがある場合に親を`PASS`／`COMPLETED`にしない。
- [ ] Report Badgeから四軸を逆算しない。
- [ ] Finalized／Published Resultの更新を拒否する。

## 33. Open Issue

| Issue ID | 内容 | 暫定方針 | 決定先 |
|---|---|---|---|
| `IR-OI-001` | UUID VersionとID Prefix／最大長 | Opaque ID原則を維持 | 共通Framework／Schema |
| `IR-OI-002` | Batchの正式単位とScheduler Job関係 | 論理Batchとして定義 | 共通Framework／Environment |
| `IR-OI-003` | Optional Checkの`NOT_EVALUATED`集約 | Expectedで必須性を明示 | Expected設計 |
| `IR-OI-004` | Check別Severity Override | 許可範囲をExpectedで制限 | Expected設計／Report |
| `IR-OI-005` | Recovery Result／CaseのSchema分離可否 | 四軸Recovery Statusは共通Result、Case／Actionは別Identityとする。Schema追加要否は第8バッチReview待ち | Log・Recovery設計／Schema Review |
| `IR-OI-006` | Report再生成Artifactの世代管理 | Source Runを不変参照 | Snapshot／Report |

## 34. 完了条件

本書は次を満たした時点でReview可能とする。

1. Identityの静的／Runtime／比較単位が分離されている。
2. RunからArtifactまでの親子関係が定義されている。
3. 四軸Status、Severity、Reasonおよび集約規則が一意である。
4. `UNKNOWN_OUTCOME`、`NOT_EVALUATED`、`NOT_COMPARED`を正常値へ丸めない。
5. Baseline更新条件と矛盾しない。
6. Schema、Java、ArtifactおよびReportのTrace境界が定義されている。
7. Java Package、Source Rootおよび物理Runtime Pathを先行固定していない。

## 35. 後続設計への入力

本書を次の正規入力とする。

1. `共通Framework設計書.md`
2. `Framework・業務定義連携設計書.md`
3. `Snapshot・Evidence設計書.md`
4. `ファイル入出力設計書.md`
5. `ログ・例外・Recovery設計書.md`
6. `環境・Runtime構成設計書.md`
7. `verification-result.schema.json`
8. `artifact-manifest.schema.json`

## 36. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | Static／Runtime Identity、四結果軸、Severity、Reason、集約、Immutable化およびTrace契約を新規定義 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | `IGNORE_VALUE`を現行Diff契約へ統一し、Reason Code例を`VERIFY_*`規則へ是正 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | 横断ReviewによりExecution Statusと終端Outcome別Artifact Package Completenessを分離 | DRAFT |
| `1.0.0-draft.4` | 2026-07-28 | Snapshot／Evidence設計に合わせ、Artifact Publication StatusをCanonical Enum `TEMPORARY / PUBLISHED / QUARANTINED`へ統一 | DRAFT |
| `1.0.0-draft.5` | 2026-07-28 | Log／Recovery設計に合わせ、Failure CodeとReason Codeを分離し、Recovery Case／Action／Resolutionの別Identityと元Run不変条件を追加 | DRAFT |
| `1.0.0-draft.6` | 2026-07-28 | Scenario Expected Schema契約に合わせ、未採用の`expectedSetId`を除去し、現行Expected Identityと`expectedVersion`追跡へ統一 | DRAFT |
| `1.0.0-draft.7` | 2026-07-28 | `verification-result.schema.json`正文に合わせ、Result Identity／Owner、四結果軸、Severity／Reason、Child ReferenceおよびSchema／Semantic Validation境界を同期 | DRAFT |
