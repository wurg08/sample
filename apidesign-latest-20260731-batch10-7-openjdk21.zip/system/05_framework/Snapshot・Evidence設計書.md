---
title: Snapshot・Evidence設計書
document_id: E6-API-VAL-SNAPSHOT-EVIDENCE-DESIGN
version: 1.0.0-draft.8
status: DRAFT
document_type: Snapshot and Evidence Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Snapshot・Evidence設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Snapshot・Evidence設計書 |
| 文書ID | `E6-API-VAL-SNAPSHOT-EVIDENCE-DESIGN` |
| 対象 | Run Artifact、Snapshot、Evidence、Artifact Manifest、Mask、Hash、完全性および公開境界 |
| 配置 | `system/05_framework/` |
| 文書種別 | Runtime Artifact・Evidence共通設計書 |
| 版数 | `1.0.0-draft.8` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | Framework / Runtime Team |
| レビュー責任 | System Architect / Runtime Lead / Verification Lead / Security Lead / Operation Lead |
| 承認責任 | System Owner |

## 2. 目的

本書は、E6 API Verification Platformが一回のRunで生成する実行事実を、安全かつ改変検知可能なEvidenceとして保存し、Result、Diff、Report、BaselineおよびRecoveryから一意に追跡するため、次を定義する。

1. Snapshot、Artifact、EvidenceおよびEvidence Packageの責務
2. Run、ScenarioおよびAPI Call単位のArtifact分類
3. Sealed Execution Planと終端Outcomeから必須Artifactを決定する規則
4. 保存前Mask、Secret除去および例外Raw Evidenceの統制
5. Canonical Serialization、Content HashおよびArtifact Manifest
6. Artifact Package CompletenessとExecution Statusの分離
7. Temporary、PublishedおよびQuarantinedの公開境界
8. Baseline、Report、Evidence IndexおよびRecoveryへの引渡し
9. Java、JSON SchemaおよびFile I/O設計が維持すべき契約

本書は単にRequest／ResponseをFileへ出力する設計ではない。安全性、Identity、Schema、Hash、参照完全性および終端Outcome別必須Artifactをすべて検証したPackageだけを通常Evidenceとして公開する。

## 3. 上位入力

| Reference | 本書で使用する契約 |
|---|---|
| `system/01_repository/Repository_Structure.md` | 凍結Runtime論理構造、相対Path、Repository／Runtime分離 |
| `system/01_repository/命名規約.md` | `api-meta.json`等の固定File名、Runtime ID、JSON Key |
| `system/01_repository/トレーサビリティ規約.md` | Artifact Trace、Manifest、Evidence Indexの逆Trace |
| `system/05_framework/システム設計書.md` | Artifact Publisher、Security、Auditability、Failure Boundary |
| `system/05_framework/共通Identity・Resultモデル設計書.md` | Artifact Identity、四結果軸、Immutable化、Baseline最低条件 |
| `system/05_framework/共通Framework設計書.md` | Commit Point、Sealed Execution Plan、Artifact／State／Report境界 |
| `system/05_framework/Framework・業務定義連携設計書.md` | Definition Bundle、Source Revision、Bundle Hash、Definition Trace |
| `system/05_framework/ScenarioContext設計書.md` | `ApiExchange`、Request／Response JSON、Context非永続化 |
| `system/05_framework/ExecutionState・Baseline管理設計書.md` | Complete Run、Baseline対象、Atomic置換、State更新順序 |
| `system/06_verification_assets/APIレスポンスDiff設計書.md` | `response-field-diff.json`、初回／比較不能表現、Mask境界 |
| `system/07_report/Report設計書.md` | Report入力、Evidence Index、Report固有Status、Report原子的公開 |

## 4. 適用範囲と責務境界

### 4.1 本書の対象

- Run Core Artifact
- API Call Artifact
- Artifact Metadata
- Evidence Package
- Artifact Manifest
- Mask／Redaction／Secret Scan
- Canonical JSONとHash
- Package Completeness
- Publication／Quarantine
- BaselineおよびReportへの安全な引渡し
- Artifact Writer／Validator／Publisherの論理Port

### 4.2 本書の対象外

| 対象外 | 確定先 |
|---|---|
| OS絶対Path、Mount Path、Storage製品 | `ファイル入出力設計書.md`、`環境・Runtime構成設計書.md` |
| File Lock、Object Storage Pointer、`fsync`実装 | `ファイル入出力設計書.md` |
| Structured Log Schema、Stack Trace、Recovery Record | `ログ・例外・Recovery設計書.md` |
| Report Layout、Markdown Template、Daily集約 | `system/07_report/Report設計書.md` |
| Response Field比較Logic | `system/06_verification_assets/APIレスポンスDiff設計書.md` |
| Retention日数、Archive、Backup世代 | `環境・Runtime構成設計書.md`および運用設計 |
| Credential取得、Key管理、暗号Provider | `環境・Runtime構成設計書.md` |
| JSON Schema実体 | `system/06_verification_assets/common/schemas/` |

本書は論理Artifact契約を確定する。未決のStorageまたはSecurity製品を仮定して物理構成を固定しない。

## 5. 用語

| 用語 | 定義 |
|---|---|
| Snapshot | ある実行時点の事実をSchema付きArtifactとして固定したもの |
| Artifact | 一意な`artifactId`、Owner、Schema、HashおよびPathを持つ公開可能な成果物 |
| Evidence | Result、Diff、監査または障害調査の根拠として利用できる安全なArtifact |
| Core Run Artifact | Report生成前に確定するRun、Scenario、API Call、ResultおよびDiffの正本Artifact |
| Evidence Package | 一つのRunに属するCore Run ArtifactとArtifact Manifestの集合 |
| Artifact Manifest | Package内ArtifactのIdentity、Path、Hash、Size、SchemaおよびMask状態を保持する完全性索引 |
| Evidence Index | ReportからArtifactへ到達するためにArtifact Manifestから生成する表示用索引 |
| Terminal Outcome Profile | Execution終端状態ごとの必須Artifact規則 |
| Canonical Content | Hash計算前に決定的規則でSerializeした公開内容 |
| Protected Raw Evidence | 例外承認時だけ隔離領域へ保存できる、通常Evidenceではない制限Artifact |
| Quarantine | 通常Report、Baselineおよび一般参照から隔離した保存状態 |

SnapshotとEvidenceを同義にしない。SnapshotであってもMask、Schema、HashまたはIdentity検証に失敗したものは通常Evidenceにならない。

## 6. 設計原則

| 原則ID | 原則 |
|---|---|
| `SNP-P001` | 通常EvidenceへSecret、Credential、Token、Cookie実値を保存しない。 |
| `SNP-P002` | Mask、Schema ValidationおよびSecret Scanは公開後ではなく永続化前に行う。 |
| `SNP-P003` | File名またはPathだけをArtifact Identityにしない。 |
| `SNP-P004` | 公開内容のCanonical HashをArtifact Manifestへ保持する。 |
| `SNP-P005` | Package CompletenessをExecution Status、Verification、ChangeおよびReport Statusと分離する。 |
| `SNP-P006` | 必須Artifact集合は固定の一律一覧ではなく、Sealed Planと終端Outcomeから決定する。 |
| `SNP-P007` | 存在しないResponse、実行されていないCallまたは未実施Diffを空Fileで偽装しない。 |
| `SNP-P008` | `ScenarioContext`、DTOまたはJava Object Graphをそのまま長期Serializeしない。 |
| `SNP-P009` | Package単位の公開完了前に、途中Artifactを通常Consumerへ公開しない。 |
| `SNP-P010` | Published Artifactを上書きせず、訂正、再生成およびRecoveryを別Identityで関連付ける。 |
| `SNP-P011` | Evidence IndexとReportはEvidenceの正本ではなく、Published Artifactから導出する。 |
| `SNP-P012` | Report生成失敗でSource Run Artifactまたは四結果軸を書き換えない。 |

## 7. Artifact階層

```mermaid
flowchart TD
    A["Sealed Execution Plan"] --> B["Core Run Artifacts"]
    B --> C["Mask・Schema・Hash"]
    C --> D["Artifact Manifest"]
    D --> E{"Completeness"}
    E -- COMPLETE --> F["Published Evidence Package"]
    E -- INCOMPLETE／INVALID --> G["Quarantine"]
    F --> H["Baseline Candidate"]
    F --> I["Report／Evidence Index"]
    F --> J["Recovery Reference"]
```

ReportはPublished Evidence PackageのConsumerであり、Core Run Artifactの作成途中へ直接接続しない。

## 8. Artifact分類

### 8.1 Core Run Artifact

| Artifact Type | 固定Path | Owner | 内容 |
|---|---|---|---|
| `RUN_META` | `run-meta.json` | Run | Run Identity、Definition、Build、時刻、四軸Result Reference |
| `SCENARIO_EXECUTION` | `scenario-execution.json` | Scenario Execution | Plan上のCall、分岐、Disposition、到達性、終端状態 |
| `VERIFICATION_RESULT` | `verification-result.json` | Scenario／Check集合 | `resultKey`、Expected照合、四結果軸、Reason |
| `API_CALL_META` | `api-calls/{apiCallCode}/api-meta.json` | API Call Execution | Call Identity、Attempt、送信／受信状態、HTTP／Transport Metadata |
| `REQUEST` | `api-calls/{apiCallCode}/request.json` | API Call Execution | 実際に送信した安全なRequest表現 |
| `RESPONSE` | `api-calls/{apiCallCode}/response.json` | API Call Execution | 実際に受信した安全なResponse表現 |
| `RESPONSE_FIELD_DIFF` | `api-calls/{apiCallCode}/response-field-diff.json` | Diff Execution | Current／Baseline比較結果または未比較理由 |
| `ARTIFACT_MANIFEST` | `artifact-manifest.json` | Run Artifact Package | Core Run Artifactの完全性索引 |

`artifact-manifest.json`は自身をArtifact Entryとして列挙しない。Manifest自身の改変検知は`manifestHash`規則で行う。

### 8.2 Derived Artifact

| Artifact | 管理方針 |
|---|---|
| Scenario Summary | Published Evidence PackageからReport Generation単位で生成する。 |
| Diff Report | `response-field-diff.json`を表示・集約し、比較を再実行しない。 |
| Evidence Index | Artifact Manifestから相対Linkを生成し、Evidenceを複製しない。 |
| Daily Summary | Batch Resultと各Published Runを入力とする。 |

`reports/`はCore Run Artifact Manifestの対象外とする。Core Manifestを入力として後生成するReportを同じManifestへ含めると循環依存になるためである。Report Setは`system/07_report/Report設計書.md`の`generationId`、Report Status、Hashおよび原子的公開契約に従う。

### 8.3 Diagnostic Artifact

Log、Exception Detail、Recovery RecordおよびProtected Raw EvidenceはCore Packageと別の統制対象とする。これらの存在をExecution、VerificationまたはPackage Completenessの代用にしない。

通常Evidenceへ連携する場合は、次の条件をすべて満たす。

1. 本書のMask／Secret非保存条件を満たす。
2. Source RunおよびOwner Identityを持つ。
3. `ログ・例外・Recovery設計書.md`でSchemaと公開Levelが定義されている。
4. Artifact Manifestの許可された拡張TypeとしてSchema Versionが登録されている。

## 9. Artifact Requirementの決定

### 9.1 Requirement Source

必須Artifactは次の二入力から決定する。

```text
Sealed Execution Plan.artifactRequirements
+
Terminal Outcome Profile
=
Effective Artifact Requirements
```

Execution中の実装判断で必須Artifactを減らしてはならない。Planに存在しないArtifactを必須扱いする場合は、契約Version不一致としてRunを安全に停止する。

### 9.2 Requirement属性

| 項目 | 内容 |
|---|---|
| `requirementId` | 必須条件の安定ID |
| `artifactType` | 対象Artifact |
| `ownerSelector` | Run／Scenario／Plan内API Call等 |
| `requiredWhen` | Outcome、Call Disposition、送信／受信状態等 |
| `schemaVersion` | 必須Schema版 |
| `sensitivityClass` | Public Metadata／Internal／Confidential等 |
| `maskProfileRef` | 適用Mask Profile |
| `absenceReasonAllowed` | Artifactを作らないことが合法な条件 |

### 9.3 API Call単位の決定規則

| 状況 | `api-meta.json` | `request.json` | `response.json` | `response-field-diff.json` |
|---|:---:|:---:|:---:|:---:|
| Plan上のCall | 必須 | 状態依存 | 状態依存 | 状態依存 |
| 条件分岐による正当なSkip | 必須 | 禁止 | 禁止 | 原則不要 |
| 前段Failureによる未到達 | 必須 | 禁止 | 禁止 | 原則不要 |
| Request生成前Failure | 必須 | 禁止 | 禁止 | 必要時`NOT_COMPARED` |
| Request確定・未送信 | 必須 | 必須 | 禁止 | 必要時`NOT_COMPARED` |
| 送信済み・Responseなし | 必須 | 必須 | 禁止 | 必須。`NOT_COMPARED`と理由を記録 |
| HTTP Response受信 | 必須 | 必須 | 必須 | 比較対象なら必須 |
| 初回実行 | 必須 | 実行時必須 | 受信時必須 | 比較対象Callでは必須。`INITIAL_EXECUTION` |

空Responseまたは空Diffを作り、存在しない実行事実を表現してはならない。Artifact不在の理由は`api-meta.json`、`scenario-execution.json`およびManifestのRequirement評価へ保持する。

## 10. Snapshot契約

### 10.1 Run Snapshot

Run Snapshotの正本は`run-meta.json`とする。最低限、次を保持する。

| 分類 | 項目 |
|---|---|
| Identity | `runId`、`batchId`、Execution Identity |
| Definition | `bundleId`、`bundleHash`、`sourceRevision`、Schema Version一覧 |
| Build | Release ID、Application Version、Build Identity、Artifact／Image Digest、Registry Snapshot Reference |
| Runtime | Runtime Deployment Profile ID／Version、SecretなしConfig Hash、Storage／Lock／HTTP／Sink Capability Profile Reference |
| Request | `requestId`、`requestedByRef`、`executionMode` |
| Lifecycle | `startedAt`、`endedAt`、Run Phase、Terminal Outcome |
| Result | 四結果軸、`resultId`、Reason Code |
| Artifact | Package Completeness、Manifest Reference |

`requestedByRef`は追跡用主体IDとし、不要な個人名、Mail AddressまたはAuthentication情報を保存しない。

### 10.2 Definition Snapshot

Definition Bundle全体をRun Directoryへ無条件複製しない。`run-meta.json`には、実行時にSealしたBundleを再特定できる次を保存する。

- `bundleId`
- `bundleVersion`
- `bundleHash`
- `sourceRevision`
- `masterSnapshots`
- `designSnapshots`
- `assetSnapshots`
- `registrySnapshot`

Input／Expectedの実値をReport用に別Fileへ複製しない。監査上内容保全が必要な場合は、不変Release Artifactまたは承認済みDefinition Archiveを`sourceRevision`とHashから取得する。ArchiveのRetentionとAccessはEnvironment／Operation設計で確定する。

### 10.3 Scenario Snapshot

Scenario Snapshotの正本は`scenario-execution.json`と`verification-result.json`である。

`scenario-execution.json`は次を保持する。

- Scenario Execution Identity
- Plan上のAPI Call一覧
- Branch判定と根拠Reference
- 各Callの`EXECUTED / SKIPPED / NOT_REACHED / REJECTED` Disposition
- Start／End時刻
- Execution StatusとReason
- Child Result Reference

`verification-result.json`は四結果軸、`resultKey`、Expected／Actualの安全なReference、Reason、Severityおよび集約根拠を保持する。

### 10.4 API Call Snapshot

`api-meta.json`はAPI Call実行事実の正本Metadataとし、次を保持する。

| 分類 | 項目 |
|---|---|
| Identity | `runId`、`scenarioExecutionId`、`apiCallExecutionId`、`apiCallCode`、`apiId` |
| Plan | Call順序、Required／Optional、Branch、Attempt Group |
| Transport | Method、Endpoint Reference、送信開始／完了、受信状態、HTTP Status |
| Outcome | Disposition、Call Status、Reason Code |
| Artifact Ref | Request、Response、Diffの`artifactId`または不在理由 |
| Timing | Start、End、Elapsed。Identityには使用しない。 |

EndpointはEnvironment設定Referenceを基本とする。実URLを保存する場合はUser Info、Credential、Secret Queryを除去し、Host／Pathの公開LevelをSecurity設計に従わせる。

### 10.5 Request／Response Snapshot

Request／Response Snapshotは外部APIのJSON項目名を維持する。DTO Field名だけをEvidenceとして保存してはならない。

保存前に次を完了する。

1. Header Allowlist適用
2. CookieおよびAuthorization除去
3. Query／Path／BodyのMask
4. Content TypeとCharacter Encoding正規化
5. JSON ParseまたはBinary Metadata化
6. Schema Validation
7. Secret／PII Scan
8. Canonical Serialization
9. Hash計算

Parse不能Payloadを文字列として通常Response Artifactへそのまま保存しない。必要な場合は、安全なMetadata、Length、Content Type、Transport ResultおよびReasonを`api-meta.json`へ記録し、Raw BodyはProtected Raw Evidenceの例外手続に従う。

### 10.6 Context Snapshot

`ScenarioContext`全体、内部Map、DTO ObjectまたはSecret参照をContext Snapshotとして保存しない。

Contextの実行事実は次へ分解して保持する。

| Context事実 | 保存先 |
|---|---|
| 実際に送信した値 | Mask済み`request.json` |
| 実際に受信した値 | Mask済み`response.json` |
| 抽出／Mapping元 | `api-meta.json`またはCheck Resultの安全なReference |
| Check結果 | `verification-result.json` |
| 分岐結果 | `scenario-execution.json` |

独立したContext Artifactが将来必要な場合は、Schema、最小項目、Mask Profile、RetentionおよびRequirementをArchitecture Reviewで追加する。汎用Object Dumpを許可しない。

### 10.7 Cross-Artifact Trace Envelope

Core Run Artifactは同じ実行を表す共通Identityを独立に持ち、File PathまたはManifest掲載順から補完しない。

| Artifact | Trace Envelopeの必須概念項目 |
|---|---|
| `run-meta.json` | `runId`、Execution Identity、`bundleId`、`bundleHash`、Registry Snapshot Reference |
| `scenario-execution.json` | `runId`、`scenarioExecutionId`、`scenarioId`、Plan上の`apiCallCode`集合、Child Result Reference |
| `api-meta.json` | `runId`、`scenarioExecutionId`、`apiCallExecutionId`、`apiCallCode`、`apiId`、Request／Response／Diff Artifact Reference |
| `verification-result.json` | `runId`、`resultId`、`ownerExecutionId`、Execution Identity、`expectedVersion`、`resultKey`集合 |
| `response-field-diff.json` | `runId`、Baseline Run ID、Execution Identity、`apiCallCode`、`apiId`、Diff Item Identity |
| `artifact-manifest.json` | `runId`、Execution Identity、`bundleId`、`bundleHash`、Artifact ID／Owner／Path／Hash |

次の横断不変条件をArtifact公開前に検証する。

1. 全Artifactの`runId`がRun MetaおよびManifestと一致する。
2. Execution IdentityがRun Meta、Verification Result、DiffおよびManifestで一致する。
3. `scenarioExecutionId`と`apiCallExecutionId`の親子関係がScenario ExecutionおよびAPI Call Metaで一意である。
4. `apiCallCode + apiId`がSealed Plan、API Call MetaおよびDiffで一致する。
5. Verification Resultの全必須`resultKey`がExpected SnapshotとCheck Registry Snapshotへ逆引きできる。
6. Manifest Entryの`artifactId`、Owner、`relativePath`、Schema Versionおよび`contentHash`が公開実体と一致する。
7. `bundleId + bundleHash`がRun MetaとManifestで一致し、当該BundleからMaster／設計／Registryへ逆引きできる。

`run-meta.json`、`scenario-execution.json`および`api-meta.json`は、それぞれ独立Schemaで構造検証する。論理Trace Envelopeの親子Identity、Call集合、Bundle／Registry Hash、Manifest Entryおよび実Byteの一致は単一Schemaでは完結しないため、Cross-Artifact Semantic ValidatorとJava Contract Testを通過するまで`TRACE-RUNTIME`を`PASSED`としない。

## 11. 保存前Mask

### 11.1 処理Flow

```mermaid
flowchart TD
    A["Runtime Payload"] --> B["Artifact Type判定"]
    B --> C["Allowlist・除去"]
    C --> D["Mask Profile適用"]
    D --> E["Secret／PII Scan"]
    E --> F{"Safe?"}
    F -- Yes --> G["Canonical Serialization"]
    F -- No --> H["永続化禁止・Quarantine Metadata"]
    G --> I["Schema・Hash・Stage"]
```

Mask失敗時に「一旦保存して後からMask」してはならない。

### 11.2 Mask Profile

| 項目 | 内容 |
|---|---|
| `maskProfileId` | Profileの安定ID |
| `profileVersion` | 規則Version |
| `profileHash` | 実行時規則の改変検知 |
| `artifactTypes` | 適用対象 |
| `rules` | Path、分類、Action、表示条件 |
| `defaultAction` | 未知Fieldの処理 |
| `approvedByRef` | 承認済みProfile Reference |

Java First原則に従い、任意式または実行ScriptをMask Profileへ埋め込まない。PathとActionの静的定義をJava実装が解決する。

### 11.3 Sensitive分類とAction

| 分類 | 例 | 既定Action |
|---|---|---|
| Credential | Password、Client Secret、API Key | `REMOVE` |
| Authentication Material | Authorization、Token、Session Cookie | `REMOVE` |
| Personal Identifier | 顧客番号、会員番号 | `PARTIAL_MASK`または`TOKENIZE` |
| Personal Data | 氏名、電話、Mail、住所 | `REDACT`または承認済み部分Mask |
| Financial／Business Confidential | 口座、契約、社内管理番号 | API別Policy |
| Diagnostic Secret | Connection String、Key Path | `REMOVE` |

CredentialとAuthentication Materialは、末尾表示、Hash化またはTokenizeによる通常Evidence保存も禁止する。低Entropy Secretの単純Hashは復元攻撃を防げないためである。

### 11.4 Mask Status

| Status | 定義 | 公開可否 |
|---|---|:---:|
| `NOT_APPLICABLE` | Payload値を持たないMetadata Artifact | Yes |
| `VERIFIED_NO_MATCH` | 規則適用とScanの結果、対象値なし | Yes |
| `APPLIED` | 一つ以上の値をRemove／Redact／Mask済み | Yes |
| `FAILED` | 規則不成立、未知Encoding、Scan Errorまたは漏えい検出 | No |

Report用の`masked` Booleanは、`NOT_APPLICABLE / VERIFIED_NO_MATCH / APPLIED`のいずれかで安全性検証済みの場合だけ`true`として導出する。単にMask対象が0件だったことを根拠に`true`へしない。

### 11.5 DiffのMask

`response-field-diff.json`へBaseline／Currentの機密実値を保存しない。

- Mask対象Valueは両辺とも同じProfileで処理する。
- Credential FieldはValueを保持せず、存在／型／変更有無だけを記録する。
- Tokenizeした値の比較には承認済みKeyed Tokenを使用し、Token KeyをArtifactへ保存しない。
- `IGNORE_VALUE`でも実値漏えいを許可しない。

## 12. Protected Raw Evidence

Mask前Raw Dataの永続化はDefault禁止とする。障害調査、外部監査または法的要件で不可欠な場合だけ、通常Evidenceとは別のProtected Raw Evidenceとして扱う。

### 12.1 必須条件

1. CredentialとAuthentication Materialは例外時も必ず除去する。
2. Run開始前またはIncident手続による明示承認を持つ。
3. Purpose、対象API、対象時間、Approver Referenceを限定する。
4. 専用暗号化領域と専用Access Roleを使用する。
5. 通常ReportおよびEvidence Indexから直接Linkしない。
6. 短期Retentionと自動削除を設定する。
7. Read、Export、DeleteのAccess Auditを保持する。
8. 通常Artifact Manifestには内容Pathを載せず、制限Evidenceが存在することだけを安全なReferenceで記録する。

### 12.2 禁止事項

- Debug Optionだけで有効化する。
- Productionで無期限保存する。
- 通常Run Directoryへ配置する。
- Secretを含むRaw PayloadのHashを通常Manifestへ載せる。
- Protected EvidenceをBaselineへ複製する。
- Chat、TicketまたはReportへ内容を貼り付ける。

Protected Raw Evidenceの物理配置、Encryption Key、Approval InterfaceおよびRetentionは後続設計のOpen Issueとする。

## 13. Canonical Serialization

### 13.1 JSON

JSON Artifactは次のCanonical ProfileでSerializeする。

| 項目 | 規則 |
|---|---|
| Encoding | UTF-8、BOMなし |
| Key順 | Unicode Code Pointによる決定的昇順 |
| Whitespace | 意味を持たない空白を出力しない |
| Number | 意味を変えない最短の決定的表現 |
| Boolean／Null | JSON標準Literal |
| Line Ending | LF |
| Duplicate Key | Reject |
| NaN／Infinity | Reject |
| Timestamp | RFC 3339、Offset付き。Identityには使用しない。 |

Java Objectの`toString()`、MapのIteration順またはPretty Print結果をHash入力にしない。

### 13.2 外部Payload

外部APIの項目名、配列順およびValue型は原仕様を維持する。Object Key順のCanonical化を業務上の項目順変更としてDiff判定してはならない。

### 13.3 Binary／非JSON

非JSON Responseを通常Evidence化できるAPIは、API設計でMedia Type、最大Size、Mask可否およびEvidence方式を明示する。未定義BinaryをBase64化して無条件保存しない。

## 14. Hash契約

### 14.1 Hash種別

| Hash | 対象 | 用途 |
|---|---|---|
| `contentHash` | Mask後Canonical Contentの公開Byte列 | Artifact内容改変検知 |
| `manifestHash` | Manifest Hash ProjectionのCanonical Byte列 | Manifest自身の改変検知 |
| `bundleHash` | Sealed Definition Bundle | 実行Definitionの特定 |
| `profileHash` | Mask ProfileのCanonical内容 | 適用Mask規則の特定 |

標準Algorithmは`SHA-256`とし、表記は次に統一する。

```text
sha256:{64文字のlowercase hex}
```

Raw Payload Hashを`contentHash`として保存してはならない。`contentHash`は公開されるMask後内容に対するHashである。

### 14.2 `contentHash`

`contentHash`は最終公開Byte列から計算する。Hash計算後にPretty Print、改行変更、再MaskまたはMetadata注入を行ってはならない。

Storageが暗号化、圧縮またはObject変換を行う場合も、論理`contentHash`は変えない。Storage固有Integrity値は別属性とし、本書の`contentHash`を上書きしない。

### 14.3 `manifestHash`

Manifest Hash Projectionは次で構成する。

- Manifest Header。ただし`manifestHash`自身を除く。
- Terminal Outcome Profile
- Effective Requirements
- Artifact Entries
- Completeness Result
- Publication Metadata

Artifact Entryは`relativePath`の昇順で固定する。最終値をすべて設定してからProjectionをCanonical化し、`manifestHash`を計算する。

## 15. Artifact Manifest

### 15.1 役割

Artifact Manifestは次だけを証明する。

1. 一つのRun Packageに何が含まれるか。
2. 各ArtifactがどのIdentity、OwnerおよびSchemaに属するか。
3. 公開Byte列のHashとSizeが一致するか。
4. 適用Mask Profileと安全性状態は何か。
5. Terminal Outcomeに対する必須Artifactが揃うか。

ManifestはArtifact本文、業務判定、Verification ResultまたはReportを代替しない。

### 15.2 Manifest共通項目

| 項目 | 必須 | 内容 |
|---|:---:|---|
| `schemaVersion` | Yes | Manifest Schema版 |
| `manifestId` | Yes | Manifest Identity |
| `runId` | Yes | Source Run |
| `executionIdentity` | Yes | Baseline比較Slot |
| `bundleId`／`bundleHash` | Yes | Definition Trace |
| `terminalOutcomeProfile` | Yes | 必須Artifact判定Profile |
| `executionStatus` | Yes | 四結果軸のExecution |
| `artifactCompleteness` | Yes | Package独立判定 |
| `publicationStatus` | Yes | `TEMPORARY / PUBLISHED / QUARANTINED` |
| `requirements` | Yes | Effective Requirement評価 |
| `artifacts` | Yes | Artifact Entry一覧 |
| `manifestHash` | Yes | Manifest Projection Hash |
| `createdAt` | Yes | Manifest生成時刻 |
| `publishedAt` | 条件付 | 公開時刻 |

### 15.3 Artifact Entry

| 項目 | 必須 | 内容 |
|---|:---:|---|
| `artifactId` | Yes | 一意なArtifact Identity |
| `artifactType` | Yes | Artifact分類 |
| `ownerExecutionType` | Yes | Run／Scenario／API Call／Diff等 |
| `ownerExecutionId` | Yes | Owner実体ID |
| `definitionRefs` | Yes | API、UseCase、Scenario等 |
| `relativePath` | Yes | Run Root基準の正規化相対Path |
| `mediaType` | Yes | 例：`application/json` |
| `schemaVersion` | Yes | Artifact Schema版 |
| `sizeBytes` | Yes | 公開Byte列Size |
| `contentHash` | Yes | Mask後Canonical Content Hash |
| `maskProfileRef` | Yes | Profile ID、Version、Hash |
| `maskStatus` | Yes | 安全性状態 |
| `createdAt` | Yes | Artifact確定時刻 |

OS絶対Path、Mount Path、Temporary Path、Signed URLまたはCredentialをManifestへ保存しない。

### 15.4 JSON例

```json
{
  "schemaVersion": "1.0",
  "manifestId": "MANIFEST-RUN-20260728-230000-550e8400",
  "runId": "RUN-20260728-230000-550e8400",
  "executionIdentity": {
    "environmentId": "ENV-STAGING",
    "useCaseId": "UC-E6-001",
    "scenarioId": "SC-E6-001",
    "inputSetId": "INPUT-DEFAULT"
  },
  "bundleId": "BUNDLE-550e8400",
  "bundleHash": "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
  "terminalOutcomeProfile": "COMPLETED_V1",
  "executionStatus": "COMPLETED",
  "artifactCompleteness": "COMPLETE",
  "publicationStatus": "PUBLISHED",
  "requirements": [
    {
      "requirementId": "REQ-RUN-META",
      "status": "SATISFIED",
      "artifactRefs": [
        "ART-RUN-META-550e8400"
      ]
    }
  ],
  "artifacts": [
    {
      "artifactId": "ART-RUN-META-550e8400",
      "artifactType": "RUN_META",
      "ownerExecutionType": "RUN",
      "ownerExecutionId": "RUN-20260728-230000-550e8400",
      "definitionRefs": [
        "UC-E6-001",
        "SC-E6-001"
      ],
      "relativePath": "run-meta.json",
      "mediaType": "application/json",
      "schemaVersion": "1.0",
      "sizeBytes": 2048,
      "contentHash": "sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      "maskProfileRef": {
        "maskProfileId": "MASK-RUN-META",
        "profileVersion": "1.0",
        "profileHash": "sha256:cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"
      },
      "maskStatus": "VERIFIED_NO_MATCH",
      "createdAt": "2026-07-28T23:05:00+09:00"
    }
  ],
  "manifestHash": "sha256:dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
  "createdAt": "2026-07-28T23:05:10+09:00",
  "publishedAt": "2026-07-28T23:05:12+09:00"
}
```

例示Hashは契約形式を示す架空値であり、実データのHashではない。

## 16. Package Completeness

### 16.1 Status

| Status | 定義 | 通常公開 |
|---|---|:---:|
| `NOT_EVALUATED` | 収集中で完全性判定前 | No |
| `COMPLETE` | Outcome別必須条件をすべて満たす | Yes |
| `INCOMPLETE` | 必須Artifactまたは参照が不足 | No |
| `INVALID` | Identity、Schema、Hash、Mask、Pathまたは未知Artifactに重大不整合 | No |

`INCOMPLETE`はExecution Statusではない。Execution `INCOMPLETE`のRunでも、失敗Outcomeの説明に必要なArtifactがすべて揃えばPackage Completenessは`COMPLETE`になり得る。

### 16.2 共通Complete条件

| 条件ID | 条件 |
|---|---|
| `SNP-COMP-001` | Run Identityが全Artifactで一致する。 |
| `SNP-COMP-002` | Execution IdentityがPlan、ResultおよびManifestで一致する。 |
| `SNP-COMP-003` | `bundleId`、`bundleHash`およびSource Revisionを逆Traceできる。 |
| `SNP-COMP-004` | Effective Requirementがすべて`SATISFIED`または許可済み`NOT_APPLICABLE`である。 |
| `SNP-COMP-005` | 必須ArtifactのSchema Validationが成功する。 |
| `SNP-COMP-006` | `contentHash`と実Byte列が一致する。 |
| `SNP-COMP-007` | Manifest Projectionと`manifestHash`が一致する。 |
| `SNP-COMP-008` | 全ArtifactのMask Statusが公開可能値である。 |
| `SNP-COMP-009` | Secret／PII Scanに未処置検出がない。 |
| `SNP-COMP-010` | 相対PathがRun Root内で一意かつ安全である。 |
| `SNP-COMP-011` | Unknown File、Temporary Fileおよび未登録Artifactが公開Packageにない。 |
| `SNP-COMP-012` | ResultがFinalizedされ、Manifestの四軸Referenceと一致する。 |
| `SNP-COMP-013` | Package WriterがCloseされ、書込途中のHandleがない。 |
| `SNP-COMP-014` | Manifestが最終Artifact集合に対して一回だけ確定される。 |

### 16.3 Terminal Outcome Profile

| Execution Status | Packageを`COMPLETE`にする最低Evidence |
|---|---|
| `COMPLETED` | Run Meta、Scenario Execution、Verification Result、全Plan CallのAPI Meta、実行CallのRequest、受信CallのResponse、必要なDiff、Manifest |
| `REJECTED` | Run Meta、Preflight／Reject理由を持つScenario Execution、`NOT_EVALUATED`理由を持つVerification Result、Manifest |
| `INCOMPLETE` | Run Meta、到達点と未到達理由を持つScenario Execution、確定済みAPI Meta／Request／Response、未評価／未比較理由を持つResult／Diff、Manifest |
| `UNKNOWN_OUTCOME` | Run Meta、対象更新CallのAPI Meta、送信済みRequest、Transport／Timeout事実、`NOT_EVALUATED`／`NOT_COMPARED`理由、Recovery `REQUIRED`、Manifest |
| `NOT_STARTED`／`RUNNING` | 非終端のため通常Published Packageを作らない。 |

HTTP Error ResponseはResponseが実際に受信されていれば`response.json`を保存する。Transport FailureまたはTimeoutでResponseが存在しない場合はResponse Fileを生成しない。

### 16.4 合法な組合せ

| Execution | Artifact Completeness | Publication | Baseline Candidate |
|---|---|---|---|
| `COMPLETED` | `COMPLETE` | Yes | 条件付きYes |
| `INCOMPLETE` | `COMPLETE` | Yes | No |
| `REJECTED` | `COMPLETE` | Yes | No |
| `UNKNOWN_OUTCOME` | `COMPLETE` | Yes | No |
| 任意終端Status | `INCOMPLETE` | No、Quarantine | No |
| 任意Status | `INVALID` | No、Quarantine | No |

Verification `FAIL`またはChange `CHANGED`はPackage Completenessを下げない。

## 17. Manifest Validation

Validation順序を固定する。

```text
1. Manifest Schema
2. Run／Execution Identity
3. Path正規化・重複
4. Artifact存在・Size
5. Artifact Schema
6. Mask Status・Profile
7. Secret Scan
8. Content Hash
9. Definition／Owner Reference
10. Requirement評価
11. Manifest Hash
12. Package Completeness
```

前段Validationに失敗した状態で後段結果を`PASS`として利用しない。複数Errorを安全に収集できる場合も、Publication判定はFail Closedとする。

## 18. Artifact Lifecycle

```mermaid
stateDiagram-v2
    [*] --> TEMPORARY
    TEMPORARY --> FINALIZING
    FINALIZING --> SEALED
    FINALIZING --> QUARANTINED
    SEALED --> PUBLISHED
    SEALED --> QUARANTINED
    PUBLISHED --> [*]
    QUARANTINED --> [*]
```

| State | 許可 |
|---|---|
| `TEMPORARY` | Artifact収集、Mask、再Serialize |
| `FINALIZING` | Schema、Identity、Hash、Requirement検証 |
| `SEALED` | 内容変更禁止、Package公開準備 |
| `PUBLISHED` | 通常Consumerから参照可能、Immutable |
| `QUARANTINED` | 制限された運用調査だけ許可 |

`publicationStatus`はManifest上では`TEMPORARY / PUBLISHED / QUARANTINED`を使用する。`FINALIZING`と`SEALED`はWriter内部Lifecycleであり、通常Published Manifestへ残さない。

## 19. 原子的公開境界

### 19.1 公開手順

```text
1. Run専用Temporary Package確保
2. Artifact単位でMask・Schema・Canonical Write
3. Result Finalize
4. Effective Requirement評価
5. Artifact Entry生成
6. Secret・Path・Orphan Scan
7. Final Manifest生成
8. Manifest Hash検証
9. Package Seal
10. Package単位でPublished RunへAtomic切替
11. 公開後Read-back Validation
```

Run DirectoryへArtifactを一件ずつ公開してはならない。Consumerからは旧Packageまたは新Packageのどちらか一方だけが見えることを必須とする。

### 19.2 Storage差異

| Storage能力 | 公開方式 |
|---|---|
| 新規RunのCreate-Only Directory公開可能 | 同一File System上のTemporary Directoryを未使用`runId`へAtomic Move |
| 既存Logical Viewを置換するBaseline／Report | Immutable Versioned Setを作成し、Expected Version付きPointerをCAS切替 |
| Object Storage | Immutable Versioned Object Setを作成し、検証済みPointerをCAS切替 |
| Atomic Pointerも保証不可 | 通常Publication禁止。Storage方式を再選定 |

Temporary、Versioned、PointerおよびQuarantineはStorage Adapter内部Namespaceとし、物理LocatorをManifestまたはEvidenceへ保存しない。具体的Root、AdapterおよびStorage製品はEnvironment設計で確定する。

### 19.3 同一`runId`

- Published `runId`を上書きしない。
- 同一`runId`の二重Publisherは一方だけ成功させる。
- 内容が同じHashでも二重Publishを成功扱いしない。
- 再実行は新しい`runId`を発行する。
- Report再生成はSource `runId`を維持し、新しい`generationId`を発行する。

## 20. Quarantine

次の場合はPackageをQuarantineへ移す。

- Mask／Secret Scan失敗
- Hash不一致
- Schema不一致
- Identity不一致
- Root外PathまたはPath Traversal
- Unknown Artifact
- Manifest欠落または自己整合不成立
- Atomic Publish結果不明

Quarantine Packageは次へ使用しない。

- Baseline
- Previous Run
- 通常Report
- Approver向けEvidence Index
- 自動再実行入力

Quarantineには機密値を含む可能性があるため、保存自体が安全でない場合はPayloadを破棄し、安全なFailure Metadataだけを残す。保持期間とAccess Roleは後続設計で決定する。

## 21. Immutable化と訂正

Published Artifactは変更しない。

| 必要な処置 | 方法 |
|---|---|
| Execution再実行 | 新しい`runId` |
| Report再生成 | 新しい`generationId`、元`runId`をSource Reference |
| Mask規則変更 | 過去Artifactを上書きせず、新しい派生Artifactまたは承認済みMigration |
| 誤判定訂正 | Correction／Recovery Artifactを元ResultへRelation付け |
| Baseline差替え | 新Baseline世代とPointer切替 |
| Manifest Error | 元PackageをInvalid化し、修正版を別Publication Identityで作成 |

元Artifactの削除がSecurity Incident対応で必要な場合は、削除理由、対象Hash、承認、時刻および代替EvidenceをAuditへ残す。通常の訂正手段として削除を使用しない。

## 22. Baseline連携

### 22.1 Candidate条件

最低条件は次とする。

```text
executionStatus == COMPLETED
AND artifactCompleteness == COMPLETE
AND identityConsistency == VALID
AND recoveryStatus NOT IN (REQUIRED, IN_PROGRESS)
```

Verification `FAIL`およびChange `CHANGED`だけを理由にCandidateから除外しない。Candidateと採用承認は別である。

### 22.2 Baseline Inventory

BaselineはRun Artifact Manifest全体をそのまま複製しない。`baseline-meta.json`に次を保持する。

- Source `runId`
- Execution Identity
- Source `manifestHash`
- Baseline対象ArtifactのInventory
- 各ArtifactのSource `artifactId`
- Copy後の`relativePath`、`contentHash`、`sizeBytes`、`schemaVersion`
- Baseline生成時刻と承認Reference

Baseline対象は最低限、`verification-result.json`および各実行Callの`response.json`とする。Request、Log、ReportおよびProtected Raw EvidenceをBaselineへ複製しない。

### 22.3 Baseline生成

1. Published Run Manifestを検証する。
2. Candidate条件を評価する。
3. 対象ArtifactをManifest Entryから解決する。
4. Hashを再検証してTemporary BaselineへCopyする。
5. `baseline-meta.json`のInventoryと`manifestHash`を生成する。
6. Temporary Baseline全体を検証する。
7. Baselineを原子的に置換する。
8. 配置後にInventory Hashを再検証する。
9. 成功後だけExecution Stateを更新する。

`baseline-meta.json.manifestHash`はBaseline InventoryのCanonical Projectionに対するHashとし、Source Runの`manifestHash`とは別項目で保持する。

## 23. ReportおよびEvidence Index連携

### 23.1 Report入力

Report GeneratorはPublished Artifact Manifestだけを入口とする。Run Directoryを無制限走査してArtifactを推測しない。

```text
Published Manifest
→ Artifact Entry解決
→ Hash／Schema再検証
→ Result／Diff読込
→ Report生成
→ Evidence Index生成
→ Report Set原子的公開
```

### 23.2 Evidence Index

Evidence Indexは次を表示する。

| 項目 | Source |
|---|---|
| `artifactId` | Manifest Entry |
| `artifactType` | Manifest Entry |
| Owner | Manifest Entry |
| `relativePath` | Manifest Entry |
| `contentHash` | Manifest Entry |
| `sizeBytes` | Manifest Entry |
| `schemaVersion` | Manifest Entry |
| `masked` | Mask Statusから導出 |
| `available` | Report生成時Read検証 |
| `unavailableReason` | 欠落・Access・Hash Error |

Evidence IndexからProtected Raw Evidenceへ直接Linkしない。Manifest自身は`manifestHash`と固定PathによりIndexへ表示できる。

### 23.3 Reportとの独立性

- Report Status `COMPLETE`はSource RunのVerification `PASS`を意味しない。
- Report FailureはSource Manifestを変更しない。
- Report SetはCore Artifact Manifestへ後付けしない。
- 同じSource Manifestと同じGenerator Versionから決定的に生成する。

## 24. Traceability

### 24.1 Forward Trace

```text
Definition Source
→ Definition Bundle
→ Sealed Execution Plan
→ Execution Identity
→ Result／Diff
→ Artifact
→ Manifest
→ Evidence Index／Report
```

### 24.2 Reverse Trace

各Artifactから最低限、次へ戻れること。

- Source `runId`
- Owner Execution
- `environmentId`
- `useCaseId`
- `scenarioId`
- `inputSetId`
- `apiCallCode`／`apiId`（API Artifact）
- `resultKey`（Check Artifact）
- `bundleId`／`bundleHash`
- Schema Version
- Mask Profile Version／Hash
- Generator／Build Identity

### 24.3 Trace不整合

Trace切れをChange `UNCHANGED`、Verification `PASS`またはArtifact `COMPLETE`として扱わない。必須Traceが解決できないPackageは`INVALID`とする。

## 25. Size、TruncateおよびExternalization

### 25.1 原則

- 必須Responseを無表示のまま切り捨てない。
- `sizeBytes`は保存後Sizeではなく公開Byte列の正確なSizeを保持する。
- Size上限超過を正常な空Responseへ変換しない。
- TruncateしたArtifactを完全なResponseとしてBaselineへ使用しない。

### 25.2 Truncate Metadata

TruncateがAPI契約上許可される場合、次を必須とする。

- `truncated=true`
- Original Size
- Stored Size
- Truncate方式
- Reason Code
- Hash対象がStored Contentであること
- Verification／Diffへの影響

必須Fieldが欠落するTruncateはExecution `INCOMPLETE`かつPackage Requirementを満たさない。外部Object化する場合のReference、IntegrityおよびAccessはFile I/O／Environment設計で決定する。

## 26. Failureと四結果軸

| Failure | Artifact処理 | Execution | Verification | Change | Recovery |
|---|---|---|---|---|---|
| Preflight不成立 | Reject Evidence Profile | `REJECTED` | `NOT_EVALUATED` | `NOT_COMPARED` | 原則`NOT_REQUIRED` |
| Request Mask失敗・未送信 | Payload保存禁止、Quarantine Metadata | `INCOMPLETE` | `NOT_EVALUATED` | `NOT_COMPARED` | 条件付き |
| Response受信後Mask失敗 | Response通常保存禁止 | `INCOMPLETE` | `NOT_EVALUATED` | `NOT_COMPARED` | 条件付き |
| 更新API送信後Timeout | Request、Call Meta、Timeout Evidence | `UNKNOWN_OUTCOME` | `NOT_EVALUATED` | `NOT_COMPARED` | `REQUIRED` |
| Manifest Hash不一致 | Package Quarantine | `INCOMPLETE`または元の上位Status | 既存値保持 | 既存値保持 | 条件付き |
| Report生成失敗 | Source Package維持 | Source値保持 | Source値保持 | Source値保持 | Source値保持 |
| Baseline生成失敗 | Published Run維持 | Source値保持 | Source値保持 | Source値保持 | 条件付き |

Execution集約では`UNKNOWN_OUTCOME`が`INCOMPLETE`より優先する。Artifact Failureを理由に更新APIの不明Outcomeを隠してはならない。

## 27. Error Code

| Error Code | 条件 | 処理 |
|---|---|---|
| `ARTIFACT_REQUIREMENT_MISSING` | 必須Artifactなし | `INCOMPLETE`、Publish禁止 |
| `ARTIFACT_SCHEMA_INVALID` | Schema不一致 | `INVALID`、Quarantine |
| `ARTIFACT_IDENTITY_MISMATCH` | Run／Owner不一致 | `INVALID`、Quarantine |
| `ARTIFACT_HASH_MISMATCH` | Content Hash不一致 | `INVALID`、Quarantine |
| `ARTIFACT_MANIFEST_INVALID` | Manifest自己整合不成立 | `INVALID`、Publish禁止 |
| `ARTIFACT_PATH_UNSAFE` | Root外／Traversal／重複 | `INVALID`、Security扱い |
| `ARTIFACT_UNKNOWN_FILE` | 未登録File混入 | `INVALID`、Quarantine |
| `SECURITY_MASK_FAILURE` | Mask処理失敗 | Payload保存禁止 |
| `SECURITY_SECRET_DETECTED` | 未Mask Secret検出 | Publish禁止、Security通知 |
| `ARTIFACT_CANONICALIZE_FAILED` | 決定的Serialize不可 | 対象Artifact失敗 |
| `ARTIFACT_PUBLISH_FAILED` | Atomic公開失敗 | 旧公開物維持、Recovery判定 |
| `ARTIFACT_PUBLISH_OUTCOME_UNKNOWN` | Pointer／Rename結果不明 | 通常Consumer停止、Recovery `REQUIRED` |
| `ARTIFACT_SIZE_LIMIT_EXCEEDED` | 許容Size超過 | Policyに従い停止または明示Truncate |

Error MessageへPayload、Secret、Full URL、Headerまたは個人情報を埋め込まない。

## 28. Java論理Component

```text
ArtifactRequirementResolver
ArtifactCollector
ArtifactMasker
SecretScanner
CanonicalSerializer
ArtifactSchemaValidator
ArtifactHasher
ArtifactManifestBuilder
ArtifactPackageValidator
ArtifactPublisher
QuarantineManager
EvidenceReader
```

### 28.1 Port

```java
public interface ArtifactWritePort {
    ArtifactReference writeTemporary(ArtifactCandidate candidate);
}

public interface ArtifactValidationPort {
    ArtifactValidationResult validate(ArtifactReference artifact);
}

public interface ArtifactPublicationPort {
    PublishedArtifactPackage publish(SealedArtifactPackage artifactPackage);
}

public interface EvidenceReadPort {
    VerifiedArtifact read(PublishedArtifactReference reference);
}
```

Interface名は論理名であり、Java PackageまたはModuleを確定しない。

### 28.2 禁止依存

- Scenario ClassからPublished Pathへ直接File Write
- Check実装からManifest更新
- Report GeneratorからSource Artifact変更
- MaskerからBaseline更新
- Storage Adapterから四結果軸再判定
- Evidence ReaderからDirectory順によるRun推測

## 29. Schema契約

本書が直接使用する現行Schemaは次のとおりである。

| Schema | 責務 |
|---|---|
| `verification-result.schema.json` | 四結果軸、Check、Reason、Severity |
| `response-field-diff.schema.json` | Diff、Ignore、Summary、Change |
| `artifact-manifest.schema.json` | Entry、Requirement、Hash、Completeness |
| `definition-bundle.schema.json` | Sealed Definition、Registry Snapshot、Reference Graph |
| `run-meta.schema.json` | Run、Bundle、Build、Runtime、ResultおよびManifest Trace |
| `scenario-execution.schema.json` | Plan Call、Branch、Disposition、Scenario終端状態 |
| `api-meta.schema.json` | API Call Identity、Dispatch、Transport、Artifact Reference |

Request／Response JSONは外部API SchemaまたはAPI別Evidence Schemaに従う。Platform Wrapperを付与する場合は、外部Payloadの項目名を変更しない。

Definition Bundle、Runtime Meta 3種、Batch ResultおよびReport 4種は初期7へ混在させず、第9バッチ第2段階で独立Schemaとして追加した。Recovery Case／Action／AuditとAPI固有Request／Responseは引き続き現行16 Schemaの対象外であり、別契約の決定前に全Platform JSONのSchema Coverage完成を宣言してはならない。

Schema共通契約はDraft 2020-12、Version付きURN `$id`およびInstance Major.Minorとする。永続JSONではSchemaを機械契約とし、Java DTO／Serializer／Loaderは同契約を緩和しない。

現行16 Schemaの正文作成と機械Validationは完了した。`artifact-manifest.schema.json`は次を構造制約として機械検証する。

- Manifest自身および後生成ReportをArtifact Entry Typeとして許可しない。
- `PUBLISHED`では`artifactCompleteness=COMPLETE`および`publishedAt`を必須とする。
- Published Entryでは`maskStatus=FAILED`を許可しない。
- OS絶対Path、Backslash、Path Traversalおよび重複Separatorを拒否する。
- Requirement、Artifact Entry、Mask Profile、Hash、Size、Schema VersionおよびOwnerを型付きで保持する。

Requirement ID、Artifact ID、`relativePath`のKey単位一意性、Entry昇順、Reference解決、実Byte Hash／Size、Canonical `manifestHash`およびTerminal Outcome別CompletenessはSemantic Validator／Manifest Writerの責務とする。

## 30. Validation

| Validation ID | 確認内容 | Level |
|---|---|---|
| `SNP-V001` | Manifestの`runId`と全EntryのSource Runが一致する。 | ERROR |
| `SNP-V002` | `relativePath`が正規化されRun Root外へ出ない。 | CRITICAL |
| `SNP-V003` | Artifact IDとPathがそれぞれ一意である。 | ERROR |
| `SNP-V004` | SizeとContent Hashが公開Byte列に一致する。 | ERROR |
| `SNP-V005` | Mask StatusとMask Profile Referenceが存在する。 | CRITICAL |
| `SNP-V006` | Secret Scanが成功し未処置検出が0件である。 | CRITICAL |
| `SNP-V007` | Schema VersionがPlan Requirementと互換である。 | ERROR |
| `SNP-V008` | Outcome Profileの必須Artifactが揃う。 | ERROR |
| `SNP-V009` | 不在Artifactに合法なReasonがある。 | ERROR |
| `SNP-V010` | Manifest Hash Projectionが一致する。 | ERROR |
| `SNP-V011` | Package内にTemporary／Unknown Fileがない。 | ERROR |
| `SNP-V012` | ResultがFinalizedされManifestと一致する。 | ERROR |
| `SNP-V013` | Protected Raw Evidenceが通常Indexへ露出しない。 | CRITICAL |
| `SNP-V014` | Report ArtifactをCore Manifestへ循環参照させていない。 | ERROR |
| `SNP-V015` | Baseline InventoryがSource Manifest Entryと一致する。 | ERROR |
| `SNP-V016` | Core Artifact間の`runId`とExecution Identityが一致する。 | ERROR |
| `SNP-V017` | `scenarioExecutionId`／`apiCallExecutionId`の親子関係と`apiCallCode + apiId`がSealed Planに一致する。 | ERROR |
| `SNP-V018` | Resultの`resultKey`がExpected／Check Registry Snapshotへ逆引きできる。 | ERROR |
| `SNP-V019` | Run MetaとManifestの`bundleId + bundleHash`が一致する。 | ERROR |
| `SNP-V020` | Schema構造ValidationだけでCross-Artifact Trace、Hash／実Byteまたは親子Identityを検証済みとしていない。 | ERROR |

## 31. Test Scenario

### 31.1 正常系

- [ ] Verification `PASS`＋Change `UNCHANGED`のPackageが`COMPLETE`になる。
- [ ] Verification `FAIL`＋Change `CHANGED`でもExecution `COMPLETED`ならPackageが`COMPLETE`になる。
- [ ] 初回Diffが`NOT_COMPARED / INITIAL_EXECUTION`として保存される。
- [ ] 条件Skip Callに`api-meta.json`があり、Request／Responseが生成されない。
- [ ] HTTP Error Responseが実Responseとして保存される。
- [ ] Evidence IndexがManifest Entryだけから生成される。

### 31.2 Failure系

- [ ] Preflight Reject Packageが通常公開でき、Baseline候補にならない。
- [ ] 更新API Timeoutが`UNKNOWN_OUTCOME + Recovery REQUIRED`の完全なEvidence Packageになる。
- [ ] Request生成後・送信前FailureでResponseが生成されない。
- [ ] ResponseなしDiffが空Object比較にならない。
- [ ] Mask失敗Payloadが通常領域へ一Byteも保存されない。
- [ ] Hash不一致PackageがQuarantineされる。
- [ ] ManifestにないFile混入でPackageが`INVALID`になる。
- [ ] Path TraversalがPublication前に拒否される。
- [ ] Report失敗後もSource Run Manifestが変化しない。

### 31.3 Crash／Concurrency

- [ ] Artifact書込途中CrashでPublished Runが見えない。
- [ ] Manifest生成後・Publish前CrashでPackageが再評価または隔離される。
- [ ] Atomic切替直後Crashで旧版か新版の一方だけが有効である。
- [ ] 同一`runId`の二重Publishが一方だけ成功する。
- [ ] 異なる`runId`の並行書込でPath、BufferまたはManifestが混在しない。

### 31.4 Security

- [ ] Authorization、Cookie、Token、Password実値が全Artifactに0件である。
- [ ] URL Query内Secretが除去される。
- [ ] Error MessageとReason ParameterにPayloadがない。
- [ ] Low Entropy Secretを単純Hashで保存しない。
- [ ] Protected Raw Evidenceが通常Report、BaselineおよびEvidence Indexへ出ない。

## 32. Open Issue

| Issue ID | 論点 | 本書の暫定方針 | 確定先 |
|---|---|---|---|
| `SNP-OI-001` | Physical Temporary／Published／Quarantine Root | File I/OでLogical／Adapter内部Namespaceを分離済み。物理Rootは未確定。 | Environment |
| `SNP-OI-002` | Atomic Rename不可Storage | File I/OでVersioned Set＋CAS Pointerを定義済み。Adapter選定は未確定。 | Environment |
| `SNP-OI-003` | Protected Raw Evidenceの承認・暗号・Retention | Default禁止、Credentialは常に除去。 | Log／Recovery／Environment |
| `SNP-OI-004` | 最大Request／Response／Manifest Size | 欠落を隠さず、未定義Truncate禁止。 | Environment／Non-functional |
| `SNP-OI-005` | Mask Profileの正式配置とApproval | Java Firstの静的Profile、任意式禁止。 | Security／Environment |
| `SNP-OI-006` | Report Set独立Hashの保存形式 | Core Manifestへ循環参照させない。 | Report／File I/O |
| `SNP-OI-007` | Definition Archive Retention | Source Revision＋Hashを必須とする。 | Environment／Operation |
| `SNP-OI-008` | Schema互換とMigration | Draft 2020-12、Version付きURN、未知Major拒否を共通契約化し、現行16 Schema正文・機械Validation済み。過去Artifact Migration、Runtime Writer／Reader Contract Testおよび正式Reviewを待つ。 | 第8～9バッチ／Runtime実装 |
| `SNP-OI-009` | Core Artifact／ReportのSchema Coverage | Definition Bundle、Runtime Meta、Batch ResultおよびReport 4種を独立Schema化済み。API固有Payload、Recovery Store、Java Writer／Readerおよび正式Reviewを待つ。 | Runtime／Architecture Review |

## 33. Review Checklist

### 33.1 Architecture

- [ ] Snapshot、Artifact、Evidence、Reportの責務が分離されている。
- [ ] Core Manifestと後生成Reportに循環依存がない。
- [ ] Scenario、Check、ReportがPublisherを迂回しない。
- [ ] 未決Storage製品またはJava Packageを固定していない。

### 33.2 Runtime

- [ ] Sealed PlanとOutcomeからRequirementが決まる。
- [ ] Skip、Not Reached、Responseなしを空Fileで偽装しない。
- [ ] Execution StatusとPackage Completenessが分離されている。
- [ ] `UNKNOWN_OUTCOME`のEvidenceがBaseline候補にならない。

### 33.3 Verification

- [ ] Expected、Actual、BaselineおよびDiffが別Artifact／Referenceである。
- [ ] 初回を`UNCHANGED`へ変換しない。
- [ ] `IGNORE_VALUE`でも機密値を保存しない。
- [ ] Verification `FAIL`がArtifact Failureへ変換されない。

### 33.4 Security

- [ ] Maskは永続化前に実行される。
- [ ] Credentialは例外Raw Evidenceにも保存されない。
- [ ] Mask Profile VersionとHashを追跡できる。
- [ ] Quarantineと通常EvidenceのAccess境界がある。

### 33.5 Operation

- [ ] Published PackageがImmutableである。
- [ ] Crash PointとAtomic Publication境界が定義されている。
- [ ] Baseline、ReportおよびRecoveryがPublished Packageだけを参照する。
- [ ] Retention未決を完了済みと誤表示していない。

## 34. 完了条件

本書の正文作成完了条件は次とする。

1. Core Artifact、Derived ArtifactおよびDiagnostic Artifactが分類されている。
2. Mask、Canonical Hash、ManifestおよびCompletenessが定義されている。
3. `COMPLETED / REJECTED / INCOMPLETE / UNKNOWN_OUTCOME`の必須Evidenceが定義されている。
4. Baseline、ReportおよびEvidence Indexとの循環しない境界が定義されている。
5. ScenarioContext、Execution State、DiffおよびReport設計との現行不整合が0件である。
6. Front Matter、H1、Code Fence、Tableおよび`document_id`の機械Validationが成功する。

正文作成完了は、正式Review、Decision承認、Schema実装、File I/O確定または文書Lifecycle `APPROVED`を意味しない。

## 35. 後続設計への入力

### 35.1 `ファイル入出力設計書.md`

- Temporary／Published／Quarantineの論理Path
- Artifact単位とPackage単位のAtomic Write
- Directory Rename／Versioned Pointer
- Crash RecoveryとRead-back
- Storage Port、Path安全性、SizeおよびStream

### 35.2 `ログ・例外・Recovery設計書.md`

- Diagnostic ArtifactとStructured Log
- Secret-safe Error Detail
- Unknown Outcome Handoff
- Protected Raw Evidence Approval／Audit
- Quarantine運用

### 35.3 `環境・Runtime構成設計書.md`

- Runtime Data Root
- Storage Capability
- Encryption、Key管理、Access Role
- Retention、Archive、Backup
- Size／Concurrency／Quota

### 35.4 第8バッチ

- `artifact-manifest.schema.json`
- Core Artifact Schema
- Schema Version互換
- Java DTO Mapping
- Contract Test

## 36. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-28 | 現行四結果軸、Sealed Execution Plan、凍結Runtime構造、Outcome別完全性、保存前Mask、Canonical Hash、Manifest、Quarantine、Baseline／Report境界に基づき全面再設計 | DRAFT |
| `1.0.0-draft.2` | 2026-07-28 | File I/O設計に合わせ、Run Create-Only、Baseline／Report Versioned Set＋CAS Pointer、Adapter内部Namespaceおよび物理Locator非永続化へ公開契約を具体化 | DRAFT |
| `1.0.0-draft.3` | 2026-07-28 | Environment／Runtime設計に合わせ、Release Digest、Runtime Deployment Profile、SecretなしConfig HashおよびProvider Capability ReferenceをRun Snapshotへ追加 | DRAFT |
| `1.0.0-draft.4` | 2026-07-28 | 第8バッチCoverage Reviewにより初期7 SchemaとCore Artifactの未対象範囲を分離し、Draft 2020-12／URN Version／Java DTO境界へ同期 | DRAFT |
| `1.0.0-draft.5` | 2026-07-28 | Scenario Expected Schema正文・機械Validation完了を反映し、残存必須Schema数とSchema Migration Open Issueを同期 | DRAFT |
| `1.0.0-draft.6` | 2026-07-28 | 初期7 Schema正文・機械Validation完了を反映し、Core ManifestのSelf／Report除外、Publication、Mask、PathおよびSchema／Semantic Validation境界を同期 | DRAFT |
| `1.0.0-draft.7` | 2026-07-28 | 第9バッチとしてCore ArtifactのCross-Artifact Trace Envelope、親子Identity、Bundle／Registry逆引きおよび未対象SchemaのFail Closedを定義 | DRAFT |
| `1.0.0-draft.8` | 2026-07-28 | 第9バッチ第2段階のDefinition Bundle、Runtime Meta 3種、Batch ResultおよびReport 4種Schemaを反映し、Schema構造検証とCross-Artifact Semantic／Java Contract Testの境界を同期 | DRAFT |
