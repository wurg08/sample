---
title: ExecutionState・Baseline管理設計書
document_id: E6-API-VAL-EXEC-BASELINE-DESIGN
version: 1.0.0-draft.8
status: DRAFT
document_type: Execution State and Baseline Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# ExecutionState・Baseline管理設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | ExecutionState・Baseline管理設計書 |
| 文書ID | `E6-API-VAL-EXEC-BASELINE-DESIGN` |
| 対象 | `execution-state.json`、固定Baseline、過去Run参照 |
| 配置 | `system/05_framework/` |
| 文書種別 | Runtime状態・Baseline管理設計書 |
| 版数 | `1.0.0-draft.8` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | Runtime / Operation Team |
| レビュー責任 | System Architect / Runtime Lead / Test Lead / Operation Lead |

## 2. 目的

本書は、E6 API Verification Platformにおける初回実行、前回実行の一意な特定、固定Baselineの読込・復旧・置換、Execution Stateの更新、同時実行排他および障害回復を定義する。

本書の最重要原則は次の二点である。

1. 前回結果を日付、更新時刻またはDirectory順から推測しない。
2. Baselineを一つの完全なRunから原子的に置き換える。

## 3. 用語

| 用語 | 定義 |
|---|---|
| Current Run | 現在実行中のRun |
| Previous | Current Runが比較に使用する前回の実際結果 |
| Baseline | 固定Pathに保持する、前回の完全Runから作成した比較用Snapshot |
| Execution State | 初回状態および前回完全RunへのPointer |
| Execution Identity | Environment、UseCase、Scenario、Input Setからなる比較単位 |
| Complete Run | 必須API処理、成果物生成および整合性確認が完了したRun |
| Verification Result | PASS／FAIL等の業務・比較判定 |
| Execution Status | Runが完全に実行・保存されたかを表す状態 |

Verification Resultが`FAIL`でもExecution Statusが`COMPLETED`であれば、Baseline更新対象になり得る。

## 4. 責務境界

| 情報・処理 | 正式な管理先 |
|---|---|
| 初期入力値 | Scenario Input |
| 実行中Request／Response | ScenarioContext |
| Expected | Scenario Expected |
| Response Field Diff | APIレスポンスDiff |
| `initialExecutionFlg`、`previousRunId` | Execution State |
| Previous読込、Baseline復旧 | Baseline Manager |
| Baseline更新可否 | 本書のComplete Run判定 |
| Baseline物理I/O | File I/O実装 |
| Daily Summary／表示 | Report |
| Baseline承認運用 | 運用設計 |

Execution StateおよびBaselineをMasterへ登録してはならない。

## 5. 基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `BL-P001` | Identity分離 | BaselineをExecution Identity単位で分離する。 |
| `BL-P002` | 固定Path優先 | 通常時は固定Baseline Pathを直接読む。 |
| `BL-P003` | Pointer復旧 | 固定Baseline欠失時だけ`previousRunId`から精確に復旧する。 |
| `BL-P004` | 日付非依存 | 日付、File更新時刻、Directory名順を検索Keyにしない。 |
| `BL-P005` | 完全Run限定 | 一つの完全RunだけをBaseline更新元にする。 |
| `BL-P006` | 全体置換 | API呼出単位の部分Baseline更新を禁止する。 |
| `BL-P007` | FAIL許容 | Verification FAILでもRunが完全ならBaselineを更新できる。 |
| `BL-P008` | Error保護 | API Error、Parse Error、中断または成果物欠落時は旧Baselineを維持する。 |
| `BL-P009` | State後更新 | Baseline置換成功後にExecution Stateを更新する。 |
| `BL-P010` | 原子性 | Temporary領域、整合性確認およびAtomic Renameで置換する。 |
| `BL-P011` | 排他 | 同じExecution IdentityのBaseline更新を同時に実行しない。 |
| `BL-P012` | 追跡性 | Baselineから必ず`sourceRunId`を追跡できる。 |

## 6. Execution Identity

BaselineおよびExecution Stateは次の単位で管理する。

```text
environmentId
+
useCaseId
+
scenarioId
+
inputSetId
```

例：

```text
ENV-STAGING
/ UC-E6-001
/ SC-E6-001
/ INPUT-001
```

| 項目 | 必須 | 理由 |
|---|:---:|---|
| `environmentId` | Yes | Environmentが異なるResponseを混在させない。 |
| `useCaseId` | Yes | 業務目的を追跡する。 |
| `scenarioId` | Yes | 実行経路を分離する。 |
| `inputSetId` | Yes | 異なる入力値のResponseを比較しない。 |

## 7. 論理Directory

物理Rootは環境設定で確定する。本書では次のConsumer可視Logical Viewを必須とする。Baselineの物理GenerationおよびCurrent PointerはFile I/O Adapter内部に隠蔽し、Directory名順、Symbolic Linkまたは更新時刻でCurrentを解決しない。

```text
execution-state/
└── {environmentId}/
    └── {useCaseId}/
        └── {scenarioId}/
            └── {inputSetId}/
                └── execution-state.json

baseline/
└── {environmentId}/
    └── {useCaseId}/
        └── {scenarioId}/
            └── {inputSetId}/
                ├── baseline-meta.json
                ├── verification-result.json
                └── api-calls/
                    └── {apiCallCode}/
                        └── response.json

runs/
└── {runId}/
    ├── run-meta.json
    ├── scenario-execution.json
    ├── verification-result.json
    └── api-calls/
        └── {apiCallCode}/
            ├── api-meta.json
            ├── request.json
            ├── response.json
            └── response-field-diff.json
```

日付は`run-meta.json`の監査項目として保存できるが、Path探索条件に使用しない。

## 8. Execution State

### 8.1 最小構造

```json
{
  "schemaVersion": "1.0",
  "environmentId": "ENV-STAGING",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "inputSetId": "INPUT-001",
  "initialExecutionFlg": false,
  "previousRunId": "RUN-c91452ab",
  "updatedAt": "2026-07-27T14:30:00+09:00"
}
```

### 8.2 項目定義

| 項目 | 型 | 必須 | Null | 内容 |
|---|---|:---:|:---:|---|
| `schemaVersion` | String | Yes | No | State Schema版 |
| `environmentId` | String | Yes | No | Execution Identity |
| `useCaseId` | String | Yes | No | Execution Identity |
| `scenarioId` | String | Yes | No | Execution Identity |
| `inputSetId` | String | Yes | No | Execution Identity |
| `initialExecutionFlg` | Boolean | Yes | No | Previousなしでの初回実行許可 |
| `previousRunId` | String | 条件付 | Yes | 直前にBaseline化した完全Run |
| `updatedAt` | String | Yes | No | 監査時刻。前回特定には使用しない。 |

`initialExecutionFlg=true`では`previousRunId=null`、`initialExecutionFlg=false`では`previousRunId`を必須とする。これ以外の組合せはState不整合として扱う。

`execution-state.schema.json`は上記内容契約を検証する。Storage AdapterがCASに使用するVersion Token、Lock Owner、LeaseまたはFencing TokenはStorage Metadata／Mutation条件であり、Execution State JSONへ混入させない。

## 9. Baseline Metadata

```json
{
  "schemaVersion": "1.0",
  "sourceRunId": "RUN-20260727-143000-c91452ab",
  "environmentId": "ENV-STAGING",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "inputSetId": "INPUT-001",
  "executionStatus": "COMPLETED",
  "verificationStatus": "FAIL",
  "sourceManifestHash": "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
  "artifacts": [
    {
      "sourceArtifactId": "ART-VERIFICATION-c91452ab",
      "artifactType": "VERIFICATION_RESULT",
      "apiCallCode": null,
      "relativePath": "verification-result.json",
      "contentHash": "sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      "sizeBytes": 4096,
      "schemaVersion": "1.0"
    },
    {
      "sourceArtifactId": "ART-RESPONSE-c91452ab",
      "artifactType": "RESPONSE",
      "apiCallCode": "CALL-001",
      "relativePath": "api-calls/CALL-001/response.json",
      "contentHash": "sha256:cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
      "sizeBytes": 2048,
      "schemaVersion": "1.0"
    }
  ],
  "createdAt": "2026-07-27T14:29:55+09:00",
  "manifestHash": "sha256:dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
  "approvalRef": null
}
```

| 項目 | 用途 |
|---|---|
| `sourceRunId` | Baselineの元Runを一意に追跡する。 |
| Execution Identity | 誤ったScenario／Inputとの比較を防止する。 |
| `executionStatus` | 完全Run由来であることを確認する。 |
| `verificationStatus` | 参考表示。Baseline更新可否の主判定には使用しない。 |
| `sourceManifestHash` | Source RunのPublished Core Manifestを固定する。 |
| `artifacts` | BaselineへCopyした対象ArtifactのSource Identity、Call、Path、Hash、SizeおよびSchema版を列挙する。 |
| `createdAt` | 監査表示。位置特定には使用しない。 |
| `manifestHash` | Baseline Inventory Canonical Projectionの改変・欠落検出に使用する。Source Manifest Hashとは別である。 |
| `approvalRef` | 自動更新Policyまたは手動承認のReference。設計済み自動更新で承認不要の場合はNull。 |

`baseline-meta.schema.json`は一つの`COMPLETED` Source Runだけを許可し、初期Baseline対象を`VERIFICATION_RESULT`と`RESPONSE`に限定する。Response Entryは`apiCallCode`必須、Verification Result Entryは`apiCallCode=null`とする。

Schemaだけでは次を確定できないため、Semantic ValidatorおよびStorage Adapterで検証する。

- `sourceArtifactId`および`relativePath`単位一意性
- Source Manifest EntryとのIdentity、Hash、Size、Schema一致
- Baseline実FileとのHash、Size一致
- `manifestHash`のCanonical再計算
- 最低1件のVerification Resultおよび実行Callごとの必要Response存在
- `approvalRef`と更新Policy／Auditの一致

## 10. Previous取得順序

```mermaid
flowchart TD
    A["Execution State読込"]
    B{"固定Baselineあり?"}
    C["Baseline整合性検証"]
    D{"有効?"}
    E{"previousRunIdあり?"}
    F["runs/{previousRunId}読込"]
    G{"完全・Identity一致?"}
    H["Baselineへ復旧"]
    I{"初回Flg=true?"}
    J["Initial Baseline"]
    K["BASELINE_NOT_FOUND"]
    L["Previousとして使用"]

    A --> B
    B -- Yes --> C --> D
    D -- Yes --> L
    D -- No --> E
    B -- No --> E
    E -- Yes --> F --> G
    G -- Yes --> H --> L
    G -- No --> I
    E -- No --> I
    I -- Yes --> J
    I -- No --> K
```

### 10.1 固定Baseline

通常はExecution Identityから固定Pathを組み立て、直接読み込む。Directory走査は行わない。

### 10.2 `previousRunId`復旧

固定Baselineが存在しない、または整合性検証に失敗した場合だけ、`execution-state.json`の`previousRunId`を使用する。

復旧元Runは次をすべて満たす必要がある。

1. `runs/{previousRunId}`が存在する。
2. `run-meta.json.runId`が一致する。
3. Execution Identityが一致する。
4. Execution Statusが`COMPLETED`である。
5. 必須成果物とManifestが完全である。
6. Response JSONがParse可能である。

### 10.3 初回

`initialExecutionFlg=true`かつPreviousを取得できない場合だけ、Initial Baselineとして実行を継続する。

初回はPrevious／Current Field Diffを実行せず、次のように明示する。

```text
comparisonStatus = NOT_COMPARED
notComparedReason = INITIAL_EXECUTION
```

Business CheckおよびExpected照合は通常どおり実行する。

### 10.4 非初回の欠失

`initialExecutionFlg=false`で固定Baselineも有効な`previousRunId`もない場合は`BASELINE_NOT_FOUND`とし、API呼出前に停止する。

## 11. 禁止する前回検索

次の方法を使用してはならない。

- 前日の日付Directoryを探す。
- Directory名またはRun IDを文字列Sortする。
- File更新日時が最新のRunを選ぶ。
- 全Runを走査して最も新しそうなRunを推測する。
- Reportの表示順から前回Runを選ぶ。
- 別`inputSetId`のRunを代用する。

時刻は監査と表示にだけ使用する。

## 12. Initial Execution

初期Stateは次のとおりとする。

```json
{
  "schemaVersion": "1.0",
  "environmentId": "ENV-STAGING",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "inputSetId": "INPUT-001",
  "initialExecutionFlg": true,
  "previousRunId": null,
  "updatedAt": "2026-07-27T08:00:00+09:00"
}
```

初回処理：

1. 固定Baselineがないことを確認する。
2. `previousRunId`がNullであることを確認する。
3. Field Diffを`NOT_COMPARED`、理由を`INITIAL_EXECUTION`とする。
4. API呼出、Business CheckおよびExpected照合を実行する。
5. Run成果物をすべて保存する。
6. Complete Runを確認する。
7. Current RunからBaselineを生成する。
8. Baselineを原子的に配置する。
9. `previousRunId`をCurrent Run IDへ更新する。
10. `initialExecutionFlg=false`へ更新する。

Baseline生成失敗時は`initialExecutionFlg=true`を維持する。

## 13. Complete Run判定

Baseline更新はVerification ResultではなくExecution Completenessで判定する。

### 13.1 必須条件

| 条件ID | 条件 |
|---|---|
| `COMP-001` | `run-meta.json`が存在しIdentityが一致する。 |
| `COMP-002` | `scenario-execution.json`が終了状態を示す。 |
| `COMP-003` | Scenario上の必須API呼出が完了している。 |
| `COMP-004` | 条件SkipされたAPIが`SKIPPED`として明示されている。 |
| `COMP-005` | 実行した必須APIのResponse JSONが存在しParse可能である。 |
| `COMP-006` | `verification-result.json`が生成済みである。 |
| `COMP-007` | 必須`resultKey`の結果が確定している。 |
| `COMP-008` | 必須Field Diffが生成済み、または初回非実行理由が明示されている。 |
| `COMP-009` | ManifestのFile一覧、SizeおよびHashが一致する。 |
| `COMP-010` | Run WriterがCloseされ、一時Fileが残っていない。 |
| `COMP-011` | Execution Statusが`COMPLETED`である。 |
| `COMP-012` | 終端Outcome別Artifact Package Completenessが`COMPLETE`である。 |

Artifact Packageが`COMPLETE`でもExecution Statusが`INCOMPLETE`、`REJECTED`または`UNKNOWN_OUTCOME`の場合はBaseline更新不可とする。Evidenceの完全性と実行の完全性を同一視しない。

### 13.2 更新可否

| 実行結果 | Run完全性 | Baseline更新 |
|---|:---:|:---:|
| 全Check PASS | Complete | Yes |
| Business Check FAIL | Complete | Yes |
| Expected不一致でFAIL | Complete | Yes |
| 有効なField Diffあり | Complete | Yes |
| 業務Error ResponseがScenario期待どおり | Complete | Yes |
| API Timeout | Incomplete | No |
| Transport Error | Incomplete | No |
| Response Parse Error | Incomplete | No |
| 必須API未実行 | Incomplete | No |
| Run中断 | Incomplete | No |
| 成果物書込失敗 | Incomplete | No |
| Result Key不整合でERROR | Incomplete | No |

Baselineは「前回の正しい結果」ではなく「前回の完全な実際結果」である。

## 14. Baseline対象ファイル

最低限、次をBaselineへ保存する。

```text
baseline-meta.json
verification-result.json
api-calls/{apiCallCode}/response.json
```

原則としてRequest JSONとLogはBaselineへ複製しない。監査目的では元Runを`sourceRunId`から参照する。

Skipされた呼出は`api-meta.json`相当のManifest情報で状態を保持し、存在しないResponseを生成しない。

## 15. Baseline置換

### 15.1 処理順

```text
1. Current Run出力完了
2. Complete Run Validation
3. Identity LockおよびFencing条件取得
4. Current Baseline PointerとVersion Token読込
5. Immutable Baseline Generation生成
6. 必須ファイルをCurrent RunからCopy
7. `baseline-meta.json`内にArtifact InventoryとInventory Hashを生成
8. Candidate Generation検証
9. Expected Pointer VersionでCurrent BaselineをCAS切替
10. Logical Baseline ViewからGeneration／Inventoryを再確認
11. Execution StateとVersion Token読込
12. Expected State VersionでExecution StateをCAS更新
13. 配置後State再確認
14. Lock解放
```

### 15.2 条件付きPublication

既存の非空Baseline DirectoryへPortableなAtomic Rename上書きが可能であると仮定しない。BaselineはStorage種別にかかわらず、論理的にImmutable Versioned SetとExpected Version付きCurrent Pointerで管理する。

File System AdapterがCurrent PointerをAtomic File Replaceで実装する場合も、Expected Version、Lock Owner／Fencing条件およびRead-backを必須とする。Object Storage Adapterは条件付きPutまたは同等のCASを使用する。

### 15.3 旧Baseline

新Baseline Pointer切替完了前に旧Generationを破壊してはならない。Pointer切替失敗または結果不明時は、旧／新Pointer VersionとGenerationを照合するまで削除しない。

Retention数と削除時期は運用設計で定義する。

## 16. Execution State更新

Baseline置換成功後にだけ次を更新する。

```json
{
  "initialExecutionFlg": false,
  "previousRunId": "RUN-c91452ab"
}
```

更新順序は固定する。

```text
完全Run保存
→ Baseline置換
→ Baseline検証
→ previousRunId更新
→ initialExecutionFlg更新
```

State更新はTemporary Objectからの無条件上書きではなく、読込時のExpected State VersionとLock Owner／Fencing条件を使用した単一Object CASとする。CAS失敗時はStateを再読込し、Last Write Winsで上書きしない。

## 17. Crash Recovery

| 障害点 | 状態 | 次回処理 |
|---|---|---|
| Current Run出力中 | 旧Baseline・旧State維持 | Incomplete Runとして隔離 |
| Baseline Generation生成中 | 旧Baseline・旧State維持 | 未参照Generationを隔離または再検証 |
| Pointer切替前 | 旧Baseline・旧State維持 | 新Generationを再利用せず再計画 |
| Pointer切替直後、応答前 | 旧または新Baseline・旧State | Pointer VersionとGenerationを照合 |
| Baseline切替後、State更新前 | 新Baseline・旧State | Baseline MetadataからState修復候補 |
| State CAS直後、応答前 | 新Baseline・旧または新State | Version付きStateを再読込 |
| State切替後 | 新Baseline・新State | 正常 |

BaselineとStateが不一致の場合、Current Pointerが示すGenerationの`sourceRunId`、`baseline-meta.json`内Artifact Inventory、Inventory HashおよびIdentityが有効なら、Baselineを正としてState修復候補を生成する。ただし自動修復の可否は運用設定で制御し、監査Logを必須とする。

## 18. 排他制御

Lock KeyはExecution Identityとする。

```text
environmentId/useCaseId/scenarioId/inputSetId
```

| ケース | 取扱い |
|---|---|
| 異なるExecution Identity | 並行実行可 |
| 同一Identityの同時Run | 起動拒否またはQueue |
| 同一Identityで読込中に別Runが更新 | Run開始時に読込んだBaseline版を固定 |
| Lock所有者異常終了 | Lease／Timeoutと運用手順で回復 |

LockなしでLast Write Winsを許可してはならない。

## 19. Java責務

```java
public interface BaselineManager {

    BaselineContext loadPrevious(
            ExecutionIdentity identity,
            ExecutionState state);

    BaselineUpdateResult replaceFromRun(
            ExecutionIdentity identity,
            String runId);
}
```

概念処理：

```java
ExecutionState state = stateRepository.load(identity);
BaselineContext previous =
        baselineManager.loadPrevious(identity, state);

ScenarioContext context =
        contextFactory.create(identity, input, expected, previous);

ScenarioExecutionResult result = scenario.execute(context);
runWriter.finalizeRun(context, result);

if (runCompletenessValidator.isComplete(identity.runId())) {
    baselineManager.replaceFromRun(identity, identity.runId());
    stateRepository.updateAfterBaseline(identity, identity.runId());
}
```

`verificationStatus == PASS`だけをBaseline更新条件にしてはならない。

## 20. Validation

| Validation ID | 確認内容 | Level |
|---|---|---|
| `BL-V001` | StateのExecution IdentityがPathと一致する。 | ERROR |
| `BL-V002` | `initialExecutionFlg=false`時に`previousRunId`が存在する。 | ERROR |
| `BL-V003` | 固定BaselineのIdentityが実行Identityと一致する。 | ERROR |
| `BL-V004` | `sourceRunId`が実在する完全Runを指す。 | ERROR |
| `BL-V005` | `baseline-meta.json`のArtifact InventoryがFile、Size、Hashと一致する。 | ERROR |
| `BL-V006` | 同一`apiCallCode`のResponseだけをPreviousとして使用する。 | ERROR |
| `BL-V007` | 日付またはFile時刻による前回検索を実装していない。 | ERROR |
| `BL-V008` | Complete RunだけがBaseline更新対象である。 | ERROR |
| `BL-V009` | BaselineをAPI単位で部分更新しない。 | ERROR |
| `BL-V010` | Temporary領域を検証後にAtomic切替する。 | ERROR |
| `BL-V011` | Baseline成功後にStateを更新する。 | ERROR |
| `BL-V012` | 同一Identityの更新が排他される。 | ERROR |
| `BL-V013` | 初回時にField Diff非実行理由を記録する。 | ERROR |
| `BL-V014` | Business FAILかつComplete Runを更新可能とする。 | ERROR |
| `BL-V015` | Incomplete Run時に旧Baselineを保持する。 | ERROR |

## 21. Error Code

本章のCodeはState／Baseline ComponentのPlatform Failure Codeであり、四結果軸の`reasonCodes`ではない。Resultへの影響とReason Codeへの変換は`ログ・例外・Recovery設計書.md`のFailure Policyに従う。

| Error Code | 条件 | 処理 |
|---|---|---|
| `EXECUTION_STATE_NOT_FOUND` | Stateがなく初期化も未承認 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `EXECUTION_STATE_INVALID` | State構文・Identity不正 | Execution `REJECTED`、Verification `NOT_EVALUATED` |
| `BASELINE_NOT_FOUND` | 非初回でBaselineも復旧元もない | API呼出前にExecution `REJECTED` |
| `BASELINE_IDENTITY_MISMATCH` | Baselineと実行Identity不一致 | 使用禁止、Execution `REJECTED` |
| `BASELINE_MANIFEST_INVALID` | File欠落またはHash不一致 | 復旧を試行し、不可ならExecution `REJECTED` |
| `PREVIOUS_RUN_NOT_FOUND` | `previousRunId`のRunなし | 初回以外はExecution `REJECTED` |
| `PREVIOUS_RUN_INCOMPLETE` | 復旧元が完全Runでない | 使用禁止、Execution `REJECTED` |
| `BASELINE_UPDATE_SKIPPED` | Current Run不完全 | 旧Baseline維持、理由記録 |
| `BASELINE_REPLACE_FAILED` | Temporary生成・切替失敗 | 旧Baseline維持、State未更新、Execution `INCOMPLETE` |
| `EXECUTION_STATE_UPDATE_FAILED` | Baseline後のState更新失敗 | Execution `INCOMPLETE`、Recovery `REQUIRED`。Baseline Metadataから復旧候補を生成 |
| `BASELINE_LOCK_CONFLICT` | 同一Identity実行中 | 起動拒否またはQueue |

## 22. 監査

次を`ログ・例外・Recovery設計書.md`のAudit PortへAppend Onlyで記録する。

- Execution Identity
- Current Run ID
- 読み込んだBaselineの`sourceRunId`
- Baseline取得方法（固定／復旧／初回）
- Complete Run判定結果と失敗条件
- Baseline更新開始・成功・失敗
- 旧／新`sourceRunId`
- State更新前後
- Lock取得・解放
- OperatorまたはScheduler Identity

Secret、Response実値および個人情報をAudit Logへ出力しない。

## 23. Retentionおよび運用

- `runs/{runId}`は監査Retentionに従って保持する。
- 現行Baselineは削除対象外とする。
- 旧Baseline Backupの保持世代を運用設計で定義する。
- `previousRunId`が指すRunをRetention Cleanupで先に削除してはならない。
- Cleanup前にBaselineおよびStateの参照整合性を検証する。
- 手動Baseline差替えは承認、理由、Operatorおよび対象Runを記録する。
- Baselineの承認方式は本書では固定せず、運用設計で定義する。

## 24. Test Scenario

| Test ID | 条件 | 期待結果 |
|---|---|---|
| `BL-T001` | 初回、Baselineなし | Field Diffを行わず完全Run後にBaseline作成 |
| `BL-T002` | 二回目、固定Baselineあり | 固定BaselineをPreviousとして使用 |
| `BL-T003` | 固定Baselineなし、`previousRunId`有効 | 指定Runから復旧 |
| `BL-T004` | 非初回、BaselineもRunもなし | `BASELINE_NOT_FOUND` |
| `BL-T005` | Business Check FAIL、Run完全 | Baseline更新 |
| `BL-T006` | API Timeout | Baseline更新せず旧版維持 |
| `BL-T007` | Response Parse Error | Baseline更新せず旧版維持 |
| `BL-T008` | Baseline Copy中にCrash | 旧Baseline維持 |
| `BL-T009` | Baseline更新後、State更新前にCrash | 新BaselineからState復旧可能 |
| `BL-T010` | 同一Identity同時起動 | 一方を拒否またはQueue |
| `BL-T011` | 異なるInput Set | Baselineを相互利用しない |
| `BL-T012` | 同一APIを複数回呼出 | 同じ`apiCallCode`同士を比較 |
| `BL-T013` | Baseline Artifact InventoryまたはInventory Hash改変 | 使用拒否し復旧またはError |
| `BL-T014` | 日付が逆転するRun | `previousRunId`により正しく特定 |

## 25. Review Checklist

- [ ] Execution IdentityにEnvironment、UseCase、Scenario、Input Setが含まれる。
- [ ] 正常時に固定Baseline Pathを直接読む。
- [ ] Baseline欠失時だけ`previousRunId`で復旧する。
- [ ] 日付、Directory順または更新時刻を使って前回を推測しない。
- [ ] 初回FlgをInputへ保存していない。
- [ ] 初回はPrevious／Current Field Diffを行わない。
- [ ] Business FAILとExecution Incompleteを区別している。
- [ ] Complete RunだけをBaseline化する。
- [ ] API単位の部分Baseline更新を行わない。
- [ ] Temporary領域とAtomic切替を使用する。
- [ ] Baseline成功後にStateを更新する。
- [ ] 同一Execution Identityの更新を排他する。
- [ ] Baselineから`sourceRunId`を追跡できる。
- [ ] Cleanupが`previousRunId`参照を破壊しない。
- [ ] Crash Pointごとの回復方法がTestされている。

## 26. 未確定事項

| Issue ID | 論点 | 暫定方針 | 確定先 |
|---|---|---|---|
| `BL-ISSUE-001` | Outputsの物理Root | File I/OのLogical Namespaceを維持し、Environment設定でRootを与える。 | Environment／Runtime設計 |
| `BL-ISSUE-002` | Baseline Generation／Pointerの物理実装 | Immutable Versioned Set＋CAS Pointerを必須とする。 | Environment／Runtime設計 |
| `BL-ISSUE-003` | Lock／Fencing実装 | Lock Port、Expected VersionおよびFencing条件を併用する。 | 共通Framework／環境設計 |
| `BL-ISSUE-004` | Baseline承認者と手動差替え | 承認Workflowを運用設計で定義する。 | 運用設計 |
| `BL-ISSUE-005` | 旧Baseline保持世代 | 監査・容量要件に基づき決定する。 | 運用設計 |

## 27. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.8` | 2026-07-28 | `execution-state.schema.json`／`baseline-meta.schema.json`正文に合わせ、Initial／Previous合法組合せ、Storage Version境界、Source Manifest、Artifact Inventoryおよび独立Inventory Hashを明確化 | DRAFT |
| `1.0.0-draft.7` | 2026-07-28 | Log／Recovery設計に合わせ、State／Baseline Error CodeをFailure CodeとしてReason Codeから分離し、Audit PortとRecovery Caseへの引渡しを同期 | DRAFT |
| `1.0.0-draft.6` | 2026-07-28 | File I/O設計に合わせ、非空Directoryの直接Atomic Rename前提を廃止し、Immutable Baseline Generation、CAS Pointer、State CAS、Version付きCrash Recoveryへ統一 | DRAFT |
| `1.0.0-draft.5` | 2026-07-28 | Snapshot／Evidence設計に合わせ、Baseline完全性索引を未定義の別Manifestではなく`baseline-meta.json`内Artifact InventoryとInventory Hashへ統一 | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | 横断Reviewにより四結果軸へError処理を統一し、Artifact Package完全性とExecution完全性を分離 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | 凍結済Repository構造に従い`system/05_framework/`へ移行。文書IDと設計責務は継承 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | 初回Diffの状態名を`NOT_COMPARED`、理由を`INITIAL_EXECUTION`へ統一 | DRAFT |
| `1.0.0-draft.1` | 2026-07-27 | `initialExecutionFlg`、`previousRunId`、固定Baseline、完全Run判定および原子置換に基づく初版作成 | DRAFT |
