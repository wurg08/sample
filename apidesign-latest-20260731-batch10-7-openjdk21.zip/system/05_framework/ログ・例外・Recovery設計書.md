---
title: ログ・例外・Recovery設計書
document_id: E6-API-VAL-LOG-EXCEPTION-RECOVERY-DESIGN
version: 1.0.0-draft.3
status: DRAFT
document_type: Log Exception and Recovery Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# ログ・例外・Recovery設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | ログ・例外・Recovery設計書 |
| 文書ID | `E6-API-VAL-LOG-EXCEPTION-RECOVERY-DESIGN` |
| 対象 | Structured Event、Diagnostic Log、Exception変換、Timeout、Retry、Cancellation、Audit、Recovery Handoff |
| 配置 | `system/05_framework/` |
| 文書種別 | Runtime横断設計書 |
| 版数 | `1.0.0-draft.3` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | Runtime / Operation Architecture Team |
| レビュー責任 | System Architect / Runtime Lead / Security Lead / Operation Lead / Verification Lead |
| 承認責任 | System Owner / Operation Owner |

## 2. 目的

本書は、E6 API Verification Platformで発生する正常Event、検証不一致、実行失敗、外部結果不明、Security事象および運用Recoveryを、四結果軸を壊さず安全に追跡するため、次を定義する。

1. Result、Event、Log、Metric、Trace、AuditおよびRecovery Caseの責務分離
2. Structured Eventの共通Envelope、Identity、Levelおよび公開Class
3. Infrastructure ExceptionからPlatform Failureへの境界変換
4. Error／Failure CodeとReason Codeの分離
5. Exception分類ごとのExecution、Verification、Change、Recoveryへの影響
6. API Callの送信状態を考慮したTimeout、RetryおよびCancellation
7. `UNKNOWN_OUTCOME`の停止、Handoff、外部確認および解決
8. Recovery CaseのLifecycle、再実行、補償、訂正および監査
9. Secret、個人情報、Request／ResponseおよびStack Traceの出力統制
10. Log Sink、Audit Sinkまたは通知障害時のFail Closed／Degraded動作

本書は特定Logging製品、APM製品、Ticket製品、Message Broker、保存先絶対Path、Retention日数または通知先実値を固定しない。

## 3. Normative Reference

| Reference | 本書で使用する契約 |
|---|---|
| `system/01_repository/Repository_Structure.md` | 凍結Repository／Runtime論理構造、Recovery非正本、未承認Directory追加禁止 |
| `system/01_repository/命名規約.md` | Identity、Enum、Platform Error Code |
| `system/01_repository/用語集.md` | 四結果軸、Severity、Evidence、Mask |
| `system/05_framework/システム設計書.md` | System Boundary、Recovery Coordinator、Failure Boundary |
| `system/05_framework/共通Identity・Resultモデル設計書.md` | Runtime Identity、四結果軸、Severity、Reason Code、Immutable Result |
| `system/05_framework/共通Framework設計書.md` | Port／Adapter、Sealed Plan、Cancellation、Retry境界 |
| `system/05_framework/ScenarioContext設計書.md` | API Call状態、Context Lifecycle、Run Isolation |
| `system/05_framework/ExecutionState・Baseline管理設計書.md` | Baseline／State更新、Crash Recovery、Audit対象 |
| `system/05_framework/Snapshot・Evidence設計書.md` | 保存前Mask、Diagnostic Artifact、Protected Evidence、Manifest |
| `system/05_framework/ファイル入出力設計書.md` | Logical／Physical分離、Create-Only、CAS、Publication Outcome |
| `system/05_framework/環境・Runtime構成設計書.md` | Provider Capability、Secret／Certificate、Process Lifecycle、Health、Retention、Backup |
| `system/06_verification_assets/検証結果・Expected設計書.md` | Check Result、`NOT_EVALUATED`、Reason Code |
| `system/06_verification_assets/APIレスポンスDiff設計書.md` | Change Status、比較不能理由 |
| `system/07_report/Report設計書.md` | 四軸表示、Problem First、Recovery表示、Report非改変 |

`recovery/legacy_05_framework/`配下の旧文書は移行要求の比較入力であり、本書のNormative Referenceではない。

## 4. 適用範囲

### 4.1 対象

- Application Bootstrap、Run、Scenario、API Call、Check、Artifact、Baseline、ReportのEvent
- Diagnostic LogとStructured Event
- Security／Integrity／Audit Event
- Java Throwableおよび外部Adapter ErrorのPlatform Failure変換
- Timeout、Connection Reset、CancellationおよびProcess中断
- Retry Eligibility、Attempt、BackoffおよびRetry Budget
- Stop Scopeと後続副作用抑止
- Recovery Case、Recovery Action、Resolutionおよび元Run Relation
- Metric、Trace Correlationおよび通知候補
- Log、AuditおよびRecovery MetadataのMask、Access、Integrity

### 4.2 対象外

| 対象外 | 正式な決定先 |
|---|---|
| Logging／APM／Ticket製品 | `環境・Runtime構成設計書.md`および運用設計 |
| Log／Audit／Recovery Storeの物理Root | `環境・Runtime構成設計書.md` |
| Retention、Archive、Backupの具体値 | 運用・監査設計 |
| Alert通知先、当番表、Escalation時間 | 運用設計 |
| API別Timeout、Retry回数、Idempotency | API詳細設計、Environment設定、Sealed Plan |
| 業務補償処理の内容 | 業務責任者、API Owner、Scenario詳細設計 |
| HTTP Client製品固有Exception | Runtime Adapter実装 |
| Protected Raw Evidenceの物理暗号領域 | Environment／Security／Operation設計 |
| Report Layout | `system/07_report/Report設計書.md` |

## 5. 基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `LER-P001` | Result Authority | 四結果軸の正本はResult Artifactであり、Log Messageから再判定しない。 |
| `LER-P002` | Signal Separation | Result、Diagnostic Log、Audit、Metric、Trace、Recovery Caseを別責務とする。 |
| `LER-P003` | Boundary Translation | 製品固有ExceptionをCoreへ漏らさず分類済みPlatform Failureへ変換する。 |
| `LER-P004` | Code Separation | Failure CodeとReason Codeを別Field、別Catalog、別用途で保持する。 |
| `LER-P005` | Dispatch Awareness | APIが送信前か、送信済みか、送達結果不明かを記録してTimeoutを判定する。 |
| `LER-P006` | No Blind Retry | 同一Mutationを結果確認なしに自動再送しない。 |
| `LER-P007` | Immutable Origin | Recoveryで元Run、元Resultまたは元Artifactを書き換えない。 |
| `LER-P008` | Safe by Construction | Mask失敗時に未Mask DataへFallbackしない。 |
| `LER-P009` | Audit Durability | Baseline、State、Recovery、承認および削除等の重要操作は監査記録を必須とする。 |
| `LER-P010` | Bounded Observability | Log量、Message Size、Stack Depth、CardinalityおよびBufferを無制限にしない。 |
| `LER-P011` | Explicit Degradation | Sink障害を握りつぶさず、処理継続可否と失われた観測範囲を明示する。 |
| `LER-P012` | No Frozen Tree Expansion | Diagnostic都合で凍結Runtime Treeへ`logs/`、`errors/`または`recovery/`を追加しない。 |
| `LER-P013` | Evidence Linkage | LogやRecoveryをResultの代用にせず、Stable Identityで双方向Traceする。 |
| `LER-P014` | Least Disclosure | Payload、Secret、個人情報および内部Locatorを必要最小限だけ扱う。 |

## 6. 用語と責務分離

| 用語 | 正本責務 | Resultとの関係 |
|---|---|---|
| Result Artifact | Execution、Verification、Change、Recoveryの原結果 | 正本 |
| Structured Event | 一つの状態遷移または観測事実 | Resultを参照するが代替しない |
| Diagnostic Log | 障害調査に必要な安全な技術情報 | 非正本 |
| Metric | 件数、時間、Gauge等の集約観測値 | 原Resultを上書きしない |
| Trace／Span | Component間の処理連鎖と時間 | 業務Evidenceではない |
| Audit Record | 重要操作のActor、対象、理由、前後Version | 操作事実の監査正本 |
| Failure Record | 一回の処理失敗を型付きで表すCore Model | 四軸へのMapping入力 |
| Failure Code | Component／処理失敗の安定Code | 診断用 |
| Reason Code | 四結果軸がその値になった理由 | Result用 |
| Recovery Case | 元Runに対する確認、復旧、補償または訂正の作業単位 | 元Runと別Identity |
| Recovery Action | Recovery Case内の一回の操作 | Append Only |
| Resolution | Recovery調査・処置結果の確定 | 元Runを変更しない |

### 6.1 Codeの分離

```text
Throwable／Adapter Error
→ Failure Code
→ Failure Classification
→ Axis Impact
→ Reason Code
```

例：

| 種類 | 値 | 用途 |
|---|---|---|
| Failure Code | `HTTP_RESPONSE_TIMEOUT` | HTTP Adapterの診断 |
| Execution | `UNKNOWN_OUTCOME` | 更新APIの原結果 |
| Recovery | `REQUIRED` | 運用介入 |
| Reason Code | `HTTP_TIMEOUT`、`RECOVERY_MANUAL_CONFIRMATION_REQUIRED` | Result説明 |

Failure Codeを`reasonCodes`へ無条件コピーせず、Reason CodeをJava Exception Class名として使用しない。

## 7. 論理Component

| Component | 主責務 | 禁止責務 |
|---|---|---|
| Event Publisher | 型付きEventの生成、Mask、送信 | Result再判定 |
| Diagnostic Log Adapter | 安全な診断Eventの保存・転送 | Payload全文の既定保存 |
| Audit Port | 重要操作のAppend Only監査 | Audit失敗の握りつぶし |
| Exception Translator | Throwable／Adapter ErrorをFailure Recordへ変換 | Message文字列だけの分類 |
| Failure Policy Resolver | Failure、Call State、PlanからAxis ImpactとStop Scopeを決定 | 未定義Caseの成功扱い |
| Timeout Controller | Deadline、Cancel要求、終了観測 | 更新APIの成功推測 |
| Retry Policy Resolver | Eligibility、Budget、Backoff、Idempotency確認 | 無条件Retry |
| Recovery Coordinator | Recovery Case生成、Handoff、Action、Resolution | 元Run Result変更 |
| Notification Port | Alert Candidateの配送 | 通知成功をRecovery解決とみなす |
| Metric／Trace Port | Counter、Timer、Spanの出力 | 高Cardinality SecretのLabel化 |

具体的Java Package、Libraryおよび製品は本書で固定しない。

## 8. Signal Model

### 8.1 Signalの関係

```mermaid
flowchart TD
    A["Runtime Event"] --> B["Failure Classification"]
    B --> C["Four-Axis Result"]
    B --> D["Safe Diagnostic Event"]
    B --> E["Audit Record"]
    C --> F["Published Evidence"]
    C --> G["Recovery Handoff"]
    G --> H["Recovery Case"]
```

同一事象から複数Signalが生成されても、各SignalのIdentityと正本責務を維持する。

### 8.2 Event Class

| Event Class | 例 | 保存要件 |
|---|---|---|
| `LIFECYCLE` | Run開始、Scenario終了 | Structured Event |
| `EXECUTION` | API Call開始、Timeout | Structured Event＋必要時Failure |
| `VERIFICATION` | Check評価完了 | Result Reference中心。値全文禁止 |
| `ARTIFACT` | Seal、Publish、Quarantine | Structured Event＋Audit条件付き |
| `STATE` | Baseline Pointer／State CAS | Audit必須 |
| `SECURITY` | Mask失敗、Path違反 | Security Event＋Audit必須 |
| `RECOVERY` | Case作成、Action、Resolution | Audit必須 |
| `OPERATION` | 手動Run、Report再生成、Retention | Audit必須 |

## 9. Structured Event Envelope

### 9.1 共通項目

| Field | 必須 | 内容 |
|---|:---:|---|
| `eventSchemaVersion` | Yes | Event契約版 |
| `eventId` | Yes | Event Instanceの一意ID |
| `eventType` | Yes | Stable Event Type |
| `eventClass` | Yes | 8.2の分類 |
| `occurredAt` | Yes | RFC 3339 Offset付き |
| `observedAt` | Yes | Sinkが観測した時刻 |
| `level` | Yes | `TRACE / DEBUG / INFO / WARN / ERROR` |
| `componentId` | Yes | 論理Component |
| `buildRef` | Yes | Build／Release Trace |
| `environmentId` | 条件付 | Environment解決後 |
| `requestId` | 条件付 | Trigger受付後 |
| `runId` | 条件付 | Run採番後 |
| `batchExecutionId` | 条件付 | Batch内実行 |
| `useCaseExecutionId` | 条件付 | UseCase実行中 |
| `scenarioExecutionId` | 条件付 | Scenario実行中 |
| `apiCallExecutionId` | 条件付 | API Call実行中 |
| `apiCallCode` | 条件付 | Call定義とのTrace |
| `checkExecutionId` | 条件付 | Check実行中 |
| `attemptId` | 条件付 | Retry／再試行単位 |
| `failureRef` | 条件付 | Failure Record参照 |
| `resultRef` | 条件付 | Result Artifact参照 |
| `artifactRef` | 条件付 | Artifact Identity参照 |
| `recoveryCaseId` | 条件付 | Recovery Case参照 |
| `messageKey` | Yes | Locale非依存Message Key |
| `safeAttributes` | No | Schema許可済み追加属性 |

### 9.2 JSON例

```json
{
  "eventSchemaVersion": "1.0",
  "eventId": "EVENT-550e8400-e29b-41d4-a716-446655440000",
  "eventType": "API_CALL_OUTCOME_UNKNOWN",
  "eventClass": "EXECUTION",
  "occurredAt": "2026-07-28T23:40:10.125+09:00",
  "observedAt": "2026-07-28T23:40:10.140+09:00",
  "level": "ERROR",
  "componentId": "API_ACCESS",
  "buildRef": "BUILD-20260728-01",
  "environmentId": "ENV-STAGING",
  "requestId": "REQ-550e8400",
  "runId": "RUN-20260728-234000-550e8400",
  "scenarioExecutionId": "SCEXEC-550e8400",
  "apiCallExecutionId": "CALLEXEC-550e8400",
  "apiCallCode": "CALL-002",
  "attemptId": "ATTEMPT-001",
  "failureRef": "FAILURE-550e8400",
  "resultRef": "RESULT-550e8400",
  "recoveryCaseId": "RECOVERY-550e8400",
  "messageKey": "api.call.outcome.unknown",
  "safeAttributes": {
    "httpMethod": "POST",
    "dispatchState": "POSSIBLY_DISPATCHED",
    "elapsedMillis": 10000
  }
}
```

Endpoint全文、Query値、Header値、Request Body、Response Body、Token、Cookie、Stack Traceまたは物理Storage Locatorを`safeAttributes`へ含めない。

## 10. Event Type管理

### 10.1 命名

Event TypeはUpper Snake Caseとし、Event Instance IDと分離する。

```text
RUN_ACCEPTED
RUN_REJECTED
API_CALL_DISPATCH_STARTED
API_CALL_RESPONSE_RECEIVED
API_CALL_OUTCOME_UNKNOWN
ARTIFACT_PACKAGE_PUBLISHED
BASELINE_POINTER_CHANGED
RECOVERY_CASE_OPENED
RECOVERY_CASE_RESOLVED
```

### 10.2 必須Event

| Phase | 必須Event |
|---|---|
| Bootstrap | `APPLICATION_STARTED / APPLICATION_START_REJECTED / APPLICATION_STOPPED` |
| Run | `RUN_ACCEPTED / RUN_STARTED / RUN_TERMINATED` |
| Preflight | `PREFLIGHT_COMPLETED / PREFLIGHT_REJECTED` |
| Scenario | `SCENARIO_STARTED / SCENARIO_TERMINATED` |
| API Call | `API_CALL_STARTED / API_CALL_DISPATCH_STATE_CHANGED / API_CALL_TERMINATED` |
| Verification | `VERIFICATION_FINALIZED` |
| Artifact | `PACKAGE_SEALED / PACKAGE_PUBLISHED / PACKAGE_QUARANTINED` |
| Baseline／State | `BASELINE_UPDATE_REQUESTED / POINTER_SWAP_RESULT / STATE_CAS_RESULT` |
| Report | `REPORT_GENERATION_TERMINATED` |
| Recovery | `RECOVERY_CASE_OPENED / ACTION_RECORDED / CASE_RESOLVED` |

開始Eventだけが存在し終了Eventがない場合、正常完了を推測しない。Crash検出またはRecovery Scanが未終端Executionを識別する。

## 11. Log Level

| Level | 用途 | 使用例 |
|---|---|---|
| `TRACE` | 開発時の詳細な制御Flow | Mask済みField Rule選択 |
| `DEBUG` | 再現に有用な内部状態 | Registry Key、Attempt、Branch ID |
| `INFO` | 通常Lifecycleと重要成功 | Run開始、Package公開 |
| `WARN` | 継続可能なDegradation／競合 | Retry予定、任意通知失敗 |
| `ERROR` | 実行不完全、結果不明、Security／Integrity異常 | Timeout、Mask失敗、CAS不明 |

`FATAL`および`AUDIT`をLog Level Enumへ追加しない。Run停止性はFailure／Executionで、監査性はEvent ClassとAudit Recordで表す。

Verification `FAIL`を機械的にLog `ERROR`へ変換しない。Log Levelは運用観測、Verification Statusは期待適合性である。

## 12. IdentityとCorrelation

### 12.1 最小Correlation

| 発生段階 | 必須Identity |
|---|---|
| Run採番前 | `requestId`、`componentId`、`environmentRef` |
| Run採番後 | `requestId`、`runId`、`environmentId` |
| Scenario中 | 上記＋`useCaseExecutionId`、`scenarioExecutionId` |
| API Call中 | 上記＋`apiCallExecutionId`、`apiCallCode`、`attemptId` |
| Check中 | 上記＋`checkExecutionId`、`resultKey` |
| Artifact | `runId`、`artifactId`、Owner Execution ID |
| Recovery | `recoveryCaseId`、`sourceRunId`、対象Execution／Artifact |

### 12.2 禁止

- Thread ID、Process IDまたはTimestampだけでRunを関連付ける。
- `apiId`だけでScenario内の複数Callを同一視する。
- `logger`文字列やMessage本文を検索Keyの正本とする。
- Actor名、Host名またはIPをStable Identityへ含める。

Process／Thread／Hostは補助診断属性として保持できるが、Identity正本ではない。

## 13. Log Content Policy

### 13.1 Default許可

- Stable Identity
- Component、Event Type、Failure Code、Reason Code
- HTTP Method
- API設計で安全と確認されたEndpoint Template ID
- HTTP Status ClassまたはStatus Code
- Media Type
- Size、Duration、Attempt Count
- Schema Version、Build Ref、Bundle Hashの安全な参照
- Artifact ID、Manifest Hash、Storage Version Tokenの安全な参照
- 四結果軸とSeverity

### 13.2 Default禁止

- Authorization、Proxy Authorization、Cookie、Set-Cookie
- Access Token、Refresh Token、API Key、Password、Client Secret
- Request／Response Body全文
- Query Parameter実値
- 個人情報、顧客番号、氏名、住所、電話、Email
- Endpoint実Host、内部IP、Mount Path、Bucket名、Signed URL
- Java Objectの無制限`toString()`
- SQL、Connection String、Environment Variable実値
- Secretを含み得るException MessageまたはStack Trace

### 13.3 Payload参照

Request／Response内容が必要な場合、Logへ複製せず、Published Evidenceの`artifactId`を参照する。Evidence自体もSnapshot／Evidence設計の保存前Maskを通過していなければならない。

## 14. Mask、RedactionおよびSecret Scan

### 14.1 適用順

```text
Typed Event生成
→ Allowlist Projection
→ Field Mask
→ Message Parameter Sanitization
→ Secret／PII Scan
→ Size／Cardinality検証
→ Sink送信
```

### 14.2 Mask失敗

| 条件 | 出力 | Runtime影響 |
|---|---|---|
| 非必須AttributeのMask失敗 | Attributeを全削除した最小Event | Failure記録 |
| 必須監査項目の安全化失敗 | PayloadなしのSecurity Audit候補 | 重要操作を開始前なら拒否 |
| Secret Scan検出 | 該当Event本文を破棄 | Security Failure、必要時Run停止 |
| Stack Trace安全化不能 | Stack Trace非保存 | Failure Codeと安全なTop Frame Hashのみ |
| Request／Response安全化不能 | Logへ出力しない | Evidence公開禁止条件を別判定 |

Mask処理例外を理由に未Mask値を緊急Logへ出力しない。

## 15. Exception Boundary

### 15.1 層別責務

| Boundary | 入力 | 出力 |
|---|---|---|
| Trigger Adapter | CLI／Scheduler／HTTP Error | Trigger Failure |
| Definition Adapter | Parse／Schema／Revision Error | Definition Failure |
| API Adapter | DNS／TLS／Connection／HTTP／Decode Error | Transport／Protocol Failure |
| Storage Adapter | I/O／CAS／Version Error | Storage Failure |
| Security Adapter | Auth／Mask／Access Error | Security Failure |
| Core | Domain Precondition／State Error | Framework Failure |
| Global Boundary | 未分類Throwable | Unexpected Failure |

各AdapterはVendor Exception型、Credential、URL実値またはResponse BodyをCore Failureへ持ち込まない。

### 15.2 Catch規則

1. `Throwable`の無差別CatchでProcess Errorを正常化しない。
2. Cancel／Interrupt Signalを通常Failureへ握りつぶさない。
3. `OutOfMemoryError`等の継続安全性を証明できない事象で同一ProcessのRun継続を仮定しない。
4. 原因Chainは安全な分類情報だけを保持し、Message全文を永続化しない。
5. Failure変換に失敗した場合は`UNEXPECTED_FAILURE`としてFail Closedする。

## 16. Failure Taxonomy

| Category | 主な条件 | 代表Failure Code Prefix |
|---|---|---|
| `DEFINITION` | Master、設計、Schema、Registry、Bundle | `DEF_` |
| `CONFIGURATION` | Environment、必須設定、Capability | `CONFIG_` |
| `CONTEXT` | Context、Mapping、型、Lifecycle | `CTX_` |
| `REQUEST_BUILD` | Request構築、Serialization | `REQUEST_` |
| `AUTHENTICATION` | Credential解決、認証 | `AUTH_` |
| `TRANSPORT` | DNS、TLS、Connection、Timeout | `HTTP_` |
| `PROTOCOL` | HTTP Status、Media Type、Header契約 | `PROTOCOL_` |
| `RESPONSE_PARSE` | Decode、JSON Parse、DTO Mapping | `PARSE_` |
| `VERIFICATION_ENGINE` | Check実装、Result生成 | `VERIFY_ENGINE_` |
| `DIFF_ENGINE` | Previous、Compare、Diff生成 | `DIFF_` |
| `ARTIFACT` | Mask、Schema、Manifest、Publish | `ARTIFACT_` |
| `STORAGE` | Read、Write、CAS、Fencing | `FIO_` |
| `STATE_BASELINE` | State、Pointer、Baseline | `BASELINE_`／`STATE_` |
| `REPORT` | Report生成、公開 | `REPORT_` |
| `SECURITY` | Path、Secret、権限、Integrity | `SECURITY_` |
| `CANCELLATION` | Cancel、Interrupt、Shutdown | `CANCEL_` |
| `UNEXPECTED` | 未分類Runtime異常 | `UNEXPECTED_` |

HTTP 4xx／5xx Responseは常にPlatform Exceptionとは限らない。API設計がResponseとして期待・評価可能と定義する場合は、ResponseをEvidence化してVerificationへ渡す。

## 17. Failure Record

### 17.1 構造

| Field | 必須 | 内容 |
|---|:---:|---|
| `failureId` | Yes | 一意ID |
| `failureCode` | Yes | Platform Error／Failure Code |
| `category` | Yes | Failure Taxonomy |
| `phase` | Yes | 発生Phase |
| `componentId` | Yes | 発生Component |
| `ownerExecutionId` | 条件付 | 発生実行 |
| `apiDispatchState` | API時 | 送信状態 |
| `retryEligibility` | Yes | Retry判定 |
| `stopScope` | Yes | 停止範囲 |
| `axisImpact` | Yes | 四軸への提案影響 |
| `reasonCodes` | Yes | Resultへ引き渡すReason |
| `safeMessageKey` | Yes | 人向けMessage Key |
| `safeParameters` | No | Allowlist済みParameter |
| `causeFingerprint` | No | 安全な原因Fingerprint |
| `evidenceRefs` | No | 安全なArtifact Reference |
| `occurredAt` | Yes | 発生時刻 |

Failure RecordはThrowable Serializeではない。Java Class名、Stack TraceおよびRaw Messageを契約必須項目にしない。

### 17.2 Axis Impact

`axisImpact`はFailure Policy Resolverの入力・出力記録であり、Result Finalizerが正本Resultへ反映する。Log Writerが四軸を変更してはならない。

## 18. 四結果軸へのMapping

| Failure | Execution | Verification | Change | Recovery |
|---|---|---|---|---|
| Preflight Definition／Config Error | `REJECTED` | `NOT_EVALUATED` | `NOT_COMPARED` | 原則`NOT_REQUIRED` |
| Request Build失敗、未送信 | `INCOMPLETE` | 対象Check `NOT_EVALUATED` | 対象Call `NOT_COMPARED` | 条件付き |
| 期待可能なHTTP Error Response受信 | 完全性に従う | API／Expected契約で評価 | Responseがあれば比較可 | 通常`NOT_REQUIRED` |
| 参照API Timeout、送信済み | `INCOMPLETE` | 未取得対象`NOT_EVALUATED` | 未取得対象`NOT_COMPARED` | Policyに従う |
| 更新APIの送達／結果不明 | `UNKNOWN_OUTCOME` | 未確定対象`NOT_EVALUATED` | 未確定対象`NOT_COMPARED` | `REQUIRED` |
| Parse／Mapping失敗 | `INCOMPLETE` | 対象`NOT_EVALUATED` | 対象`NOT_COMPARED` | 条件付き |
| Check不一致 | 完全なら`COMPLETED` | `FAIL` | 独立判定 | 通常`NOT_REQUIRED` |
| Check実装Exception | `INCOMPLETE` | 対象`NOT_EVALUATED` | 既存値保持 | 条件付き |
| Evidence Publish失敗 | `INCOMPLETE`または元`UNKNOWN_OUTCOME`保持 | 確定値保持 | 確定値保持 | 条件付き |
| Baseline／State更新結果不明 | Source Run値を変更しない | Source値保持 | Source値保持 | `REQUIRED` |
| Report生成失敗 | Source Run値を変更しない | Source値保持 | Source値保持 | Source値保持 |
| Security／Integrity違反 | `REJECTED`または`INCOMPLETE` | 未確定対象`NOT_EVALUATED` | 未確定対象`NOT_COMPARED` | 条件付き`REQUIRED` |

一つの後続I/O Errorによって更新APIの`UNKNOWN_OUTCOME`を`INCOMPLETE`へ下げない。

## 19. Stop Scope

### 19.1 Enum

```text
CONTINUE
STOP_CURRENT_CHECK
STOP_CURRENT_CALL
STOP_CURRENT_SCENARIO
STOP_CURRENT_USECASE
STOP_RUN
STOP_PROCESS
```

### 19.2 決定規則

| 条件 | 最小Stop Scope |
|---|---|
| 独立Optional Check不一致 | `CONTINUE` |
| Check実装Exception | `STOP_CURRENT_CHECK`。必須性によりScenario停止 |
| Request Build失敗 | `STOP_CURRENT_CALL`。依存Callは`NOT_REACHED` |
| 必須Context欠失 | `STOP_CURRENT_SCENARIO` |
| 更新API `UNKNOWN_OUTCOME` | `STOP_CURRENT_SCENARIO`かつ後続副作用禁止 |
| Shared Credential／Environment破損 | `STOP_RUN` |
| Secret漏洩Risk／Root外Write Risk | `STOP_RUN`以上 |
| Process安全性不明 | `STOP_PROCESS` |

Stop ScopeとVerification Statusを混在させない。`STOP_CURRENT_SCENARIO`はVerification `FAIL`を意味しない。

## 20. API Dispatch State

Timeout／Cancel／Connection Errorを正しく判定するため、API Call Metaに次の送信状態を保持する。

| Dispatch State | 定義 |
|---|---|
| `NOT_DISPATCHED` | Network送信開始前 |
| `DISPATCH_STARTED` | Clientが送信処理を開始 |
| `POSSIBLY_DISPATCHED` | Provider到達有無を証明できない |
| `DISPATCH_CONFIRMED` | 送信完了またはProvider受理を確認 |
| `RESPONSE_HEADERS_RECEIVED` | Response Header受信 |
| `RESPONSE_BODY_RECEIVED` | 必要Body受信完了 |

Client LibraryのMethod戻り値だけでProviderの業務Commitを断定しない。

## 21. Timeout Model

### 21.1 Timeout種別

| Timeout | 範囲 | 主な判定 |
|---|---|---|
| `QUEUE_TIMEOUT` | 実行待機 | API未送信 |
| `CONNECT_TIMEOUT` | 接続確立 | Dispatch Stateで判断 |
| `TLS_TIMEOUT` | TLS確立 | 通常未送信だがAdapterが証明 |
| `WRITE_TIMEOUT` | Request送信 | 部分送信の可能性あり |
| `RESPONSE_HEADER_TIMEOUT` | Header待機 | Provider処理済み可能性あり |
| `RESPONSE_BODY_TIMEOUT` | Body受信 | Status／部分Bodyだけで成功推測禁止 |
| `TOTAL_DEADLINE_EXCEEDED` | Call全体 | 内部状態からOutcome判定 |
| `RUN_DEADLINE_EXCEEDED` | Run全体 | 新規副作用開始禁止 |

### 21.2 判定Matrix

| API Capability | Dispatch State | Execution | 自動Retry |
|---|---|---|:---:|
| 参照系 | `NOT_DISPATCHED` | `INCOMPLETE` | 明示Policy時のみ可 |
| 参照系 | `POSSIBLY_DISPATCHED`以上 | `INCOMPLETE` | IdempotencyとBudget確認時のみ |
| 更新系 | `NOT_DISPATCHED`を証明 | `INCOMPLETE` | 明示Policyと承認時のみ |
| 更新系 | `DISPATCH_STARTED`以上 | `UNKNOWN_OUTCOME` | No |
| 不明Capability | 任意 | 安全側判定 | No |

更新APIで送信状態が不明な場合、`NOT_DISPATCHED`と推測してはならない。

## 22. Retry

### 22.1 Eligibility

Retryを行うには次をすべて満たす。

1. Sealed PlanにRetry Policy ID、Version、Hashがある。
2. API Capabilityが参照系またはIdempotencyを証明する。
3. Failure CodeがRetry Allowlistにある。
4. Dispatch Stateが許可条件を満たす。
5. Retry Budget、Maximum AttemptおよびDeadline内である。
6. CancelまたはLock Lease喪失がない。
7. 同一Requestの再送が業務副作用を重複させない。
8. 直前AttemptのOutcomeが不明ではない。

一項でも不明なら自動Retryしない。

### 22.2 Attempt

各Attemptは新しい`attemptId`を持ち、次を記録する。

- Parent API Call Execution ID
- Attempt Number
- Failure Code
- Dispatch State
- Started／Finished At
- Backoff
- Retry Policy Ref
- Outcome

前AttemptのEvidence、FailureまたはLogを上書きしない。

### 22.3 Backoff

Backoff Algorithm、最大回数、Jitterおよび具体値はEnvironment／API設計で決定する。本書は固定回数を既定化しない。

## 23. CancellationとShutdown

| 発生点 | 処理 |
|---|---|
| API呼出前 | 新規副作用を開始せず安全停止 |
| Request Build中 | Resource解放後`INCOMPLETE` |
| 参照API呼出中 | Client能力でCancelし、Dispatch／Response状態を記録 |
| 更新API呼出中／直後 | 成否不明なら`UNKNOWN_OUTCOME + REQUIRED` |
| Artifact Write中 | Partial Objectを公開せず照合 |
| Run Publish中 | Create-Only DestinationとManifest Hashを照合 |
| Baseline／State CAS中 | Pointer／State Versionを再読込 |
| Report生成中 | Source Runを変更せずGenerationを破棄または再生成 |

Process Shutdown Hookの成功を完全なRecoveryとみなさない。強制終了後はPublished Stateから再構成する。

## 24. Recovery Trigger

| Trigger | Recovery要否 |
|---|---|
| 更新API `UNKNOWN_OUTCOME` | 必須 |
| Publication Outcome `UNKNOWN` | 必須 |
| Baseline Pointer／State CAS結果不明 | 必須 |
| Lock Lease喪失後にMutation結果不明 | 必須 |
| Security／Integrity違反 | 影響評価が必要 |
| Protected Evidenceが承認外で生成された疑い | 必須 |
| Report生成失敗のみ | 通常はReport再生成で対応 |
| Verification `FAIL`のみ | 原則Recovery不要 |
| Preflight `REJECTED`のみ | 原則設定／定義修正後に新規Run |

Recovery Statusは元Runの運用介入要否であり、業務値の期待一致を表さない。

## 25. Recovery Case

### 25.1 Identity

Recovery Caseは一意な`recoveryCaseId`を持ち、元Runの`runId`と分離する。

| Field | 必須 | 内容 |
|---|:---:|---|
| `recoveryCaseId` | Yes | Recovery作業Identity |
| `sourceRunId` | Yes | 元Run |
| `sourceResultId` | Yes | 元Result |
| `sourceFailureRefs` | Yes | Trigger Failure |
| `targetRefs` | Yes | API Call、Artifact、Pointer等 |
| `caseType` | Yes | `CONFIRM / RESTORE / COMPENSATE / REEXECUTE / CORRECT` |
| `status` | Yes | Case Lifecycle |
| `severity` | Yes | 運用重要度 |
| `ownerRole` | Yes | 責任Role。個人名固定禁止 |
| `openedAt` | Yes | Open時刻 |
| `actions` | Yes | Append Only Action参照 |
| `resolution` | 条件付 | 終了時の結論 |
| `auditRefs` | Yes | Audit Record参照 |

### 25.2 Case Lifecycle

```mermaid
stateDiagram-v2
    [*] --> OPEN
    OPEN --> ASSIGNED
    ASSIGNED --> IN_PROGRESS
    IN_PROGRESS --> WAITING_EXTERNAL
    WAITING_EXTERNAL --> IN_PROGRESS
    IN_PROGRESS --> RESOLVED
    IN_PROGRESS --> CLOSED_UNRESOLVED
    RESOLVED --> [*]
    CLOSED_UNRESOLVED --> [*]
```

Case Statusと四結果軸のRecovery Statusは一対一ではない。Caseが`RESOLVED`になった時点で、元Runに関連するRecovery Resultを別記録として確定するが、元Runの他軸は不変とする。

## 26. Recovery Handoff

### 26.1 Handoff Package

| 項目 | 内容 |
|---|---|
| 元Run／Execution Identity | 調査対象 |
| 四結果軸 | 元Result |
| Failure／Reason | 機械可読原因 |
| API Dispatch State | 送信状態 |
| API Capability | Read／Update、Idempotency |
| Evidence Ref | Mask済みPublished Artifact |
| Definition／Build Ref | 再現性 |
| State／Pointer Version | I/O照合 |
| Prohibited Actions | 自動再送禁止等 |
| Recommended Next Action | 確認、照合、承認、補償候補 |
| Owner Role | 対応責任 |

### 26.2 Handoff失敗

Recovery CaseまたはAuditを安全に生成できない場合、Runを正常終了扱いにしない。最小安全Event、外部Alert CandidateおよびBootstrap／Process監視へ引き渡し、失敗したHandoff自体を新たなFailureとして記録する。

## 27. Recovery Action

| Action Type | 説明 | 制約 |
|---|---|---|
| `CONFIRM_EXTERNAL_STATE` | Provider側結果確認 | 確認根拠を保持 |
| `VERIFY_PUBLISHED_STATE` | Run／Pointer／State照合 | Pinned Read＋Hash |
| `RESTORE_POINTER` | 承認済みGenerationへ復旧 | CAS＋Fencing＋Audit |
| `REGENERATE_REPORT` | Published RunからReport再生成 | 元Run不変 |
| `REEXECUTE_AS_NEW_RUN` | 新しい`runId`で再実行 | 元Run Relation必須 |
| `COMPENSATE` | 業務補償処理 | 業務Owner承認必須 |
| `CORRECT_METADATA` | 訂正Record追加 | 元Artifact上書き禁止 |
| `WAIVE_WITH_JUSTIFICATION` | 未解決Riskを承認 | Approver、期限、理由必須 |

通常Scenarioの途中から同じRunを暗黙再開しない。再開可能性を明示的に証明できない場合は新規Runまたは専用Recovery Actionとする。

## 28. Resolution

### 28.1 Resolution Outcome

```text
CONFIRMED_SUCCEEDED
CONFIRMED_FAILED
RESTORED
COMPENSATED
REEXECUTED
WAIVED
UNRESOLVED
```

### 28.2 不変条件

- `CONFIRMED_SUCCEEDED`でも元RunのExecution `UNKNOWN_OUTCOME`を`COMPLETED`へ書き換えない。
- 確認結果はRecovery RecordとCorrection／Follow-up Resultで表現する。
- 新規RunのResultを元RunへCopyしない。
- WaiverはFailureを消去せず、承認されたRisk受容として保持する。
- ResolutionにはActor Role、Evidence、時刻、理由およびAudit Refを必須とする。

## 29. Audit

### 29.1 Audit必須操作

| 操作 | 最小Audit項目 |
|---|---|
| 手動Run開始／取消 | Actor、Scope、理由、Request ID |
| PROD／更新API実行承認 | Actor、対象、期限、Approval Ref |
| Baseline候補承認／Pointer切替／Rollback | 前後Generation、Expected Version、Result |
| Execution State修復 | 前後Version、根拠 |
| Recovery Case作成／割当／Action／Resolution | Case、Actor、Evidence、理由 |
| Protected Evidence Access／Export／Delete | 対象、Approval、目的 |
| Report再生成 | Source Run、Generation |
| Retention／Archive／Delete | 対象、Policy、件数、Result |
| Config／Mask Profile／Retry Policy変更 | 前後Version／Hash |

### 29.2 Audit Record

Audit RecordはAppend Onlyとし、最低限次を持つ。

- `auditRecordId`
- `auditEventType`
- `actorType`
- `actorRef`
- `delegationRef`
- `action`
- `targetRefs`
- `decision`
- `justificationCode`
- `beforeVersionRef`
- `afterVersionRef`
- `occurredAt`
- `correlationIds`
- `integrityRef`

Credential実値、個人の不要属性またはPayload本文を含めない。

### 29.3 Audit Failure

重要Mutationの開始前にAudit必須記録を作成できない場合、Mutationを拒否する。Mutation結果が既に外部で成立した可能性がある後段Audit失敗では、結果を推測せずRecovery Caseを作成する。

## 30. Log／Audit／Recoveryの保存境界

### 30.1 Logical Sink

| Domain | Logical Port | 更新特性 |
|---|---|---|
| Diagnostic Event | `DiagnosticEventPort` | Append／Best Effort条件付き |
| Security Event | `SecurityEventPort` | Durable Append |
| Audit Record | `AuditPort` | Append Only／Integrity保護 |
| Recovery Case | `RecoveryCasePort` | Version付きState＋Append Only Action |
| Metric | `MetricPort` | 集約 |
| Trace | `TracePort` | Sampled |

物理File、Database、Object Storage、Log ServiceまたはTicket ServiceはEnvironment設計で選定する。

### 30.2 Frozen Runtime Tree

本書は凍結Runtime Treeへ次を追加しない。

- `runs/{runId}/logs/`
- `error.json`
- `error-snapshot.json`
- `recovery/`
- `audit.log`
- `bootstrap-error.log`

通常Evidenceへ安全なDiagnostic Artifactを連携する場合は、Snapshot／Evidence設計の拡張Artifact契約とManifest登録を満たす。任意Pathを先行追加しない。

## 31. Sink FailureとBackpressure

| Failure | 処理 |
|---|---|
| TRACE／DEBUG配送失敗 | Drop Countを安全に集約し、Run Resultは変更しない |
| INFO配送遅延 | Bounded Buffer内で処理。上限超過をEvent化 |
| ERROR Event配送失敗 | Secondary安全経路またはProcess監視へ通知 |
| Security Event配送失敗 | Security Failure、重要処理停止を検討 |
| Audit Append失敗 | 重要MutationをFail Closed |
| Recovery Case保存失敗 | Recovery `REQUIRED`を保持し、Handoff Failure通知 |
| Sink Outcome不明 | 重複許容Event IDで照合。Auditを無条件再送しない |

Application Threadを無制限にBlockせず、Buffer Overflow時に古いERROR／Auditを黙って破棄しない。

## 32. Stack TraceとCause Fingerprint

### 32.1 Stack Trace

Stack Traceは既定で通常Evidence／Reportへ出力しない。Environmentごとの許可があっても次を必須とする。

- Access制限
- Mask／Secret Scan
- Size／Depth上限
- Retention
- Export Audit
- Source Code／Path情報の安全性確認

### 32.2 Fingerprint

同一原因の集約には安全化した次の組合せを使用できる。

```text
failureCode
+ componentId
+ safeTopFrameIdentifier
+ buildRef
```

Exception Message、顧客値、URLまたはResponse本文をFingerprintへ含めない。

## 33. Metric

### 33.1 必須候補

- Run `COMPLETED / INCOMPLETE / REJECTED / UNKNOWN_OUTCOME`件数
- Verification `PASS / FAIL / NOT_EVALUATED`件数
- Change `CHANGED / UNCHANGED / NOT_COMPARED`件数
- Recovery `REQUIRED / IN_PROGRESS / RESOLVED`件数
- Failure Category／Code件数
- API Call Duration、Timeout、Attempt Count
- Artifact Publish、CAS、Read-back Failure
- Lock競合、Lease喪失、Fencing Reject
- Open Recovery Case数とAge
- Audit／Security Event配送失敗
- Dropped Diagnostic Event数

### 33.2 Label制約

`runId`、`customerId`、URL、Error Message等の高Cardinality／機密値をMetric Labelへ使用しない。詳細TraceはEventまたはArtifact Referenceで行う。

## 34. Alert Candidate

| 条件 | 最小Severity | 通知候補 |
|---|---|---|
| 更新API `UNKNOWN_OUTCOME` | `CRITICAL` | Runtime／Operation／API Owner |
| Secret検出／Mask失敗 | `CRITICAL` | Security／Runtime |
| Baseline／State結果不明 | `CRITICAL` | Runtime／Operation |
| Run `INCOMPLETE` | `ERROR` | Runtime／Verification |
| Preflight `REJECTED`連続 | `ERROR` | Definition／Environment Owner |
| Verification `FAIL` | Check Severityに従う | Business／Verification |
| Recovery Case期限超過 | `ERROR`以上 | Operation Owner |
| Audit Sink障害 | `CRITICAL` | Operation／Security |
| Report生成失敗 | `ERROR` | Report Owner |

通知配送成功を問題解決とみなさない。Recovery Caseまたは担当WorkflowのStatusを別途確認する。

## 35. SecurityとAccess

| Role | 許可 | 禁止 |
|---|---|---|
| Runtime Writer | Event送信、Run内Correlation | Audit改変、過去Event削除 |
| Diagnostic Reader | Mask済みLog閲覧 | Protected Evidence閲覧 |
| Security Analyst | Security Event調査 | Baseline変更 |
| Recovery Operator | Case Action実行 | 承認なし補償 |
| Approver | 承認／Waiver | Credential取得 |
| Auditor | Audit／Evidence Read | Runtime Mutation |

最低権限、Access Audit、Encryption at Rest／TransitおよびKey管理の具体方式はEnvironment設計で確定する。

## 36. Crash Recovery

### 36.1 Scan

Runtime起動時または専用Recovery Jobは次を検出候補とする。

- 終端EventのないRun
- `RUNNING`のままLease切れとなったExecution
- Publication Outcome `UNKNOWN`
- Current PointerとGenerationの不一致
- BaselineとExecution Stateの不一致
- Recovery `REQUIRED`だがCase ReferenceがないRun
- Recovery Caseが期限超過

### 36.2 規則

1. Process Memory、最後のLog行またはFile更新時刻だけで結果を決めない。
2. Published Manifest、Pointer Version、State Version、API MetaおよびAuditを照合する。
3. 自動修復は承認済みRunbookとCAS／Fencing条件がある操作に限定する。
4. External API Outcomeの推測やMutation再送をCrash Recoveryへ含めない。
5. 修復結果をAuditし、元Runを変更しない。

## 37. Java論理契約

```java
public interface ExceptionTranslator {
    FailureRecord translate(Throwable throwable, FailureContext context);
}

public interface FailurePolicyResolver {
    FailureDisposition resolve(FailureRecord failure, SealedExecutionPlan plan);
}

public interface DiagnosticEventPort {
    PublishReceipt publish(SafeDiagnosticEvent event);
}

public interface AuditPort {
    AuditReceipt append(AuditRecord record, ExpectedAuditState expected);
}

public interface RecoveryCasePort {
    RecoveryCase create(CreateRecoveryCase command);
    RecoveryCase appendAction(AppendRecoveryAction command, long expectedVersion);
    RecoveryCase resolve(ResolveRecoveryCase command, long expectedVersion);
}
```

Interfaceは論理契約例であり、Package、Framework Annotation、Logging LibraryまたはStorage製品を確定しない。

## 38. 主処理Flow

```mermaid
flowchart TD
    A["Failure発生"] --> B["Boundary Translation"]
    B --> C["Failure Record"]
    C --> D["Mask・Safe Event"]
    C --> E["Failure Policy"]
    E --> F["Four-Axis Result"]
    E --> G{"Recovery Required?"}
    G -- Yes --> H["Recovery Case"]
    G -- No --> I["通常終了処理"]
    F --> J["Evidence Publish"]
    H --> K["Audit・Handoff"]
```

Failure Event送信が失敗しても、Failure PolicyとResult FinalizeをLog Writerへ依存させない。

## 39. Validation

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `LER-V001` | Result、Log、Audit、Recovery Caseが別責務である。 | ERROR |
| `LER-V002` | Failure CodeとReason Codeが別Fieldである。 | ERROR |
| `LER-V003` | 全EventにEvent Type、Schema、Component、時刻がある。 | ERROR |
| `LER-V004` | Run開始後のEventが`runId`で追跡できる。 | ERROR |
| `LER-V005` | API Eventが`apiCallExecutionId`、`apiCallCode`、`attemptId`を区別する。 | ERROR |
| `LER-V006` | Secret、Token、Cookie、Body全文が通常Logにない。 | ERROR |
| `LER-V007` | Mask失敗時に未Mask DataへFallbackしない。 | ERROR |
| `LER-V008` | 更新APIの送信後Timeoutを自動Retryしない。 | ERROR |
| `LER-V009` | Dispatch State不明を未送信と推測しない。 | ERROR |
| `LER-V010` | `UNKNOWN_OUTCOME`で後続副作用を停止する。 | ERROR |
| `LER-V011` | Recoveryが元Run四軸を変更しない。 | ERROR |
| `LER-V012` | Recovery ActionがAppend OnlyでAudit可能である。 | ERROR |
| `LER-V013` | Audit必須MutationがAudit不可時にFail Closedする。 | ERROR |
| `LER-V014` | Log Sink障害時のDrop／停止条件が明示される。 | ERROR |
| `LER-V015` | 凍結Runtime Treeへ未承認Pathを追加していない。 | ERROR |
| `LER-V016` | Metric Labelに高Cardinality機密値がない。 | ERROR |
| `LER-V017` | Stack TraceにAccess、Mask、Size、Retention統制がある。 | ERROR |
| `LER-V018` | Crash RecoveryがLog時刻順や推測に依存しない。 | ERROR |

## 40. Test観点

| Test ID | Scenario | 期待結果 |
|---|---|---|
| `LER-T001` | Preflight Schema Error | `REJECTED / NOT_EVALUATED / NOT_COMPARED` |
| `LER-T002` | Request Build失敗、未送信 | `INCOMPLETE`、Retryなし |
| `LER-T003` | 参照API Connect Timeout | Dispatch Stateに基づきRetry Eligibility判定 |
| `LER-T004` | 更新API Response Header Timeout | `UNKNOWN_OUTCOME + REQUIRED`、自動Retryなし |
| `LER-T005` | CancellationとResponse受信が競合 | Published API MetaからOutcome判定 |
| `LER-T006` | Check実装Exception | `FAIL`へ丸めず`NOT_EVALUATED` |
| `LER-T007` | Mask処理Exception | Payload非出力、Security Failure |
| `LER-T008` | Audit Sink停止中のBaseline更新 | Mutation拒否 |
| `LER-T009` | Diagnostic Sink Buffer Overflow | Drop Count記録、Audit保持 |
| `LER-T010` | Recovery Case二重更新 | Expected Version不一致を拒否 |
| `LER-T011` | Recoveryで成功確認 | 元Run不変、Resolution追加 |
| `LER-T012` | Process強制終了後のScan | Manifest／Pointer／Stateから再構成 |
| `LER-T013` | Frozen Tree Path検査 | `logs/`、`error.json`、`recovery/`追加0件 |
| `LER-T014` | Exception MessageにToken混入 | Message非保存、Fingerprint安全 |
| `LER-T015` | Report再生成失敗 | 元Run四軸、Baseline、State不変 |

## 41. Open Issue

| Issue ID | 未確定事項 | 本書の暫定制約 | 確定先 |
|---|---|---|---|
| `LER-OI-001` | Logging／APM／Trace製品 | Provider Capability、Signal分離、Bounded Bufferを定義済み。製品を待つ。 | Operation／Infrastructure Review |
| `LER-OI-002` | Audit StoreとIntegrity方式 | Append Only、Access Audit、改変検知、Audit必須MutationのFail Closedを定義済み。製品を待つ。 | Security／Infrastructure Review |
| `LER-OI-003` | Recovery Case Store／Ticket連携 | 元Runと別Identity、Version付き更新、Adapter Capabilityを定義済み。製品を待つ。 | Operation／Infrastructure Review |
| `LER-OI-004` | Alert Route、SLA、Escalation | SeverityとOwner Roleだけを定義する。 | Operation |
| `LER-OI-005` | API別Timeout／Retry値 | Bounded HTTP Capability、無制限なし、更新API送信後Retry禁止。具体値を待つ。 | API設計／NFR Review |
| `LER-OI-006` | Cancellation能力 | Dispatch-aware Client Capabilityを必須とし、能力不足を成功とみなさない。製品を待つ。 | Runtime Review |
| `LER-OI-007` | Stack Trace保持範囲 | 通常Evidence／Reportへ出さず、Provider ProfileとRetention値を待つ。 | Security／Operation Review |
| `LER-OI-008` | Protected Evidenceの承認・暗号・Retention | Default禁止、別暗号Domain、Access Audit、Credential常時除去。製品と値を待つ。 | Security／Infrastructure／Operation Review |
| `LER-OI-009` | 自動修復Runbook | CAS／Fencingで安全な操作だけ候補とする。 | Operation |
| `LER-OI-010` | Recovery Case／Action／Audit Schemaを現行16 Schemaへ追加するか | 第9バッチ第2段階ではDefinition／Runtime／Batch／Reportを優先して完了。Recovery Store契約、Producer／Consumer、Migrationを分離してArchitecture Reviewする。 | `FW-OI-018`／Schema／Architecture Review |

## 42. Review Checklist

- [ ] Logが四結果軸の正本になっていない。
- [ ] Failure CodeとReason Codeを混在させていない。
- [ ] Verification `FAIL`とRuntime Exceptionを区別している。
- [ ] Dispatch Stateを取得せずTimeoutを分類していない。
- [ ] 更新APIの結果不明時に自動Retryしていない。
- [ ] Retry PolicyがSealed Plan、API CapabilityおよびBudgetを参照する。
- [ ] Cancel要求とCancel成立を区別している。
- [ ] Recovery Caseが元Runと別Identityである。
- [ ] Recovery Resolutionで元Runを書き換えていない。
- [ ] Audit必須操作とFail Closed条件が明示されている。
- [ ] Secret、Body、URL、Path、Stack TraceがAllowlist外である。
- [ ] Mask失敗時の安全な最小Eventが定義されている。
- [ ] Diagnostic Sink障害とAudit Sink障害の扱いが異なる。
- [ ] 凍結Runtime Treeへ新規Log／Recovery Pathを追加していない。
- [ ] 未決製品、Retention、SLAおよび物理Rootを固定していない。
- [ ] Recovery文書をNormative Referenceにしていない。

## 43. 下流設計への引渡し

### 43.1 `環境・Runtime構成設計書.md`

- Logging／Audit／Recovery Adapter選定
- HTTP ClientのTimeout／Cancellation能力
- Process、Container、SchedulerおよびShutdown
- Secret Provider、Encryption、Access Control
- Buffer、Size、Retention、Archive、Backup
- Metric／Trace／Alert基盤

### 43.2 第8バッチSchema

- Failure／Reason CodeのField分離確認
- API MetaのDispatch State／Attempt
- `UNKNOWN_OUTCOME`とRecovery `REQUIRED`
- Artifact ManifestのDiagnostic拡張可否
- Recovery Schema追加要否のArchitecture Review

### 43.3 Operation設計

- Recovery Owner、On-call、SLA、Escalation
- Provider確認、補償、WaiverのRunbook
- Protected Evidence Access
- Baseline／State修復承認
- Retention／Delete／Archive

## 44. 完了条件

本書の正文作成完了は、次を満たすことを意味する。

1. Signal、Failure、Timeout、Retry、Cancellation、AuditおよびRecovery責務が定義済みである。
2. 四結果軸と矛盾する独自`FAIL / ERROR / FATAL`総合Resultを導入していない。
3. 更新API `UNKNOWN_OUTCOME`の判定と自動Retry禁止が明示されている。
4. Recovery Caseが元Run不変条件を満たす。
5. 凍結Runtime Treeに未承認Pathを追加していない。
6. Downstream Open IssueがOwnerと決定先を持つ。

これは正式Review、Decision Approval、Java実装、運用試験または文書Freezeの完了を意味しない。

## 45. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-28 | 四結果軸、Failure／Reason Code分離、Dispatch State、Timeout／Retry／Cancellation、Audit、Immutable Recovery Caseおよび凍結Runtime Tree境界に基づき新規作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-28 | Environment／Runtime設計に合わせ、Provider Capability、Secret／Certificate、Process Lifecycle、Health、Retention、BackupおよびAdapter選定境界を同期 | DRAFT |
| `1.0.0-draft.3` | 2026-07-28 | 第9バッチ第2段階の現行16 Schemaを反映し、Recovery Case／Action／Audit Schema判断を`FW-OI-018`へ明確に分離 | DRAFT |
