---
title: Scenario入力データ設計書
document_id: E6-API-VAL-SCN-INPUT-DESIGN
version: 1.0.0-draft.5
status: DRAFT
document_type: Runtime Input Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Scenario入力データ設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Scenario入力データ設計書 |
| 文書ID | `E6-API-VAL-SCN-INPUT-DESIGN` |
| 対象 | Scenario単位の`input.json` |
| 配置 | `system/04_usecase_design/` |
| 文書種別 | 実行入力共通設計書 |
| 版数 | `1.0.0-draft.5` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | Scenario Design Team |
| レビュー責任 | System Architect / Runtime Lead / Test Lead |

## 2. 目的

本書は、E6 API Verification PlatformにおいてScenario実行開始時に読み込む`input.json`の責務、論理構造、記述規則、Validation、Securityおよび関連成果物との境界を定義する。

`input.json`は、次の情報だけを提供する。

- 実行対象UseCase、Scenario、EnvironmentおよびInput Setの識別情報
- Scenario開始時に外部から与える共通入力値
- Scenario内の各API呼出に対して外部から与える初期値

`input.json`は、業務分岐、API呼出仕様、前段Responseから後段RequestへのMapping、Expected、Baselineまたは比較規則の正本ではない。

## 3. 適用範囲

本書は、`Scenario_Master.md`の`inputRef`から参照されるすべてのScenario Inputに適用する。

対象外は次のとおりである。

| 対象外情報 | 正式な管理先 |
|---|---|
| API呼出順序、分岐、Skip、停止条件 | Scenario詳細設計書およびJava Scenario Class |
| API Request／Response項目定義 | API詳細設計書、Request／Response DTO |
| 前段Responseから後段Requestへの値引継ぎ | Scenario詳細設計書およびJava実装 |
| Expected結果 | Scenario Expected |
| `resultKey`およびBusiness Check | Scenario詳細設計書、Java Check、Expected |
| `initialExecutionFlg`、`previousRunId` | `ExecutionState・Baseline管理設計書.md` |
| Baseline実体 | 固定Baseline領域 |
| Credential、Token、Password | Secret StoreまたはEnvironment設定 |
| Retry、Timeout、並列数 | Runtime設定および共通実行設計 |

## 4. 基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `IN-P001` | 初期値限定 | 実行開始前に外部から決定できる値だけを記載する。 |
| `IN-P002` | Java First | Request生成、値引継ぎ、分岐および業務判断はJavaが明示的に実装する。 |
| `IN-P003` | 1 Scenario 1基本Input | 原則として一つのScenarioに一つの基本Inputファイルを対応させる。 |
| `IN-P004` | 呼出実体識別 | API別初期値は`apiCallCode`で識別する。 |
| `IN-P005` | API定義参照 | API固定属性は`apiId`で参照し、Inputへ重複定義しない。 |
| `IN-P006` | Secret非保持 | Secret実値をInputへ保存しない。 |
| `IN-P007` | 推測禁止 | 欠落値を他のInput、前回Runまたはファイル名から推測しない。 |
| `IN-P008` | 決定性 | 同一Input、同一Environment前提および同一外部状態から同じ経路を再現できるようにする。 |
| `IN-P009` | 表示順と正本の分離 | `apis`配列順はScenario詳細設計との照合用であり、呼出順序の正本にしない。 |
| `IN-P010` | 変更追跡 | Input変更はGit差分および`inputSetId`で追跡可能にする。 |

## 5. 正本関係

```mermaid
flowchart TD
    M["Scenario Master<br/>inputRef"]
    D["Scenario詳細設計<br/>呼出・分岐"]
    I["input.json<br/>初期値"]
    J["Java Scenario Class<br/>Request生成"]
    C["ScenarioContext<br/>実行時データ"]

    M --> I
    D --> J
    I --> J
    J --> C
```

| 情報 | 正本 |
|---|---|
| `scenarioId`とInput Pathの関係 | Scenario Master |
| API呼出実体、`apiCallCode`、`callSequence` | Scenario詳細設計書 |
| 実行開始時の外部入力値 | `input.json` |
| 入力値をAPI Requestへ設定する処理 | Java Scenario Class |
| API Request／Response項目 | API詳細設計書およびDTO |
| 実行中のRequest／Response | ScenarioContextおよびRun成果物 |

`input.json`の`apis`とScenario詳細設計書が不一致の場合、Inputを根拠に呼出経路を変更してはならない。起動前Validation Errorとする。

## 6. Execution Identity

InputおよびBaselineの比較単位は次の複合Identityとする。

```text
environmentId
+
useCaseId
+
scenarioId
+
inputSetId
```

| 項目 | Scope | 説明 |
|---|---|---|
| `environmentId` | 全システム | Environment Masterで解決可能な実行環境 |
| `useCaseId` | 全システム | UseCase Masterで解決可能なUseCase |
| `scenarioId` | 全システム | Scenario Masterで解決可能なScenario |
| `inputSetId` | Scenario内 | 同一Scenarioで異なる初期値集合を区別するID |

異なる`inputSetId`のRunを同一Baselineとして比較してはならない。

## 7. ファイル命名

基本ファイル名はScenario Masterの`inputRef`に従う。

```text
system/04_usecase_design/input/{scenarioId}-input.json
```

例：

```text
system/04_usecase_design/examples/input/SC-E6-901-input_Example.json
```

同一Scenarioで複数Input Setを正式運用する場合の物理配置は、Repository Structureおよびファイル入出力設計で確定する。それまではファイル名を独自拡張せず、`inputSetId`で論理的に識別する。

## 8. JSON論理構造

### 8.1 全体構造

```json
{
  "schemaVersion": "1.0",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "environmentId": "ENV-STAGING",
  "inputSetId": "INPUT-001",
  "request": {},
  "apis": []
}
```

### 8.2 項目定義

| No. | JSON Path | 型 | 必須 | Null | 内容 |
|---:|---|---|:---:|:---:|---|
| 1 | `$.schemaVersion` | String | Yes | No | Input SchemaのMajor／Minor版 |
| 2 | `$.useCaseId` | String | Yes | No | 対象UseCase ID |
| 3 | `$.scenarioId` | String | Yes | No | 対象Scenario ID |
| 4 | `$.environmentId` | String | Yes | No | 対象Environment ID |
| 5 | `$.inputSetId` | String | Yes | No | Scenario内で一意なInput Set ID |
| 6 | `$.request` | Object | Yes | No | Scenario入口および複数APIで使用する共通初期値 |
| 7 | `$.apis` | Array | Yes | No | Scenario詳細設計に存在するAPI呼出実体別の初期値 |
| 8 | `$.apis[*].apiCallCode` | String | Yes | No | Scenario内のAPI呼出実体ID |
| 9 | `$.apis[*].apiId` | String | Yes | No | API Masterで解決可能なAPI ID |
| 10 | `$.apis[*].initialValues` | Object | Yes | No | 当該呼出に外部から与える初期値 |

追加プロパティは、Schema改訂を行わずに共通階層へ追加してはならない。業務固有値は`request`または`initialValues`配下へ配置する。

### 8.3 JSON Schema契約

Scenario Inputの機械可読契約は次を正本とする。

```text
system/06_verification_assets/common/schemas/scenario-input.schema.json
```

| 項目 | 契約 |
|---|---|
| JSON Schema Dialect | Draft 2020-12 |
| `$id` | `urn:e6-api-verification:schema:scenario-input:1.0` |
| Instance `schemaVersion` | `1.0` |
| Top Level | 未定義Propertyを拒否する。 |
| `apis[*]` | 未定義Propertyを拒否する。 |
| `request`／`initialValues` | Scenario固有の業務値を許可する。詳細はScenario詳細設計で定義する。 |
| Java関係 | JSON Schemaを永続JSONの機械契約とし、Java DTO／Loaderは同契約を緩和しない。業務処理は従来どおりJava Firstとする。 |

Schema Validationだけでは次を判定できないため、Definition Resolverまたは専用Semantic Validatorで検証する。

- `useCaseId`、`scenarioId`、`environmentId`および`apiId`のMaster存在確認
- `scenarioId`と`useCaseId`の親子関係
- `apiCallCode + apiId`とScenario詳細設計の一致
- `apiCallCode`のKey単位一意性
- `apis`配列順と`callSequence`の照合
- 業務固有値の型、桁数、形式および必須性
- Secret、分岐式、Mapping式、ExpectedおよびBaselineの混入検査

`uniqueItems: true`は完全一致した重複Objectを拒否するだけであり、異なる`initialValues`を持つ同一`apiCallCode`の重複を検出できない。したがって`IN-V009`をJSON Schemaだけで実装済みとみなしてはならない。

## 9. `request`設計

`request`はScenario入口値および複数のAPI呼出で共通利用する初期値を保持する。

例：

```json
{
  "request": {
    "memberId": "M000001",
    "businessDate": "2026-07-27",
    "operatorId": "USER001"
  }
}
```

### 9.1 記載してよい値

- Batch起動引数から確定する業務入力
- Test Dataから取得した業務キー
- 複数APIで利用する固定入力
- Scenario開始前に確定する基準日または処理区分

### 9.2 記載してはならない値

- API実行後に初めて得られるResponse値
- `runId`、開始時刻、終了時刻
- `previousRunId`、`initialExecutionFlg`
- Password、Access Token、Secret Key
- Expected結果
- 分岐条件式またはJava Method名
- Previous／Current値

`request`の業務項目はScenario詳細設計書で意味を定義する。API DTOの全項目を機械的に複製する必要はない。

## 10. `apis`設計

### 10.1 役割

`apis`は、Scenario詳細設計で確定したAPI呼出実体ごとに、外部から与える初期値を関連付ける。

```json
{
  "apis": [
    {
      "apiCallCode": "CALL-001",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "BEFORE_UPDATE"
      }
    },
    {
      "apiCallCode": "CALL-002",
      "apiId": "API-002",
      "initialValues": {
        "updateType": "NORMAL"
      }
    },
    {
      "apiCallCode": "CALL-003",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "AFTER_UPDATE"
      }
    }
  ]
}
```

同一`apiId`を複数回記載できるが、同一Scenario内の`apiCallCode`は重複してはならない。

### 10.2 配列順

`apis`はレビュー容易性のためScenario詳細設計の`callSequence`昇順で記載する。ただし、Runtimeは配列順だけを根拠にAPIを呼び出してはならない。

呼出順序、分岐、Skipおよび終了条件の正本はScenario詳細設計書とJava Scenario Classである。

### 10.3 `initialValues`

`initialValues`には、当該API呼出で外部指定が必要な値だけを記載する。

前段Responseから得る値は記載しない。

```text
CALL-001.response.memberId
    ↓ Javaが取得・型検証
CALL-002.request.memberId
```

値引継ぎを次のような式でInputへ記載してはならない。

```json
{
  "memberId": "${CALL-001.response.memberId}"
}
```

## 11. Request生成規則

Javaは、API Requestを次の情報から明示的に生成する。

```text
Scenario Input.request
+
Scenario Input.apis[apiCallCode].initialValues
+
先行ApiExchangeのResponse DTO
+
Javaで生成する実行値
```

優先順位を動的Mergeで解決してはならない。各Request Builderが、項目単位で設定元と優先順位をコードおよびScenario詳細設計に明示する。

例：

```java
MemberUpdateRequest request =
        new MemberUpdateRequest(
                context.input().requiredText("request.memberId"),
                context.response("CALL-001", MemberSearchResponse.class).memberStatus(),
                context.input().requiredText("apis.CALL-002.initialValues.updateType")
        );
```

API Request生成後は、送信直前のDTOとJSONを`ApiExchange`へ保存する。

## 12. 業務分岐の取扱い

Inputへ分岐定義を記載してはならない。

禁止例：

```json
{
  "branches": {
    "ACTIVE": "CALL-002",
    "SUSPENDED": "CALL-003"
  }
}
```

業務目的、通過経路または期待終了状態が異なる場合は、原則としてScenarioを分ける。

```text
SC-E6-001
    CALL-001 → CALL-002 → CALL-003

SC-E6-002
    CALL-001 → 更新対象なしで終了
```

同一Scenario内で条件呼出が不可避な場合も、条件はScenario詳細設計書とJavaに定義し、Inputは条件評価に必要な初期値だけを提供する。

## 13. 完整JSON例

次は構造説明用の例であり、現行E6 APIの確定Test Dataではない。

```json
{
  "schemaVersion": "1.0",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "environmentId": "ENV-STAGING",
  "inputSetId": "INPUT-001",
  "request": {
    "memberId": "M000001",
    "businessDate": "2026-07-27",
    "operatorId": "USER001"
  },
  "apis": [
    {
      "apiCallCode": "CALL-001",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "BEFORE_UPDATE"
      }
    },
    {
      "apiCallCode": "CALL-002",
      "apiId": "API-002",
      "initialValues": {
        "updateType": "NORMAL",
        "updateReason": "DAILY_VERIFICATION"
      }
    },
    {
      "apiCallCode": "CALL-003",
      "apiId": "API-001",
      "initialValues": {
        "searchType": "AFTER_UPDATE"
      }
    }
  ]
}
```

現行Masterでは`API-002.enabled=false`であるため、この例を実行可能データとして使用してはならない。`TRC-V008`解消前の`SC-E6-001`はRelease対象外である。

## 14. Load処理

起動前の処理順は次のとおりとする。

```mermaid
flowchart TD
    A["inputRef解決"]
    B["JSON読込"]
    C["Schema Validation"]
    D["Master・設計照合"]
    E["Secret検査"]
    F["Immutable Input生成"]
    G["ScenarioContextへ設定"]

    A --> B --> C --> D --> E --> F --> G
```

1. Scenario Masterから`inputRef`を解決する。
2. UTF-8のJSONとして読み込む。
3. JSON構文およびSchemaを検証する。
4. `useCaseId`、`scenarioId`および`environmentId`を各Masterと照合する。
5. `apiCallCode + apiId`をScenario詳細設計と照合する。
6. Secretらしき実値を検査する。
7. Input Objectを不変Objectとして生成する。
8. 新規ScenarioContextへ一度だけ設定する。

Runtime中にInput Objectを書き換えてはならない。

## 15. Validation

| Validation ID | 確認内容 | Level |
|---|---|---|
| `IN-V001` | JSONがUTF-8かつ構文上有効である。 | ERROR |
| `IN-V002` | 必須共通項目が存在し、Nullでない。 | ERROR |
| `IN-V003` | `schemaVersion`がRuntimeの対応版である。 | ERROR |
| `IN-V004` | `useCaseId`がUseCase Masterで解決できる。 | ERROR |
| `IN-V005` | `scenarioId`がScenario Masterで解決でき、`inputRef`と一致する。 | ERROR |
| `IN-V006` | `scenarioId`の親UseCaseが`useCaseId`と一致する。 | ERROR |
| `IN-V007` | `environmentId`がEnvironment Masterで解決できる。 | ERROR |
| `IN-V008` | `inputSetId`が同一Scenario内で一意である。 | ERROR |
| `IN-V009` | `apiCallCode`がScenario内で一意である。 | ERROR |
| `IN-V010` | `apiCallCode + apiId`がScenario詳細設計と一致する。 | ERROR |
| `IN-V011` | `apis`配列順が`callSequence`昇順と一致する。 | WARNING |
| `IN-V012` | 未定義API呼出または不足した必須API呼出がない。 | ERROR |
| `IN-V013` | 必須初期値が存在し、型・桁数・形式を満たす。 | ERROR |
| `IN-V014` | Secret実値が含まれていない。 | ERROR |
| `IN-V015` | 分岐、Mapping式、ExpectedまたはBaselineが混入していない。 | ERROR |
| `IN-V016` | 有効Scenarioの全参照先が起動前に解決できる。 | ERROR |

起動前Validation Error時はAPIを一件も呼び出さない。

## 16. Error

| Error Code | 条件 | 処理 |
|---|---|---|
| `INPUT_NOT_FOUND` | `inputRef`が存在しない | APIを呼ばずExecution `REJECTED`、Verification `NOT_EVALUATED` |
| `INPUT_PARSE_ERROR` | JSON構文不正 | APIを呼ばずExecution `REJECTED`、Verification `NOT_EVALUATED` |
| `INPUT_SCHEMA_ERROR` | Schema不一致 | APIを呼ばずExecution `REJECTED`、Verification `NOT_EVALUATED` |
| `INPUT_ID_MISMATCH` | MasterとIDが不一致 | APIを呼ばずExecution `REJECTED`、Verification `NOT_EVALUATED` |
| `INPUT_API_CALL_MISMATCH` | Scenario詳細設計とAPI呼出が不一致 | APIを呼ばずExecution `REJECTED`、Verification `NOT_EVALUATED` |
| `INPUT_REQUIRED_VALUE_MISSING` | 必須初期値欠落 | APIを呼ばずExecution `REJECTED`、Verification `NOT_EVALUATED` |
| `INPUT_SECRET_DETECTED` | Secret実値を検出 | 値をLogへ出さずExecution `REJECTED`、Verification `NOT_EVALUATED` |

## 17. Security

1. InputへCredential実値を保存しない。
2. SecretはEnvironment設定またはSecret Storeの参照名だけを扱う。
3. LogへInput全体を無条件出力しない。
4. 個人情報、会員情報等はMask規則を適用する。
5. Reportへ表示するInputはWhitelist方式で選択する。
6. InputのHashをRun Metadataへ保存し、実行時の改変を検出可能にする。
7. Input読込後にSecret解決値をInput Objectへ逆書きしない。

## 18. Versionおよび変更管理

| 変更 | 取扱い |
|---|---|
| 業務値だけの変更 | 同一構造のInput改訂。影響をレビューする。 |
| `inputSetId`の意味が変わる | 新しい`inputSetId`を採番する。 |
| 共通項目追加 | `schemaVersion`を改訂する。 |
| API呼出追加・削除 | Scenario詳細設計、Java、対応表と同一Change Setで更新する。 |
| `apiCallCode`変更 | 追跡性に影響するため原則新しい呼出実体として扱う。 |
| API項目名変更 | API詳細設計、DTO、Request BuilderおよびInput影響を確認する。 |
| Environment変更 | `environmentId`を変更し、Baseline Identityを分離する。 |

過去Runが参照したInputを上書きして再現性を失わせてはならない。`run-meta.json`内Definition SnapshotへInput Version、Content HashおよびSource Revisionを保持する。Input実体のRun内Copyを通常Runtime Artifactとして追加してはならない。

## 19. Test観点

- [ ] Scenario Masterの`inputRef`から解決できる。
- [ ] `useCaseId`、`scenarioId`、`environmentId`が各Masterと一致する。
- [ ] `inputSetId`がBaseline Identityに含まれる。
- [ ] 同一API複数回呼出を異なる`apiCallCode`で識別できる。
- [ ] API呼出順序の正本をInputへ移していない。
- [ ] 前段ResponseをInputへ重複記載していない。
- [ ] Request Mapping式をInputへ記載していない。
- [ ] 分岐条件、Expected、BaselineおよびPolicyが混入していない。
- [ ] Secret実値を含まない。
- [ ] Input Objectが実行中に変更されない。
- [ ] Schema不正時にAPI呼出前に停止する。
- [ ] Input Hashから使用版を追跡できる。

## 20. 未確定事項

| Issue ID | 論点 | 暫定方針 | 確定先 |
|---|---|---|---|
| `IN-ISSUE-001` | 複数Input Setの物理配置 | 基本は1 Scenario 1ファイルとし、`inputSetId`で論理識別する。 | Repository Structure／ファイル入出力設計 |
| `IN-ISSUE-002` | Input JSON Schemaの物理Path | `system/06_verification_assets/common/schemas/scenario-input.schema.json`へ配置済み。Schema本文はDRAFTであり正式Review待ち。 | Repository Structure／Schema Review |
| `IN-ISSUE-003` | Secret検査方式 | Key名と値Patternを組み合わせた起動前検査とする。 | Security／ログ・例外設計 |
| `IN-ISSUE-004` | `API-002`の利用可否 | 現在は無効のためSC-E6-001をRelease不可とする。 | API仕様／API Master |
| `IN-ISSUE-005` | `SC-E6-002`の不存在Test Data Reference | DRAFTの5必須ReferenceをNullとし、承認まで起動しない。 | Scenario詳細設計／Test Data |
| `IN-ISSUE-006` | `SC-E6-003`のTimeout Test／Recovery Reference | DRAFTの8必須ReferenceをNullとし、Timeout制御、状態確認およびCleanup承認まで起動しない。 | Scenario詳細設計／Test Data／Recovery |

## 21. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | Java First、`request + apis[]`、`apiCallCode`およびExecution Identityに基づく初版作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | SC-E6-002 Input DRAFT作成後のReference解決と、不存在Test Data未承認による起動Blockerを同期 | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | SC-E6-003 Input DRAFTのReference解決、8必須Null ReferenceおよびTimeout／Recovery未承認Blockerを同期 | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | Framework横断再走査によりInput異常時の起動拒否をExecution `REJECTED`、Verification `NOT_EVALUATED`およびReason Codeへ統一 | DRAFT |
| `1.0.0-draft.5` | 2026-07-28 | Draft 2020-12の`scenario-input.schema.json`、Schema／Semantic Validation境界、Schema Firstの永続JSON契約およびDefinition Snapshot追跡へ同期 | DRAFT |
