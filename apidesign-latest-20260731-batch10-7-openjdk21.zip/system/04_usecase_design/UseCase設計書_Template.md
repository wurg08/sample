---
title: UseCase設計書 Template
document_id: E6-API-VAL-USECASE-DESIGN-TEMPLATE
version: 2.0.0-draft.3
status: DRAFT
document_type: UseCase Detail Design Template
system_name: E6 API Verification Platform
updated: 2026-07-29
---

# UseCase設計書 Template

> 本Templateを複製し、`UC-{systemCode}-{NNN}設計書.md`として使用する。  
> `<>`内のPlaceholder、説明文および不要な記入例は、Review依頼前に置換または削除する。

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | `<UseCase正式名称> UseCase設計書` |
| 文書ID | `<E6-API-VAL-UC-E6-NNN-DESIGN>` |
| UseCase ID | `<UC-E6-NNN>` |
| 対象システム | `<E6>` |
| 文書種別 | UseCase詳細設計書 |
| 版数 | `<1.0.0-draft.1>` |
| 文書状態 | `<DRAFT / REVIEW / APPROVED / FROZEN>` |
| 最終更新日 | `<YYYY-MM-DD>` |
| 作成責任 | `<Author / Team>` |
| レビュー責任 | `<Business Owner / Scenario Design Lead / Runtime Lead>` |
| 承認責任 | `<System Owner>` |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更区分 | 作成者 | 承認状態 |
|---|---|---|---|---|---|
| `<1.0.0-draft.1>` | `<YYYY-MM-DD>` | `<初版作成>` | `<NEW>` | `<Name>` | `<DRAFT>` |

変更区分は`NEW`、`SCOPE_CHANGE`、`SCENARIO_CHANGE`、`DOCUMENT_ONLY`のいずれかとする。

## 3. 目的

本書は、`<UC-E6-NNN>`が検証する業務目的、業務範囲、Actor、Trigger、共通前提条件、業務Flow、Scenario Coverage、共通成立条件および関連成果物とのTraceabilityを定義する。

本書は次の問いに回答できなければならない。

1. このUseCaseは何の業務成立を検証するか。
2. 開始点と終了点はどこか。
3. 誰または何が開始し、どの外部Systemと関係するか。
4. 全Scenarioに共通する前提と業務不変条件は何か。
5. 正常、代替、異常、境界をどのScenarioで具体化するか。
6. どのBusiness、Environment、業務分析書およびReportへ追跡できるか。

## 4. 適用範囲

### 4.1 対象

- UseCaseの業務目的
- 業務上の開始点と終了点
- Primary／Supporting Actor
- Trigger
- 全Scenario共通の前提条件
- 業務Flow
- Scenario分類とCoverage
- UseCase共通の成立条件
- 業務データへの影響
- Environment適用条件
- TraceabilityとRelease判定

### 4.2 対象外

| 対象外 | 正式な定義・実装先 |
|---|---|
| Scenario内のAPI呼出順序、`apiCallCode` | Scenario詳細設計書 |
| API呼出分岐、Skip、停止条件 | Scenario詳細設計書、Java Scenario Class |
| 前段Responseから後続RequestへのMapping | Scenario詳細設計書、Java Scenario Class |
| Request／Response項目定義 | API詳細設計書、Java DTO |
| Scenario初期値 | Scenario Input JSON |
| `resultKey`、期待値、Check順序 | Scenario Expected、Java Check |
| Previous／Baseline選定 | Execution State・Baseline管理設計 |
| `IGNORE_FIELD`／`IGNORE_VALUE` | API／呼出別Java Compare Definition |
| Run結果、Diff明細、Report実体 | Runtime成果物 |
| Scheduler、実行日時、前回Run | 運用設計、RunContext |

## 5. 根拠資料

| Source ID | 資料名 | 種別 | Reference | 対象版 | 確認状態 |
|---|---|---|---|---|---|
| `<SRC-001>` | `<現行業務分析書>` | Business Analysis | `<business/...>` | `<version/date>` | `<CONFIRMED / OPEN>` |
| `<SRC-002>` | `<BA分析書×Scenario一覧>` | Scenario Analysis | `<business/...>` | `<version/date>` | `<CONFIRMED / OPEN>` |
| `<SRC-003>` | `UseCase_Master.md` | Master | `system/02_master/UseCase_Master.md` | `<version>` | `<CONFIRMED>` |
| `<SRC-004>` | `Scenario_Master.md` | Master | `system/02_master/Scenario_Master.md` | `<version>` | `<CONFIRMED>` |
| `<SRC-005>` | `<業務担当説明／会議Evidence>` | Evidence | `<reference>` | `<date>` | `<CONFIRMED / OPEN>` |

未確認情報を業務要件として確定せず、30章のOpen Issuesへ登録する。

## 6. UseCase Master整合

`UseCase_Master.md`の対象レコードを転記する。

| useCaseId | useCaseName | businessIds | businessPurpose | businessScope | preconditionSummary | applicableEnvironmentIds | scenarioIds | useCaseDesignRef | enabled |
|---|---|---|---|---|---|---|---|---|:---:|
| `<UC-E6-NNN>` | `<UseCase名称>` | `<BUS-E6-NNN>` | `<業務目的>` | `<業務範囲>` | `<共通前提>` | `<ENV-...>` | `<SC-E6-NNN>` | `system/04_usecase_design/UC-E6-<NNN>設計書.md` | `<true/false>` |

### 6.1 整合性判定

| 確認項目 | 判定 | Evidence／Issue |
|---|---|---|
| `useCaseId`とFile名が一致 | `<PASS / ERROR>` | `<reference>` |
| `businessIds`をBusiness Masterで解決 | `<PASS / ERROR>` | `<reference>` |
| `applicableEnvironmentIds`をEnvironment Masterで解決 | `<PASS / ERROR>` | `<reference>` |
| `scenarioIds`がScenario Masterの逆参照と一致 | `<PASS / ERROR>` | `<reference>` |
| `useCaseDesignRef`が本書を参照 | `<PASS / ERROR>` | `<reference>` |
| `enabled=true`の実行前提を満たす | `<PASS / BLOCKED / ERROR>` | `<reference>` |

## 7. UseCase概要

| 項目 | 内容 |
|---|---|
| UseCase ID | `<UC-E6-NNN>` |
| UseCase名称 | `<正式名称>` |
| Primary Business | `<BUS-E6-NNN>` |
| 業務目的 | `<何を確認し、どの状態が成立すればよいか>` |
| 開始点 | `<業務上の開始状態>` |
| 終了点 | `<業務上の完了状態>` |
| 主対象 | `<対象Entity／業務データ>` |
| 業務データ更新 | `<READ_ONLY / CREATE / UPDATE / DELETE / MIXED>` |
| 適用Environment | `<ENV-LOCAL / ENV-STAGING / ...>` |
| 有効状態 | `<enabled=true/false>` |

## 8. Businessとの関係

| businessId | Business名称 | 本UseCaseで扱う範囲 | Business Analysis Ref | 整合性 |
|---|---|---|---|---|
| `<BUS-E6-NNN>` | `<名称>` | `<対象範囲>` | `<business/...>` | `<PASS / BLOCKED>` |

複数Businessを設定する場合も、UseCaseの業務目的は一つでなければならない。独立した複数目的がある場合はUseCaseを分割する。

## 9. Actor

| Actor ID | Actor名 | 種別 | 責務 | 入力 | 受領結果 |
|---|---|---|---|---|---|
| `<ACT-001>` | `<Batch Scheduler>` | `<PRIMARY>` | `<UseCaseを起動する>` | `<実行指示>` | `<Batch結果>` |
| `<ACT-002>` | `<E6 System>` | `<SUPPORTING_SYSTEM>` | `<API処理を提供する>` | `<API Request>` | `<NONE>` |
| `<ACT-003>` | `<Approver>` | `<SECONDARY>` | `<Reportを確認する>` | `<Report>` | `<承認判断>` |

実際の個人名をActor Identityに使用しない。

## 10. Trigger

| Trigger ID | Trigger | 起点Actor | 条件 | UseCase Input | 対象Scenario |
|---|---|---|---|---|---|
| `<TRG-001>` | `<日次検証開始>` | `<Scheduler>` | `<実行Window内>` | `<Execution Identity>` | `<対象Scenario集合>` |

Scheduler時刻またはCron式は運用設計へ定義する。本書では業務上のTriggerだけを記載する。

## 11. 前提条件

### 11.1 共通前提

| Precondition ID | 前提条件 | 確認方法 | 未成立時 | Owner |
|---|---|---|---|---|
| `<PRE-001>` | `<対象Environmentが利用可能>` | `<Health Check>` | `<BLOCKED>` | `<Owner>` |
| `<PRE-002>` | `<Scenario Inputが承認済み>` | `<Reference Validation>` | `<BLOCKED>` | `<Owner>` |
| `<PRE-003>` | `<必要な業務データが存在>` | `<事前照会／準備Evidence>` | `<Scenarioに従う>` | `<Owner>` |

### 11.2 前提条件の責務

- 全Scenarioに共通する前提だけを本章へ記載する。
- Scenario固有の前提はScenario詳細設計へ記載する。
- 実行時に変化する値をUseCase Masterまたは本書へ固定しない。
- Credential実値を前提条件として記載しない。

## 12. 事後条件

| Postcondition ID | 終了区分 | 事後条件 | 確認主体 | Evidence |
|---|---|---|---|---|
| `<POST-001>` | `<SUCCESS>` | `<業務状態が想定どおり成立>` | `<Java Check>` | `<verification-result.json>` |
| `<POST-002>` | `<ALTERNATIVE>` | `<代替経路の業務状態で終了>` | `<Java Check>` | `<verification-result.json>` |
| `<POST-003>` | `<ERROR>` | `<後続を実行せず状態を記録>` | `<Scenario Runner>` | `<scenario-execution.json>` |

本章は業務上の事後状態を定義する。具体的な`resultKey`または期待値はExpectedへ記載する。

## 13. 業務範囲

### 13.1 In Scope

| Scope ID | 対象処理 | 開始 | 終了 | 備考 |
|---|---|---|---|---|
| `<SCP-IN-001>` | `<対象業務処理>` | `<開始点>` | `<終了点>` | `<備考>` |

### 13.2 Out of Scope

| Scope ID | 対象外処理 | 理由 | 関連UseCase／成果物 |
|---|---|---|---|
| `<SCP-OUT-001>` | `<対象外処理>` | `<理由>` | `<reference / NONE>` |

### 13.3 境界規則

1. 単一APIの実装範囲をUseCase範囲の代替にしない。
2. API呼出後に業務目的が未完了なら、UseCaseを途中で終了させない。
3. 別の独立業務目的まで含める場合は、UseCase分割を検討する。
4. Report生成やBaseline更新はUseCaseの業務範囲ではなく共通Runtime後処理である。

## 14. 業務Flow

### 14.1 標準業務Flow

```mermaid
flowchart TD
    A["業務開始"]
    B["対象状態確認"]
    C["業務処理"]
    D["結果状態確認"]
    E["業務終了"]

    A --> B
    B --> C
    C --> D
    D --> E
```

本Flowは業務活動を表す。API ID、`apiCallCode`、Java Method名またはJSON Pathを主語にしない。

### 14.2 業務Step

| Business Step ID | 業務活動 | Actor | 入力概要 | 出力概要 | 成立条件 | 関連Scenario |
|---|---|---|---|---|---|---|
| `<BS-001>` | `<対象状態を確認>` | `<Actor>` | `<業務入力>` | `<確認結果>` | `<業務条件>` | `<SC-E6-NNN>` |
| `<BS-002>` | `<業務処理を行う>` | `<Actor>` | `<業務入力>` | `<更新結果>` | `<業務条件>` | `<SC-E6-NNN>` |

Business Step IDを`apiCallCode`またはRuntime Identityとして使用しない。

## 15. 業務ルール／不変条件

UseCase全体で成立すべき業務要求を記載する。

| Rule ID | 業務ルール | 適用範囲 | 違反時の業務意味 | 具体化先 |
|---|---|---|---|---|
| `<BR-001>` | `<更新対象が一意である>` | `<全Scenario>` | `<業務不成立>` | `<Scenario Check>` |
| `<BR-002>` | `<更新前後で識別子が不変>` | `<更新Scenario>` | `<整合性不成立>` | `<Cross-API Check>` |

本章にJava式、JSONPath抽出式、`resultKey`または期待実値を記載しない。具体的な判定はScenario詳細設計、ExpectedおよびJavaへ展開する。

## 16. Scenario構成

### 16.1 Scenario一覧

| scenarioId | Scenario名称 | scenarioType | 開始条件 | 経路概要 | 期待終了状態 | enabled | 詳細設計Ref |
|---|---|---|---|---|---|:---:|---|
| `<SC-E6-NNN>` | `<名称>` | `<NORMAL>` | `<条件>` | `<業務経路概要>` | `<終了状態>` | `<true/false>` | `system/04_usecase_design/scenario/<SC-E6-NNN>設計書.md` |

本表の`scenarioId`集合は`UseCase_Master.scenarioIds`および`Scenario_Master.useCaseId`の逆参照と一致しなければならない。

### 16.2 Scenario種別

| Type | 意味 | 本UseCaseで必要か | 対象Scenario／理由 |
|---|---|:---:|---|
| `NORMAL` | 主正常経路 | `<Yes/No>` | `<SC-...>` |
| `ALTERNATIVE` | 業務上成立する代替経路 | `<Yes/No>` | `<SC-... / 理由>` |
| `BUSINESS_ERROR` | 業務エラー経路 | `<Yes/No>` | `<SC-... / 理由>` |
| `TECHNICAL_ERROR` | 技術エラー経路 | `<Yes/No>` | `<SC-... / 理由>` |
| `TIMEOUT` | Timeout／停止経路 | `<Yes/No>` | `<SC-... / 理由>` |
| `BOUNDARY` | 境界値経路 | `<Yes/No>` | `<SC-... / 理由>` |

実際の許可EnumはScenario Master設計書に従う。追加Typeを本Templateだけで新設しない。

## 17. Scenario分割判断

### 17.1 別Scenarioとする差異

- 開始条件が異なる。
- API呼出経路が異なる。
- 分岐またはSkipが異なる。
- 業務上の期待終了状態が異なる。
- Timeout／技術Error時の停止経路が異なる。

### 17.2 別Scenarioとしない差異

- 単一フィールドの必須、型、長さまたは固定値Check
- 同一経路での単なる入力データ違い
- Report表示順
- Environment名だけの違い
- Ignored Diff Pathだけの違い
- Java Method名だけの違い

同一経路の複数データPatternが必要な場合は、`inputSetId`またはTest Data設計で表現する。

## 18. Scenario Coverage

| Coverage ID | 観点 | 必要性 | 対象Scenario | 根拠 | 状態 |
|---|---|:---:|---|---|---|
| `<COV-001>` | 主正常経路 | Yes | `<SC-...>` | `<業務Flow>` | `<COVERED / OPEN>` |
| `<COV-002>` | 対象不存在 | `<Yes/No>` | `<SC-...>` | `<業務Rule>` | `<COVERED / N/A / OPEN>` |
| `<COV-003>` | Provider Timeout | `<Yes/No>` | `<SC-...>` | `<運用要求>` | `<COVERED / N/A / OPEN>` |
| `<COV-004>` | 境界データ | `<Yes/No>` | `<SC-...>` | `<API契約>` | `<COVERED / N/A / OPEN>` |

Scenario件数が多いこと自体をCoverage PASSの根拠にしない。

## 19. Environment適用

| environmentId | 用途 | UseCase適用 | 実行許可 | 必要Profile／Config | 未確認事項 |
|---|---|:---:|:---:|---|---|
| `<ENV-LOCAL>` | `<Local Verification>` | `<Yes>` | `<Yes/No>` | `<config ref>` | `<NONE>` |
| `<ENV-STAGING>` | `<Integration>` | `<Yes>` | `<Yes/No>` | `<config ref>` | `<NONE>` |
| `<ENV-PROD>` | `<Production>` | `<確認>` | `<No>` | `<config ref>` | `<本番実行承認>` |

### 19.1 Environment規則

1. UseCase Masterの`applicableEnvironmentIds`と一致させる。
2. `enabled=false`のEnvironmentを有効UseCaseが参照する場合はCross-Master `ERROR`とする。
3. EnvironmentごとのURL、IPまたはSecret実値を記載しない。
4. 本番環境で更新系UseCaseを実行する場合は、データ影響と承認手順を別途確認する。

## 20. 入出力概要

### 20.1 UseCase Input

| Input区分 | 内容 | 正本 | Scenario差異 |
|---|---|---|---|
| Execution Identity | Environment、UseCase、Scenario、Input Set | RunContext | Scenarioごと |
| 初期業務値 | `<会員番号等>` | Scenario Input | Scenario／Input Setごと |
| Environment設定 | 接続／認証Profile Reference | Environment設定 | Environmentごと |

### 20.2 UseCase Output

| Output区分 | 内容 | 保存先 |
|---|---|---|
| Execution結果 | API実行状態、Scenario状態 | `runs/{runId}/scenario-execution.json` |
| Verification結果 | Check Result | `runs/{runId}/verification-result.json` |
| Diff | API Call別Field Diff | `runs/{runId}/api-calls/{apiCallCode}/response-field-diff.json` |
| Report | Scenario Summary、Diff、Evidence | `runs/{runId}/reports/` |

UseCase設計書はこれらの結果を再判定しない。

## 21. データ状態・副作用

| Data ID | 対象Data | 操作 | 更新前状態 | 更新後状態 | Recovery要求 | Owner |
|---|---|---|---|---|---|---|
| `<DATA-001>` | `<Entity>` | `<READ/UPDATE>` | `<概要>` | `<概要>` | `<Rollback/Reset/NONE>` | `<Owner>` |

### 21.1 更新系UseCase

- 更新対象を一意に識別する。
- 他利用者または本番業務への影響を確認する。
- 再実行時の冪等性またはData Reset方法を明示する。
- Timeout後に結果不明となる場合の確認経路をScenario化する。
- Baseline更新と業務Data更新を同一概念として扱わない。

## 22. 共通Verification要求

UseCase全体として必要な確認目的を定義する。具体的なCheckはScenarioへ展開する。

| Verification Requirement ID | 業務確認目的 | 対象Scenario | 具体化先 | 完了判定 |
|---|---|---|---|---|
| `<UC-VR-001>` | `<業務状態が想定どおり遷移>` | `<SC-...>` | `<Scenario Check>` | `<ExpectedとJava結果>` |
| `<UC-VR-002>` | `<前後APIで識別子が一致>` | `<SC-...>` | `<Cross-API Check>` | `<ExpectedとJava結果>` |

### 22.1 判定軸

| 軸 | 例 | 意味 |
|---|---|---|
| Execution | `NOT_STARTED / RUNNING / COMPLETED / INCOMPLETE / REJECTED / UNKNOWN_OUTCOME` | 実行と必要Artifact生成の到達状態 |
| Verification | `NOT_EVALUATED / PASS / FAIL` | 業務・契約Check結果 |
| Change | `NOT_COMPARED / UNCHANGED / CHANGED` | Baselineとの差 |
| Recovery | `NOT_REQUIRED / REQUIRED / IN_PROGRESS / RESOLVED` | 復旧または結果確認の必要性と進行状態 |

四軸を一つのPASS／FAILへ潰さない。前提条件不成立、実装例外および外部障害はExecution／RecoveryとReason Codeへ保持し、Verificationへ`BLOCKED`または`ERROR`を追加しない。

## 23. Expectedとの関係

Expected実体はScenario単位で次に配置する。

```text
system/04_usecase_design/expected/{scenarioId}-expected.json
```

UseCase設計書は次を行わない。

- `resultKey`一覧の正本化
- Expected値の重複保持
- Java Check式の記載
- 別Scenario Expectedの流用
- Expected欠落時の推測

## 24. Baseline／Diffとの関係

1. BaselineはEnvironment＋UseCase＋Scenario＋Input Setで分離する。
2. UseCase設計書はPrevious Runを選定しない。
3. Diff IgnoreはBusiness Checkを免除しない。
4. `PASS + CHANGED`と`FAIL + UNCHANGED`はいずれも合法な結果である。
5. Business FAILでもRunが完全な場合にBaseline更新可能かはBaseline管理設計に従う。
6. API Error、解析失敗、中断または成果物不完全時はBaselineを更新しない。

## 25. Report要求

| 利用者 | 必要Report | 確認内容 | 再判定禁止 |
|---|---|---|:---:|
| Approver | Daily Summary | 全体結果、Blocker、差分 | Yes |
| Business Owner | Scenario Summary | 業務Check結果 | Yes |
| Developer | Diff Report | Effective／Ignored Diff | Yes |
| Auditor | Evidence Index | Artifact、Hash、Trace | Yes |

Reportは既存結果を集約し、UseCaseの業務判定またはBaselineを変更しない。

## 26. 非機能要求

| NFR ID | 観点 | 要求 | 検証方法 |
|---|---|---|---|
| `<NFR-001>` | 再現性 | Input、Expected、Build、Baselineを追跡できる。 | `<Evidence確認>` |
| `<NFR-002>` | 並行実行 | 異なるExecution Identityを分離する。 | `<Concurrency Test>` |
| `<NFR-003>` | 排他 | 同一Execution IdentityのBaseline更新を競合させない。 | `<Lock Test>` |
| `<NFR-004>` | Security | SecretとSensitive DataをMaskする。 | `<Security Review>` |
| `<NFR-005>` | 監査 | Run成果物のHashとReferenceを保持する。 | `<Manifest確認>` |

具体的なTimeout秒数、並列数またはRetention日数は共通設計／運用設計へ定義する。

## 27. Traceability

### 27.1 順方向

```text
Business Analysis
→ Business Master
→ UseCase Master
→ UseCase設計書
→ Scenario Master
→ Scenario詳細設計
→ Input／Expected／Java
→ Verification Result／Diff／Report
```

### 27.2 Trace一覧

| Trace種別 | ID／Reference | 整合性 | 備考 |
|---|---|---|---|
| Business | `<BUS-E6-NNN>` | `<PASS / BLOCKED>` | `<Business Analysis Ref>` |
| UseCase Master | `<UC-E6-NNN>` | `<PASS / ERROR>` | `<version>` |
| Scenario | `<SC-E6-NNN...>` | `<PASS / ERROR>` | `<Scenario Master>` |
| API関係 | `<対応表Ref>` | `<PASS / ERROR>` | API順序の正本ではない |
| Java Scenario | `<executionClass>` | `<BUILD PASS / OPEN>` | `<class>` |
| Input | `<inputRef>` | `<PASS / OPEN>` | `<scenarioId一致>` |
| Expected | `<expectedRef>` | `<PASS / OPEN>` | `<scenarioId一致>` |

## 28. Validation

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `UC-DES-V001` | File名、文書内`useCaseId`、UseCase Masterが一致する。 | ERROR |
| `UC-DES-V002` | Business ReferenceがBusiness Masterで解決できる。 | ERROR |
| `UC-DES-V003` | Environment ReferenceがEnvironment Masterで解決できる。 | ERROR |
| `UC-DES-V004` | Scenario集合が両Master間で一致する。 | ERROR |
| `UC-DES-V005` | 有効UseCaseに1件以上の有効Scenarioがある。 | ERROR |
| `UC-DES-V006` | 各Scenario詳細設計、Input、Expected、Java Classを解決できる。 | ERROR |
| `UC-DES-V007` | 業務目的、開始点、終了点および範囲が明確である。 | ERROR |
| `UC-DES-V008` | Scenario Coverageに根拠がある。 | ERROR |
| `UC-DES-V009` | API呼出順序、Mapping、Expected実値を重複保持しない。 | ERROR |
| `UC-DES-V010` | Execution／Verification／Change／Recovery判定を分離する。 | ERROR |
| `UC-DES-V011` | Secretまたは実個人情報を保持しない。 | ERROR |
| `UC-DES-V012` | 業務データ更新の影響とRecoveryが定義される。 | ERROR |

## 29. Review Checklist

### 29.1 業務

- [ ] 一つの独立した業務目的である。
- [ ] 開始点と終了点が明確である。
- [ ] In Scope／Out of Scopeが明確である。
- [ ] ActorとTriggerが業務的に説明できる。
- [ ] 全Scenario共通の前提だけを記載している。

### 29.2 Scenario

- [ ] 正常、代替、異常、Timeout、境界の要否を判断した。
- [ ] Scenario件数ではなく業務経路でCoverageを説明できる。
- [ ] UseCase MasterとScenario Masterの関係が一致する。
- [ ] 無効Scenarioを実行可能として扱っていない。

### 29.3 責務境界

- [ ] API呼出順序を本書の正本にしていない。
- [ ] `apiCallCode`、MappingまたはJava Methodを保持していない。
- [ ] Expected、`resultKey`またはDiff Ignoreを保持していない。
- [ ] Run状態またはBaselineを保持していない。

### 29.4 運用・安全

- [ ] 更新系業務のData影響を確認した。
- [ ] Environmentごとの実行許可を確認した。
- [ ] 再実行、Timeoutおよび結果不明時の考慮がある。
- [ ] Sensitive Dataを適切に扱っている。

## 30. Open Issues

| Issue ID | 確認事項 | 影響 | 確認元 | Owner | 期限 | 状態 |
|---|---|---|---|---|---|---|
| `<UC-DES-ISSUE-001>` | `<確認事項>` | `<影響>` | `<Source>` | `<Owner>` | `<YYYY-MM-DD>` | `<OPEN>` |

## 31. Release Blocker

| Block ID | 内容 | 解除条件 | Owner | 状態 |
|---|---|---|---|---|
| `<UC-DES-BLOCK-001>` | `<未解決Reference／業務判断>` | `<解除条件>` | `<Owner>` | `<OPEN>` |

Blockerを文章上の注意事項だけに置き換えず、Release Gateで機械的に判定可能な状態を保持する。

## 32. 完了条件

1. Business AnalysisとBA分析書×Scenario一覧を参照できる。
2. UseCase Masterの正式10項目と本書が一致する。
3. Business／Environment／Scenario Referenceが解決可能である。
4. 業務目的、範囲、Actor、Trigger、前提、事後条件が承認されている。
5. Scenario Coverageが業務根拠に基づき説明されている。
6. 更新系の場合、Data影響、再実行およびRecoveryが定義されている。
7. `UC-DES-V001～V012`の`ERROR`が0件である。
8. Open IssueにOwner、期限およびRelease影響がある。

## 33. 禁止事項

1. 単一APIまたは単一Field CheckをUseCaseとして登録する。
2. API呼出順序、`apiCallCode`、Skip条件を本書へ定義する。
3. 前後API値Mappingを文章だけで実装の代替にする。
4. Expected、`resultKey`、ActualまたはBaselineを保存する。
5. Context／Verification／Verification Policy／Compare Policy Masterを参照する。
6. Ignored Diffを理由にBusiness Checkを自動PASSにする。
7. 有効UseCaseから無効Environmentまたは無効API関係を隠す。
8. 未確認業務条件を推測で確定する。
9. 実個人名、Secret、Credentialまたは実顧客データを記載する。

## 34. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 最新5 Master、Java First、Scenario／Input／Expected／Baseline／Diff／Report責務分離に基づき全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | Framework横断再走査により四結果軸、Canonical Status、Reason Code責務および合法組合せ例へ統一 | DRAFT |
| `2.0.0-draft.3` | 2026-07-29 | `ENV-PROD`を本番として明示し、Production-like環境区分をTemplateから削除。本番更新系UseCaseの安全Gateを維持 | DRAFT |
