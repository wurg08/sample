---
title: 注文状態変更検証UseCase設計書（Example）
document_id: EX-UC-E6-901-DESIGN
version: 1.0.0-draft.6
status: DRAFT
document_type: UseCase Detail Design Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 注文状態変更検証UseCase設計書（Example）

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 注文状態変更検証UseCase設計書（Example） |
| 文書ID | `EX-UC-E6-901-DESIGN` |
| UseCase ID | `UC-E6-901` |
| Business ID | `BUS-E6-901` |
| 文書種別 | UseCase詳細設計書記入例 |
| 版数 | `1.0.0-draft.6` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Example UseCase Design Team |
| レビュー責任 | Business Owner / Verification Lead / Operations Owner |
| 承認責任 | Example System Owner |

本書の注文業務、Business、Environment、Scenario、APIおよびJava Classはすべて架空である。正式E6業務またはRuntimeへ転記してはならない。

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更区分 | 承認状態 |
|---|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | UseCase設計書Templateに基づく900番台記入例を新規作成 | NEW | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | Environment ID整合とAPI-902、SC-E6-901 Input／Expectedの作成状態を反映 | UPDATE | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | SC-E6-902詳細設計、Input、Expectedの作成状態およびAlternative経路の呼出境界を反映 | UPDATE | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | SC-E6-903詳細設計、Input、Expected、Timeout停止、Baseline保護およびRecovery引渡しを反映 | UPDATE | DRAFT |
| `1.0.0-draft.5` | 2026-07-27 | Framework横断ReviewによりUseCase成果物と完了条件を四結果軸へ統一 | UPDATE | DRAFT |
| `1.0.0-draft.6` | 2026-07-27 | 横断再走査により判定軸のCanonical Enum、RecoveryおよびReason Code責務へ統一 | UPDATE | DRAFT |

## 3. 目的

本書は、注文状態の変更前後を確認し、業務上許可された状態遷移が成立することを検証する架空UseCaseについて、業務境界、Scenario分割、Environment適用、共通Verification、Data安全性およびTraceabilityの記入例を示す。

UseCaseはAPI呼出手順そのものではない。本書は「何を業務として確認するか」を定義し、具体的な呼出順序、Mapping、Expected値およびDiff規則はScenarioまたはAPI設計へ委譲する。

## 4. 適用範囲

### 4.1 対象

- 注文状態変更の業務目的と検証範囲
- 更新対象、開始状態および目標状態に関する共通前提
- 正常、対象不存在およびTimeoutのScenario構成
- `ENV-EXAMPLE-LOCAL`および`ENV-EXAMPLE-STAGING`への適用例
- 共通Verification要求
- 更新Data、排他、Cleanupおよび再実行の安全境界
- BusinessからScenario、Expected、EvidenceまでのTrace

### 4.2 対象外

| 対象外 | 正式な定義先 |
|---|---|
| API Method、Path、Request／Response Field | API詳細設計 |
| API呼出順序、条件分岐、Skip、Mapping | Scenario詳細設計 |
| 注文ID、状態値等の具体的Input | Scenario Input |
| Result Key別Expected値 | Scenario Expected |
| Java Checkの実装 | Scenario Class／Check Registry |
| Environment接続値、Credential | Environment設定／Secret Provider |
| Runtime Artifact形式 | Run Context／Report設計 |

## 5. 根拠資料

| Source ID | 資料名 | Reference | 確認状態 |
|---|---|---|---|
| UC901-SRC-001 | Business Master記入例 | `system/02_master/examples/Business_Master_Example.md` | CONFIRMED |
| UC901-SRC-002 | Environment Master記入例 | `system/02_master/examples/Environment_Master_Example.md` | CONFIRMED |
| UC901-SRC-003 | UseCase Master記入例 | `system/02_master/examples/UseCase_Master_Example.md` | CONFIRMED |
| UC901-SRC-004 | Scenario Master記入例 | `system/02_master/examples/Scenario_Master_Example.md` | CONFIRMED |
| UC901-SRC-005 | 対応表記入例 | `system/02_master/examples/API_UseCase_Scenario対応表_Example.md` | CONFIRMED |
| UC901-SRC-006 | UseCase設計書Template | `system/04_usecase_design/UseCase設計書_Template.md` | CONFIRMED |
| UC901-SRC-007 | 架空業務分析書 | `business/examples/注文状態管理_現行業務分析書_Example.md` | REFERENCE EXAMPLE |

## 6. UseCase Master整合

| useCaseId | useCaseName | businessIds | applicableEnvironmentIds | scenarioIds | enabled |
|---|---|---|---|---|:---:|
| UC-E6-901 | 注文状態変更検証 | BUS-E6-901 | ENV-EXAMPLE-LOCAL、ENV-EXAMPLE-STAGING | SC-E6-901、SC-E6-902、SC-E6-903 | true |

### 6.1 整合性判定

| Check | 判定 | 根拠 |
|---|:---:|---|
| UseCase ID | PASS | `UC-E6-901`で一致する。 |
| Business | PASS | Example Businessで解決する。 |
| Environment | PASS | Example上の論理IDで解決する。 |
| Scenario集合 | PASS | 901～903の3経路が双方向一致する。 |
| Detail Reference | PASS | 本書Pathと一致する。 |
| Example分離 | PASS | 900番台かつ`examples/`配下である。 |

本整合はExample文書内の教育用整合であり、実行可能性を意味しない。

## 7. UseCase概要

| 項目 | 内容 |
|---|---|
| UseCase ID | `UC-E6-901` |
| UseCase名称 | 注文状態変更検証 |
| Business ID | `BUS-E6-901` |
| 業務目的 | 注文状態の変更前後を確認し、許可された状態遷移が成立することを検証する。 |
| 開始点 | 検証対象注文、開始状態、目標状態、権限および排他が準備された状態 |
| 完了点 | 正常、代替または異常経路の結果とEvidenceが確定した状態 |
| 主Actor | Verification Operator |
| 副Actor | Order API Provider、Business Reviewer |
| 更新有無 | あり |
| Example状態 | 文書記入例。Runtime実行禁止 |

## 8. Businessとの関係

| 項目 | 内容 |
|---|---|
| Business ID | `BUS-E6-901` |
| Business名称 | 注文状態管理業務 |
| 業務目的 | 注文状態を業務上許可された状態へ変更し、結果を確認可能にする。 |
| UseCaseの役割 | 上記業務の状態変更成立性をAPI経由で検証する。 |
| 対象外 | 注文取消、返金、出荷処理、決済処理 |

UseCaseの目的を「API-902を呼び出すこと」と定義してはならない。APIは業務目的を検証する手段である。

## 9. Actor

| Actor | 種別 | 責務 |
|---|---|---|
| Verification Operator | Primary | 承認済みExecution Planを起動する。 |
| Business Reviewer | Human | 状態遷移と業務結果を確認する。 |
| Order API Provider | External System | 注文照会および状態変更APIを提供する。 |
| Runtime Platform | System | Gate、Scenario、Check、Evidence、Reportを制御する。 |
| Operations Owner | Human | Environment利用、更新影響およびRecoveryを承認する。 |

## 10. Trigger

| Trigger ID | Trigger | 条件 |
|---|---|---|
| UC901-TRG-001 | 手動回帰検証 | 承認済みOperatorが対象Runを指定する。 |
| UC901-TRG-002 | 日次Execution Plan | 更新可能時間帯、Data予約、Environment許可が成立する。 |

Scheduleだけで更新系UseCaseを無条件起動してはならない。

## 11. 前提条件

### 11.1 共通前提

| Precondition ID | 条件 | 確認方法 | 未成立時 |
|---|---|---|---|
| UC901-PRE-001 | 対象EnvironmentがUseCase適用対象である。 | Environment Master／Runtime Gate | BLOCKED |
| UC901-PRE-002 | Test Dataが承認され、Run単位で予約される。 | Test Data Reference／Lease | BLOCKED |
| UC901-PRE-003 | 対象注文と開始状態を一意に確認できる。 | Input Reference／事前照会 | BLOCKED |
| UC901-PRE-004 | 目標状態が許可状態遷移に含まれる。 | Business Rule Reference | BLOCKED |
| UC901-PRE-005 | 利用者権限が照会・更新に必要なScopeを持つ。 | Authorization Check | BLOCKED |
| UC901-PRE-006 | RecoveryおよびCleanup手順が承認済みである。 | Procedure Reference | BLOCKED |
| UC901-PRE-007 | Java Class、Input、Expected、API契約を解決できる。 | Build Validation | ERROR |

### 11.2 前提条件の責務

具体的な`orderId`、開始状態値、目標状態値、Timeout秒数またはCredentialをUseCaseへ記載しない。これらはScenario Input、API契約またはEnvironment設定で管理する。

## 12. 事後条件

| Outcome | 事後条件 |
|---|---|
| 正常 | 更新後注文状態が期待遷移を満たし、Evidenceが保存される。 |
| 対象不存在 | 更新APIを呼び出さず、業務分類とEvidenceが保存される。 |
| Timeout | 更新結果を推測せず`UNKNOWN`とし、Recoveryへ引き渡す。 |
| Contract Error | 業務成功として扱わず、違反FieldとEvidenceを保存する。 |
| Gate不成立 | APIを一件も呼び出さず、Blockerを保存する。 |

## 13. 業務範囲

### 13.1 In Scope

- 更新前注文情報の確認
- 許可状態遷移の判定
- 注文状態更新
- 更新後注文情報の確認
- 正常／代替／Timeout経路の判定
- 検証結果およびEvidenceの作成

### 13.2 Out of Scope

- 決済、返金、出荷または在庫引当
- 注文の新規登録または削除
- Provider側業務ロジックの実装
- 未承認Production Dataの更新
- Timeout後の自動再送

### 13.3 境界規則

UseCaseは注文状態変更という一つの業務目的を保持する。正常、対象不存在およびTimeoutの違いはScenarioで表し、別UseCaseへ分割しない。

## 14. 業務Flow

### 14.1 標準業務Flow

```mermaid
flowchart TD
    A["対象・権限確認"]
    B["更新前状態確認"]
    C{"更新可能か"}
    D["状態変更"]
    E["更新後状態確認"]
    F["結果・Evidence確定"]
    X["代替／異常結果確定"]

    A --> B --> C
    C -->|Yes| D --> E --> F
    C -->|No| X
    D -->|Timeout／Error| X
```

### 14.2 業務Step

| Step | 業務処理 | 完了条件 | 実装責務 |
|---:|---|---|---|
| 10 | 対象と開始状態を確認する。 | 対象有無と開始状態が確定する。 | Scenario |
| 20 | 状態変更可否を判定する。 | 許可遷移または停止理由が確定する。 | Java Business Check |
| 30 | 状態を変更する。 | 成功、失敗または結果不明が確定する。 | Scenario／API Client |
| 40 | 更新後状態を確認する。 | 更新結果の業務判定が確定する。 | Scenario／Java Check |
| 50 | EvidenceとReportを確定する。 | 四結果軸を保存する。 | Runtime／Report |

## 15. 業務ルール／不変条件

| Rule ID | ルール |
|---|---|
| UC901-BR-001 | 対象注文はRun内で同一Identityを維持する。 |
| UC901-BR-002 | 開始状態から目標状態への遷移がBusiness Ruleで許可される。 |
| UC901-BR-003 | 更新後の注文Versionは更新前より増加する。 |
| UC901-BR-004 | 対象不存在時に更新APIを呼び出さない。 |
| UC901-BR-005 | 更新Timeout時に更新未実施と推測しない。 |
| UC901-BR-006 | 技術Errorを業務正常へ変換しない。 |
| UC901-BR-007 | Contract違反FieldをDiff Ignoreで免除しない。 |

## 16. Scenario構成

### 16.1 Scenario一覧

| scenarioId | 名称 | Type | 目的 | Example enabled |
|---|---|---|---|:---:|
| SC-E6-901 | 注文状態変更正常経路 | NORMAL | 取得、更新、再照会を正常完了する。 | true |
| SC-E6-902 | 変更対象注文不存在経路 | ALTERNATIVE | 対象不存在時に更新を行わない。 | false |
| SC-E6-903 | 注文状態変更Timeout経路 | TIMEOUT | Timeout後の停止とRecovery引渡しを確認する。 | false |

### 16.2 Scenario種別

| Type | 本UseCaseでの意味 |
|---|---|
| NORMAL | 許可された状態変更を行い、更新後状態を確認する。 |
| ALTERNATIVE | 更新対象が存在せず、更新を実行しない。 |
| TIMEOUT | 更新結果が不明となり、通常後続処理を停止する。 |

## 17. Scenario分割判断

### 17.1 別Scenarioとする差異

- 呼出集合または呼出順序が異なる。
- 停止条件またはSkip条件が異なる。
- Executionの終了状態が異なる。
- 業務結果分類またはRecovery責務が異なる。

### 17.2 別Scenarioとしない差異

- 同一路径でInput実値だけが異なる。
- Response Field Checkを追加する。
- Reportの表示順だけが異なる。
- Environmentだけが異なる。
- Baseline候補だけが異なる。

## 18. Scenario Coverage

| 業務観点 | SC-E6-901 | SC-E6-902 | SC-E6-903 |
|---|:---:|:---:|:---:|
| 対象存在 | Yes | No | Yes |
| 更新API実行 | Yes | No | Yes |
| 更新後照会 | Yes | No | No |
| 正常完了 | Yes | 候補 | No |
| 更新結果UNKNOWN | No | No | Yes |
| Recovery必要 | No | No | Yes |

SC-E6-902の最終業務分類はExampleとしての設計観点であり、正式E6業務判断を示さない。

## 19. Environment適用

| environmentId | 用途 | 更新許可 | 実行条件 |
|---|---|:---:|---|
| ENV-EXAMPLE-LOCAL | Mock／開発者検証 | Example設定に従う | Mock Dataを使用する。 |
| ENV-EXAMPLE-STAGING | 結合／日次回帰 | 承認時のみ | Data予約、時間帯、権限、Cleanup成立。 |

### 19.1 Environment規則

- Host、CredentialまたはSecretを本書へ記載しない。
- EnvironmentごとにUseCase IDを分割しない。
- Production相当Environmentは明示承認なしに追加しない。
- `enabled=true`をEnvironment利用許可の代替にしない。

## 20. 入出力概要

### 20.1 UseCase Input

| 論理Input | 目的 | 詳細 |
|---|---|---|
| Test Data Reference | 対象Data識別 | Scenario Input |
| Target Order Reference | 更新対象指定 | Scenario Input |
| Start State Reference | 開始状態確認 | Scenario Input／CALL-001 |
| Target State Reference | 目標状態指定 | Scenario Input |
| Environment ID | 接続Context | Execution Plan |
| Approval／Lease | 更新安全性 | Runtime Gate |

### 20.2 UseCase Output

| Output | 内容 |
|---|---|
| Execution Status | `NOT_STARTED`、`RUNNING`、`COMPLETED`、`INCOMPLETE`、`REJECTED`、`UNKNOWN_OUTCOME` |
| Verification Status | `NOT_EVALUATED`、`PASS`、`FAIL` |
| Change Status | `NOT_COMPARED`、`UNCHANGED`、`CHANGED` |
| Recovery Status | `NOT_REQUIRED`、`REQUIRED`、`IN_PROGRESS`、`RESOLVED` |
| API Call Evidence | Request／Response／Meta |
| Check Results | Result Key別判定 |
| Recovery Reference | Timeout等で必要な場合 |

## 21. データ状態・副作用

本UseCaseは更新系である。実行前後のData状態を明示し、Run失敗時も更新が発生している可能性を保持する。

### 21.1 更新系UseCase

| 制御 | 要求 |
|---|---|
| Data予約 | Run開始前に排他Leaseを取得する。 |
| 開始状態 | CALL-001とBusiness Checkで確認する。 |
| 更新許可 | Environment、時間帯、Operator、Target Stateを確認する。 |
| 再実行 | 前Runの更新結果とCleanupを確認後に新Runとして実行する。 |
| Cleanup | 更新結果確認後、承認済み手順だけを実行する。 |
| Timeout | 自動RetryせずRecoveryへ引き渡す。 |

## 22. 共通Verification要求

| Requirement ID | 要求 |
|---|---|
| UC901-VR-001 | 全API Responseが固定Contractを満たす。 |
| UC901-VR-002 | Request対象とResponse対象が一致する。 |
| UC901-VR-003 | 正常経路で状態遷移がBusiness Ruleを満たす。 |
| UC901-VR-004 | 正常経路で注文Versionが増加する。 |
| UC901-VR-005 | 対象不存在時に更新Callが0件である。 |
| UC901-VR-006 | Timeout時に自動Retryが0件である。 |
| UC901-VR-007 | Ignore対象FieldにもContract Checkを適用する。 |
| UC901-VR-008 | 全ResultにEvidence Referenceが存在する。 |

### 22.1 判定軸

| 軸 | 質問 | 例 |
|---|---|---|
| Execution | 実行と必要Artifact生成がどこまで到達したか。 | `COMPLETED`,`INCOMPLETE`,`REJECTED`,`UNKNOWN_OUTCOME` |
| Verification | 契約・業務期待を評価でき、満たしたか。 | `NOT_EVALUATED`,`PASS`,`FAIL` |
| Change | 比較対象に差異があるか。 | `CHANGED`,`UNCHANGED`,`NOT_COMPARED` |
| Recovery | 復旧または結果確認が必要か。 | `NOT_REQUIRED`,`REQUIRED`,`IN_PROGRESS`,`RESOLVED` |

四軸を一つの成功／失敗Booleanへ統合してはならない。前提不足または実装異常はReason CodeとExecution／Recoveryへ保持する。

## 23. Expectedとの関係

UseCaseは共通検証目的を定義し、Scenario Expectedは経路別`resultKey`と期待結果を定義する。UseCase設計書へ具体的な注文ID、状態値またはJSONPath別Expectedを複製しない。

| scenarioId | Expected Reference | 状態 |
|---|---|---|
| SC-E6-901 | `system/04_usecase_design/examples/expected/SC-E6-901-expected_Example.json` | 静的Example作成済み |
| SC-E6-902 | `system/04_usecase_design/examples/expected/SC-E6-902-expected_Example.json` | 静的Example作成済み |
| SC-E6-903 | `system/04_usecase_design/examples/expected/SC-E6-903-expected_Example.json` | 静的Example作成済み |

## 24. Baseline／Diffとの関係

- CALL単位のIdentityを`scenarioId + apiCallCode`とする。
- SC-E6-901のCALL-001とCALL-003を互いのBaselineにしない。
- 更新前後の業務比較は専用Java Checkで行う。
- API ResponseのPrevious／Baseline Diffと業務状態遷移Checkを分離する。
- `updatedAt`の`IGNORE_VALUE`はChange軸だけに適用する。

## 25. Report要求

| Report項目 | 要求 |
|---|---|
| UseCase／Scenario Identity | 必須 |
| Environment／Run ID | 必須 |
| Execution／Verification／Change／Recovery | 別項目で表示 |
| API Call一覧 | 順序、Status、Duration、Evidence |
| Business Check | Rule ID、Result、根拠 |
| Diff | CALL Identity別に表示 |
| Recovery | 必要時にOwnerとReferenceを表示 |

## 26. 非機能要求

| 分類 | 要求 |
|---|---|
| 再現性 | 同一版のInput、Expected、Master、Javaを追跡できる。 |
| 監査性 | Operator、承認、Environment、Data Leaseを追跡できる。 |
| 安全性 | 未承認更新、Secret出力、自動Retryを防止する。 |
| 可観測性 | CALL開始・終了・Skip・Timeoutを記録する。 |
| 独立性 | 並列Run間でContext、DataおよびEvidenceを共有しない。 |

## 27. Traceability

### 27.1 順方向

```text
BUS-E6-901
→ UC-E6-901
→ SC-E6-901／902／903
→ API Call
→ Expected／Java Check
→ Evidence
→ Report
```

### 27.2 Trace一覧

| Source | Target | 関係 |
|---|---|---|
| BUS-E6-901 | UC-E6-901 | 業務目的 |
| UC-E6-901 | SC-E6-901 | 正常経路 |
| UC-E6-901 | SC-E6-902 | 代替経路 |
| UC-E6-901 | SC-E6-903 | Timeout経路 |
| SC-E6-901 | API-901／902 | 呼出 |
| SC-E6-901 | Input／Expected | 実行資産 |
| SC-E6-902 | API-901／Input／Expected | Alternative経路 |
| SC-E6-903 | API-901／902／Input／Expected | Timeout経路 |

## 28. Validation

| Rule ID | 確認内容 | 期待 |
|---|---|---|
| UC901-V001 | Front Matterと文書情報が一致する。 | PASS |
| UC901-V002 | UseCase Master Exampleと固定項目が一致する。 | PASS |
| UC901-V003 | Scenario集合が双方向一致する。 | PASS |
| UC901-V004 | API Stepを業務目的としていない。 | PASS |
| UC901-V005 | 四結果軸を分離する。 | PASS |
| UC901-V006 | 更新安全性とTimeout境界を明示する。 | PASS |
| UC901-V007 | 900番台Exampleが正式Masterから分離される。 | PASS |

## 29. Review Checklist

### 29.1 業務

- [ ] 業務目的と開始・完了境界が明確である。
- [ ] API呼出自体を業務目的としていない。
- [ ] 許可状態遷移の正本責務が明確である。

### 29.2 Scenario

- [ ] 正常、代替、Timeoutの分割理由が明確である。
- [ ] Scenario一覧を実行順序として扱っていない。
- [ ] Scenario Masterと双方向一致する。

### 29.3 責務境界

- [ ] 具体的Input、Expected、MappingおよびDiffを重複定義していない。
- [ ] API固定契約をUseCaseへ複製していない。

### 29.4 運用・安全

- [ ] 更新Data、排他、再実行、CleanupおよびRecoveryを確認した。
- [ ] Environment許可とUseCase有効状態を分離した。

## 30. Open Issues

| Issue ID | 内容 | 影響 | Owner | 状態 |
|---|---|---|---|---|
| UC901-OI-001 | API-902詳細設計Exampleが未作成 | 正常・Timeout経路のAPI契約例が未完 | Example API Team | CLOSED |
| UC901-OI-002 | SC-E6-901 Input／Expected Exampleが未作成 | 実行資産の記入例が未完 | Example Scenario Team | CLOSED |
| UC901-OI-003 | SC-E6-902詳細設計／Input／Expected Exampleの作成 | Alternative経路の静的Exampleを補完 | Example Scenario Team | CLOSED |
| UC901-OI-004 | SC-E6-903詳細設計／Input／Expected Exampleの作成 | Timeout経路の静的Exampleを補完 | Example Scenario Team | CLOSED |

## 31. Release Blocker

本書はExampleであるため、内容が完全でも正式ReleaseまたはRuntime実行の対象外とする。`enabled=true`はExample Master上の関係説明に限る。

## 32. 完了条件

1. Business目的、Scope、前提、事後条件が一意である。
2. 3 Scenarioの分割理由とCoverageが説明できる。
3. 共通Verificationと四結果軸が定義される。
4. 更新Data安全性とRecovery境界が定義される。
5. Example値が正式MasterおよびRuntimeから分離される。

## 33. 禁止事項

- 本Exampleを正式業務要件として引用する。
- 900番台IDを正式Masterへ登録する。
- Scenario一覧を実行順序として使用する。
- 具体的なInputまたはExpectedをUseCaseへ埋め込む。
- EnvironmentのHostまたはCredentialを記載する。
- `enabled=true`だけで実行可能と判定する。
- Timeout時に自動Retryまたは自動Cleanupを行う。

## 34. 次工程

1. Java ExampleのSource RootとPackage構成を確定する。
2. SC-E6-901～903のScenario Class、BuilderおよびCheck Registryを実装する。
3. Timeout Harness、Recovery HandoffおよびEvidence Artifact Schemaを設計する。
4. 3 Scenarioの静的ReferenceとJava Registryを双方向照合する。
