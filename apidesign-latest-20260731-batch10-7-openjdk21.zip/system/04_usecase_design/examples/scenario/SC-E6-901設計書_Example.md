---
title: 注文状態変更正常経路Scenario設計書（Example）
document_id: EX-SC-E6-901-DESIGN
version: 1.0.0-draft.6
status: DRAFT
document_type: Scenario Detail Design Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 注文状態変更正常経路Scenario設計書（Example）

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 注文状態変更正常経路Scenario設計書（Example） |
| 文書ID | `EX-SC-E6-901-DESIGN` |
| Scenario ID | `SC-E6-901` |
| UseCase ID | `UC-E6-901` |
| 文書種別 | Scenario詳細設計書記入例 |
| 版数 | `1.0.0-draft.6` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Example Scenario Design Team |
| レビュー責任 | Business Owner / API Owner / Runtime Lead / Test Lead |
| 承認責任 | Example System Owner |

本書のScenario、注文、API、DTO、Java Class、Input、Expectedおよび業務値はすべて架空である。正式E6 ScenarioまたはRuntimeへ転記してはならない。

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更区分 | 承認状態 |
|---|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | 正常経路Scenarioの900番台記入例を新規作成 | NEW | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | API-902、Input、Expectedの作成状態と共通resultType整合を反映 | UPDATE | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | SC-E6-902資産作成後の次工程を同期 | UPDATE | DRAFT |
| `1.0.0-draft.4` | 2026-07-27 | SC-E6-903資産作成後の次工程をJava実装・Registry照合へ更新 | UPDATE | DRAFT |
| `1.0.0-draft.5` | 2026-07-27 | Framework横断Reviewにより分岐結果、集約および四結果軸をCanonical Statusへ統一 | UPDATE | DRAFT |
| `1.0.0-draft.6` | 2026-07-27 | 横断再走査によりError／Timeout処理をCanonical四結果軸とReason Codeへ統一 | UPDATE | DRAFT |

## 3. 目的

本書は、注文情報を取得し、許可された状態へ更新し、再照会によって状態遷移成立を確認する架空正常Scenarioについて、開始条件、API呼出順序、分岐、Mapping、Check、Diff、Evidence、Data安全性およびJava実装契約の記入例を示す。

本Scenarioは次の3呼出を一つの同期実行単位として扱う。

```text
CALL-001 → API-901：更新前注文情報取得
CALL-002 → API-902：注文状態更新
CALL-003 → API-901：更新後注文情報再取得
```

同じ`API-901`を2回使用しても、呼出Identity、Expected、EvidenceおよびDiffを共有しない。

## 4. 適用範囲

### 4.1 対象

- SC-E6-901の開始条件と終了条件
- CALL-001～003の順序、実行条件、Skipおよび停止
- Request生成とField Mappingの責務
- Input／Expected ReferenceおよびResult Key
- 更新前後のBusiness Check
- Execution／Verification／Change／Recoveryの四結果軸
- API Response Diffと業務状態遷移Checkの分離
- 更新Data、排他、再実行、CleanupおよびSecurity
- Java Scenario／Builder／CheckとのTrace

### 4.2 対象外

| 対象外 | 正式な定義先 |
|---|---|
| API固定Request／Response契約 | API-901／902詳細設計 |
| Environment別接続値 | Environment設定 |
| 注文ID、開始状態、目標状態の実値 | Scenario Input Example |
| Result Key別Expected実体 | Scenario Expected Example |
| API既定Diff | API詳細設計／Java Compare Definition |
| Runtime Artifact Schema | Run Context／File I/O設計 |
| Timeout経路 | SC-E6-903 Example |

## 5. 根拠資料

| Source ID | 資料名 | Reference | 確認状態 |
|---|---|---|---|
| SC901-SRC-001 | Scenario Master記入例 | `system/02_master/examples/Scenario_Master_Example.md` | CONFIRMED |
| SC901-SRC-002 | 対応表記入例 | `system/02_master/examples/API_UseCase_Scenario対応表_Example.md` | CONFIRMED |
| SC901-SRC-003 | UC-E6-901設計書Example | `system/04_usecase_design/examples/UC-E6-901設計書_Example.md` | CONFIRMED |
| SC901-SRC-004 | API-901設計書Example | `system/03_api_design/examples/API-901設計書_Example.md` | CONFIRMED |
| SC901-SRC-005 | API-902設計書Example | `system/03_api_design/examples/API-902設計書_Example.md` | CONFIRMED |
| SC901-SRC-006 | Input Example | `system/04_usecase_design/examples/input/SC-E6-901-input_Example.json` | CONFIRMED |
| SC901-SRC-007 | Expected Example | `system/04_usecase_design/examples/expected/SC-E6-901-expected_Example.json` | CONFIRMED |

## 6. Master整合

### 6.1 Scenario Master

| scenarioId | useCaseId | scenarioName | scenarioType | executionClass | enabled |
|---|---|---|---|---|:---:|
| SC-E6-901 | UC-E6-901 | 注文状態変更正常経路 | NORMAL | `com.example.e6.scenario.OrderStatusChangeScenario` | true |

### 6.2 API呼出関係

| callSequence | apiCallCode | apiId | 呼出目的 | Example relationStatus |
|---:|---|---|---|---|
| 10 | CALL-001 | API-901 | 変更前注文情報取得 | ACTIVE |
| 20 | CALL-002 | API-902 | 注文状態変更 | ACTIVE |
| 30 | CALL-003 | API-901 | 変更後注文情報再取得 | ACTIVE |

`ACTIVE`はExample表記上の関係説明であり、Runtime実行許可を意味しない。Input、ExpectedおよびAPI-902の静的Exampleは存在するが、Java、Environment実体、Test Data実体および承認Gateがないため、本Exampleは実行不可である。

## 7. Scenario概要

| 項目 | 内容 |
|---|---|
| Scenario ID | `SC-E6-901` |
| Scenario名称 | 注文状態変更正常経路 |
| Scenario Type | `NORMAL` |
| 親UseCase | `UC-E6-901` |
| 開始点 | 承認済み対象、開始状態、目標状態、Environmentおよび排他を解決した状態 |
| 終了点 | 更新後状態とBusiness Check、Diff、Evidenceを確定した状態 |
| 実行Class | `com.example.e6.scenario.OrderStatusChangeScenario` |
| 宣言API呼出数 | 3 |
| 正常時実行API呼出数 | 3 |
| 更新API呼出数 | 1 |
| Example実行可否 | `NOT_EXECUTABLE` |

## 8. 開始条件

### 8.1 業務前提

| Precondition ID | 条件 | 確認方法 | 未成立時 |
|---|---|---|---|
| SC901-PRE-001 | 対象注文が存在する。 | CALL-001 | Scenario停止 |
| SC901-PRE-002 | 開始状態がInputの期待開始状態と一致する。 | Java Business Check | Scenario停止 |
| SC901-PRE-003 | 開始状態から目標状態への遷移が許可される。 | Business Rule Reference | Scenario停止 |
| SC901-PRE-004 | Test Dataの排他Leaseが成立する。 | Runtime Gate | API未呼出 |
| SC901-PRE-005 | Environmentが更新を許可する。 | Environment／Approval | API未呼出 |
| SC901-PRE-006 | CleanupおよびRecovery手順を解決できる。 | Procedure Reference | API未呼出 |

### 8.2 起動前Validation Gate

| Gate ID | 条件 | Example判定 | 未成立時 |
|---|---|---|---|
| SC901-GATE-001 | Scenario、UseCase、APIが有効 | Example上PASS | API未呼出 |
| SC901-GATE-002 | Input／Expectedが存在しSchema適合 | STATIC PASS／Runtime BLOCKED | API未呼出 |
| SC901-GATE-003 | Execution Identityが一致 | STATIC PASS | API未呼出 |
| SC901-GATE-004 | Java Scenario、DTO、Client、Builderを解決 | BLOCKED | API未呼出 |
| SC901-GATE-005 | ExpectedとCheck Registryが双方向一致 | BLOCKED | API未呼出 |
| SC901-GATE-006 | Environment、Approval、Leaseが成立 | BLOCKED | API未呼出 |
| SC901-GATE-007 | Secret／Sensitive Data検査を通過 | BLOCKED | API未呼出 |

本ExampleはGate不成立であり、3 API Callを実行してはならない。

## 9. 正常Flow

```mermaid
flowchart TD
    A["起動前Gate"]
    B["CALL-001 更新前照会"]
    C["開始状態・遷移Check"]
    D["CALL-002 状態更新"]
    E["CALL-003 更新後照会"]
    F["更新前後Business Check"]
    G["結果・Evidence確定"]
    X["停止・非PASS記録"]

    A -->|PASS| B
    A -->|非PASS| X
    B -->|正常| C
    B -->|非正常| X
    C -->|PASS| D
    C -->|非PASS| X
    D -->|成功| E
    D -->|非成功| X
    E -->|正常| F --> G
    E -->|非正常| X
```

## 10. API呼出定義

| callSequence | apiCallCode | apiId | 実行条件 | 成功後 | 非成功時 |
|---:|---|---|---|---|---|
| 10 | CALL-001 | API-901 | 起動前Gateが全成立 | 状態・遷移Checkへ進む。 | CALL-002／003をSkipし終了 |
| 20 | CALL-002 | API-902 | CALL-001および事前CheckがPASS | CALL-003へ進む。 | CALL-003をSkipし終了 |
| 30 | CALL-003 | API-901 | CALL-002が更新成功かつ結果既知 | 更新前後Checkへ進む。 | Scenario終了 |

## 11. Step詳細

### 11.1 CALL-001：更新前注文情報取得

| 項目 | 内容 |
|---|---|
| API | `API-901` |
| Request Source | Inputの`targetOrderRef` |
| Response DTO | `OrderDetailResponse` |
| 成功条件 | HTTP 200、Contract PASS、対象一致 |
| Business Check | 開始状態一致、遷移許可、Version取得 |
| Evidence | Mask済Request／Response、Meta、Check Result |
| Diff Identity | `SC-E6-901 + CALL-001` |

### 11.2 CALL-002：注文状態更新

| 項目 | 内容 |
|---|---|
| API | `API-902` |
| Request Source | Inputの目標状態ReferenceおよびCALL-001のIdentity／Version |
| Request DTO | `OrderStatusUpdateRequest` |
| Response DTO | `OrderStatusUpdateResponse` |
| 成功条件 | 正式Success Status、Contract PASS、更新受付対象一致 |
| Retry | 自動Retry禁止 |
| Timeout | 更新結果`UNKNOWN`として停止し、CALL-003を通常実行しない。 |
| Diff Identity | `SC-E6-901 + CALL-002` |

### 11.3 CALL-003：更新後注文情報再取得

| 項目 | 内容 |
|---|---|
| API | `API-901` |
| Request Source | CALL-001と同一の承認済み対象Reference |
| 成功条件 | HTTP 200、Contract PASS、対象一致 |
| Business Check | 目標状態一致、Version増加、不変項目保持 |
| Evidence | Mask済Request／Response、Meta、Check Result |
| Diff Identity | `SC-E6-901 + CALL-003` |

CALL-003はRecovery照会ではない。CALL-002の結果が不明な場合は別Recovery責務へ引き渡す。

## 12. 分岐・Skip・停止

| Rule ID | 判定点 | 条件 | Action | Execution | Verification |
|---|---|---|---|---|---|
| SC901-BR-001 | 起動前 | Gate非成立 | 全CALL未実行 | REJECTED | NOT_EVALUATED |
| SC901-BR-002 | CALL-001 | 対象不存在 | CALL-002／003 Skip | COMPLETED候補 | Scenario契約に従う。 |
| SC901-BR-003 | 事前Check | 開始状態不一致／遷移不可 | CALL-002／003 Skip | COMPLETED候補 | FAIL |
| SC901-BR-004 | CALL-002 | Business Error | CALL-003 Skip | COMPLETEDまたはINCOMPLETEを契約で確定 | FAILまたはNOT_EVALUATED |
| SC901-BR-005 | CALL-002 | Timeout | 結果UNKNOWN、CALL-003 Skip、Recovery引渡し | UNKNOWN_OUTCOME | NOT_EVALUATED |
| SC901-BR-006 | CALL-003 | Contract／Business Error | 終了 | COMPLETEDまたはINCOMPLETE | FAILまたはNOT_EVALUATED |
| SC901-BR-007 | Runtime | 未定義CALLまたは順序違反 | 即時停止 | INCOMPLETE | NOT_EVALUATED |

## 13. Request生成・Mapping

### 13.1 基本原則

1. Inputの任意MapをRequest DTOへ動的Mergeしない。
2. Field単位でSource、Target、変換、NullおよびOwnerを定義する。
3. Candidate Field名を正式Fieldとして推測しない。
4. CALL-001 Response全体をCALL-002 Requestへコピーしない。
5. Business値とTimeout等のHarness制御値を混在させない。

### 13.2 論理Mapping契約

| Mapping ID | Source | Target | 変換 | Owner |
|---|---|---|---|---|
| SC901-MAP-001 | Input `targetOrderRef` | CALL-001 `orderId` | Reference解決 | OrderQueryRequestBuilder |
| SC901-MAP-002 | CALL-001 `orderId` | CALL-002 `orderId` | 同値 | OrderStatusUpdateRequestBuilder |
| SC901-MAP-003 | CALL-001 `orderVersion` | CALL-002 `expectedVersion` | Long同値 | OrderStatusUpdateRequestBuilder |
| SC901-MAP-004 | Input `targetStateRef` | CALL-002 `targetStatus` | Enum解決 | OrderStatusUpdateRequestBuilder |
| SC901-MAP-005 | Input `targetOrderRef` | CALL-003 `orderId` | Reference解決 | OrderQueryRequestBuilder |

正式JSON FieldはAPI-902 Example完成時に双方向照合する。

## 14. Scenario Input契約

| 項目 | 設計 |
|---|---|
| Reference | `system/04_usecase_design/examples/input/SC-E6-901-input_Example.json` |
| Identity | `ENV-EXAMPLE-STAGING + UC-E6-901 + SC-E6-901 + INPUT-SC-E6-901-EXAMPLE-001` |
| 現在の状態 | STATIC EXAMPLE CREATED |
| 実行可否 | 不可 |

### 14.1 必須論理入力

| Input Key | 目的 | 必須 | Null |
|---|---|:---:|:---:|
| `request.testDataId` | Test Data識別 | Yes | No |
| `request.dataSetVersion` | Data版識別 | Yes | No |
| `request.contentHash` | Data完全性 | Yes | No |
| `request.targetOrderRef` | 対象注文参照 | Yes | No |
| `request.expectedStartStateRef` | 開始状態参照 | Yes | No |
| `request.targetStateRef` | 目標状態参照 | Yes | No |
| `request.cleanupRef` | Cleanup手順参照 | Yes | No |

一つでも未解決ならRuntimeはAPIを呼び出してはならない。

### 14.2 API Call初期値

InputはCALL別初期値を持てるが、正式Request Field以外を含めない。CALL-002のVersion等、前段Responseから取得する値をInputで上書きしてはならない。

## 15. Expected／Check契約

| 項目 | 設計 |
|---|---|
| Reference | `system/04_usecase_design/examples/expected/SC-E6-901-expected_Example.json` |
| Identity | Inputと同一 |
| 現在の状態 | STATIC EXAMPLE CREATED |
| 実行可否 | 不可 |

### 15.1 必須Result Key

| 順序 | resultKey | resultType | apiCallCode | 期待 |
|---:|---|---|---|---|
| 10 | `CALL-001_RESPONSE_CONTRACT` | RESPONSE_CONTRACT | CALL-001 | PASS |
| 20 | `CALL-001_START_STATE` | BUSINESS_VALUE | CALL-001 | PASS |
| 30 | `CALL-002_REQUEST_CONTRACT` | INPUT_MATCH | CALL-002 | PASS |
| 40 | `CALL-002_RESPONSE_CONTRACT` | RESPONSE_CONTRACT | CALL-002 | PASS |
| 50 | `CALL-003_RESPONSE_CONTRACT` | RESPONSE_CONTRACT | CALL-003 | PASS |
| 60 | `SC901_TARGET_IDENTITY_UNCHANGED` | API_CHAIN_MATCH | なし | PASS |
| 70 | `SC901_STATUS_TRANSITION` | BUSINESS_TRANSITION | なし | PASS |
| 80 | `SC901_VERSION_INCREMENTED` | BUSINESS_TRANSITION | なし | PASS |
| 90 | `SC901_EVIDENCE_COMPLETENESS` | EVIDENCE_COMPLETENESS | なし | PASS |

### 15.2 Expected Value境界

具体的`orderId`、開始状態および目標状態はExpectedへ直書きせず、承認済みReferenceまたはInputとの相関で評価する。`HTTP 200`だけをScenario PASS条件にしてはならない。

## 16. Check実行・集約

### 16.1 実行規則

1. API固定Contract Checkを各CALLで実行する。
2. Contractが成立したResponseだけをBusiness Checkへ渡す。
3. CALL-001／003間の状態遷移は専用Java Checkで評価する。
4. Result Keyごとに判定、Evidence、Messageを保存する。
5. `IGNORE_VALUE` Fieldにも存在、型、NullおよびFormat Checkを行う。

### 16.2 集約優先順位

```text
FAIL > NOT_EVALUATED > PASS
```

Execution、Verification、ChangeおよびRecovery Statusは別々に集約する。

## 17. 四結果軸

| 軸 | 正常経路の期待 | 説明 |
|---|---|---|
| Execution | COMPLETED | 3 CALLとCheckが所定順序で完了する。 |
| Verification | PASS | 全Contract／Business／Evidence CheckがPASS。 |
| Change | UNCHANGEDまたはCHANGED | 各CALLのBaseline Diffを独立判定する。 |
| Recovery | NOT_REQUIRED | 正常経路では運用介入不要。 |

状態更新があってもAPI Response全体のChange Statusが必ず`CHANGED`になるとは限らない。業務状態遷移は専用Checkで確定する。

## 18. Response Diff

| Compare対象 | Identity | 目的 |
|---|---|---|
| CALL-001 vs CALL-001 Baseline | `SC-E6-901 + CALL-001` | 更新前照会の回帰差分 |
| CALL-002 vs CALL-002 Baseline | `SC-E6-901 + CALL-002` | 更新Responseの回帰差分 |
| CALL-003 vs CALL-003 Baseline | `SC-E6-901 + CALL-003` | 更新後照会の回帰差分 |
| CALL-001 vs CALL-003 | 専用Business Check | 状態、Version、不変項目の遷移確認 |

CALL-001をCALL-003のBaselineとして使用してはならない。

## 19. Error／Timeout処理

| 事象 | 自動Retry | CALL-003 | 更新結果 | 処理 |
|---|:---:|---|---|---|
| CALL-001 Timeout | なし | SKIPPED | 未更新 | Execution `INCOMPLETE`、Verification `NOT_EVALUATED` |
| CALL-002 Timeout | なし | SKIPPED | UNKNOWN | Execution `UNKNOWN_OUTCOME`、Recovery `REQUIRED` |
| CALL-002 Error Response | なし | 原則SKIPPED | 契約に従う。 | Expectedに従いVerification `PASS／FAIL`、必要ならExecution `INCOMPLETE` |
| CALL-003 Timeout | なし | TIMEOUT | 更新済み可能性あり | Execution `INCOMPLETE`、未評価Checkは`NOT_EVALUATED`、Recovery `REQUIRED` |
| Parse Error | なし | 後続停止 | 推測しない。 | Execution `INCOMPLETE`、Verification `NOT_EVALUATED` |
| Contract不一致 | なし | 設計に従う | 取得事実を保持 | Verification `FAIL`、ExecutionはArtifact完全性に従う |

## 20. 更新Data安全性

### 20.1 必須制御

| Control ID | 制御 |
|---|---|
| SC901-DATA-001 | 承認済みTest Dataだけを使用する。 |
| SC901-DATA-002 | Run開始前に対象Leaseを取得する。 |
| SC901-DATA-003 | 開始状態とVersionを更新直前に再確認する。 |
| SC901-DATA-004 | 更新RequestをEvidence化してから送信する。 |
| SC901-DATA-005 | Timeout後は結果UNKNOWNとしてDataを隔離する。 |
| SC901-DATA-006 | Cleanup前に更新結果を確認する。 |

### 20.2 再実行

同じRun IDを再利用しない。前Runの更新結果、Recovery、CleanupおよびData Leaseを確認後、新しいRun IDで実行する。

## 21. Cleanup

| 条件 | Cleanup |
|---|---|
| 正常完了 | 承認済み手順で開始状態へ戻すか、専用Dataを廃棄する。 |
| CALL-002 Timeout | 自動Cleanup禁止。Recovery後に判断する。 |
| CALL-003失敗 | 更新済み可能性を保持し、状態確認後に判断する。 |
| Gate不成立 | API未呼出のため業務Cleanup不要。Lease解放のみ検討する。 |

## 22. Security／Mask

| 対象 | 取扱い |
|---|---|
| Authorization | 保存しない。全Mask。 |
| Order ID | 承認済みMask規則を適用する。 |
| Customer ID | 末尾を除きMaskする。 |
| Request／Response | Mask後のArtifactだけをReportから参照する。 |
| Error Message | Secret／個人情報検査後に保存する。 |

## 23. Evidence

| Evidence | CALL-001 | CALL-002 | CALL-003 | Scenario |
|---|:---:|:---:|:---:|:---:|
| Request Meta | Yes | Yes | Yes | - |
| Response／Error | Yes | Yes | Yes | - |
| Contract Result | Yes | Yes | Yes | - |
| Business Result | 条件付き | 条件付き | 条件付き | Yes |
| Diff Result | Yes | Yes | Yes | Summary |
| Data Lease／Approval | - | - | - | Yes |
| Cleanup／Recovery | - | - | - | 条件付き |

## 24. Java実装契約

### 24.1 Class構成

| Class | Example FQCN | 責務 |
|---|---|---|
| Scenario | `com.example.e6.scenario.OrderStatusChangeScenario` | Flow制御 |
| Query Builder | `com.example.e6.scenario.order.OrderQueryRequestBuilder` | CALL-001／003 Request生成 |
| Update Builder | `com.example.e6.scenario.order.OrderStatusUpdateRequestBuilder` | CALL-002 Request生成 |
| Business Check | `com.example.e6.scenario.order.OrderStatusTransitionCheck` | 更新前後の状態遷移確認 |
| Evidence Check | `com.example.e6.scenario.common.EvidenceCompletenessCheck` | 必須Evidence確認 |

### 24.2 擬似Flow

```java
validateLaunchGate();
var before = executeCall001();
checkStartStateAndTransition(before);
var update = executeCall002(before);
var after = executeCall003();
checkIdentityUnchanged(before, after);
checkStatusTransition(before, update, after);
checkVersionIncremented(before, after);
finalizeEvidence();
```

これは責務説明用の架空Codeであり、正式Sourceへコピーしてはならない。

### 24.3 Context要求

| Context | 要求 |
|---|---|
| Execution Identity | Environment、UseCase、Scenario、Input IDを保持する。 |
| Call Context | CALL別Status、時刻、Evidence Referenceを保持する。 |
| Data Context | Test Data、Lease、Cleanup、Recoveryを保持する。 |
| Result Context | 四結果軸とResult Key別結果を保持する。 |

## 25. Test観点

### 25.1 起動前

- Input／Expected不存在
- Identity不一致
- API／Scenario無効
- Environment更新禁止
- Lease取得失敗
- Secret未解決

### 25.2 Flow

- 3 CALL正常
- CALL-001対象不存在
- 開始状態不一致
- CALL-002 Business Error／Timeout
- CALL-003 Timeout／Contract Error
- 未定義CALLまたは順序違反

### 25.3 Mapping／Check

- 対象Identity保持
- Version Mapping
- 許可状態遷移
- 目標状態一致
- Version増加
- `IGNORE_VALUE` FieldのContract違反

### 25.4 Data／Security

- Lease競合
- 二重実行
- Timeout後Data再利用防止
- Secret非出力
- Mask済Evidence

## 26. Traceability

| Source | Target | 確認 |
|---|---|---|
| UC-E6-901 | SC-E6-901 | 親子関係 |
| SC-E6-901 | CALL-001～003 | 呼出集合 |
| CALL-001／003 | API-901 | API固定契約 |
| CALL-002 | API-902 | API固定契約 |
| SC-E6-901 | Input Example | 初期値・Reference |
| SC-E6-901 | Expected Example | Result Key |
| Result Key | Java Check | 双方向一致 |
| Java Check | Evidence | 判定根拠 |

## 27. Validation

| Rule ID | 確認内容 | 現在 |
|---|---|---|
| SC901-V001 | Front Matterと文書情報が一致する。 | PASS |
| SC901-V002 | Master ExampleとScenario Identityが一致する。 | PASS |
| SC901-V003 | CALL集合・順序が対応表Exampleと一致する。 | PASS |
| SC901-V004 | CALL-001／003を別Identityとして扱う。 | PASS |
| SC901-V005 | Input／Expected Referenceが存在し、IdentityとCALL集合が一致する。 | PASS |
| SC901-V006 | API-902詳細設計Exampleが存在し、CALL-002契約と一致する。 | PASS |
| SC901-V007 | Result KeyとJava Checkが双方向一致する。 | BLOCKED |
| SC901-V008 | Exampleが正式Masterから分離される。 | PASS |

## 28. Open Issues

| Issue ID | 内容 | 影響 | Owner | 状態 |
|---|---|---|---|---|
| SC901-OI-001 | API-902設計書Example未作成 | CALL-002契約を照合できない。 | Example API Team | CLOSED |
| SC901-OI-002 | Input Example未作成 | 起動Inputを解決できない。 | Example Scenario Team | CLOSED |
| SC901-OI-003 | Expected Example未作成 | Result Keyと期待結果を解決できない。 | Example Scenario Team | CLOSED |
| SC901-OI-004 | Java Example未実装 | Flow、Mapping、CheckをBuild照合できない。 | Example Java Team | OPEN |

## 29. Release Blocker

- 本書はExampleであり正式Release対象外。
- Java Scenario／Builder／Check未実装。
- Test Data、Environment、Approval、Lease、Cleanup実体を持たない。
- Expectedの9個の`resultKey`をJava Check Registryと双方向照合できない。

## 30. 完了条件

1. Scenario Identity、呼出集合、順序および条件が一意である。
2. Mapping Source／Target／Ownerを追跡できる。
3. Result Keyと四結果軸が定義される。
4. Diffと更新前後Business Checkが分離される。
5. 更新Data、Timeout、CleanupおよびSecurity境界が明示される。
6. Example値が正式MasterおよびRuntimeから分離される。

## 31. 禁止事項

- 本Exampleを正式E6 Scenarioとして登録する。
- `enabled=true`だけで実行する。
- CALL-001とCALL-003を同一Baseline Identityとして扱う。
- CALL-001 Response全体をCALL-002 Requestへ動的Mergeする。
- HTTP SuccessだけでScenario PASSと判定する。
- `IGNORE_FIELD／IGNORE_VALUE`でContractまたはBusiness Checkを免除する。
- CALL-002 Timeout後に自動Retry、CALL-003通常実行または自動Cleanupを行う。
- Sample値、Class名またはReferenceを正式値として転記する。

## 32. 次工程

1. Java ExampleのSource RootとPackage構成を確定する。
2. `OrderStatusChangeScenario`、Builderおよび9 Checkを実装する。
3. Input／ExpectedとJava Check Registryを双方向照合する。
4. Test Data、Lease、CleanupおよびEvidenceのRuntime契約を具体化する。
