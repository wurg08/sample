---
title: 変更対象注文不存在経路Scenario設計書（Example）
document_id: EX-SC-E6-902-DESIGN
version: 1.0.0-draft.3
status: DRAFT
document_type: Scenario Detail Design Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 変更対象注文不存在経路Scenario設計書（Example）

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 変更対象注文不存在経路Scenario設計書（Example） |
| 文書ID | `EX-SC-E6-902-DESIGN` |
| Scenario ID | `SC-E6-902` |
| UseCase ID | `UC-E6-901` |
| 文書種別 | Scenario詳細設計書記入例 |
| 版数 | `1.0.0-draft.3` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Example Scenario Design Team |
| レビュー責任 | Business Owner / API Owner / Runtime Lead / Test Lead |
| 承認責任 | Example System Owner |

本書のScenario、注文、API、DTO、Java Class、Input、Expectedおよび業務値はすべて架空である。正式E6 Scenario、正式MasterまたはRuntimeへ転記してはならない。

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更区分 | 承認状態 |
|---|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | 対象不存在、更新抑止、未計画Call制御および三判定軸を含むAlternative経路Exampleを新規作成 | NEW | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | SC-E6-903資産作成後の次工程をJava実装・Registry照合へ更新 | UPDATE | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | Framework横断Reviewにより分岐、Error処理、集約および四結果軸をCanonical Statusへ統一 | UPDATE | DRAFT |

## 3. 目的

本書は、状態変更対象の注文が存在しない場合に、注文情報取得APIを一度だけ呼び出し、正式Error契約によって対象不存在を確認し、更新APIおよび更新後照会を呼び出さずに想定した業務結果で終了するAlternative Scenarioの記入例を示す。

本Scenarioの正規呼出集合は次の1件だけである。

```text
CALL-001 → API-901：変更対象注文の不存在確認
```

`CALL-002`および`CALL-003`は本Scenarioに宣言しない。実行しないCallを`SKIPPED`として記録件数へ水増しせず、「未計画であり実行0件」としてExecution Traceで保証する。

## 4. 適用範囲

### 4.1 対象

- SC-E6-902の開始条件、Alternative経路および終了条件
- CALL-001のRequest生成、Error Contractおよび対象不存在判定
- API-902更新呼出が0件であることの確認
- 更新後API-901再照会が0件であることの確認
- 未計画Callと`SKIPPED` Callの区別
- Execution／Verification／Change／Recoveryの四結果軸
- Input、Expected、Result Key、EvidenceおよびJava実装契約
- 不存在Test Data、Namespace予約、競合登録防止およびSecurity

### 4.2 対象外

| 対象外 | 定義先 |
|---|---|
| API-901固定Request／Response／Error契約 | API-901設計書Example |
| 注文状態更新契約 | API-902設計書Example |
| 正常更新経路 | SC-E6-901設計書Example |
| 更新Timeout経路 | SC-E6-903設計書Example |
| Environment別Host、Credential、Secret | Environment設定 |
| 不存在対象の実値 | Test Data Asset |
| Runtime Artifactの物理Schema | Run Context／File I/O設計 |
| 正式E6業務における不存在結果 | 正式Business Owner承認 |

## 5. 根拠資料

| Source ID | 資料名 | Reference | 確認状態 |
|---|---|---|---|
| SC902-SRC-001 | Scenario Master記入例 | `system/02_master/examples/Scenario_Master_Example.md` | CONFIRMED |
| SC902-SRC-002 | 対応表記入例 | `system/02_master/examples/API_UseCase_Scenario対応表_Example.md` | CONFIRMED |
| SC902-SRC-003 | UC-E6-901設計書Example | `system/04_usecase_design/examples/UC-E6-901設計書_Example.md` | CONFIRMED |
| SC902-SRC-004 | API-901設計書Example | `system/03_api_design/examples/API-901設計書_Example.md` | CONFIRMED |
| SC902-SRC-005 | Input Example | `system/04_usecase_design/examples/input/SC-E6-902-input_Example.json` | CONFIRMED |
| SC902-SRC-006 | Expected Example | `system/04_usecase_design/examples/expected/SC-E6-902-expected_Example.json` | CONFIRMED |
| SC902-SRC-007 | Scenario入力データ設計書 | `system/04_usecase_design/Scenario入力データ設計書.md` | CONFIRMED |
| SC902-SRC-008 | 検証結果・Expected設計書 | `system/06_verification_assets/検証結果・Expected設計書.md` | CONFIRMED |

## 6. Master整合

### 6.1 Scenario Master

| scenarioId | useCaseId | scenarioName | scenarioType | executionClass | enabled |
|---|---|---|---|---|:---:|
| SC-E6-902 | UC-E6-901 | 変更対象注文不存在経路 | ALTERNATIVE | `com.example.e6.scenario.OrderNotFoundScenario` | false |

### 6.2 API呼出関係

| callSequence | apiCallCode | apiId | 呼出目的 | Example relationStatus |
|---:|---|---|---|---|
| 10 | CALL-001 | API-901 | 変更対象注文の不存在確認 | INACTIVE |

`relationStatus=INACTIVE`はAPI-901の無効を意味しない。`SC-E6-902.enabled=false`から導出される。本書、InputおよびExpectedが存在しても自動的に`ACTIVE`へ変更してはならない。

### 6.3 宣言外Call

| apiCallCode | 正常経路での用途 | SC-E6-902での取扱い |
|---|---|---|
| CALL-002 | API-902による注文状態更新 | 未計画。Scenario呼出集合へ登録しない。 |
| CALL-003 | API-901による更新後照会 | 未計画。Scenario呼出集合へ登録しない。 |

## 7. Scenario概要

| 項目 | 内容 |
|---|---|
| Scenario ID | `SC-E6-902` |
| Scenario名称 | 変更対象注文不存在経路 |
| Scenario Type | `ALTERNATIVE` |
| 親UseCase | `UC-E6-901` |
| 開始点 | 承認済み不存在対象、Environment、Input、Expectedおよび予約制御を解決した状態 |
| 終了点 | API-901の正式Error契約で対象不存在を確認し、更新・後続照会0件とEvidenceを確定した状態 |
| 実行Class | `com.example.e6.scenario.OrderNotFoundScenario` |
| 宣言API呼出数 | 1 |
| 期待実行API呼出数 | 1 |
| 更新API呼出数 | 0 |
| Recovery要否 | 不要 |
| Example実行可否 | `NOT_EXECUTABLE` |

## 8. 開始条件

### 8.1 業務前提

| Precondition ID | 条件 | 確認方法 | 未成立時 |
|---|---|---|---|
| SC902-PRE-001 | 不存在確認対象を一意に識別できる。 | `targetOrderRef`解決 | `BLOCKED` |
| SC902-PRE-002 | 対象がEnvironment内に存在しないことを事前保証できる。 | `absenceConditionRef` | `BLOCKED` |
| SC902-PRE-003 | 実行中に同一IDが他処理から登録されない。 | `reservationRef`／Namespace制御 | `BLOCKED` |
| SC902-PRE-004 | API-901の404／`ORDER_NOT_FOUND`契約が利用可能である。 | API-901設計書／Java DTO | `BLOCKED` |
| SC902-PRE-005 | 対象不存在を本Exampleの想定Alternativeとして承認している。 | Expected／Review | `BLOCKED` |

### 8.2 起動前Validation Gate

| Gate ID | 条件 | Example判定 | 未成立時 |
|---|---|---|---|
| SC902-GATE-001 | UseCase、ScenarioおよびAPI Identityが整合 | Scenario無効のためBLOCKED | API未呼出 |
| SC902-GATE-002 | Input／Expectedが存在しSchema適合 | STATIC PASS | API未呼出 |
| SC902-GATE-003 | Execution Identityが一致 | STATIC PASS | API未呼出 |
| SC902-GATE-004 | 6件のInput Referenceを安全に解決 | Runtime BLOCKED | API未呼出 |
| SC902-GATE-005 | Java Scenario、DTO、Client、Builderを解決 | BLOCKED | API未呼出 |
| SC902-GATE-006 | 7 Result KeyとCheck Registryが双方向一致 | BLOCKED | API未呼出 |
| SC902-GATE-007 | Environment、Approval、Reservationが成立 | BLOCKED | API未呼出 |
| SC902-GATE-008 | Secret／Sensitive Data検査を通過 | BLOCKED | API未呼出 |

静的Exampleが完成していても、全Gateが成立しない限りAPIを一件も呼び出してはならない。

## 9. Alternative Flow

```mermaid
flowchart TD
    A["起動前Gate"]
    B["CALL-001 注文照会"]
    C["404・ORDER_NOT_FOUND契約確認"]
    D["更新・後続照会0件確認"]
    E["PASS・Evidence確定"]
    X["停止・非PASS記録"]

    A -->|PASS| B
    A -->|非PASS| X
    B -->|正式な不存在応答| C
    B -->|対象存在／技術Error| X
    C --> D --> E
```

SC-E6-901実行中に対象不存在が発生しても、Run途中でScenario IDをSC-E6-902へ付け替えてはならない。SC-E6-902は独立Input、Expected、Run IDおよびEvidenceで開始する。

## 10. API呼出定義

| callSequence | apiCallCode | apiId | 実行条件 | 期待結果 | 非期待結果 |
|---:|---|---|---|---|---|
| 10 | CALL-001 | API-901 | 起動前Gateが全成立 | HTTP 404かつ`ORDER_NOT_FOUND`の正式Error契約 | 対象存在、Status／Code不一致、Timeout、通信／Parse／Contract Error |

本ScenarioにCALL-002またはCALL-003を追加してはならない。将来、存在再確認等の追加照会が必要になった場合は、業務経路と終了条件を再レビューし、Scenario設計を改訂する。

## 11. CALL-001詳細

| 項目 | 内容 |
|---|---|
| API | `API-901` |
| Method／Endpoint | `GET /api/v1/orders/{orderId}` |
| Request Builder | `OrderNotFoundQueryRequestBuilder` |
| Request Source | Inputの`targetOrderRef` |
| Response DTO | `ApiErrorResponse` |
| 期待HTTP Status | 404 |
| 期待Error Code | `ORDER_NOT_FOUND` |
| 必須相関 | Errorの対象／Correlationが当該Requestと追跡可能 |
| Timeout／通信Error | 不存在と推測せずExecution `INCOMPLETE`、Verification `NOT_EVALUATED` |
| Parse／Contract Error | 不存在と推測せずExecution `INCOMPLETE`、Verification `NOT_EVALUATED` |
| 対象存在（HTTP 200） | Execution `COMPLETED`候補、Verification `FAIL` |
| Evidence | Mask済Request、Error Response、Call Meta、Contract／Business Check |
| Diff Identity | `SC-E6-902 + CALL-001` |

HTTP 404だけ、空Bodyだけ、任意Error Messageだけでは対象不存在を確定しない。HTTP Status、Error Code、固定Error ContractおよびRequest相関を一体として確認する。

## 12. 分岐・停止

| Rule ID | 判定点 | 条件 | Action | Execution | Verification |
|---|---|---|---|---|---|
| SC902-BR-001 | 起動前 | Gate非成立 | CALL-001未実行 | REJECTED | NOT_EVALUATED |
| SC902-BR-002 | CALL-001 | 404＋`ORDER_NOT_FOUND`＋Contract PASS | 更新・後続照会を実行せずCheckへ進む | COMPLETED | PASS候補 |
| SC902-BR-003 | CALL-001 | HTTP 200で対象存在 | 更新せず終了 | COMPLETED | FAIL |
| SC902-BR-004 | CALL-001 | 404だがError Code／Contract不一致 | 更新せず終了 | COMPLETEDまたはINCOMPLETE | FAILまたはNOT_EVALUATED |
| SC902-BR-005 | CALL-001 | Timeout／通信Error | 更新せず終了 | INCOMPLETE | NOT_EVALUATED |
| SC902-BR-006 | CALL-001 | Parse Error | 更新せず終了 | INCOMPLETE | NOT_EVALUATED |
| SC902-BR-007 | Runtime | CALL-002／003または未定義Callを検出 | 即時停止 | INCOMPLETE | NOT_EVALUATED |

## 13. 未計画Call制御

### 13.1 `NOT_PLANNED`と`SKIPPED`

| 状態 | 意味 | SC-E6-902での使用 |
|---|---|---|
| `NOT_PLANNED` | Scenarioの宣言呼出集合に含まれない。 | CALL-002／003 |
| `SKIPPED` | Scenarioに宣言済みだが、分岐・停止により実行しなかった。 | 使用しない。 |
| `NOT_STARTED` | 起動前Gate不成立により宣言Callを開始できなかった。 | CALL-001で使用可能 |

SC-E6-902の結果Artifactに、CALL-002／003の擬似Call Recordを生成してはならない。Execution Trace Checkは、実行Call集合が`{CALL-001}`だけであること、およびAPI-902呼出が0件であることを確認する。

### 13.2 副作用保証

| Control ID | 確認対象 | 期待 |
|---|---|---|
| SC902-SIDE-001 | API-902 Request数 | 0 |
| SC902-SIDE-002 | 更新Command／Event数 | 0 |
| SC902-SIDE-003 | CALL-003 API-901 Request数 | 0 |
| SC902-SIDE-004 | Cleanup／Recovery実行数 | 0 |

## 14. Request生成・Mapping

### 14.1 基本原則

1. Inputの任意MapをRequestへ動的Mergeしない。
2. `targetOrderRef`を専用Resolverで解決し、正式DTO Fieldへ設定する。
3. 不存在確認のために実在注文IDを加工して生成しない。
4. 予約済みExample Namespaceだけを使用する。
5. Secret、Credentialまたは個人情報をInputへ格納しない。
6. CALL-001 Error Responseから更新Requestを生成しない。

### 14.2 論理Mapping契約

| Mapping ID | Source | Target | 変換 | Owner |
|---|---|---|---|---|
| SC902-MAP-001 | Input `targetOrderRef` | CALL-001 `orderId` | Test Data Reference解決 | OrderNotFoundQueryRequestBuilder |
| SC902-MAP-002 | Input `absenceConditionRef` | 起動前Absence Gate | Rule Reference解決 | AbsenceConditionResolver |
| SC902-MAP-003 | Input `reservationRef` | Namespace予約Context | Reservation解決 | TestDataReservationService |

Error Responseの`message`文字列をBusiness Keyとして後続処理へ渡してはならない。

## 15. Scenario Input契約

| 項目 | 設計 |
|---|---|
| Reference | `system/04_usecase_design/examples/input/SC-E6-902-input_Example.json` |
| Identity | `ENV-EXAMPLE-STAGING + UC-E6-901 + SC-E6-902 + INPUT-SC-E6-902-EXAMPLE-001` |
| 現在の状態 | STATIC EXAMPLE CREATED |
| 実行可否 | 不可 |

### 15.1 必須論理入力

| Input Key | 目的 | 必須 | Null |
|---|---|:---:|:---:|
| `request.testDataId` | Test Data識別 | Yes | No |
| `request.dataSetVersion` | Data版識別 | Yes | No |
| `request.contentHash` | Data完全性 | Yes | No |
| `request.targetOrderRef` | 不存在対象の安全な参照 | Yes | No |
| `request.absenceConditionRef` | 不存在保証条件 | Yes | No |
| `request.reservationRef` | 競合登録防止制御 | Yes | No |

Input Exampleの文字列はReference記入例であり、Runtime実体が存在することを意味しない。一つでも解決できなければAPIを呼び出さない。

### 15.2 API Call集合

Inputの`apis[]`はCALL-001だけを持つ。API-902やCALL-003の空Objectを追加してはならない。

## 16. Expected／Check契約

| 項目 | 設計 |
|---|---|
| Reference | `system/04_usecase_design/examples/expected/SC-E6-902-expected_Example.json` |
| Identity | Inputと同一 |
| expectedExecutionStatus | `COMPLETED` |
| expectedVerificationStatus | `PASS` |
| expectedRecoveryStatus | `NOT_REQUIRED` |
| Result Key数 | 7 |
| 現在の状態 | STATIC EXAMPLE CREATED |
| 実行可否 | Java Check未実装のため不可 |

### 16.1 必須Result Key

| 順序 | resultKey | resultType | apiCallCode | 期待 |
|---:|---|---|---|---|
| 10 | `CALL-001_ERROR_RESPONSE_CONTRACT` | RESPONSE_CONTRACT | CALL-001 | PASS |
| 20 | `CALL-001_TARGET_NOT_FOUND` | BUSINESS_VALUE | CALL-001 | PASS |
| 30 | `SC902_ONLY_DECLARED_CALL_EXECUTED` | EXECUTION_TRACE | なし | PASS |
| 40 | `SC902_NO_UPDATE_CALL` | EXECUTION_TRACE | なし | PASS |
| 50 | `SC902_NO_POST_QUERY_CALL` | EXECUTION_TRACE | なし | PASS |
| 60 | `SC902_BUSINESS_OUTCOME_CLASSIFICATION` | BUSINESS_OUTCOME | なし | PASS |
| 70 | `SC902_EVIDENCE_COMPLETENESS` | EVIDENCE_COMPLETENESS | なし | PASS |

### 16.2 PASS条件

次の全条件が成立した場合だけScenario Verificationを`PASS`とする。

1. CALL-001が一度だけ実行される。
2. HTTP 404、`ORDER_NOT_FOUND`および固定Error Contractが成立する。
3. 不存在応答が当該Requestと追跡可能である。
4. 実行Call集合が`{CALL-001}`と完全一致する。
5. API-902更新呼出が0件である。
6. CALL-003更新後照会が0件である。
7. 必須EvidenceがMask、HashおよびTrace付きで存在する。

## 17. Check実行・集約

1. ExpectedとJava Check Registryの`resultKey`集合を起動前に双方向照合する。
2. Error Contract CheckがPASSしたArtifactだけをTarget Not Found Checkへ渡す。
3. Target Not Found CheckはStatus単独ではなくError Codeと相関を含めて判定する。
4. Execution Trace Checkは宣言Call集合と実行Call集合を完全一致比較する。
5. 未定義Call検出は業務`FAIL`ではなくExecution `INCOMPLETE`、Verification `NOT_EVALUATED`およびReason Codeで表す。
6. 必須Checkが一件でも未実装ならScenarioを起動しない。

集約優先順位：

```text
FAIL > NOT_EVALUATED > PASS
```

## 18. 四結果軸

| 軸 | 期待 | 説明 |
|---|---|---|
| Execution | COMPLETED | CALL-001と全Checkが所定どおり完了する。 |
| Verification | PASS | 対象不存在、無更新、Call集合およびEvidenceが全て期待どおりである。 |
| Change | UNCHANGEDまたはCHANGED | 過去の同一Error Contract Artifactとの差分を独立観測する。 |
| Recovery | NOT_REQUIRED | 想定Alternativeが成立した場合は運用介入不要。 |

HTTP 404はExecution失敗を意味しない。SC-E6-902では、Transportが正常に完了し、設計されたError Responseを受信・検証できた場合、Executionは`COMPLETED`となり得る。

## 19. Response Diff

| Compare対象 | Identity | 目的 |
|---|---|---|
| CALL-001 Current vs Baseline | `SC-E6-902 + CALL-001` | Error Contractの回帰差分 |

### 19.1 比較規則

- HTTP Status、`errorCode`およびError DTO構造はContract Check対象とする。
- `correlationId`、`occurredAt`等の実行時変動値はAPI-901のCompare規則に従う。
- `IGNORE_VALUE`はField不存在、型違反、Null違反またはFormat違反を免除しない。
- SC-E6-901のCALL-001 Baselineと比較しない。
- Baselineがない場合は`NOT_COMPARED`とし、Verification PASSをChange軸へ転用しない。

## 20. Error／Timeout処理

| Event | API Call状態 | Execution | Verification | Change |
|---|---|---|---|---|
| 起動前Gate不成立 | NOT_STARTED | REJECTED | NOT_EVALUATED | NOT_COMPARED |
| 正式な対象不存在 | COMPLETED | COMPLETED | PASS候補 | Call別判定 |
| 対象存在 | COMPLETED | COMPLETED | FAIL | Call別判定 |
| 404＋Error Contract不一致 | COMPLETEDまたはPARSE_ERROR | COMPLETEDまたはINCOMPLETE | FAILまたはNOT_EVALUATED | CHANGEDまたはNOT_COMPARED |
| Timeout／通信Error | TIMEOUT／TRANSPORT_ERROR | INCOMPLETE | NOT_EVALUATED | NOT_COMPARED |
| Parse Error | PARSE_ERROR | INCOMPLETE | NOT_EVALUATED | NOT_COMPARED |
| 未定義Call実行 | N/A | INCOMPLETE | NOT_EVALUATED | 取得済み結果を保持 |
| Result保存Error | N/A | INCOMPLETE | 評価済み値を保持 | 取得済み結果を保持 |

Timeout、通信Error、空BodyまたはParse失敗を対象不存在へ変換してはならない。

## 21. Test Data安全性

| Control ID | 制御 | Evidence | 未成立時 |
|---|---|---|---|
| SC902-DATA-001 | Stable Test Data Identity | `testDataId + dataSetVersion + contentHash` | BLOCKED |
| SC902-DATA-002 | 不存在Namespace予約 | Reservation Reference | BLOCKED |
| SC902-DATA-003 | 同一IDの競合登録防止 | Lease／期間制御 | BLOCKED |
| SC902-DATA-004 | 実注文ID非使用 | Data Classification | BLOCKED |
| SC902-DATA-005 | 実行後の予約解放 | Reservation Result | Evidence不足 |

本Scenarioは業務更新を行わないため、状態復元Cleanupを実行しない。ただし、Test Data Namespace予約の解放は管理制御として実施し、結果をEvidence化する。

## 22. Cleanup／Recovery

| 条件 | 業務Cleanup | Recovery | 管理制御 |
|---|---|---|---|
| 想定不存在で完了 | 不要 | 不要 | Namespace予約を解放 |
| 対象存在 | 更新未実施のため不要 | Data準備異常として調査 | 予約を隔離 |
| CALL-001 Timeout／通信Error | 更新未実施のため不要 | API疎通調査 | 予約解放可否を判断 |
| 未定義更新Call検出 | 自動Cleanup禁止 | 更新有無を確認 | Dataを隔離 |

## 23. Security／Mask

1. Credential、Token、PasswordまたはSecret実値をInput、Expected、Log、Reportへ保存しない。
2. 不存在対象に実注文IDまたは顧客情報を使用しない。
3. Request／Response全文はMask前に永続化しない。
4. Order IDは承認済みMaskまたはHashで表示する。
5. Error MessageへHeader、Credentialまたは未Mask識別値を連結しない。
6. Evidence ReferenceにはRoot基準相対Pathを使用し、Path Traversalを拒否する。

## 24. Evidence

| Artifact | Scope | 必須 | 内容 |
|---|---|:---:|---|
| Scenario Execution | Scenario | Yes | Gate、Step状態、時刻、終了理由 |
| Mask済Request | CALL-001 | 実行時 | 送信Request |
| Mask済Error Response | CALL-001 | 実行時 | 404 Error DTO |
| API Call Meta | CALL-001 | 実行時 | Status、Duration、Hash、Identity |
| Contract Result | CALL-001 | Yes | Error Contract判定 |
| Business Result | CALL-001 | Yes | Target Not Found判定 |
| Execution Trace | Scenario | Yes | 宣言・実行Call集合、更新Call数 |
| Verification Result | Scenario | Yes | 7 Result Key明細 |
| Response Diff | CALL-001 | 比較時 | Effective／Ignored／Not Compared |
| Reservation Result | Scenario | Yes | Namespace予約・解放 |
| Evidence Index | Scenario | Yes | Artifact Reference、Hash、Integrity |

CALL-002／003のRequest、Responseまたは擬似Evidenceを生成してはならない。

## 25. Java実装契約

### 25.1 Class構成

| Class | Example FQCN | 責務 | 状態 |
|---|---|---|---|
| Scenario | `com.example.e6.scenario.OrderNotFoundScenario` | Alternative Flow統制 | 未実装 |
| Request Builder | `com.example.e6.scenario.order.OrderNotFoundQueryRequestBuilder` | CALL-001 Request生成 | 未実装 |
| Contract Check | `com.example.e6.scenario.order.OrderNotFoundErrorContractCheck` | 404 Error契約確認 | 未実装 |
| Business Check | `com.example.e6.scenario.order.OrderTargetNotFoundCheck` | 対象不存在確認 | 未実装 |
| Trace Check | `com.example.e6.scenario.common.DeclaredCallSetCheck` | 宣言／実行Call集合確認 | 未実装 |
| Evidence Check | `com.example.e6.scenario.common.EvidenceCompletenessCheck` | 必須Evidence確認 | 未実装 |

### 25.2 擬似Flow

```java
validateLaunchGate();
ApiExchange notFound = executeCall001();
checkErrorResponseContract(notFound);
checkTargetNotFound(notFound);
requireExecutedCallSet(Set.of("CALL-001"));
requireNoApiCall("API-902");
requireNoCall("CALL-003");
checkEvidenceCompleteness();
finalizeScenario(PASS);
```

擬似Codeは責務説明であり、正式Sourceへコピーしてはならない。`finalizeScenario(PASS)`は全Check PASS後だけ到達可能とする。

### 25.3 Context要求

| Context | 要求 |
|---|---|
| Execution Identity | Environment、UseCase、Scenario、Input Setを保持する。 |
| Call Context | CALL-001だけを保持する。 |
| Data Context | Test Data、Absence Rule、Reservationを保持する。 |
| Result Context | 四結果軸と7 Result Keyを保持する。 |
| Evidence Context | Mask済Artifact ReferenceとHashを保持する。 |

## 26. Test観点

### 26.1 起動前

- Scenario無効
- Input／Expected不存在
- Identity不一致
- Reference解決不能
- Namespace予約失敗
- Java Class／Check Registry不存在
- Secret検査不合格

### 26.2 Flow

- 404＋`ORDER_NOT_FOUND`正常Alternative
- 404＋異なるError Code
- 404＋Contract Field不足
- HTTP 200で対象存在
- Timeout／通信Error
- Parse Error
- CALL-002／003誤実行
- CALL-001複数回実行

### 26.3 Data／Security

- 競合登録
- 実注文ID混入
- Content Hash不一致
- Reservation期限切れ
- Secret／個人情報非出力
- Mask前Artifact永続化防止

### 26.4 Result／Evidence

- 7 Result Keyの双方向一致
- 必須Evidence不足
- CALL-002／003擬似Artifact混入
- Change軸とVerification軸の独立

## 27. Traceability

| Source | Target | 確認 |
|---|---|---|
| UC-E6-901 | SC-E6-902 | 親子関係 |
| SC-E6-902 | CALL-001 | 唯一の呼出実体 |
| CALL-001 | API-901 | Error Contract |
| SC-E6-902 | Input Example | 不存在対象・予約Reference |
| SC-E6-902 | Expected Example | 7 Result Key |
| Result Key | Java Check | 双方向一致 |
| Java Check | Evidence | 判定根拠 |

## 28. Validation

| Rule ID | 確認内容 | 現在 |
|---|---|---|
| SC902-V001 | Front Matterと文書情報が一致する。 | PASS |
| SC902-V002 | Master ExampleとScenario Identityが一致する。 | PASS |
| SC902-V003 | CALL集合が`CALL-001 → API-901`だけである。 | PASS |
| SC902-V004 | 対応表ExampleにSC-E6-902の1行が存在する。 | PASS |
| SC902-V005 | Input／Expected Referenceが存在しIdentityが一致する。 | PASS |
| SC902-V006 | Expectedに7個の一意なResult Keyがある。 | PASS |
| SC902-V007 | Result KeyとJava Check Registryが双方向一致する。 | BLOCKED |
| SC902-V008 | Exampleが正式MasterとRuntimeから分離される。 | PASS |
| SC902-V009 | CALL-002／003の擬似実行資産が存在しない。 | PASS |

## 29. Open Issues

| Issue ID | 内容 | 影響 | Owner | 状態 |
|---|---|---|---|---|
| SC902-OI-001 | Java Scenario／Builder／Check未実装 | Build／Runtime照合不可 | Example Java Team | OPEN |
| SC902-OI-002 | Environment、Test Data、Reservation実体なし | Runtime起動不可 | Example Runtime Team | OPEN |
| SC902-OI-003 | 7 Result KeyのCheck Registry未作成 | 起動前双方向照合不可 | Example Java Team | OPEN |

## 30. Release Blocker

- `SC-E6-902.enabled=false`。
- 本書はExampleであり正式Release対象外。
- Java Scenario、Builder、DTO、ClientおよびCheck Registryが未実装。
- Test Data、Environment、Approval、ReservationおよびEvidence Storeの実体がない。
- 静的Reference値は教育用でありRuntime Assetではない。

## 31. 完了条件

1. Alternative開始・終了条件が一意である。
2. 正規呼出集合がCALL-001だけである。
3. 不存在契約とScenario PASS条件が明確である。
4. 更新および後続照会0件を検証できる。
5. 未計画Callと`SKIPPED`を区別できる。
6. Input／Expected IdentityとResult Keyが整合する。
7. Data安全性、EvidenceおよびSecurity境界が明示される。
8. Exampleが正式E6 MasterおよびRuntimeから分離される。

## 32. 禁止事項

- 本Exampleを正式E6 Scenarioとして登録する。
- `enabled=false`のまま実行する。
- HTTP 404だけでScenario PASSと判定する。
- Timeout、通信Errorまたは空Bodyを対象不存在とみなす。
- CALL-002／003を`SKIPPED`擬似Recordとして生成する。
- 実在注文IDを加工して不存在Test Dataにする。
- Error Message文字列だけでBusiness Codeを判定する。
- `IGNORE_VALUE`でContract Checkを免除する。
- Example Reference、ClassまたはSample値を正式値として転記する。

## 33. 次工程

1. Java ExampleのSource RootとPackage構成を確定する。
2. `OrderNotFoundScenario`、Builderおよび7 Checkを実装する。
3. Input／ExpectedとJava Check Registryを双方向照合する。
4. Test Data Namespace、ReservationおよびEvidenceのRuntime契約を具体化する。
