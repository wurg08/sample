---
title: 注文状態変更Timeout経路Scenario設計書（Example）
document_id: EX-SC-E6-903-DESIGN
version: 1.0.0-draft.3
status: DRAFT
document_type: Scenario Detail Design Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 注文状態変更Timeout経路Scenario設計書（Example）

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | 注文状態変更Timeout経路Scenario設計書（Example） |
| 文書ID | `EX-SC-E6-903-DESIGN` |
| Scenario ID | `SC-E6-903` |
| UseCase ID | `UC-E6-901` |
| 文書種別 | Scenario詳細設計書記入例 |
| 版数 | `1.0.0-draft.3` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Example Scenario Design Team |
| レビュー責任 | Business Owner / API Owner / Runtime Lead / Operations Lead / Test Lead |
| 承認責任 | Example System Owner |

本書のScenario、注文、API、DTO、Java Class、Input、Expected、Timeout HarnessおよびRecoveryはすべて架空である。正式E6 Scenario、正式MasterまたはRuntimeへ転記してはならない。

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 変更区分 | 承認状態 |
|---|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | 更新API Timeout、結果UNKNOWN、No Retry、後続Skip、Baseline保護およびRecovery引渡しを含むError経路Exampleを新規作成 | NEW | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | Execution State・Baseline設計Referenceを`system/05_framework/`へ同期 | UPDATE | DRAFT |
| `1.0.0-draft.3` | 2026-07-27 | Framework横断ReviewによりTimeout経路を`UNKNOWN_OUTCOME`と四結果軸へ統一 | UPDATE | DRAFT |

## 3. 目的

本書は、注文状態更新APIへのRequest送信後にResponseを受領できずTimeoutとなった場合について、更新結果を推測せず`UNKNOWN`として保持し、自動Retryと通常の更新後照会を禁止し、承認済みRecoveryへ安全に引き渡すScenario設計の記入例を示す。

本Scenarioの宣言Call集合は次の3件である。

```text
CALL-001 → API-901：更新前注文情報取得
CALL-002 → API-902：注文状態更新（TIMEOUT）
CALL-003 → API-901：更新後注文情報再取得（SKIPPED）
```

CALL-003は本Scenarioに宣言されるため、CALL-002 Timeout後は`SKIPPED`として記録する。SC-E6-902のような未計画Callとは異なる。

## 4. 適用範囲

### 4.1 対象

- SC-E6-903の開始条件、Error経路および終了条件
- CALL-001成功後のCALL-002 Timeout制御
- Request送信試行回数と自動Retry禁止
- Timeout後の更新結果`UNKNOWN`
- CALL-003の`SKIPPED`記録
- Execution／Verification／Change／Recoveryの四結果軸
- 不完全RunからのBaseline更新禁止
- Recovery引渡し、状態確認、再送可否判断およびCleanup責務境界
- Input、Expected、Result Key、EvidenceおよびJava実装契約
- Timeout Harnessの安全性、再現性および本番分離

### 4.2 対象外

| 対象外 | 定義先 |
|---|---|
| API-901固定Request／Response契約 | API-901設計書Example |
| API-902固定Request／Response／Timeout契約 | API-902設計書Example |
| 正常な注文状態変更 | SC-E6-901設計書Example |
| 対象不存在経路 | SC-E6-902設計書Example |
| Timeout秒数のEnvironment別実値 | Environment設定／Timeout Control Asset |
| Timeout後の状態確認API手順 | Recovery Procedure |
| 再送実施判断 | Business Owner／Operations Owner承認 |
| Cleanupの物理Command | Cleanup Procedure |
| Runtime Artifactの物理Schema | Run Context／File I/O設計 |
| 正式E6業務への適用判断 | 正式Business Owner承認 |

## 5. 根拠資料

| Source ID | 資料名 | Reference | 確認状態 |
|---|---|---|---|
| SC903-SRC-001 | Scenario Master記入例 | `system/02_master/examples/Scenario_Master_Example.md` | CONFIRMED |
| SC903-SRC-002 | 対応表記入例 | `system/02_master/examples/API_UseCase_Scenario対応表_Example.md` | CONFIRMED |
| SC903-SRC-003 | UC-E6-901設計書Example | `system/04_usecase_design/examples/UC-E6-901設計書_Example.md` | CONFIRMED |
| SC903-SRC-004 | API-901設計書Example | `system/03_api_design/examples/API-901設計書_Example.md` | CONFIRMED |
| SC903-SRC-005 | API-902設計書Example | `system/03_api_design/examples/API-902設計書_Example.md` | CONFIRMED |
| SC903-SRC-006 | Input Example | `system/04_usecase_design/examples/input/SC-E6-903-input_Example.json` | CONFIRMED |
| SC903-SRC-007 | Expected Example | `system/04_usecase_design/examples/expected/SC-E6-903-expected_Example.json` | CONFIRMED |
| SC903-SRC-008 | Timeout／Recovery設計原則 | `system/06_verification_assets/検証結果・Expected設計書.md` | CONFIRMED |
| SC903-SRC-009 | ExecutionState・Baseline管理設計 | `system/05_framework/ExecutionState・Baseline管理設計書.md` | CONFIRMED |
| SC903-SRC-010 | 検証結果・Expected設計 | `system/06_verification_assets/検証結果・Expected設計書.md` | CONFIRMED |

本ExampleのTimeout制御は説明用である。900番台の業務値またはExample Referenceを正式設計へ逆流させない。

## 6. Master整合

### 6.1 Scenario Master

| scenarioId | useCaseId | scenarioName | scenarioType | executionClass | enabled |
|---|---|---|---|---|:---:|
| SC-E6-903 | UC-E6-901 | 注文状態変更Timeout経路 | TIMEOUT | `com.example.e6.scenario.OrderStatusChangeTimeoutScenario` | false |

### 6.2 API呼出関係

| callSequence | apiCallCode | apiId | 呼出目的 | 期待Call状態 | Example relationStatus |
|---:|---|---|---|---|---|
| 10 | CALL-001 | API-901 | 更新前注文情報取得 | `COMPLETED` | INACTIVE |
| 20 | CALL-002 | API-902 | 注文状態更新 | `TIMEOUT` | INACTIVE |
| 30 | CALL-003 | API-901 | 更新後注文情報再取得 | `SKIPPED` | INACTIVE |

`relationStatus=INACTIVE`はAPIが無効であることを意味しない。`SC-E6-903.enabled=false`から導出される。

### 6.3 宣言Callと実行状態

| 区分 | 意味 | 本Scenario |
|---|---|---|
| 宣言済み・実行完了 | Scenario Flowに存在し処理が完了 | CALL-001 |
| 宣言済み・Timeout | Scenario Flowに存在しResponse未受領 | CALL-002 |
| 宣言済み・Skip | Scenario Flowに存在するが停止条件により未実行 | CALL-003 |
| 未計画 | Scenario Flow自体に存在しない | 該当なし |

CALL-003のExecution Recordは作成するが、Request送信、Response、HTTP StatusまたはResponse Bodyを捏造してはならない。

## 7. Scenario概要

| 項目 | 内容 |
|---|---|
| Scenario ID | `SC-E6-903` |
| Scenario名称 | 注文状態変更Timeout経路 |
| Scenario Type | `TIMEOUT` |
| 親UseCase | `UC-E6-901` |
| 開始点 | 承認済み更新対象、Timeout Control、RecoveryおよびEnvironmentを解決した状態 |
| 終了点 | Timeout、UNKNOWN、No Retry、CALL-003 Skip、Baseline保護およびRecovery引渡しを記録した状態 |
| 実行Class | `com.example.e6.scenario.OrderStatusChangeTimeoutScenario` |
| 宣言API呼出数 | 3 |
| 期待送信API呼出数 | 2 |
| 期待完了Response数 | 1 |
| Timeout Call数 | 1 |
| Skip Call数 | 1 |
| 更新結果 | `UNKNOWN` |
| Recovery | `REQUIRED` |
| Example実行可否 | `NOT_EXECUTABLE` |

## 8. 開始条件

### 8.1 業務前提

| Precondition ID | 条件 | 確認方法 | 未成立時 |
|---|---|---|---|
| SC903-PRE-001 | 更新対象注文が存在し、開始状態を一意に確認できる。 | CALL-001／Business Check | Scenario停止 |
| SC903-PRE-002 | 開始状態から目標状態への遷移が許可される。 | Business Rule Reference | CALL-002未実行 |
| SC903-PRE-003 | Test Data LeaseがRun単位で成立する。 | Runtime Gate | API未呼出 |
| SC903-PRE-004 | Timeout ControlがAPI-902のCALL-002だけを対象とする。 | Harness Definition | API未呼出 |
| SC903-PRE-005 | Timeout Controlが実Dataを直接変更しない。 | Harness Review | API未呼出 |
| SC903-PRE-006 | 状態確認、再送判断、CleanupのRecovery Procedureを解決できる。 | Recovery Reference | API未呼出 |
| SC903-PRE-007 | Timeout後に通常Flowを自動継続しない。 | Java Scenario Contract | API未呼出 |

### 8.2 起動前Validation Gate

| Gate ID | 条件 | Example判定 | 未成立時 |
|---|---|---|---|
| SC903-GATE-001 | UseCase、Scenario、API Identityが整合 | Scenario無効のためBLOCKED | API未呼出 |
| SC903-GATE-002 | Input／Expectedが存在しSchema適合 | STATIC PASS | API未呼出 |
| SC903-GATE-003 | Execution Identityが一致 | STATIC PASS | API未呼出 |
| SC903-GATE-004 | 10件のInput Referenceを安全に解決 | Runtime BLOCKED | API未呼出 |
| SC903-GATE-005 | 9 Result KeyとCheck Registryが双方向一致 | BLOCKED | API未呼出 |
| SC903-GATE-006 | Java Scenario、DTO、Client、Builderを解決 | BLOCKED | API未呼出 |
| SC903-GATE-007 | Timeout Harnessが対象Environmentで承認済み | BLOCKED | API未呼出 |
| SC903-GATE-008 | Test Data、Lease、Recovery、Cleanupが成立 | BLOCKED | API未呼出 |
| SC903-GATE-009 | Secret／Sensitive Data検査を通過 | BLOCKED | API未呼出 |

静的Exampleが完成しても、すべてのRuntime Gateが成立するまでAPIを呼び出してはならない。

## 9. Timeout Flow

```mermaid
flowchart TD
    A["起動前Gate"]
    B["CALL-001 更新前照会"]
    C["開始状態・遷移Check"]
    D["CALL-002 状態更新"]
    E["TIMEOUT・結果UNKNOWN"]
    F["CALL-003をSKIPPED記録"]
    G["Baseline更新禁止"]
    H["Recoveryへ引渡し"]
    X["起動前停止"]

    A -->|PASS| B
    A -->|非PASS| X
    B -->|正常| C
    B -->|非正常| X
    C -->|PASS| D
    C -->|非PASS| X
    D -->|TIMEOUT| E --> F --> G --> H
```

本Scenarioが期待する異常はCALL-002のTimeoutだけである。CALL-001異常、Request Validation Error、Harness起動失敗またはCALL-002 Business ErrorをTimeout成功例として扱わない。

## 10. API呼出定義

| callSequence | apiCallCode | apiId | 実行条件 | 期待結果 | 後続 |
|---:|---|---|---|---|---|
| 10 | CALL-001 | API-901 | 起動前Gateが全成立 | HTTP 200、Contract PASS、対象・開始状態一致 | CALL-002へ進む |
| 20 | CALL-002 | API-902 | CALL-001と事前CheckがPASS、Harness Armed | `TIMEOUT`、送信試行1回、Responseなし | CALL-003をSkip |
| 30 | CALL-003 | API-901 | CALL-002が更新成功かつ結果既知 | 本Scenarioでは条件不成立 | `SKIPPED`を記録 |

### 10.1 CALL-001

| 項目 | 内容 |
|---|---|
| 目的 | 更新対象と開始状態の確定 |
| Request Source | `targetOrderRef` |
| 成功条件 | API-901 Contract PASS、対象一致、開始状態一致 |
| Evidence | Mask済Request／Response、Meta、Check Result |
| Diff Identity | `SC-E6-903 + CALL-001` |

### 10.2 CALL-002

| 項目 | 内容 |
|---|---|
| 目的 | 注文状態更新Requestを一回送信しTimeoutを観測 |
| Request Source | Inputの目標状態とCALL-001の対象／Version |
| Harness | `timeoutControlRef`で解決した承認済み制御 |
| 期待Transport結果 | `TIMEOUT` |
| 期待HTTP Status | なし |
| Response DTO | 生成しない |
| 送信試行回数 | 1 |
| 自動Retry | 0 |
| 更新結果 | `UNKNOWN` |
| Evidence | Mask済Request、送信時刻、Timeout分類、Duration、Harness Reference |
| Diff Identity | `SC-E6-903 + CALL-002` |

### 10.3 CALL-003

| 項目 | 内容 |
|---|---|
| 目的 | 正常Flowでは更新後状態を確認 |
| 本Scenarioの状態 | `SKIPPED` |
| Request送信 | 0件 |
| HTTP Status | 設定しない |
| Response Body | 生成しない |
| Skip Reason | `PREVIOUS_CALL_TIMEOUT` |
| Evidence | Skip Reason、前提Call、Timestamp、Scenario State Reference |

CALL-003はRecovery照会ではない。Recoveryが状態確認を行う場合は、別Recovery Execution IdentityとEvidenceを使用する。

## 11. Timeout成立条件

| Rule ID | 条件 | 不成立時 |
|---|---|---|
| SC903-TO-001 | CALL-002 Request Validationが送信前にPASS | Timeoutとして扱わない |
| SC903-TO-002 | API Clientが送信開始を記録 | Timeoutとして扱わない |
| SC903-TO-003 | Response Header／Bodyを受領していない | 受領結果に従う |
| SC903-TO-004 | Clientの正式Timeout分類に一致 | 通信Errorとして分類 |
| SC903-TO-005 | HarnessがCALL-002だけを対象 | Harness Error |
| SC903-TO-006 | 送信試行回数が1 | Scenario Error |
| SC903-TO-007 | 架空HTTP StatusまたはError DTOを生成しない | Contract Error |

Timeout秒数はInputへ実値を直接記載せず、`timeoutControlRef`からEnvironment別設定を解決する。

## 12. Request生成・Mapping

| Mapping ID | Source | Target | 変換 | Owner |
|---|---|---|---|---|
| SC903-MAP-001 | Input `targetOrderRef` | CALL-001 `orderId` | Reference解決 | OrderQueryRequestBuilder |
| SC903-MAP-002 | CALL-001 `orderId` | CALL-002 `orderId` | 同値 | OrderStatusUpdateRequestBuilder |
| SC903-MAP-003 | CALL-001 `orderVersion` | CALL-002 `expectedVersion` | Long同値 | OrderStatusUpdateRequestBuilder |
| SC903-MAP-004 | Input `targetStateRef` | CALL-002 `targetStatus` | Enum解決 | OrderStatusUpdateRequestBuilder |
| SC903-MAP-005 | Input `timeoutControlRef` | Harness Control | Reference解決 | TimeoutHarnessController |

CALL-001 Response全体をCALL-002 RequestへMergeしてはならない。Harness制御値をAPI Request Bodyへ混入してはならない。

## 13. Scenario Input契約

| 項目 | 設計 |
|---|---|
| Reference | `system/04_usecase_design/examples/input/SC-E6-903-input_Example.json` |
| Identity | `ENV-EXAMPLE-STAGING + UC-E6-901 + SC-E6-903 + INPUT-SC-E6-903-EXAMPLE-001` |
| 現在の状態 | STATIC EXAMPLE CREATED |
| 実行可否 | 不可 |

### 13.1 必須Reference

| Input Key | 目的 | 必須 | Null |
|---|---|:---:|:---:|
| `request.testDataId` | Test Data識別 | Yes | No |
| `request.dataSetVersion` | Data版識別 | Yes | No |
| `request.contentHash` | Data完全性 | Yes | No |
| `request.targetOrderRef` | 更新対象注文 | Yes | No |
| `request.expectedStartStateRef` | 開始状態 | Yes | No |
| `request.targetStateRef` | 目標状態 | Yes | No |
| `request.timeoutControlRef` | Timeout注入制御 | Yes | No |
| `request.outcomeConfirmationRef` | Recovery状態確認 | Yes | No |
| `request.cleanupRef` | 結果確認後Cleanup | Yes | No |
| `request.recoveryRef` | Recovery引渡し先 | Yes | No |

Referenceは非Secretの論理識別子である。Host、Token、Credential、実注文IDまたはTimeout秒数を直接保存しない。

### 13.2 API Call集合

Inputの`apis`は3件を宣言する。CALL-003は実行予定を意味するが、RuntimeではCALL-002 Timeoutにより`SKIPPED`へ遷移する。

## 14. Expected／Check契約

| 項目 | 設計 |
|---|---|
| Reference | `system/04_usecase_design/examples/expected/SC-E6-903-expected_Example.json` |
| Identity | Inputと同一 |
| Expected Execution | `UNKNOWN_OUTCOME` |
| Expected Verification | `PASS` |
| Expected Change | `NOT_COMPARED` |
| Expected Recovery | `REQUIRED` |
| Result Key数 | 9 |
| 現在の状態 | STATIC EXAMPLE CREATED |

### 14.1 必須Result Key

| 順序 | resultKey | resultType | apiCallCode | 期待 |
|---:|---|---|---|---|
| 10 | `CALL-001_RESPONSE_CONTRACT` | RESPONSE_CONTRACT | CALL-001 | PASS |
| 20 | `CALL-001_TARGET_IDENTIFIED` | BUSINESS_VALUE | CALL-001 | PASS |
| 30 | `CALL-002_TIMEOUT_OUTCOME` | API_CALL_OUTCOME | CALL-002 | PASS／TIMEOUT |
| 40 | `SC903_NO_AUTOMATIC_RETRY` | EXECUTION_TRACE | CALL-002 | PASS／1試行 |
| 50 | `SC903_UPDATE_OUTCOME_UNKNOWN` | SCENARIO_STATE | なし | PASS／UNKNOWN |
| 60 | `CALL-003_SKIPPED_AFTER_TIMEOUT` | EXECUTION_TRACE | CALL-003 | PASS／SKIPPED |
| 70 | `SC903_BASELINE_UPDATE_FORBIDDEN` | BASELINE_CONTROL | なし | PASS／false |
| 80 | `SC903_RECOVERY_HANDOFF_REQUIRED` | RECOVERY_CONTROL | なし | PASS／REQUIRED |
| 90 | `SC903_EVIDENCE_COMPLETENESS` | EVIDENCE_COMPLETENESS | なし | PASS |

`CALL-002_TIMEOUT_OUTCOME=PASS`はTimeout経路の観測と制御が期待どおりだったことだけを表す。更新処理の成否は断定せず、Execution `UNKNOWN_OUTCOME`とRecovery `REQUIRED`を保持する。

## 15. 四結果軸

| 軸 | 期待 | 根拠 |
|---|---|---|
| Execution Status | `UNKNOWN_OUTCOME` | CALL-002送信後にResponseを受領できず外部結果を断定できない。 |
| Verification Status | `PASS` | Timeout検出、Retry禁止、後続Skip、Baseline保護およびHandoffを評価できた。 |
| Change Status | `NOT_COMPARED` | CALL-002 Responseがなく、CALL-003も実行しない。 |
| Recovery Status | `REQUIRED` | 外部状態確認と運用判断が必要。 |

Timeoutがテスト目的どおり発生してもExecutionを`COMPLETED`へ丸めない。Verification `PASS`はTimeout制御Checkの適合だけを表し、更新API自体の成功を意味しない。

## 16. Scenario State遷移

```text
READY
→ CALL_001_COMPLETED
→ CALL_002_SENT
→ CALL_002_TIMEOUT
→ UPDATE_OUTCOME_UNKNOWN
→ CALL_003_SKIPPED
→ BASELINE_UPDATE_FORBIDDEN
→ RECOVERY_PENDING
→ TERMINATED_WITH_UNKNOWN_OUTCOME
```

| State | 必須記録 |
|---|---|
| `CALL_002_SENT` | 送信時刻、Request Hash、Idempotency Key Hash |
| `CALL_002_TIMEOUT` | Timeout分類、Duration、Client Error Reference |
| `UPDATE_OUTCOME_UNKNOWN` | 推測禁止理由 |
| `CALL_003_SKIPPED` | Skip Reason、前提Call |
| `RECOVERY_PENDING` | Recovery ID、Owner、引渡し時刻 |

## 17. Retry／Idempotency

| 項目 | 設計 |
|---|---|
| API Client自動Retry | 0 |
| Scenario自動Retry | 0 |
| Scheduler同一Run再送 | 禁止 |
| Idempotency Key | CALL-002送信前に一意生成しHash保存 |
| Idempotency Key再利用 | Recovery承認なしに禁止 |
| 新規Run | 前RunのOutcome確認とData状態確定後だけ許可 |

Idempotency Keyは重複排除の補助手段であり、Providerの保証範囲と状態確認なしに再送を正当化しない。

## 18. Recovery責務

### 18.1 ScenarioからRecoveryへの引渡し

| Handoff項目 | 内容 |
|---|---|
| Run Identity | Environment、UseCase、Scenario、Input Set、Run ID |
| Call Identity | `SC-E6-903 + CALL-002` |
| Target Reference | Mask済み対象Reference |
| Request Evidence | Request Hash、Version、目標状態 |
| Transport Evidence | 送信時刻、Timeout分類、Duration |
| Idempotency Evidence | Idempotency Key Hash |
| Outcome | `UNKNOWN` |
| Required Procedure | `recoveryRef`、`outcomeConfirmationRef` |
| Cleanup | Outcome確認後だけ`cleanupRef`を評価 |

### 18.2 Recoveryが判断する事項

1. Providerが更新Requestを受理・Commitしたか。
2. 現在状態とVersionが何であるか。
3. 同一Requestの再送が安全か。
4. Cleanupが必要かつ安全か。
5. Test Dataを再利用可能にできるか。

### 18.3 Scenarioが行ってはならない事項

- Timeoutを未更新と仮定する。
- Timeoutを更新成功と仮定する。
- CALL-003をRecovery照会として流用する。
- 自動再送する。
- 状態確認前にCleanupする。
- Recovery完了前にTest Data Leaseを通常解放する。

## 19. Baseline管理

本ScenarioのTimeout RunはComplete Runではないため、Baseline更新元に使用しない。

| 条件 | 判定 |
|---|---|
| CALL-002 Responseなし | 不完全 |
| CALL-003 SKIPPED | 不完全 |
| Execution Status `UNKNOWN_OUTCOME` | 更新禁止 |
| 必須通常Artifact欠落 | 更新禁止 |
| Recoveryが後日完了 | 元Timeout RunをBaselineへ昇格しない |

旧Baselineを維持し、Execution Stateの`previousRunId`をTimeout Runへ更新しない。Recovery成果物は別Identityで追跡する。

## 20. Diff／Compare

| Call | Response | Diff |
|---|---|---|
| CALL-001 | あり | CALL-001専用Baselineと比較可能 |
| CALL-002 | なし | `NOT_COMPARED` |
| CALL-003 | SKIPPED | `NOT_COMPARED` |

CALL-001だけ比較できてもScenario全体をComplete Runとしない。部分Baseline更新は禁止する。

## 21. Evidence

| Artifact | CALL-001 | CALL-002 | CALL-003 | 必須 |
|---|:---:|:---:|:---:|:---:|
| Call Meta | Yes | Yes | Yes | Yes |
| Mask済Request | Yes | Yes | No | 条件付 |
| Mask済Response | Yes | No | No | 条件付 |
| Response Field Diff | Yes | No | No | 条件付 |
| Timeout Error | No | Yes | No | Yes |
| Retry Count | No | Yes | No | Yes |
| Skip Record | No | No | Yes | Yes |
| Scenario State | - | - | - | Yes |
| Recovery Handoff | - | - | - | Yes |
| Artifact Manifest | - | - | - | Yes |

CALL-003のCall Metaは`SKIPPED`と理由を示す最小Artifactであり、Request／Responseファイルを空JSONで捏造しない。

## 22. Error分類

| Error Code | 条件 | Execution | Verification | Recovery |
|---|---|---|---|---|
| `SC903_UPDATE_TIMEOUT` | CALL-002正式Timeout | UNKNOWN_OUTCOME | PASSまたはNOT_EVALUATED | REQUIRED |
| `SC903_TIMEOUT_HARNESS_ERROR` | Harness起動／対象制御失敗 | INCOMPLETE | NOT_EVALUATED | 条件付 |
| `SC903_RETRY_DETECTED` | CALL-002送信試行が2回以上 | UNKNOWN_OUTCOME | FAIL | REQUIRED |
| `SC903_SKIP_VIOLATION` | Timeout後にCALL-003送信 | UNKNOWN_OUTCOME | FAIL | REQUIRED |
| `SC903_RECOVERY_REF_MISSING` | Recovery引渡し先なし | UNKNOWN_OUTCOME | FAIL | REQUIRED |
| `SC903_BASELINE_UPDATE_VIOLATION` | Timeout RunからBaseline更新 | INCOMPLETE | FAIL | REQUIRED |

## 23. Java実装契約

### 23.1 Class

```text
com.example.e6.scenario.OrderStatusChangeTimeoutScenario
com.example.e6.scenario.builder.OrderQueryRequestBuilder
com.example.e6.scenario.builder.OrderStatusUpdateRequestBuilder
com.example.e6.api.OrderQueryApiClient
com.example.e6.api.OrderStatusUpdateApiClient
com.example.e6.harness.TimeoutHarnessController
com.example.e6.recovery.RecoveryHandoffService
com.example.e6.check.OrderStatusChangeTimeoutCheckRegistry
```

Class名はExampleであり、正式Java Source RootまたはPackageを確定しない。

### 23.2 擬似処理

```java
CallResult before = orderQueryApiClient.execute(
        orderQueryRequestBuilder.build(input.targetOrderRef()));

preUpdateChecks.verify(before, input);
timeoutHarnessController.arm(input.timeoutControlRef(), "CALL-002");

try {
    orderStatusUpdateApiClient.executeOnce(
            orderStatusUpdateRequestBuilder.build(before, input));
    throw new UnexpectedCallOutcomeException("TIMEOUT was expected");
} catch (ReadTimeoutException ex) {
    context.markTimeout("CALL-002", ex);
    context.markUpdateOutcomeUnknown();
    context.skip("CALL-003", "PREVIOUS_CALL_TIMEOUT");
    baselineManager.forbidUpdate(context.runId());
    recoveryHandoffService.handoff(context, input.recoveryRef());
}
```

### 23.3 実装禁止

- HTTP Clientの暗黙Retryを有効にする。
- Timeout ExceptionをHTTP 500 Responseへ変換する。
- Timeout catch内でCALL-003を呼び出す。
- `UNKNOWN`をBoolean `false`へ変換する。
- Recovery ProcedureをScenario Classへ埋め込む。
- Expected JSONから任意Scriptを実行する。

## 24. Security／Safety

| 対象 | 保存 | 保護 |
|---|:---:|---|
| Authorization | No | 全Mask |
| Idempotency Key | 条件付 | Hashのみ |
| Order ID | Yes | 末尾以外Mask |
| Timeout Control | Referenceのみ | 実設定非保存 |
| Error Message | Yes | Secret／個人情報検査 |
| Recovery Reference | Yes | 実Credential非保存 |

Timeout HarnessはProduction相当Environmentで既定無効とし、対象Call、対象Run、適用時間、Ownerおよび自動解除条件を持つ。

## 25. Test Data／並行実行

| 制御 | 要求 |
|---|---|
| Lease | Run開始前に一意取得 |
| 並行Run | 同一対象への同時更新禁止 |
| Timeout後Lease | Recovery完了まで隔離状態 |
| 再利用 | Outcome、Cleanup、Version確認後だけ許可 |
| Harness Scope | Run ID＋CALL-002に限定 |
| 残存確認 | Harness解除とData状態の両方を確認 |

## 26. Validation

| Rule ID | 確認内容 | 期待 |
|---|---|---|
| SC903-V001 | Scenario Master Exampleの固定項目と一致する。 | PASS |
| SC903-V002 | Input／Expected／設計書Identityが一致する。 | PASS |
| SC903-V003 | 呼出集合がCALL-001～003で一意である。 | PASS |
| SC903-V004 | CALL-002の期待OutcomeがTIMEOUTである。 | PASS |
| SC903-V005 | CALL-002送信試行回数が1である。 | PASS |
| SC903-V006 | CALL-003がSKIPPEDである。 | PASS |
| SC903-V007 | 更新結果がUNKNOWNである。 | PASS |
| SC903-V008 | Timeout RunのBaseline更新が禁止される。 | PASS |
| SC903-V009 | Recovery引渡しが必須である。 | PASS |
| SC903-V010 | 9 Result KeyがJava Registryと双方向一致する。 | BLOCKED |
| SC903-V011 | 900番台が正式Master／Runtimeから分離される。 | PASS |

## 27. Review Checklist

### 27.1 Flow

- [ ] CALL-001成功、CALL-002 Timeout、CALL-003 Skipが一意である。
- [ ] 未計画CallとSkip Callを区別する。
- [ ] Timeout以外のErrorを期待Timeoutへ丸めない。

### 27.2 Result

- [ ] Execution、Verification、Change、Recoveryを分離する。
- [ ] 更新結果を`UNKNOWN`として保持する。
- [ ] 技術ErrorをScenario PASSへ変換しない。

### 27.3 Recovery

- [ ] 状態確認、再送判断およびCleanupのOwnerが明確である。
- [ ] ScenarioとRecoveryのExecution Identityを分離する。
- [ ] Recovery前のLease解放とData再利用を禁止する。

### 27.4 Runtime

- [ ] Client／Scenario／Schedulerの自動Retryが0である。
- [ ] Timeout HarnessのScopeと解除条件が明確である。
- [ ] 不完全RunからBaselineを更新しない。

### 27.5 Security

- [ ] Secret、Credential、実注文IDまたはTimeout秒数が保存されていない。
- [ ] Request、Error、Idempotency KeyおよびEvidenceのMaskが定義される。

## 28. 完了条件

1. Input、ExpectedおよびScenario設計のIdentityが一致する。
2. CALL-001成功、CALL-002 Timeout、CALL-003 Skipを機械判定できる。
3. No Retry、UNKNOWN、Baseline保護およびRecovery引渡しを確認できる。
4. 9 Result Keyが標準`resultType`だけを使用する。
5. Example値が正式MasterおよびRuntimeから分離される。
6. Markdown、JSONおよびReference Validationを通過する。

## 29. Release Blocker

本書は教育用Exampleであり正式Release対象外である。さらに次が未解決であるためRuntime実行不可とする。

- `SC-E6-903.enabled=false`
- Java Scenario、Builder、Client、Harness、Recovery ServiceおよびCheck Registry未実装
- Environment、Secret、Test Data、Lease、Timeout ControlおよびRecovery実体なし
- 9 Result KeyとJava Check Registryの双方向照合未実施
- ProviderのIdempotency保証および再送条件未承認
- Timeout Harness／Fault Injection方式未承認

## 30. Open Issues

| Issue ID | 内容 | 影響 | Owner | 状態 |
|---|---|---|---|---|
| SC903-OI-001 | Java Example未実装 | Static設計とBuildを照合できない。 | Example Java Team | OPEN |
| SC903-OI-002 | Timeout Harness実体なし | Timeoutを安全・再現可能に発生させられない。 | Example Test Platform Team | OPEN |
| SC903-OI-003 | Recovery Procedure実体なし | Outcome確認、再送判断、Cleanupを実行できない。 | Example Operations Team | OPEN |
| SC903-OI-004 | Provider Idempotency保証が架空 | 再送可否を確定できない。 | Example API Owner | OPEN |
| SC903-OI-005 | Java Check Registry未実装 | 9 Result Keyを実行できない。 | Example Verification Team | OPEN |

## 31. 禁止事項

- 本Exampleを正式E6 Timeout仕様として引用する。
- `SC-E6-903`を正式Masterへ登録する。
- Timeoutを未更新または更新成功と推測する。
- Timeoutを想定内という理由でExecution `COMPLETED`またはVerification `PASS`にする。
- HTTP Status、Response DTOまたはResponse Bodyを捏造する。
- CALL-003を通常FlowまたはRecovery照会として実行する。
- Client、ScenarioまたはSchedulerから自動Retryする。
- Outcome確認前にCleanupまたはTest Data再利用を行う。
- Timeout RunからBaselineの全部または一部を更新する。
- Harness制御値をAPI Requestへ混入する。

## 32. 次工程

1. Java ExampleのSource RootとPackage構成を確定する。
2. `OrderStatusChangeTimeoutScenario`と9 Checkを実装する。
3. Timeout Harness、Recovery HandoffおよびEvidence Artifact Schemaを設計する。
4. ProviderのIdempotency保証、状態確認手順、再送条件およびCleanupを承認する。
5. 静的Validation通過後も`enabled=false`を維持し、Runtime Gateを別途審査する。
