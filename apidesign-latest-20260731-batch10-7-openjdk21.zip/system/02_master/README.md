---
title: 02_master README
document_id: README-E6-MST-001
version: 2.0.0-draft.5
status: DRAFT
document_type: README
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 02_master README

## 1. 目的

`system/02_master/`は、E6 API Verification Platformで共通参照する安定した識別情報と、その作成・Review・整合性確認に必要な文書を管理する。

本Directoryは、実行ごとに変化する値、Scenario固有の実行詳細、Expected、Runtime状態またはJava比較ロジックを管理しない。

## 2. 正式構成

```text
system/
└── 02_master/
    ├── README.md
    ├── Business_Master.md
    ├── Environment_Master.md
    ├── API_Master.md
    ├── UseCase_Master.md
    ├── Scenario_Master.md
    ├── API_UseCase_Scenario対応表.md
    │
    ├── design/
    │   ├── Master共通設計書.md
    │   ├── Business_Master設計書.md
    │   ├── Environment_Master設計書.md
    │   ├── API_Master設計書.md
    │   ├── UseCase_Master設計書.md
    │   ├── Scenario_Master設計書.md
    │   └── API・UseCase・Scenario対応表設計書.md
    │
    ├── guide/
    │   ├── Master作成・更新ガイド.md
    │   └── Master_ID・Reference記述ガイド.md
    │
    ├── checklist/
    │   ├── MasterレビューChecklist.md
    │   └── Master整合性Checklist.md
    │
    └── examples/
        ├── Business_Master_Example.md
        ├── Environment_Master_Example.md
        ├── API_Master_Example.md
        ├── UseCase_Master_Example.md
        ├── Scenario_Master_Example.md
        └── API_UseCase_Scenario対応表_Example.md
```

この構成はMaster領域の正式な固定構成である。新しいMaster種別、Directoryまたは正式列を追加する場合は、先に`Master共通設計書.md`を変更し、Architecture Reviewと承認を得る。

## 3. Master体系

| Master | 正式ファイル | 主ID | 管理責務 |
|---|---|---|---|
| Business | `Business_Master.md` | `businessId` | 業務分類、業務境界、業務の固定識別 |
| Environment | `Environment_Master.md` | `environmentId` | 論理実行環境の固定識別と適用情報 |
| API | `API_Master.md` | `apiId` | API自身の安定した技術属性 |
| UseCase | `UseCase_Master.md` | `useCaseId` | 一つの業務検証目的、範囲、所属Scenario |
| Scenario | `Scenario_Master.md` | `scenarioId` | 一つの確定業務経路と実行資産参照 |

Masterはこの5種類だけとする。

## 4. Traceability View

`API_UseCase_Scenario対応表.md`は、UseCase、Scenario、APIおよびScenario内API呼出を横断表示する正式成果物である。ただしMasterではなく、次の正本から導出するTraceability Viewである。

| 表示情報 | 正本 |
|---|---|
| UseCase属性 | `UseCase_Master.md` |
| Scenario属性 | `Scenario_Master.md` |
| API属性 | `API_Master.md` |
| `apiCallCode`、`callSequence`、呼出目的、実行条件 | Scenario詳細設計書 |

対応表の1行は`scenarioId + apiCallCode`で識別する。対応表だけを変更してJavaの呼出順序、呼出先または条件を変更してはならない。

## 5. 正本関係

```mermaid
flowchart TD
    B["Business Master"]
    U["UseCase Master"]
    S["Scenario Master"]
    D["Scenario詳細設計"]
    A["API Master"]
    T["Traceability View"]

    B --> U
    U --> S
    S --> D
    A --> D
    D --> T
    U --> T
    A --> T
```

Environment MasterはUseCaseの適用環境を識別する。実際のCredential、Secret、Host別機密設定および実行時状態はEnvironment Masterへ記載しない。

## 6. Directory別責務

| Directory | 責務 | 変更起点 |
|---|---|---|
| `02_master/` | 正式MasterとTraceability View | 各Master Owner |
| `design/` | 正式列、型、必須、Enum、責務境界、Validation設計 | System Architect／各Domain Lead |
| `guide/` | 作成・更新、採番、Referenceの実作業手順 | Master Governance Owner |
| `checklist/` | 人のReviewと機械的整合性確認 | Reviewer／Validation Owner |
| `examples/` | 架空値による記入例 | Documentation Owner |

Exampleは正本ではなく、正式E6値を保証しない。

## 7. 文書の使い分け

| 知りたい内容 | 最初に読む文書 |
|---|---|
| Master全体の思想と責務境界 | `design/Master共通設計書.md` |
| 各Masterの正式項目と個別規則 | 対象の`design/*_Master設計書.md` |
| 対応表14項目と導出規則 | `design/API・UseCase・Scenario対応表設計書.md` |
| Masterを追加・変更・無効化する手順 | `guide/Master作成・更新ガイド.md` |
| ID、採番、Path、List、Class Reference | `guide/Master_ID・Reference記述ガイド.md` |
| 人による妥当性Reviewと承認 | `checklist/MasterレビューChecklist.md` |
| Cross-Master整合性とRelease Gate | `checklist/Master整合性Checklist.md` |
| 記入方法 | 対応する`examples/*_Example.md` |

## 8. 標準作業順序

```text
根拠資料確認
→ 正本とOwner特定
→ ID採番または既存ID継続判断
→ 対象Master／詳細設計更新
→ Java・DTO・Input・Expected影響反映
→ Traceability View再生成
→ 整合性Validation
→ 人によるReview
→ Release Gate
→ 承認・凍結
```

詳細は`guide/Master作成・更新ガイド.md`に従う。

## 9. IDの基本

| ID | 例 | Scope | 正本 |
|---|---|---|---|
| `businessId` | `BUS-E6-001` | 全システム | Business Master |
| `environmentId` | `ENV-STAGING` | 全システム | Environment Master |
| `apiId` | `API-001` | 全システム | API Master |
| `useCaseId` | `UC-E6-001` | 全システム | UseCase Master |
| `scenarioId` | `SC-E6-001` | 全システム | Scenario Master |
| `apiCallCode` | `CALL-001` | 一つのScenario内 | Scenario詳細設計 |
| `resultKey` | Stable Key | 定義されたCheck Scope | Scenario設計／Expected／Java |

IDは初回登録後に変更しない。名称、Path、Class名、`callSequence`または表示順をIdentityとして利用しない。900番台はExample専用とし、正式Masterへ登録しない。

## 10. `enabled`と文書状態

| 項目 | 対象 | 意味 |
|---|---|---|
| `status` | 文書 | `DRAFT`、`IN_REVIEW`、`APPROVED`、`RELEASED`、`DEPRECATED`、`RETIRED`の文書Lifecycle |
| `enabled` | Masterレコード | 新しい設計・実行計画から参照可能か |
| `relationStatus` | 対応表行 | 関係する正本の`enabled`から導出した状態 |

これらを相互の代替として使用してはならない。

## 11. Masterへ置かない情報

次の情報はMaster化しない。

- API呼出順序、分岐、Skip、`apiCallCode`
- Request実値、Test Data、API間値引継ぎ
- Expected値、`resultKey`、Business Check
- `IGNORE_FIELD`、`IGNORE_VALUE`
- Context、ApiExchange、Run ID
- Previous、Current、Baseline、Snapshot、Diff
- Execution／Verification／Change／Recoveryの実行結果
- Retry、Timeout、並列数、Scheduler時刻

これらはScenario詳細設計、Java、Input、Expected、Runtime、Diffまたは運用設計を正本とする。

## 12. 禁止されるMaster

次の旧分類は現在のMaster体系に含めない。

- Context Master
- Verification Master
- Verification Policy Master
- Compare Policy Master

必要な共通規則は通常の設計書またはJava実装で管理し、Masterとして復活させない。

## 13. Validation

Validationは次の順で実施する。

1. File Inventory
2. Front Matter／Markdown
3. 単一Master Schema
4. ID
5. ID／File Reference
6. Cross-Master
7. Scenario詳細設計／Java
8. Traceability View／Coverage
9. 状態・責務境界
10. Release Gate

正式Rule、結果形式および現行E6の既知Errorは`checklist/Master整合性Checklist.md`を参照する。

## 14. ReviewとRelease

Releaseには次が必要である。

1. 対象文書が承認済みである。
2. Validation `ERROR`が0件である。
3. `WARNING`が修正済みまたは承認済みである。
4. 有効ID、File Reference、Java ClassおよびDTOが解決可能である。
5. 有効UseCase、ScenarioおよびAPIの関係が実行可能である。
6. 対応表が正本とScenario詳細設計に一致する。
7. 変更履歴、影響分析、Reviewおよび承認Evidenceが存在する。

人のReviewは`checklist/MasterレビューChecklist.md`、整合性検証は`checklist/Master整合性Checklist.md`を使用する。

## 15. 現行E6データの注意事項

現時点の正式登録件数は、Business、API、UseCase、ScenarioおよびAPI呼出関係のすべてが0件である。

これは検証対象が存在しないことを意味せず、7業務Flowの現行業務分析、API分析およびOwner Reviewが未完了であることを意味する。架空値で空表を補完したり、Recoveryまたは900番台Exampleから正式レコードを生成してはならない。

初回正式登録は次の順序で行う。

1. 現行業務分析からBusinessを登録する。
2. API分析からAPIを登録する。
3. Business目的とAPI連鎖からUseCaseを登録する。
4. 承認済み経路からScenarioを登録する。
5. Scenario詳細設計から対応表を生成する。

正式登録が0件である期間はRuntime実行対象も0件とし、Release判定は`BLOCKED`とする。

## 16. 変更ルール

1. 変更前に正本とOwnerを特定する。
2. 同じ情報を複数Masterへ重複登録しない。
3. 関係変更ではUseCase、Scenario、API、詳細設計、Javaおよび対応表への影響を確認する。
4. 無効化済みIDを再利用しない。
5. 物理削除前に参照0件と過去Runの解決性を確認する。
6. 対応表およびExampleを変更起点にしない。
7. 構成、Master種別または正式列を承認なしに追加しない。

## 17. 文書メタデータ

新規・更新文書のFront Matterは`snake_case`を使用する。

```yaml
---
title: Scenario Master
document_id: MST-E6-SC-001
version: 1.0.0-draft.1
status: DRAFT
document_type: Master
system_name: E6 API Verification Platform
updated: 2026-07-27
---
```

同一文書内で`snake_case`と`camelCase`を混在させない。既存の旧形式文書は、内容変更時に同一Change Setで移行する。

## 18. 完了・凍結条件

`02_master`を対象Releaseで凍結するには、次をすべて満たす。

1. 五つのMasterとTraceability Viewの責務が承認されている。
2. 全設計書、Guide、ChecklistおよびExampleが正式構成にそろっている。
3. Cross-Master Validationが完了している。
4. Validation `ERROR`が0件である。
5. 未決事項にOwner、期限およびRelease影響がある。
6. 必須ReviewerとApproverのEvidenceがある。
7. 対象Source Versionを一意に識別できる。

現行E6データは正式Business、API、UseCase、ScenarioおよびTraceability行が0件であり、Environmentの外部Configuration／Authentication Referenceも未確認であるため、文書内容の整備は完了しても業務データReleaseおよびRuntime Gateは`BLOCKED`である。正式Scenarioが0件のため、`TRC-V008`等のレコード間Validationは`NOT_APPLICABLE`であり、現行データ不整合として扱わない。

## 19. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 五つのMaster、一つのTraceability View、設計書、Guide、ChecklistおよびExampleの正式入口として全面再作成し、Front Matter LifecycleをCanonical値へ統一。 |
| `2.0.0-draft.2` | 2026-07-27 | Framework横断再走査によりMaster非保持対象の実行結果をCanonical四結果軸へ統一。 |
| `2.0.0-draft.3` | 2026-07-29 | `REP-MIG-002／003`によるAPI Master／Exampleの最終File名移行に伴い、Current Referenceを同期。文書固有の責務と業務内容は変更なし。 |
| `2.0.0-draft.4` | 2026-07-29 | Master共通設計書の全面再作成に合わせ、正式レコード0件時の構造Validation、Cross-Master `NOT_APPLICABLE`および業務データ／Runtime `BLOCKED`を分離。 |
| `2.0.0-draft.5` | 2026-07-29 | `ENV-PROD`の本番確定とProduction-like廃止を反映し、Masterごとの正式項目数を個別設計書で管理する表現へ変更。 |
