---
title: Business Master設計書
document_id: DES-MST-E6-BUS-001
version: 2.0.0-draft.2
status: DRAFT
document_type: Master Design
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# Business Master設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Business Master設計書 |
| 文書ID | `DES-MST-E6-BUS-001` |
| 対象Master | `system/02_master/Business_Master.md` |
| 対象システム | E6 API Verification Platform |
| 版数 | `2.0.0-draft.2` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Verification Platform Team |
| レビュー責任 | System Architect / Business Analysis Lead / UseCase Design Lead |
| 承認責任 | System Owner / Business Owner |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 五つのMaster、Java First、固定10項目および廃止Master非依存の責務に基づき全面再作成し、Lifecycle StatusをCanonical値へ統一 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | Framework横断再走査によりScenarioContext参照とMaster非保持対象のCanonical四結果軸を同期 | DRAFT |

## 3. 目的

本書は、E6 API Verification Platformで使用するBusiness Masterの責務、業務粒度、正式項目、ID、Reference、Validation、変更管理および他成果物との境界を定義する。

Business Masterは、検証対象となる安定した業務分類または業務境界を`businessId`で識別し、次の問いに対する正本を提供する。

- どのBusinessが存在するか。
- Businessの正式名称、分類、目的および境界は何か。
- どのSystemのBusinessか。
- 根拠となる現行業務分析成果物は何か。
- Businessの管理責任者は誰か。
- 新しいUseCaseから参照可能なBusinessか。

Business Masterは、業務分析書、UseCase設計書、Scenario実行仕様またはJava検証実装の代替ではない。

## 4. 適用範囲

本書は、現行7業務Flowを整理して得られる安定したBusiness定義に適用する。

Businessは次の単位で登録する。

1. 業務担当者が目的と責任範囲を独立して説明できる。
2. 複数のUseCaseから共通参照できる。
3. API、Scenario、入力値または実行Environmentが変わってもBusinessとしての同一性を維持する。
4. 業務分析成果物に根拠を持つ。

単一API、単一Scenario、一時的なTest Patternまたは日次Run単位をBusinessとして登録してはならない。

## 5. 基本原則

| 原則ID | 原則 | 説明 |
|---|---|---|
| `BUS-MST-P001` | One Stable Boundary | 一つの安定した業務分類・境界を一つのレコードとする。 |
| `BUS-MST-P002` | Business Analysis First | Businessの目的と境界は現行業務分析成果物を根拠とする。 |
| `BUS-MST-P003` | Stable Identity | 名称変更では`businessId`を変更しない。 |
| `BUS-MST-P004` | No Flow Duplication | Flow Step、分岐、API順序をMasterへ複製しない。 |
| `BUS-MST-P005` | No Execution Detail | Input、Context、Expected、DiffまたはRun状態を保持しない。 |
| `BUS-MST-P006` | No Reverse List | API、UseCase、Scenarioの逆参照一覧を正式列として保持しない。 |
| `BUS-MST-P007` | Explicit Source | 根拠となる業務分析成果物をReferenceで追跡する。 |
| `BUS-MST-P008` | Explicit Ownership | Business境界の判断責任をRoleまたは組織で明確にする。 |
| `BUS-MST-P009` | Fail Fast | 未確認の有効BusinessをRelease入力にしない。 |
| `BUS-MST-P010` | History Retention | 利用停止時も物理削除せず`enabled=false`で追跡性を保持する。 |

## 6. 責務

Business Masterは、次の10項目だけを正式レコードとして管理する。

1. Business ID
2. Business名称
3. System ID
4. Business分類
5. Business目的
6. Business Scope
7. 現行業務分析書Reference
8. Business Owner
9. 有効フラグ
10. 説明

## 7. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| 詳細な業務背景、Actor、前提、Flow、分岐、終了条件 | `business/`配下の現行業務分析成果物 |
| Businessに属するUseCaseの詳細 | UseCase MasterおよびUseCase設計書 |
| Businessに属するScenarioの経路 | Scenario MasterおよびScenario詳細設計書 |
| API一覧、API呼出順序、分岐、Skip、`apiCallCode` | Scenario詳細設計書およびJava実装 |
| Request／Response項目、型、長さ、必須、固定値 | API詳細設計書およびDTO |
| Request初期値、Test Data | Scenario Input |
| API間の値引継ぎ、ScenarioContext、ApiExchange | Scenario設計、ScenarioContext設計およびJava |
| Expected、`resultKey`、Business Check | Scenario ExpectedおよびJava Check |
| `IGNORE_FIELD`、`IGNORE_VALUE`、Diff判定 | Java比較定義およびAPIレスポンスDiff設計書 |
| Previous、Current、Baseline、Run ID | Execution StateおよびRun成果物 |
| `NOT_EVALUATED`、`PASS`、`FAIL` | Verification Result |
| Execution／Change／Recovery Status | Run Result／Execution State |
| Base URL、Authentication、Credential | Environment Masterおよび外部実行設定 |
| Retry、Timeout、並列数、Schedule | Runtime設定および運用設計 |

Context、Verification、Verification PolicyまたはCompare PolicyをBusiness Masterから参照してはならない。これらは現在のMaster体系に存在しない。

## 8. 関連成果物と正本境界

```mermaid
flowchart TD
    BA["現行業務分析<br/>目的・Flow・根拠"]
    B["Business Master<br/>Identity・境界"]
    U["UseCase Master<br/>検証目的"]
    S["Scenario Master<br/>確定経路"]
    D["Scenario設計・Java<br/>API実行・Check"]

    BA --> B
    B --> U
    U --> S
    S --> D
```

| 成果物 | Business Masterとの関係 | 正本 |
|---|---|---|
| 現行業務分析書 | Businessの目的、背景、ScopeおよびFlowの根拠を提供する。 | 業務分析詳細 |
| `Business_Master.md` | Business Identityと固定10項目を登録する。 | Business固定属性 |
| `UseCase_Master.md` | `businessIds`でBusinessを参照する。 | UseCase属性 |
| `Scenario_Master.md` | UseCaseを介してBusinessへ追跡する。 | Scenario属性 |
| `API_UseCase_Scenario対応表.md` | Businessを直接の実行Keyにせず、UseCase以降の横断関係を表示する。 | Traceability View |
| Java Scenario実装 | Business IDをEvidenceへ引き継げるが、Business定義を上書きしない。 | 実行実装 |

BusinessからUseCaseへの逆参照は次の検索で導出する。

```text
UseCase_Master.businessIds contains businessId
```

Business Masterへ`useCaseIds`、`scenarioIds`または`apiIds`を追加して二重正本化してはならない。

## 9. Business成立条件

次をすべて満たす対象を一つのBusinessとして登録する。

1. 業務目的を一文で説明できる。
2. In ScopeとOut of Scopeを区別できる。
3. 一つ以上のUseCaseから共通参照される、または参照予定が承認されている。
4. 特定APIの存在だけに依存しない。
5. 業務分析成果物に根拠がある。
6. 境界判断のOwnerが存在する。

次の差異だけでは新しいBusinessを作成しない。

| 差異 | 取扱い |
|---|---|
| 正常、代替、異常経路 | Scenarioを分ける。 |
| 業務目的内の検証範囲 | UseCaseを分ける。 |
| Request値、Test Data | Scenario Inputを分ける。 |
| API呼出先または順序 | Scenario詳細設計を変更する。 |
| Environment | UseCaseの適用Environmentまたは実行設定で扱う。 |
| Expected、Check、Diff | ExpectedまたはJava実装で扱う。 |

## 10. 正式レコード

`Business_Master.md`では、一行を一つのBusinessとする。正式列は次の10項目とし、順序を固定する。

| No. | 表示名 | 列名 | 型 | 必須 | 設定規則 |
|---:|---|---|---|:---:|---|
| 1 | Business ID | `businessId` | String | Yes | `BUS-E6-NNN`形式。一意かつ不変。 |
| 2 | Business名称 | `businessName` | String | Yes | 業務担当者が識別できる正式名称。 |
| 3 | System ID | `systemId` | String | Yes | 対象Systemの固定ID。本Projectでは原則`E6`。 |
| 4 | Business分類 | `businessCategory` | Enum | Yes | 許可Enumから一つ設定する。 |
| 5 | Business目的 | `businessPurpose` | String | Yes | 業務が達成する目的を一文で記述する。 |
| 6 | Business Scope | `businessScope` | String | Yes | In Scopeと境界を判断可能な一文で要約する。 |
| 7 | 現行業務分析書参照 | `businessAnalysisRef` | Path | Yes | Repository Root基準。正式Business登録前に実在し、IDと内容が一致すること。 |
| 8 | Business Owner | `businessOwner` | String | Yes | 氏名ではなく、原則として正式なRoleまたは組織を記述する。 |
| 9 | 有効フラグ | `enabled` | Boolean | Yes | `true`または`false`。 |
| 10 | 説明 | `description` | String | Yes | 他Businessとの違いが分かる補足。 |

記述形式は次のとおりである。

```markdown
| businessId | businessName | systemId | businessCategory | businessPurpose | businessScope | businessAnalysisRef | businessOwner | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|
| BUS-E6-901 | 注文状態管理業務 | E6 | UPDATE | 注文状態を許可された状態へ変更し、結果を確認可能にする架空Example。 | 注文情報の確認から状態変更結果の確認まで。 | business/examples/注文状態管理_現行業務分析書_Example.md | Order Business Owner | true | 900番台の記入例。正式Masterへコピーしない。 |
```

`businessAnalysisRef=NONE`は未確認値を正式化するための値ではない。正式Businessの先行仮登録には使用せず、業務分析書完成後に登録する。

## 11. 項目別設計規則

### 11.1 `businessId`

- Patternは`^BUS-E6-[0-9]{3,}$`とする。
- Repository全体で一意とする。
- 名称、Ownerまたは詳細文書Pathの変更ではIDを維持する。
- Businessの目的または境界が別物になる分割・統合では、新IDを検討する。
- 廃止ID、欠番および900番台Example IDを再利用しない。

### 11.2 `businessName`

- 日本語の正式業務名称とする。
- 「正常系」「異常系」「API-001」等のScenarioまたはAPI表現を名称にしない。
- Environment名、年度またはTest Data識別子を含めない。

### 11.3 `systemId`

- 対象Systemの固定識別子を設定する。
- Host、Environment ID、Repository名またはJava Module名を設定しない。
- 複数Systemに跨る場合も、本MasterではBusinessの主対象Systemを設定し、詳細は業務分析書で説明する。

### 11.4 `businessCategory`

許可値は次のとおりとする。

| 値 | 意味 |
|---|---|
| `INQUIRY` | 照会・取得を主目的とする業務 |
| `REGISTRATION` | 新規登録を主目的とする業務 |
| `UPDATE` | 既存状態の更新を主目的とする業務 |
| `CANCELLATION` | 取消、無効化または削除を主目的とする業務 |
| `FILE` | File入出力を主目的とする業務 |
| `COMMON` | 複数業務に共通する業務境界 |
| `OTHER` | 上記に該当せず、理由を`description`へ記載する業務 |

分類はAPI MethodやData Impactの完全な代替ではない。一つの主分類を設定し、複合的な業務内容は業務分析書へ記載する。

### 11.5 `businessPurpose`

- 「何のための業務か」を業務用語で一文にする。
- 「APIを呼び出す」「Responseを比較する」等の技術手段を目的にしない。
- Expected結果またはCheck条件を記載しない。

### 11.6 `businessScope`

- 開始点、対象処理および終了境界を判断できるようにする。
- API Step、分岐条件、値Mappingまたは実行順序を列挙しない。
- 詳細は`businessAnalysisRef`の業務分析書を正本とする。

### 11.7 `businessAnalysisRef`

- Repository Root基準の相対Pathとする。
- `./`、`../`、絶対Path、URLまたは個人PCのPathを禁止する。
- 正式Businessの根拠となる業務分析成果物を指す。
- TemplateまたはExampleを正式Businessの根拠に使用しない。
- 業務分析書未作成のBusinessは正式Masterへ先行登録しない。

### 11.8 `businessOwner`

- 業務境界、名称および目的の判断責任を持つRoleまたは組織を設定する。
- 個人のメールアドレス、電話番号またはCredentialを記載しない。
- `NONE`または空欄を許可しない。

### 11.9 `enabled`

- `true`は新しいUseCaseから参照可能であることを表す。
- `false`は新規参照禁止であり、過去Traceabilityのためレコードを保持する。
- `businessAnalysisRef`が未解決またはOwner未承認のBusinessは正式登録できない。
- 文書`status`の代替として使用しない。

### 11.10 `description`

- Businessの境界または他Businessとの差異を補足する。
- 実行仕様、API一覧、ExpectedまたはRuntime値を記載しない。
- 補足不要の場合は`NONE`を明示する。

## 12. Reference規則

### 12.1 Forward Reference

Business Master自身が持つFile Referenceは`businessAnalysisRef`だけとする。

### 12.2 Reverse Reference

UseCaseからBusinessへのReferenceは`UseCase_Master.businessIds`を正本とする。

```text
Business → UseCase
    = UseCase MasterをbusinessIdで逆引き
```

### 12.3 Reference不一致

次を`ERROR`とする。

- UseCaseが存在しない`businessId`を参照する。
- 有効UseCaseが`enabled=false`のBusinessを参照する。
- `businessAnalysisRef`がPath規則に違反する。
- 参照先業務分析書の対象Businessが異なる。

`businessAnalysisRef`に`NONE`、空欄、ExampleまたはRecoveryを設定してはならない。業務分析書未完成の場合は候補管理に留め、正式Business一覧へ登録しない。

## 13. Validation

### 13.1 単一レコードValidation

| Rule ID | 規則 | Level |
|---|---|---|
| `BUS-MST-V001` | 正式表が10列で、列名と順序が本書に一致する。 | ERROR |
| `BUS-MST-V002` | `businessId`がPatternに一致し一意である。 | ERROR |
| `BUS-MST-V003` | 必須項目が空欄でない。 | ERROR |
| `BUS-MST-V004` | `businessCategory`が許可Enumである。 | ERROR |
| `BUS-MST-V005` | `enabled`がBooleanである。 | ERROR |
| `BUS-MST-V006` | `businessAnalysisRef`がPath規則に一致し、正式業務分析書として解決できる。 | ERROR |
| `BUS-MST-V007` | `businessPurpose`と`businessScope`がAPI実行仕様を含まない。 | ERROR |
| `BUS-MST-V008` | 900番台IDが正式Masterへ存在しない。 | ERROR |

### 13.2 Cross-Master Validation

| Rule ID | 規則 | Level |
|---|---|---|
| `BUS-MST-X001` | 全UseCaseの`businessIds`がBusiness Masterで解決できる。 | ERROR |
| `BUS-MST-X002` | 有効UseCaseが無効Businessを参照しない。 | ERROR |
| `BUS-MST-X003` | Businessから導出したUseCase集合がCoverage確認に使用できる。 | ERROR |
| `BUS-MST-X004` | Business名称とUseCaseの業務目的が明白に矛盾しない。 | WARNING |
| `BUS-MST-X005` | `businessAnalysisRef`の業務境界とMasterのScopeが一致する。 | ERROR |

### 13.3 Release Validation

| Rule ID | 規則 | 判定 |
|---|---|---|
| `BUS-MST-R001` | 有効Businessの`businessAnalysisRef`が実ファイルで解決できる。 | 未解決時`BLOCKED` |
| `BUS-MST-R002` | Business OwnerまたはBA Leadの承認Evidenceがある。 | 未承認時`BLOCKED` |
| `BUS-MST-R003` | 有効Businessを参照する有効UseCaseが一件以上ある、または未使用理由が承認されている。 | 未達時`WARNING` |
| `BUS-MST-R004` | Cross-Master `ERROR`が0件である。 | 未達時`FAIL` |

## 14. 変更管理

| 変更 | ID | 必要な処置 |
|---|---|---|
| 名称、説明、Owner変更 | 継続 | Master、業務分析書、Review Evidenceを更新する。 |
| Category変更 | 原則継続 | 業務目的・Scopeとの整合性を再Reviewする。 |
| Scopeの軽微な明確化 | 継続 | 関連UseCaseへの影響を確認する。 |
| Business境界の分割 | 新ID | 旧IDの扱い、UseCase移行および過去追跡を定義する。 |
| Business統合 | 新IDを検討 | 旧IDを無効化し、参照移行を記録する。 |
| 利用停止 | 継続 | `enabled=false`とし、新規参照を禁止する。 |
| 物理削除 | 原則禁止 | 参照0件、過去Run解決性および承認を確認する。 |

変更時は、Business Master、UseCase Master、業務分析書、Example、Validation結果およびTraceabilityへの影響を同一Change Setで確認する。

## 15. Java・Runtimeとの境界

Javaは`businessId`をExecution Identity、結果集約およびReport上の追跡に使用できる。

JavaがBusiness Masterから解決してよい情報は次のとおりである。

- Business ID
- Business名称
- System ID
- Category
- 有効状態

JavaがBusiness Masterから解決してはならない情報は次のとおりである。

- API呼出順序
- Request値
- Expected値
- Business Check式
- Ignore Field
- Baseline
- Retry、Timeout、Schedule

Java実装の都合で正式列を追加してはならない。

## 16. Review Checklist

- [ ] 一つの安定した業務分類・境界である。
- [ ] 他Businessと目的またはScopeが重複していない。
- [ ] 正式10項目と列順が本書に一致する。
- [ ] `businessId`が一意かつ不変である。
- [ ] 業務目的とScopeが業務用語で記述されている。
- [ ] 業務分析成果物が根拠として追跡可能である。
- [ ] Ownerが業務境界を承認している。
- [ ] UseCaseの`businessIds`が解決できる。
- [ ] API、Scenario、Expected、DiffまたはRuntime情報が混入していない。
- [ ] 廃止済みMasterを参照していない。

## 17. 完了条件

本設計書は次をすべて満たした時点で内容完成とする。

1. 正式10項目、型、必須およびEnumが確定している。
2. Business粒度と業務分析成果物との境界が定義されている。
3. UseCaseからのReferenceと逆引き規則が定義されている。
4. ValidationとRelease Gateが定義されている。
5. `Business_Master.md`と`Business_Master_Example.md`が本書に一致する。
6. `Master共通設計書.md`、GuideおよびChecklistと矛盾しない。
7. Context、Verification、Verification PolicyまたはCompare Policy Masterへ依存しない。

内容完成はRelease凍結を意味しない。有効Businessの根拠資料または承認が未解決の場合、Release判定は`BLOCKED`とする。

## 18. 決定事項

| Decision ID | 決定事項 | 理由 |
|---|---|---|
| `BUS-MST-DEC-001` | Business Masterは固定10項目とする。 | 他Masterと同じ機械検証可能な形式へ統一するため。 |
| `BUS-MST-DEC-002` | API、UseCase、Scenarioの逆参照一覧を正式列にしない。 | 二重正本を防止するため。 |
| `BUS-MST-DEC-003` | 業務Flow詳細は現行業務分析成果物を正本とする。 | Masterを安定情報へ限定するため。 |
| `BUS-MST-DEC-004` | `businessAnalysisRef`未解決の候補は正式Masterへ登録しない。 | 架空Businessまたは未確認Pathの正式化を防止するため。 |
| `BUS-MST-DEC-005` | Java検証規則をBusiness Masterへ保持しない。 | Java Firstモデルとの二重管理を防止するため。 |

## 19. 未決事項

| Issue ID | 内容 | 現在の扱い | Release影響 |
|---|---|---|---|
| `BUS-MST-ISSUE-001` | `BUS-E6-001`の正式な現行業務分析書Path | 正式業務分析書完成後に設定する。 | `BLOCKED` |
| `BUS-MST-ISSUE-002` | 7業務Flowから抽出する残りBusinessの正式名称と境界 | 業務分析完了後に追加する。 | Coverage未確定 |
