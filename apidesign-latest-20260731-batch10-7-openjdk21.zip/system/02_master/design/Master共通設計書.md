---
title: Master共通設計書
document_id: E6-API-VAL-MST-COMMON-DESIGN
version: 3.0.0-draft.3
status: DRAFT
document_type: Design
system_name: E6 API Verification Platform
updated: 2026-07-31
---

# Master共通設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Master共通設計書 |
| 文書ID | `E6-API-VAL-MST-COMMON-DESIGN` |
| 対象システム | E6 API Verification Platform |
| 対象範囲 | `system/02_master/`配下の5 Master、1 Traceability View、設計書、Guide、ChecklistおよびExample |
| 文書種別 | Master共通設計書 |
| 版数 | `3.0.0-draft.3` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-31 |
| 作成責任 | Verification Platform Team |
| レビュー責任 | System Architect / Business Analysis Lead / API Design Lead / Scenario Design Lead / Runtime Lead / Test Lead |
| 承認責任 | System Owner / Business Owner |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-25 | Master体系をBusiness、Environment、API、UseCase、Scenarioへ収束し、対応表をTraceability Viewとするモデルで全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-26 | Guide、Checklist、Example、ValidationおよびRelease Evidenceとの関係を追加 | DRAFT |
| `2.0.0-draft.3` | 2026-07-27 | 文書LifecycleとExample識別規則を文書作成規約へ同期 | DRAFT |
| `2.0.0-draft.4` | 2026-07-27 | Master非保持対象の実行結果をCanonical四結果軸へ同期 | DRAFT |
| `2.0.0-draft.5` | 2026-07-29 | `REP-MIG-002／003`によるAPI Master／ExampleのFile名移行を反映 | DRAFT |
| `3.0.0-draft.1` | 2026-07-29 | Repository 4.0.2を入力として再設計し、成果物Version 4.0.3へ反映。正式Master 0件、Environment候補3件、Spring Boot 4.1.0／Java 17非Web Batchおよび明示Scenario Registry契約を基準として全面再作成。旧`SC-E6-001 → API-002`実データ記述を削除し、構造妥当性と業務データRelease可否を分離 | DRAFT |
| `3.0.0-draft.2` | 2026-07-29 | `REP-CR-012`により`ENV-PROD`を本番として確定。Production-like環境、`PRODUCTION_LIKE` Enumおよび`productionLike`列を廃止し、Environment Masterを固定9列へ変更。本番実行可否は独立Issueとして`enabled=false`を維持 | DRAFT |
| `3.0.0-draft.3` | 2026-07-31 | `REP-CR-013`によりJava 17＋Maven＋Plain Java CLIへ移行し、Spring Boot／Spring Framework非採用、明示CompositionおよびSpring依存禁止GateをCurrent実装境界へ同期。Master種類、列、正式Data件数およびRegistry契約は変更なし | DRAFT |
| `3.0.0-draft.4` | 2026-07-31 | `REP-CR-014`により現行Java基線をOpenJDK 21／`release=21`へ訂正し、Build／Runtime／Contract Test Gateを同期。Master種類、列、正式Data件数およびRegistry契約は変更なし | DRAFT |

## 3. 目的

本書は、E6 API Verification PlatformにおけるMasterの共通統制を定義する。

共通統制には、次を含む。

1. Masterとして管理する情報の成立条件
2. 5 Masterと1 Traceability Viewの責務および正本関係
3. ID、Reference、文書メタデータ、状態および有効性の共通規則
4. 登録、変更、無効化、置換および削除の統制
5. Cross-Master Validation、ReviewおよびRelease Gate
6. Java実装、Definition Bundle、Runtimeおよび実行成果物との境界
7. 現行データが0件である期間の正しい判定方法

本書は、各Masterの正式列、型、Enumおよび項目固有規則を再定義しない。それらは各個別Master設計書を正本とする。

## 4. 設計原則

| 原則ID | 原則 | 設計上の意味 |
|---|---|---|
| `MST-CMN-P001` | Single Source of Truth | 一つの情報に一つの変更起点を割り当てる。 |
| `MST-CMN-P002` | Stable Identity | 名称、Path、Class名または表示順ではなく不変IDで参照する。 |
| `MST-CMN-P003` | Fail Closed | 必須情報を解決できない場合は推測せず、登録または実行を拒否する。 |
| `MST-CMN-P004` | Java First | 実行順序、分岐、Mapping、Checkおよび比較ロジックを外部Masterの式として実行しない。 |
| `MST-CMN-P005` | Immutable Trace | 変更後も過去Runが使用した定義VersionとSourceを追跡可能にする。 |
| `MST-CMN-P006` | Evidence Based | 正式E6値は業務分析、API仕様、設計、実装および承認Evidenceで根拠付ける。 |
| `MST-CMN-P007` | Example Isolation | Example、Recoveryおよび会話上の仮定を正式Masterへ混入させない。 |
| `MST-CMN-P008` | State Separation | 文書状態、データ準備状態、レコード有効性およびValidation結果を分離する。 |
| `MST-CMN-P009` | Atomic Change | 正本、Reference、実装および派生成果物を一つのChange Setで整合させる。 |
| `MST-CMN-P010` | Fixed Scope | 承認なしにMaster種別、Directoryまたは正式列を追加しない。 |

## 5. 適用範囲

### 5.1 正本Master

| Master | 正式ファイル | 主ID | 主責務 |
|---|---|---|---|
| Business Master | `system/02_master/Business_Master.md` | `businessId` | 業務分類、業務目的、業務境界およびOwner |
| Environment Master | `system/02_master/Environment_Master.md` | `environmentId` | 論理実行EnvironmentのIdentityと外部設定Reference |
| API Master | `system/02_master/API_Master.md` | `apiId` | APIのIdentityと安定した技術属性 |
| UseCase Master | `system/02_master/UseCase_Master.md` | `useCaseId` | 一つの業務検証目的、範囲、前提、適用EnvironmentおよびScenario集合 |
| Scenario Master | `system/02_master/Scenario_Master.md` | `scenarioId` | 一つの確定経路と実行資産Reference |

Masterは上記5種類だけとする。

### 5.2 Traceability View

| View | 正式ファイル | 複合Key | 位置付け |
|---|---|---|---|
| API・UseCase・Scenario対応表 | `system/02_master/API_UseCase_Scenario対応表.md` | `scenarioId + apiCallCode` | MasterおよびScenario詳細設計から導出する横断確認用View |

対応表は正式成果物であるがMasterではない。対応表を値の新規決定、正本の上書きまたはRuntime経路の動的構築に使用してはならない。

### 5.3 支援成果物

| 区分 | 対象 | 責務 |
|---|---|---|
| 共通設計 | `design/Master共通設計書.md` | 本書。Master全体の共通統制 |
| 個別設計 | `design/*_Master設計書.md` | 正式列、型、必須、Enum、個別Validation |
| View設計 | `design/API・UseCase・Scenario対応表設計書.md` | 14項目、導出、複合KeyおよびCoverage |
| 作業Guide | `guide/` | 作成、更新、採番およびReference記述手順 |
| Checklist | `checklist/` | 人によるReviewと機械的整合性確認 |
| Example | `examples/` | 900番台の架空値による記入例 |

## 6. 固定構成

```text
system/02_master/
├── README.md
├── Business_Master.md
├── Environment_Master.md
├── API_Master.md
├── UseCase_Master.md
├── Scenario_Master.md
├── API_UseCase_Scenario対応表.md
├── design/
│   ├── Master共通設計書.md
│   ├── Business_Master設計書.md
│   ├── Environment_Master設計書.md
│   ├── API_Master設計書.md
│   ├── UseCase_Master設計書.md
│   ├── Scenario_Master設計書.md
│   └── API・UseCase・Scenario対応表設計書.md
├── guide/
│   ├── Master作成・更新ガイド.md
│   └── Master_ID・Reference記述ガイド.md
├── checklist/
│   ├── MasterレビューChecklist.md
│   └── Master整合性Checklist.md
└── examples/
    ├── Business_Master_Example.md
    ├── Environment_Master_Example.md
    ├── API_Master_Example.md
    ├── UseCase_Master_Example.md
    ├── Scenario_Master_Example.md
    └── API_UseCase_Scenario対応表_Example.md
```

この構成へ新しいMaster、Directoryまたは正式成果物を追加する場合は、先にArchitecture Change Requestを承認し、Repository Structure、本書、README、Guide、ChecklistおよびConsumerを同一Change Setで更新する。

## 7. Masterの成立条件

ある情報をMasterとして管理するには、次の条件をすべて満たさなければならない。

| 条件ID | 条件 |
|---|---|
| `MST-CMN-C001` | 複数の設計、実装または運用成果物から共通参照される。 |
| `MST-CMN-C002` | 実行ごとの値ではなく、一定期間安定している。 |
| `MST-CMN-C003` | Repository全体で一意かつ不変のIDを付与できる。 |
| `MST-CMN-C004` | 値のOwner、変更起点および承認責任を一つに決められる。 |
| `MST-CMN-C005` | 集中管理しなければ重複、不整合または参照不能が発生する。 |
| `MST-CMN-C006` | Scenario固有の実行詳細、Runtime状態またはJava固定実装と重複しない。 |
| `MST-CMN-C007` | 根拠資料、変更履歴および過去Runからの追跡性を保持できる。 |
| `MST-CMN-C008` | 登録前に個別Master設計書の必須項目とRegistration Gateを満たせる。 |

「一覧にすると便利」「Javaから読みやすい」「将来使用する可能性がある」という理由だけでMasterを追加してはならない。

## 8. Masterではない情報

| 情報 | 正式な管理先 | Masterにしない理由 |
|---|---|---|
| API呼出順序、分岐、Skip、`apiCallCode` | Scenario詳細設計書およびJava Scenario | Scenario固有の実行仕様 |
| Request初期値、Test Data | Scenario Input／Test Data | 実行条件とデータVariation |
| 前段Responseから後段RequestへのMapping | Scenario詳細設計書およびJava | 実行時処理 |
| Request／Response項目、型、必須、桁数、Enum | API詳細設計書およびJava DTO | API契約 |
| Expected値、`resultKey` | Scenario ExpectedおよびJava Check | Scenario固有の検証契約 |
| 必須、非空、固定値、属性値、状態遷移の判定 | API／UseCase設計およびJava Check | 業務判定実装 |
| `IGNORE_FIELD`、`IGNORE_VALUE` | APIまたはScenario専用Java比較定義 | 実行可能な比較規則 |
| Scenario Context、ApiExchange | Framework設計およびRuntime Object | Runごとに生成される状態 |
| Run ID、Previous、Current、Baseline | Execution StateおよびRun成果物 | 実行ごとに変化する情報 |
| Verification／Change／Recovery結果 | Result Artifact | 実行結果 |
| Retry、Timeout、並列数 | Runtime設定および共通Framework | 実行制御 |
| Schedule、実行頻度 | 運用設計 | 運用固有設定 |
| URL、Credential、Secret実値 | 外部Configuration／Secret Provider | Security境界 |

次の旧分類をMasterとして復活させない。

- Context Master
- Verification Master
- Verification Policy Master
- Compare Policy Master

必要な共通規則は通常の設計書、SchemaまたはJava実装で管理する。

## 9. 正本関係

```mermaid
flowchart TD
    B["Business Master"]
    U["UseCase Master"]
    S["Scenario Master"]
    D["Scenario詳細設計"]
    A["API Master"]
    T["Traceability View"]

    B --> U
    U --> S
    S --> D
    A --> D
    U --> T
    S --> T
    A --> T
    D --> T
```

Environment MasterはUseCaseの適用Environmentを識別する。実際の接続値は外部ConfigurationおよびSecret Providerから解決する。

| 情報 | 正本 | Consumerでの扱い |
|---|---|---|
| `businessId`とBusiness属性 | Business Master | ID参照 |
| `environmentId`と論理Environment属性 | Environment Master | IDおよび外部設定Key参照 |
| `apiId`とAPI固定属性 | API Master | ID参照 |
| `useCaseId`とUseCase属性 | UseCase Master | ID参照 |
| `scenarioId`とScenario属性 | Scenario Master | ID参照 |
| `apiCallCode`、順序、目的、条件 | Scenario詳細設計書 | Viewへ導出、Javaで実装 |
| 横断表示 | 対応表 | 正本を変更しないProjection |

正本とViewが不一致の場合、Viewの値で正本またはJavaを上書きしてはならない。

## 10. 文書優先順位

同じ対象について記述差異がある場合は、次の順序で正本性を確認する。

1. 承認済みArchitecture Decision／Repository Structure
2. 本書
3. 対象の個別Master設計書または対応表設計書
4. 正式MasterまたはTraceability View
5. Guide
6. Checklist
7. Example

上位文書が常に内容上正しいと機械的に決めてはならない。矛盾を検出した場合はChange Requestを起票し、承認された正本を同一Change Setで是正する。ChecklistまたはExampleだけで設計規則を変更してはならない。

## 11. 共通文書メタデータ

### 11.1 必須項目

全Master、設計書、Guide、ChecklistおよびExampleはYAML Front Matterを持つ。

| 項目 | 必須 | 説明 | 例 |
|---|:---:|---|---|
| `title` | ○ | 文書名称 | `Scenario Master` |
| `document_id` | ○ | 文書自身の一意なID | `MST-E6-SC-001` |
| `version` | ○ | 文書版数 | `3.0.0-draft.1` |
| `status` | ○ | 文書Lifecycle | `DRAFT` |
| `document_type` | ○ | Master、Design、Guide等 | `Master` |
| `system_name` | ○ | 対象システム | `E6 API Verification Platform` |
| `updated` | ○ | 最終更新日 | `2026-07-29` |
| `data_status` | 条件付 | 正式データ準備状態を明示するMaster／Viewだけで使用 | `EMPTY_PENDING_API_ANALYSIS` |

キーは`snake_case`へ統一する。同一文書内で`snake_case`と`camelCase`を混在させない。

### 11.2 Version

1. Front Matter、文書情報および改訂履歴の現行Versionを一致させる。
2. 内容変更時はVersionと改訂履歴を同一Change Setで更新する。
3. File名変更だけで`document_id`を変更しない。
4. 正式データVersionと文書Versionを同一概念として扱わない。
5. 過去Versionの履歴を改変して現行判断へ見せかけない。

## 12. 状態モデル

### 12.1 文書Lifecycle

| `status` | 意味 | Releaseでの扱い |
|---|---|---|
| `DRAFT` | 作成・更新中 | Release入力不可 |
| `IN_REVIEW` | Review中 | 指摘修正以外の並行変更を制限 |
| `APPROVED` | 内容承認済み | Release候補 |
| `RELEASED` | Release対象として確定 | Change Requestなしの変更禁止 |
| `DEPRECATED` | 後継あり、新規利用禁止 | 過去追跡のみ |
| `RETIRED` | 利用終了 | 履歴保持のみ |

### 12.2 データ準備状態

`data_status`は、その文書内に正式データを登録できる準備状況を表す。文書LifecycleまたはValidation結果の代替ではない。

現行で使用している主な値は次のとおりである。

| `data_status` | 意味 |
|---|---|
| `EMPTY_PENDING_BUSINESS_ANALYSIS` | Business分析と承認待ちのため正式Business 0件 |
| `EMPTY_PENDING_API_ANALYSIS` | API分析と承認待ちのため正式API 0件 |
| `EMPTY_PENDING_BUSINESS_AND_API_ANALYSIS` | Business／API分析待ちのため正式UseCase 0件 |
| `EMPTY_PENDING_USECASE_DESIGN` | UseCase／Scenario設計待ちのため正式ScenarioまたはRelation 0件 |

新しい値を追加する場合は、利用文書、意味、遷移条件およびReleaseへの影響を本書または個別設計書で承認する。

### 12.3 レコード有効性

| `enabled` | 意味 |
|:---:|---|
| `true` | 新しい設計または実行計画から参照可能 |
| `false` | 新規参照禁止。履歴、移行または将来候補として保持 |

`enabled=false`は、未確認値、参照切れまたは不完全な正式レコードを隠す手段ではない。登録Gateを満たさない候補は正式表へ登録しない。

### 12.4 Validation Result

| Result | 意味 |
|---|---|
| `PASS` | Ruleを満たす。 |
| `FAIL` | Rule違反を検出した。 |
| `BLOCKED` | 必須入力または実行環境不足により判定できない。 |
| `NOT_APPLICABLE` | 対象レコードが0件等、Ruleの適用対象が存在しない。 |

`BLOCKED`と`NOT_APPLICABLE`を`PASS`へ読み替えない。

### 12.5 状態の分離

```text
文書 status
≠ data_status
≠ レコード enabled
≠ Validation Result
≠ Runtime Result
```

たとえば、空表の列構造Validationは`PASS`、レコード間Validationは`NOT_APPLICABLE`、正式業務データRelease Gateは`BLOCKED`となり得る。

## 13. 現行登録状態

2026-07-29時点の正式状態は次のとおりである。

| 対象 | 正式件数 | 有効件数 | 構造状態 | データ／実行状態 |
|---|---:|---:|---|---|
| Business Master | 0 | 0 | 固定10列 | 7業務Flowの分析・Owner Review待ち |
| Environment Master | 3 | 2 | 固定9列 | `ENV-PROD=PRODUCTION`確定済み。外部Config／Auth Key実在性と本番実行許可待ち |
| API Master | 0 | 0 | 固定10列 | 約24 APIの分析・Provider Review待ち |
| UseCase Master | 0 | 0 | 固定10列 | Business／API確定待ち |
| Scenario Master | 0 | 0 | 固定10列 | UseCase、設計、Input、Expected、正式Java Class待ち |
| Traceability View | 0行 | 0行 | 固定14項目 | Scenario詳細設計待ち |
| E6 Scenario Registry | 0件 | 0件 | 明示空Catalog実装済み | 正式Scenario登録待ち |

上表の0件は「検証対象が存在しない」という業務判断ではない。正式な根拠と承認が未完了であるため、架空値を登録していない状態を表す。

現行判定は次のとおりとする。

| 判定対象 | 現行判定 | 理由 |
|---|---|---|
| Master File構造 | `PASS` | 固定構成と正式列を保持している。 |
| Example／Recovery分離 | `PASS` | 架空001系列を正式正本から除外済み。 |
| レコード間Validation | `NOT_APPLICABLE` | Business／API／UseCase／Scenarioが0件。 |
| Environment Runtime解決 | `BLOCKED` | 外部Config／Auth Referenceの実在性未確認。 |
| 業務データRelease | `BLOCKED` | 正式Business／API／UseCase／Scenarioが0件。 |
| OpenJDK 21 Build／Contract Test | `BLOCKED_BY_ENVIRONMENT` | 現行検証環境にOpenJDK 21 Compilerがなく、承認済み依存Repositoryへ接続できない。 |

現行データに「有効Scenarioから無効APIへの参照Error」は存在しない。`TRC-V008`等の参照Ruleは、正式Scenario 0件のため`NOT_APPLICABLE`である。

## 14. ID共通規則

### 14.1 ID体系

| ID | Pattern | Scope | 正本 |
|---|---|---|---|
| `businessId` | `BUS-{systemCode}-{NNN}` | Repository全体 | Business Master |
| `environmentId` | `ENV-{NAME}` | Repository全体 | Environment Master |
| `apiId` | `API-{NNN}` | Repository全体 | API Master |
| `useCaseId` | `UC-{systemCode}-{NNN}` | Repository全体 | UseCase Master |
| `scenarioId` | `SC-{systemCode}-{NNN}` | Repository全体 | Scenario Master |
| `apiCallCode` | `CALL-{NNN}` | 一つのScenario内 | Scenario詳細設計書 |
| `resultKey` | 承認済みStable Key | 定義されたCheck Scope | Scenario設計／Expected／Java |

### 14.2 不変性

1. IDは初回正式登録後に変更しない。
2. 名称、File名、Path、Class名、表示順または`callSequence`をIdentityとして使用しない。
3. 欠番を許容し、無効化または廃止したIDを再利用しない。
4. 同一対象の属性変更ではIDを維持する。
5. 契約または業務Identityが別物となる置換では新IDを採番する。
6. `apiId`と`apiCallCode`、`scenarioId`と`resultKey`を混同しない。
7. 900番台はExample専用とし、正式Masterへ登録しない。

詳細は`system/02_master/guide/Master_ID・Reference記述ガイド.md`に従う。

## 15. Reference共通規則

### 15.1 ID Reference

Master間の論理参照はIDで行う。

| 参照元 | 参照先 | 項目 |
|---|---|---|
| UseCase Master | Business Master | `businessIds` |
| UseCase Master | Environment Master | `applicableEnvironmentIds` |
| UseCase Master | Scenario Master | `scenarioIds` |
| Scenario Master | UseCase Master | `useCaseId` |
| Scenario詳細設計書 | API Master | `apiId` |

全Referenceは対応する正本で解決できなければならない。UseCaseの`scenarioIds`とScenarioの`useCaseId`は双方向一致を必須とする。

### 15.2 File Reference

1. Repository Root基準の相対Pathを使用する。
2. 絶対Path、個人PC Path、`./`および`../`を使用しない。
3. 大文字・小文字を実ファイルと一致させる。
4. Reference先の文書種別と対象IDを照合する。
5. File名変更時は全Current Referenceを同一Change Setで更新する。
6. `enabled=true`のレコードは必須ReferenceをPreflightで解決できなければならない。
7. Exampleまたは`recovery/`を正式Referenceにしない。

### 15.3 List Reference

1. 重複IDを保持しない。
2. Markdownの一セルでは`<br>`区切りを使用する。
3. 意味上の順序がないListはID昇順とする。
4. 実行順序をListの並びだけで表現しない。
5. 空Listと未確認を混同しない。

### 15.4 Java Class Reference

Scenario Masterの`executionClass`は次を満たす。

1. Base Package `jp.co.mufg.e6.verifier`配下の完全修飾Class名である。
2. 正式Java Source RootとBuild対象Moduleで解決できる。
3. Registry Keyには使用しない。Registry Keyは`scenarioId`とする。
4. `scenarioId`で解決したDescriptorの`implementationType`と完全一致する。
5. Registry管理済みの生成済みInstanceを使用する。
6. 任意ClassのReflection生成、Class名入力によるDI探索またはClasspath Scan実行を禁止する。

## 16. 共通記述規則

1. 正式ファイルはMarkdownとする。
2. 一行を一つのMasterレコードまたは一つの対応関係とする。
3. 正式列を個別設計書の承認なしに追加、削除または並べ替えない。
4. 未確認値を`TBD`として正式レコードへ仮登録しない。
5. Booleanは`true`または`false`とする。
6. Enumは個別設計書で定義された大文字値を使用する。
7. Dateは`YYYY-MM-DD`形式とする。
8. PathとIDはBacktickで囲む。
9. セル内の複数値は`<br>`で区切る。
10. 巨大JSON、Secret、Runtime LogまたはJava実装をMasterへ埋め込まない。
11. 空表には列Headerを保持し、件数と空である理由を本文で明示する。
12. 空表を件数合わせの架空値で補完しない。

## 17. 役割と責任

| 役割 | 主な責任 |
|---|---|
| Requester | 変更理由、根拠、対象Releaseおよび期限を提示する。 |
| Master Owner | 正本、ID継続可否、登録可否および影響範囲を決定する。 |
| Editor | Guideと設計書に従って成果物を更新する。 |
| Domain Reviewer | Business、EnvironmentまたはAPI内容の妥当性を確認する。 |
| System Architect | Master成立条件、正本境界、ID、Referenceおよび構成変更を確認する。 |
| Java／Runtime Reviewer | DTO、Scenario Registry、Class、ConfigおよびPreflightとの整合を確認する。 |
| Test Lead | Scenario、Input、Expected、Check、DiffおよびCoverageを確認する。 |
| Security／Operations Reviewer | Secret境界、Production影響、権限および運用適用性を確認する。 |
| Release Approver | ValidationとReview Evidenceに基づきRelease可否を決定する。 |

一人が複数Roleを担当する場合でも、各観点の判定とEvidenceを分離して記録する。

## 18. 登録Gate

### 18.1 共通Gate

正式レコードは次をすべて満たした場合だけ登録する。

1. 対象のIdentityと粒度が個別設計書の成立条件を満たす。
2. 正式根拠資料が存在する。
3. 主ID、Ownerおよび必須属性が確定している。
4. 必須ID／File Referenceを解決できる。
5. Example、Recoveryまたは会話上の仮定を根拠にしていない。
6. 重複する既存レコードがない。
7. 登録後のConsumer、Java、Input、ExpectedおよびViewへの影響を確認している。
8. 必須ReviewerのEvidenceがある。

### 18.2 登録順序

```text
現行業務分析
→ Business登録
→ API分析
→ API登録
→ UseCase設計
→ UseCase登録
→ Scenario詳細設計・Input・Expected・Java Class
→ Scenario登録
→ Traceability View生成
→ Definition／Registry／Build Trace
```

EnvironmentはUseCase適用前に論理Environmentと外部設定Referenceを確定する。

### 18.3 空Masterの扱い

1. 登録Gate未達の候補を`enabled=false`で先行登録しない。
2. 正式レコード0件でもHeader、状態、Gate、ValidationおよびOpen Issueを維持する。
3. 0件に対する単一レコードまたはCross-Master Ruleは`NOT_APPLICABLE`とする。
4. 業務実行可能性を要求するRelease Gateは`BLOCKED`とする。

## 19. 変更管理

### 19.1 変更区分

| 区分 | 例 | IDの扱い |
|---|---|---|
| 追加 | 新Business、API、UseCase、Scenario | 新IDを採番 |
| 属性変更 | 名称、説明、Path、Class名 | Identityが同一ならID継続 |
| 関係変更 | Scenario所属、API呼出先 | 関係正本を変更し横断Review |
| 無効化 | 廃止、利用停止 | ID維持、`enabled=false` |
| 置換 | 非互換API、別業務目的 | 新IDを採番し旧IDを無効化 |
| 物理削除 | 誤登録、保持期限経過後の例外処理 | 参照0件、履歴解決性および承認必須 |

### 19.2 Atomic Change Set

影響に応じて次を同一Change Setで更新する。

- Master
- 個別Master設計書
- API／UseCase／Scenario詳細設計
- Java Scenario、DTO、RegistryおよびContract Test
- Scenario Input／Expected
- Traceability View
- SchemaおよびValidation
- Guide、ChecklistおよびExample
- 改訂履歴、Decision、IssueおよびEvidence

変更対象外と判断した成果物も、Impact Analysisで確認済みであることを記録する。

### 19.3 無効化と削除

1. 無効化したIDを新しい有効関係から参照しない。
2. 過去Runが参照した定義を物理削除しない。
3. 物理削除前にCurrent Reference 0件、過去Trace解決、RetentionおよびApprover承認を確認する。
4. 名前変更またはFile移行で文書IDと業務IDを変更しない。

詳細手順は`system/02_master/guide/Master作成・更新ガイド.md`に従う。

## 20. Traceability View

### 20.1 導出入力

| 表示情報 | 正本 |
|---|---|
| UseCase Identity、名称 | UseCase Master |
| Scenario Identity、名称、種別 | Scenario Master |
| API Identity、名称 | API Master |
| `callSequence`、`apiCallCode`、目的、条件 | Scenario詳細設計書 |
| `relationStatus` | 関係する正本の`enabled`から導出 |

### 20.2 導出規則

1. 一行を一つのScenario内API呼出実体とする。
2. 複合Keyは`scenarioId + apiCallCode`とする。
3. 同一APIの複数回呼出は異なる`apiCallCode`で別行にする。
4. `callSequence`は順序でありIdentityではない。
5. Viewの名称とPathは正本から導出する。
6. 正本変更後は同一Change Setで再生成または再照合する。
7. Viewの手修正を正本へ逆反映しない。

## 21. Java・Runtime境界

### 21.1 承認済み実装基線

| 項目 | 現行決定 |
|---|---|
| Application Framework | なし（Plain Java） |
| Java Distribution | 銀行承認済みOpenJDK Distribution |
| Java compile release | `21` |
| 最低Runtime Version | OpenJDK 21 |
| 実行形態 | Plain Java非Web Batch／CLI |
| Web Server | Tomcat非採用 |
| Spring関連 | Spring Boot／Spring Framework／Spring Batch非採用 |
| Build | Maven Wrapper `3.9.16` |
| Base Package | `jp.co.mufg.e6.verifier` |
| Registry | 明示Catalog＋Immutable Scenario Registry |

### 21.2 Javaが解決する情報

- `scenarioId`からRegistry管理済みScenario Instanceを解決する。
- Scenario Masterの`executionClass`とDescriptorの`implementationType`を照合する。
- `apiId`からAPI固定属性とAPI設計を追跡する。
- `environmentId`から外部Configuration／Authentication Referenceを選択する。
- `useCaseId`、`scenarioId`、`apiCallCode`および`resultKey`をEvidenceへ引き継ぐ。

### 21.3 JavaがMasterから解決しない情報

- API呼出順序、分岐およびMapping
- Request実値
- Expected値およびCheck条件式
- JSON Diffの詳細規則
- Previous、CurrentおよびBaseline実体
- Runtime ResultおよびRecovery状態

これらはScenario詳細設計、Java、Input、Expected、Runtime設定または実行成果物を正本とする。

### 21.4 Scenario Registry契約

```mermaid
flowchart TD
    M["Scenario Master"]
    C["E6ScenarioCatalog"]
    R["Immutable Registry"]
    P["Preflight"]
    X["Scenario Instance"]

    M --> P
    C --> R
    R --> P
    P --> X
```

1. `E6ScenarioCatalog`が承認済みScenarioを明示登録する。
2. `verifier-app`のComposition Rootが起動時にImmutable Registryを一度だけSealする。
3. Registry Keyは`scenarioId`とする。
4. Descriptorと生成済みInstanceを一組として保持する。
5. 重複`scenarioId`、型不一致または未登録Scenarioを拒否する。
6. Registry Snapshotは決定的なContent Hashを持つ。
7. 正式Scenario 0件の期間は明示空Catalogを維持し、Fixtureを正式Catalogへ混入させない。

## 22. Definitionおよび実行前Gate

Runtimeへ引き渡す前に、定義を次の段階で固定する。

```text
Definition Source Set
→ Validated Definition Bundle
→ Registry Binding
→ Sealed Execution Plan
→ Run
```

| Gate | 主な確認 |
|---|---|
| Source Gate | Master、設計、Input、ExpectedおよびSchemaのSource Version／Hash |
| Structure Gate | Markdown、JSON、Schema、列、型およびEnum |
| Reference Gate | ID、File、DTO、ClassおよびCross-Master Reference |
| Registry Gate | `scenarioId`、Descriptor、Instanceおよび`executionClass` |
| Plan Gate | Environment、UseCase、Scenario、Input、ExpectedおよびAPI呼出の閉包 |

Gate失敗時に不足値、仮Class、仮APIまたは空Expectedを自動生成してはならない。

## 23. Validation設計

### 23.1 Severity

| Level | 意味 | Releaseへの影響 |
|---|---|---|
| `ERROR` | 参照不能、重複、責務違反または実行不能につながる不整合 | Release不可 |
| `WARNING` | 実行不能ではないが品質、Coverageまたは保守性に懸念 | 修正または承認必須 |
| `INFO` | 件数、状態またはCoverageの参考情報 | Releaseを直接妨げない |

### 23.2 共通Rule

| Rule ID | 検証内容 | Level |
|---|---|---|
| `MST-CMN-V001` | MarkdownおよびFront Matterを解析できる。 | ERROR |
| `MST-CMN-V002` | `document_id`がRepository内で一意である。 | ERROR |
| `MST-CMN-V003` | Front Matter Versionと現行改訂履歴が一致する。 | ERROR |
| `MST-CMN-V004` | 正式Master／Viewの列数、名称および順序が個別設計書と一致する。 | ERROR |
| `MST-CMN-V005` | 主IDがPatternに一致しScope内で一意である。 | ERROR |
| `MST-CMN-V006` | Boolean、Enum、DateおよびPathが規則に一致する。 | ERROR |
| `MST-CMN-V007` | 全ID Referenceが正本で解決できる。 | ERROR |
| `MST-CMN-V008` | 有効レコードの必須File／Class Referenceを解決できる。 | ERROR |
| `MST-CMN-V009` | UseCaseとScenarioの双方向Referenceが一致する。 | ERROR |
| `MST-CMN-V010` | 有効UseCaseが無効EnvironmentまたはScenarioを参照しない。 | ERROR |
| `MST-CMN-V011` | 有効Scenarioが無効または未登録APIを参照しない。 | ERROR |
| `MST-CMN-V012` | Traceability Viewの複合Keyが一意で正本と一致する。 | ERROR |
| `MST-CMN-V013` | MasterへRuntime、Expected、Check、DiffまたはSecret実値が混入していない。 | ERROR |
| `MST-CMN-V014` | Example、Recoveryまたは900番台架空値が正式Masterへ混入していない。 | ERROR |
| `MST-CMN-V015` | 変更に対応する改訂履歴、Impact AnalysisおよびEvidenceが存在する。 | WARNING |
| `MST-CMN-V016` | 0件Ruleを`NOT_APPLICABLE`とし、存在しない不整合を生成していない。 | ERROR |

### 23.3 実行順序

```text
File Inventory
→ Front Matter／Markdown
→ 単一Master Schema
→ ID
→ ID／File Reference
→ Cross-Master
→ Scenario詳細設計／Java Registry
→ Traceability View／Coverage
→ State／Responsibility
→ Release Gate
```

前段Errorを後段の補完、View修正または人の承認だけで解除してはならない。

### 23.4 Evidence

Validation結果は少なくとも次を保持する。

| 項目 | 内容 |
|---|---|
| Validation Run ID | 一回の検証を識別するID |
| Change ID | 対象Change Set |
| Source Version | Commitまたは不変なSource識別子 |
| Rule ID | 共通、個別またはTrace Rule |
| Result | `PASS`、`FAIL`、`BLOCKED`、`NOT_APPLICABLE` |
| Target | File、ID、Referenceまたは行 |
| Expected／Actual | 期待値と実値 |
| Evidence | Log、Report、DiffまたはPath |
| Issue ID | Failureまたは承認対象Warningとの対応 |

## 24. Review

### 24.1 Review観点

| 観点 | 確認内容 |
|---|---|
| 責務 | 安定した共通情報だけを保持しているか。 |
| 正本 | 値の変更起点が一つか。 |
| Identity | 不変IDと名称、Path、Class、順序を分離しているか。 |
| Reference | ID、File、DTOおよびClassを解決できるか。 |
| State | `status`、`data_status`、`enabled`、ValidationおよびRuntime Resultを分離しているか。 |
| Traceability | BusinessからReportまで順方向・逆方向に追跡できるか。 |
| Java整合 | Registry、DTO、Input、ExpectedおよびScenario実装と一致するか。 |
| Security | Secret実値、任意Classおよび任意Pathを許可していないか。 |
| 変更影響 | Consumer、過去Runおよび派生成果物を確認したか。 |

### 24.2 ReviewとValidationの分離

1. 機械Validationを先に実施し、EvidenceをReview Packageへ含める。
2. 人のReviewは業務妥当性、責務、根拠、RiskおよびRelease判断を確認する。
3. Validation `ERROR`を人の承認だけで解除しない。
4. 人の指摘をValidation `PASS`だけでCloseしない。
5. 正式Role Review未実施をAI事前Reviewで代替しない。

人のReview記録は`MasterレビューChecklist.md`、機械的整合性確認は`Master整合性Checklist.md`を使用する。

## 25. Release Gate

### 25.1 文書構造Gate

次をすべて満たす場合、文書構造はRelease候補とできる。

1. 固定構成がRepository Structureと一致する。
2. 本書、個別設計書、Guide、ChecklistおよびExampleがそろっている。
3. Front Matter、文書ID、Versionおよび改訂履歴が整合する。
4. 正式列と責務境界が承認済みである。
5. Example／Recoveryが正式正本から分離されている。
6. 構造Validationの`ERROR`が0件である。

### 25.2 業務データGate

次をすべて満たす場合、正式E6データをRelease候補とできる。

1. Business、API、UseCaseおよびScenarioの正式登録とOwner Reviewが完了している。
2. 有効UseCaseに一件以上の有効Scenarioが存在する。
3. 有効Scenarioに一件以上のAPI呼出が存在する。
4. 全ID、File、Input、Expected、DTOおよびClass Referenceを解決できる。
5. Environment外部Config／Auth Referenceを解決できる。
6. Traceability Viewが正本およびScenario詳細設計と一致する。
7. Cross-Master `ERROR`と必須`BLOCKED`が0件である。

### 25.3 Build／Runtime Gate

1. 承認済みOpenJDK 21でMaven `clean verify`が成功する。
2. Module依存、Schema、DTOおよびRegistry Contract Testが成功する。
3. 正式Scenarioの`executionClass`とRegistry Descriptorが一致する。
4. Sealed Execution Planを決定的に生成できる。
5. 対象Release Unit、Definition BundleおよびRegistry SnapshotのVersion／Hashを記録できる。

### 25.4 最終Release Gate

1. 対象文書が`APPROVED`である。
2. 必須Validation `ERROR`および`BLOCKED`が0件である。
3. `WARNING`が修正済みまたは承認済みである。
4. 同一Source VersionでValidationとReviewを実施している。
5. 必須ReviewerとRelease ApproverのEvidenceが存在する。
6. Release対象を不変なVersionまたはHashで識別できる。

現行状態では、文書構造の機械確認は可能であるが、業務データGateおよびBuild／Runtime Gateは`BLOCKED`である。これは既知のデータ不整合による`FAIL`ではない。

## 26. Securityおよび安全境界

1. URL、IP、Password、Token、API Key、秘密鍵または個人情報をMasterへ保存しない。
2. Environment Masterは外部Configuration／Authentication Reference Keyだけを保持する。
3. Production EnvironmentはOwner、影響範囲、権限および実行承認を確定するまで有効化しない。
4. `executionClass`から任意ClassをReflection生成しない。
5. File Referenceを任意Path読込に使用せず、許可されたRepository Root内で正規化・検証する。
6. Example、RecoveryおよびTest Fixtureを正式Runtime入力にしない。
7. ValidationまたはReportへSecret実値を出力しない。

## 27. 禁止事項

1. 同じ定義を複数Masterへ重複登録する。
2. Java固定実装を外部Masterとして再定義する。
3. Scenario固有情報を共通Masterへ昇格する。
4. Runtime Objectまたは実行結果をMasterへ保存する。
5. 未確認値を推測して正式レコードを作成する。
6. 名称、Path、Class名または表示順を参照Keyにする。
7. View、ExampleまたはRecoveryを正本として利用する。
8. `enabled=false`で参照不整合または未完成を隠す。
9. 対応表だけを変更してJava実行経路を変更する。
10. 過去Runの解決性を確認せずIDまたはレコードを物理削除する。
11. 承認なしに正式列、Master種別またはDirectoryを追加する。
12. 旧Context、Verification、Verification PolicyまたはCompare Policy Masterを復活させる。
13. 正式データ0件の状態へ架空001系列または900番台Exampleを投入する。
14. `BLOCKED`または`NOT_APPLICABLE`を`PASS`として報告する。

## 28. 支援文書の利用順序

```text
README
→ Master共通設計書
→ 個別Master／View設計書
→ ID・Reference記述ガイド
→ Master作成・更新ガイド
→ Master整合性Checklist
→ MasterレビューChecklist
```

| 対象 | 設計正本 | 実施文書 |
|---|---|---|
| Master成立条件・責務境界 | 本書 | `MasterレビューChecklist.md` |
| 正式列・型・必須・Enum | 個別Master設計書 | `Master整合性Checklist.md` |
| ID・Reference | 本書／ID・Reference Guide | `Master整合性Checklist.md` |
| 変更手順 | 本書／作成・更新Guide | `MasterレビューChecklist.md` |
| Cross-Master関係 | 本書／対応表設計書 | `Master整合性Checklist.md` |
| Release Gate | 本書 | 両ChecklistのEvidence |

## 29. 決定事項

| Decision ID | 決定事項 | 理由 |
|---|---|---|
| `MST-CMN-DEC-001` | MasterはBusiness、Environment、API、UseCase、Scenarioの5種類だけとする。 | 安定した共通Identityへ責務を収束するため。 |
| `MST-CMN-DEC-002` | API・UseCase・Scenario対応表はTraceability Viewとする。 | 重複正本を防止するため。 |
| `MST-CMN-DEC-003` | API呼出明細はScenario詳細設計書、実行はJavaを正本とする。 | Scenario固有経路をMaster化しないため。 |
| `MST-CMN-DEC-004` | Java比較・判定ロジックをMaster化しない。 | 実装との二重管理を防止するため。 |
| `MST-CMN-DEC-005` | Runtime状態と実行結果をMaster化しない。 | Runごとに変化するため。 |
| `MST-CMN-DEC-006` | IDを不変とし、廃止は原則`enabled=false`で表す。 | 過去Traceを維持するため。 |
| `MST-CMN-DEC-007` | 未確認値を推測登録しない。 | 仮定を正式仕様化しないため。 |
| `MST-CMN-DEC-008` | Front Matterを`snake_case`へ統一する。 | 機械解析を安定させるため。 |
| `MST-CMN-DEC-009` | 人のReviewと機械Validationを分離する。 | 妥当性判断と再現可能な検証を混同しないため。 |
| `MST-CMN-DEC-010` | 空Masterの構造`PASS`と業務データRelease `BLOCKED`を分離する。 | 0件を架空Errorまたは成功として扱わないため。 |
| `MST-CMN-DEC-011` | Scenarioは`scenarioId`で明示Registryから解決する。 | 任意Class実行を防止するため。 |
| `MST-CMN-DEC-012` | 正式Scenario 0件の期間は空E6 Catalogを維持する。 | Fixture混入を防止するため。 |
| `MST-CMN-DEC-013` | `ENV-PROD`は本番であり、Production-like Environment、`PRODUCTION_LIKE` Enumおよび`productionLike`列を使用しない。 | 環境区分と安全境界の二重管理を廃止するため。 |
| `MST-CMN-DEC-014` | Java実装はMaven＋Plain Java CLIとし、Spring Boot／Spring Frameworkへ依存しない。 | Master／Registry BindingをDI ScanまたはApplication Contextへ依存させず、明示的かつ静的に検証するため。 |

## 30. 未決事項

| Issue ID | 内容 | 現在の扱い | Owner／決定時期 |
|---|---|---|---|
| `MST-CMN-ISSUE-001` | 7業務Flowの正式Business、Ownerおよび根拠Path | 仮登録せずBusiness Masterを0件で維持 | Business Owner／業務分析時 |
| `MST-CMN-ISSUE-002` | 約24 APIの正式一覧、契約およびOwner | 仮登録せずAPI Masterを0件で維持 | API Owner／API分析時 |
| `MST-CMN-ISSUE-003` | `ENV-PROD`を本Toolから実行可能とするか | 本番区分は解決済み。実行許可までは`enabled=false`を維持 | Security／Operations Review時 |
| `MST-CMN-ISSUE-004` | Environment外部Config／Auth Referenceの実在性 | Runtime Gateを`BLOCKED`とする | Runtime構築時 |
| `MST-CMN-ISSUE-005` | 対応表を完全自動生成するか | 手動でも同一Validation必須 | Build設計時 |
| `MST-CMN-ISSUE-006` | 文書VersionとMaster Data Versionの分離方式 | 現段階は文書Versionを使用 | 運用設計時 |
| `MST-CMN-ISSUE-007` | 過去Runが使用したMaster版の固定Evidence | Source Revision／Hashを候補とする | Audit実装時 |
| `MST-CMN-ISSUE-008` | OpenJDK 21 Maven Build／Contract Test | 現環境制約として`BLOCKED_BY_ENVIRONMENT`を維持 | OpenJDK 21＋承認済みRepository接続環境準備時 |

## 31. 完了条件

本設計書の正文作成は、次を満たした時点で完了とする。

1. 5 Masterと1 Traceability Viewの責務が明確である。
2. 現行固定構成とRepository 4.0.6に矛盾しない。
3. ID、Reference、状態、登録および変更の共通規則が定義されている。
4. OpenJDK 21、Maven、Plain Java非Web Batchおよび明示Registry境界と一致する。
5. 空Masterの構造Validationと業務データRelease判定が分離されている。
6. 現行正式データ0件とEnvironment候補3件を正しく反映している。
7. 架空001系列を現行E6の正式不整合として扱っていない。
8. 個別設計書、Guide、ChecklistおよびREADMEと重大な矛盾がない。
9. 共通Validation RuleとRelease Gateが再現可能である。
10. 正式Role Review前であることを明示している。

正文作成完了は`APPROVED`または`RELEASED`を意味しない。正式Role Reviewと承認が完了するまで文書状態は`DRAFT`とする。
