---
title: Environment Master設計書
document_id: DES-MST-E6-ENV-001
version: 2.0.0-draft.3
status: DRAFT
document_type: Master Design
system_name: E6 API Verification Platform
updated: 2026-07-29
---

# Environment Master設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Environment Master設計書 |
| 文書ID | `DES-MST-E6-ENV-001` |
| 対象Master | `system/02_master/Environment_Master.md` |
| 対象システム | E6 API Verification Platform |
| 版数 | `2.0.0-draft.3` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-29 |
| 作成責任 | Verification Platform Team |
| レビュー責任 | System Architect / Runtime Lead / Security Lead / Operations Lead |
| 承認責任 | System Owner / Environment Owner |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 五つのMaster、Java First、外部設定参照および固定10項目の責務に基づき全面再作成し、Lifecycle StatusをCanonical値へ統一 | DRAFT |
| `2.0.0-draft.2` | 2026-07-27 | Framework横断再走査によりMaster非保持対象の実行結果をCanonical四結果軸へ統一 | DRAFT |
| `2.0.0-draft.3` | 2026-07-29 | `ENV-PROD`を本番として確定し、Production-like環境、`PRODUCTION_LIKE` Enumおよび`productionLike`列を廃止。Environment Masterを固定9項目へ変更し、本番安全Gateを`PRODUCTION` Typeに直接適用 | DRAFT |

## 3. 目的

本書は、E6 API Verification Platformで使用するEnvironment Masterの責務、論理Environment粒度、正式項目、外部設定Reference、Security境界、Validationおよび変更管理を定義する。

Environment Masterは、検証実行で選択する論理Environmentを`environmentId`で識別し、次の問いに対する正本を提供する。

- どの論理Environmentが存在するか。
- Environmentの正式名称、Typeおよび用途は何か。
- どのSystemへ接続するEnvironmentか。
- Base URLをどの外部設定Keyで解決するか。
- Authentication Profileをどの外部設定Keyで解決するか。
- 本番環境か。
- Environmentの管理責任者は誰か。
- 新しい実行計画から参照可能か。

Environment Masterは、Credential実値、Host別Secret、Run状態、BaselineまたはRuntime制御値を保存しない。

## 4. 適用範囲

本書は、Local、開発、結合、StagingおよびProduction等の論理実行環境に適用する。Production-likeを独立Environment Typeとして登録しない。

一つのEnvironmentは次の単位で登録する。

1. 実行先として独立して選択される。
2. 用途、安全境界または運用責任が他Environmentと区別できる。
3. Host交換やCredential Rotationがあっても論理的同一性を維持する。
4. 外部設定を安定したReference Keyで解決できる。

Host名、IP Address、Container、Pod、個人端末または一回のRunをEnvironmentとして登録してはならない。

## 5. 基本原則

| 原則ID | 原則 | 説明 |
|---|---|---|
| `ENV-MST-P001` | Logical Environment | 物理Hostではなく論理Environmentを一つのレコードとする。 |
| `ENV-MST-P002` | Stable Identity | Host、URLまたはCredential変更では`environmentId`を変更しない。 |
| `ENV-MST-P003` | No Secret | Password、Token、API Key、秘密鍵または証明書実値を保存しない。 |
| `ENV-MST-P004` | Reference Only | Base URLとAuthenticationは外部設定Keyだけを保持する。 |
| `ENV-MST-P005` | Explicit Production Boundary | 本番環境を`environmentType=PRODUCTION`で明示し、安全Gateを直接適用する。 |
| `ENV-MST-P006` | No Runtime State | Run ID、前回Run、Baselineまたは実行結果を保持しない。 |
| `ENV-MST-P007` | No Runtime Tuning | Timeout、Retry、並列数、ScheduleをMasterへ保持しない。 |
| `ENV-MST-P008` | Fail Closed | 未確認または未承認Environmentを有効化しない。 |
| `ENV-MST-P009` | Explicit Ownership | 接続・運用責任をRoleまたは組織で明確にする。 |
| `ENV-MST-P010` | History Retention | 利用停止時も`enabled=false`で履歴を保持する。 |

## 6. 責務

Environment Masterは、次の9項目だけを正式レコードとして管理する。

1. Environment ID
2. Environment名称
3. Environment Type
4. 用途
5. System ID
6. Base URL Reference
7. Authentication Profile Reference
8. Environment Owner
9. 有効フラグ

## 7. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| Base URL、Host、IP Addressの実値 | Environment別外部Configuration |
| Username、Password、Token、API Key、Client Secret | Secret Provider |
| 秘密鍵、証明書実値 | Secret／Certificate Provider |
| Proxy、TLS実値およびTrust Store | Runtime／Infrastructure設定 |
| Timeout、Retry、Backoff、Connection Pool、並列数 | Runtime設定・共通実行設計 |
| API固有Path、Method、DTO | API MasterおよびAPI詳細設計書 |
| Business／UseCase／Scenario別の許可条件 | UseCase／Scenario設計および実行安全設計 |
| Request、Response、Context、Expected | Scenario設計およびRunContext |
| `initialExecutionFlg`、`previousRunId`、Baseline | Execution State・Baseline管理 |
| Snapshot、Diff、Report、Evidence実体 | Run成果物およびReport設計 |
| Scheduler時刻、実行頻度、Maintenance Window | 運用設計 |
| OS、JDK、Docker、Network、Deployment | System／Infrastructure設計 |
| `NOT_EVALUATED`、`PASS`、`FAIL` | Verification Result |
| Execution／Change／Recovery Status | Run Result／Execution State |

Environment MasterからContext、Verification、Verification PolicyまたはCompare Policy Masterを参照してはならない。

## 8. 関連成果物と正本境界

```mermaid
flowchart TD
    U["UseCase Master<br/>適用Environment ID"]
    E["Environment Master<br/>論理Environment"]
    C["External Configuration<br/>URL・非Secret設定"]
    K["Secret Provider<br/>Credential実値"]
    R["Runtime<br/>接続・実行"]

    U --> E
    E --> C
    E --> K
    C --> R
    K --> R
```

| 成果物 | Environment Masterとの関係 | 正本 |
|---|---|---|
| `Environment_Master.md` | 論理Environmentの固定9項目を登録する。 | Environment Identity |
| `UseCase_Master.md` | `applicableEnvironmentIds`でEnvironmentを参照する。 | UseCase適用範囲 |
| External Configuration | Base URL、Proxy等の変更可能な非Secret実値を管理する。 | 接続実値 |
| Secret Provider | Credential、Token、証明書秘密情報を管理する。 | Secret実値 |
| Runtime設定 | Timeout、Retry、並列数等を管理する。 | 実行制御 |
| Execution State | Run、Baselineおよび前回実行を管理する。 | 実行状態 |

Environment MasterのReference Keyは外部設定を識別するが、値そのものではない。

## 9. Environment成立条件

次をすべて満たす対象を一つのEnvironmentとして登録する。

1. 論理的な実行先として独立して選択される。
2. Environment Typeと用途を説明できる。
3. 接続先Systemを特定できる。
4. Base URLとAuthenticationを外部設定から解決できる、または不要である。
5. 本番環境か否かをEnvironment Typeで判断できる。
6. 接続・運用責任のOwnerが存在する。

次の差異だけでは新しいEnvironmentを作成しない。

| 差異 | 取扱い |
|---|---|
| Host交換、IP変更 | 同一IDを維持し、外部設定を変更する。 |
| Credential Rotation | 同一IDを維持し、Secret Providerを更新する。 |
| Timeout、Retry変更 | Runtime設定を変更する。 |
| API Path変更 | API設計を変更する。 |
| RunごとのInput差 | Scenario Inputを変更する。 |
| Baseline世代差 | Execution Stateで管理する。 |

用途、安全境界または運用責任が別物になるEnvironment分割では、新IDを採番する。

## 10. 正式レコード

`Environment_Master.md`では、一行を一つの論理Environmentとする。正式列は次の9項目とし、順序を固定する。

| No. | 表示名 | 列名 | 型 | 必須 | 設定規則 |
|---:|---|---|---|:---:|---|
| 1 | Environment ID | `environmentId` | String | Yes | `ENV-NAME`形式。一意かつ不変。 |
| 2 | Environment名称 | `environmentName` | String | Yes | 組織内で識別できる正式名称。 |
| 3 | Environment Type | `environmentType` | Enum | Yes | 許可Enumから一つ設定する。 |
| 4 | 用途 | `purpose` | String | Yes | 主な利用目的を一文で記述する。 |
| 5 | System ID | `systemId` | String | Yes | 接続対象Systemの固定ID。 |
| 6 | Base URL Reference | `baseUrlRef` | String / `NONE` | Yes | 外部Configuration Key。URL実値は禁止。 |
| 7 | Authentication Profile Reference | `authProfileRef` | String / `NONE` | Yes | 外部Authentication Profile Key。Secret実値は禁止。 |
| 8 | Environment Owner | `environmentOwner` | String | Yes | 接続・運用責任を持つRoleまたは組織。 |
| 9 | 有効フラグ | `enabled` | Boolean | Yes | `true`または`false`。 |

記述形式は次のとおりである。

```markdown
| environmentId | environmentName | environmentType | purpose | systemId | baseUrlRef | authProfileRef | environmentOwner | enabled |
|---|---|---|---|---|---|---|---|:---:|
| ENV-STAGING | Staging検証環境 | STAGING | 結合および日次回帰検証に使用する。 | E6 | CONFIG:E6:STAGING:BASE_URL | AUTH:E6:STAGING | Verification Platform Operations | true |
```

## 11. 項目別設計規則

### 11.1 `environmentId`

- Patternは`^ENV-[A-Z0-9]+(?:-[A-Z0-9]+)*$`とする。
- Repository全体で一意とする。
- Host名、IP Address、個人名、Credentialまたは日付を含めない。
- Host変更だけではIDを変更しない。
- 廃止IDを再利用しない。

### 11.2 `environmentName`

- 組織内の正式な論理Environment名称とする。
- 物理Host名だけを名称にしない。
- 本番環境は名称と`environmentType=PRODUCTION`を一致させる。

### 11.3 `environmentType`

許可値は次のとおりとする。

| 値 | 意味 |
|---|---|
| `LOCAL` | 開発者またはCI上の隔離されたLocal検証環境 |
| `DEVELOPMENT` | 共同開発環境 |
| `INTEGRATION` | System間結合環境 |
| `STAGING` | Release前の正式検証環境 |
| `PRODUCTION` | 本番環境 |
| `SANDBOX` | 外部影響を隔離した実験環境 |
| `OTHER` | 上記以外。用途と理由を明記する。 |

### 11.4 `purpose`

- 主な利用目的を一文で記述する。
- Schedule、実行時刻、個別Scenario名または一時的な作業目的を記載しない。
- 本番環境は承認・安全制約の詳細を運用設計へ委ねる。

### 11.5 `systemId`

- 接続対象Systemの固定識別子を設定する。
- Host、Service名、Java Module名またはEnvironment名を設定しない。
- 本ProjectでE6へ接続する場合は`E6`とする。

### 11.6 `baseUrlRef`

- 形式は`CONFIG:<SYSTEM>:<ENVIRONMENT>:BASE_URL`を推奨する。
- `https://`、Host、IP Address、PortまたはQueryを直接記載しない。
- 外部設定を必要としないMock環境だけ`NONE`を許可する。
- 有効EnvironmentのReferenceはRuntime開始前に解決可能でなければならない。

### 11.7 `authProfileRef`

- 形式は`AUTH:<SYSTEM>:<ENVIRONMENT>`を推奨する。
- Username、Password、Token、Secret Key、Client Secret、Cookieまたは証明書実値を記載しない。
- 認証不要の隔離Mock環境だけ`NONE`を許可する。
- ProfileからSecret実値への解決はSecret Providerの責務とする。

### 11.8 `environmentOwner`

- 接続、外部設定、利用可否および運用判断の責任Roleまたは組織を設定する。
- 個人連絡先、CredentialまたはSecretを記載しない。
- 空欄または`NONE`を許可しない。

### 11.9 `enabled`

- `true`は新しいUseCaseおよび実行計画から参照可能であることを表す。
- `false`は新規参照禁止である。
- 外部設定Reference、Ownerまたは安全分類が未確認の場合は`true`にしない。
- `enabled=true`だけで個別Business、UseCaseまたはScenarioの実行許可を保証しない。
- 文書`status`の代替として使用しない。

## 12. 実行可否の責務

Environment Masterの`enabled`は、論理Environment自体を新しい実行計画から参照可能かだけを表す。

最終的な実行可否は次を組み合わせて判定する。

```text
Environment.enabled
AND UseCase.applicableEnvironmentIds
AND Scenario設計上の制約
AND Runtime安全設定
AND 必要な承認
```

Environment MasterへBusiness別、UseCase別、Scenario別の巨大なAllow／Deny表を追加してはならない。

## 13. Security規則

次を検出した場合、Validationを`ERROR`とする。

- URL実値
- IP Address
- UsernameまたはPassword
- Token、API KeyまたはClient Secret
- CookieまたはSession ID
- 秘密鍵または証明書秘密情報
- 個人情報

Reference KeyにSecret実値を含めてはならない。Referenceの命名からCredential内容を推測できる情報も避ける。

## 14. Reference規則

### 14.1 ID Reference

UseCaseからEnvironmentへのReferenceは`UseCase_Master.applicableEnvironmentIds`を正本とする。

### 14.2 Configuration Reference

`baseUrlRef`と`authProfileRef`は外部設定Keyであり、File Pathではない。

次を満たすこと。

1. Keyが規定形式に一致する。
2. 有効Environmentでは実行開始前に解決できる。
3. 解決結果をLogまたはReportへSecretとして出力しない。
4. Reference変更時もEnvironment IDを維持する。

### 14.3 Reference不一致

次を`ERROR`とする。

- UseCaseが存在しない`environmentId`を参照する。
- 有効UseCaseが無効Environmentを参照する。
- 有効Environmentの外部設定Keyが解決できない。
- `baseUrlRef`または`authProfileRef`に実値が記載されている。

## 15. Validation

### 15.1 単一レコードValidation

| Rule ID | 規則 | Level |
|---|---|---|
| `ENV-MST-V001` | 正式表が9列で、列名と順序が本書に一致する。 | ERROR |
| `ENV-MST-V002` | `environmentId`がPatternに一致し一意である。 | ERROR |
| `ENV-MST-V003` | 必須項目が空欄でない。 | ERROR |
| `ENV-MST-V004` | `environmentType`が許可Enumである。 | ERROR |
| `ENV-MST-V005` | `enabled`がBooleanである。 | ERROR |
| `ENV-MST-V006` | 廃止値`PRODUCTION_LIKE`が使用されていない。 | ERROR |
| `ENV-MST-V007` | URL、IP、Credential、Secretまたは個人情報を含まない。 | ERROR |
| `ENV-MST-V008` | Reference Keyが規定形式または`NONE`である。 | ERROR |

### 15.2 Cross-Master Validation

| Rule ID | 規則 | Level |
|---|---|---|
| `ENV-MST-X001` | UseCaseの全`applicableEnvironmentIds`がEnvironment Masterで解決できる。 | ERROR |
| `ENV-MST-X002` | 有効UseCaseが無効Environmentを参照しない。 | ERROR |
| `ENV-MST-X003` | Environmentの`systemId`が対象UseCaseおよびAPIのSystemと矛盾しない。 | ERROR |
| `ENV-MST-X004` | Production Environmentの利用がScenario／運用設計で保護される。 | WARNING |

### 15.3 Runtime Validation

| Rule ID | 規則 | 判定 |
|---|---|---|
| `ENV-MST-R001` | 有効Environmentの`baseUrlRef`が解決できる。 | 未解決時`BLOCKED` |
| `ENV-MST-R002` | 認証が必要な有効Environmentの`authProfileRef`が解決できる。 | 未解決時`BLOCKED` |
| `ENV-MST-R003` | Secret実値をMasterまたはValidation Evidenceへ出力していない。 | 違反時`FAIL` |
| `ENV-MST-R004` | Production Environmentの承認・安全Gateが存在する。 | 未確認時`BLOCKED` |

## 16. 変更管理

| 変更 | ID | 必要な処置 |
|---|---|---|
| 名称、Purpose変更 | 継続 | Masterと運用文書を更新する。 |
| Host、Base URL変更 | 継続 | 外部Configurationを更新し、接続確認を行う。 |
| Credential Rotation | 継続 | Secret Providerを更新し、Masterを変更しない。 |
| Environment Type変更 | 原則継続 | Safety ReviewとUseCase影響を確認する。 |
| 本番区分への変更 | 継続 | Security、運用、UseCaseおよびScenarioを再Reviewする。 |
| 論理Environment分割 | 新ID | 旧IDの無効化とReference移行を行う。 |
| 利用停止 | 継続 | `enabled=false`とし、新規参照を禁止する。 |
| 物理削除 | 原則禁止 | 参照0件、過去Run解決性および承認を確認する。 |

## 17. Java・Runtimeとの境界

Javaは`environmentId`を受け取り、Environment Masterから外部設定Keyを解決対象として取得できる。

```text
environmentId
    ↓
Environment Master
    ↓
baseUrlRef / authProfileRef
    ↓
External Configuration / Secret Provider
    ↓
Runtime Connection
```

JavaはMasterへ次の値を書き戻してはならない。

- 解決後のURL
- TokenまたはCredential
- Run ID
- Response
- Baseline
- 実行結果
- Retry回数またはTimeout実績

## 18. Review Checklist

- [ ] 一つの論理Environmentを一つのレコードとしている。
- [ ] 正式9項目と列順が本書に一致する。
- [ ] Host変更だけで別Environmentを登録していない。
- [ ] Environment名称、TypeおよびPurposeが整合し、本番は`PRODUCTION`で明示される。
- [ ] Base URLとAuthenticationがReference Keyである。
- [ ] Credential、Secret、URL、IPまたは個人情報を含まない。
- [ ] Environment Ownerが明確である。
- [ ] UseCaseのEnvironment Referenceが解決できる。
- [ ] Timeout、Retry、ScheduleまたはRun状態が混入していない。
- [ ] 廃止済みMasterを参照していない。

## 19. 完了条件

本設計書は次をすべて満たした時点で内容完成とする。

1. 正式9項目、型、必須およびEnumが確定している。
2. 論理Environmentと物理接続実値の境界が定義されている。
3. Secret非保持と外部設定Reference規則が定義されている。
4. UseCaseからのReferenceおよび実行可否境界が定義されている。
5. ValidationとRelease Gateが定義されている。
6. `Environment_Master.md`と`Environment_Master_Example.md`が本書に一致する。
7. `Master共通設計書.md`、GuideおよびChecklistと矛盾しない。
8. Context、Verification、Verification PolicyまたはCompare Policy Masterへ依存しない。

内容完成はRelease凍結を意味しない。外部設定、OwnerまたはProduction Environmentの安全Gateが未解決の場合、Release判定は`BLOCKED`とする。

## 20. 決定事項

| Decision ID | 決定事項 | 理由 |
|---|---|---|
| `ENV-MST-DEC-001` | Environment Masterは固定9項目とする。 | 廃止したProduction-like属性を正本構造へ残さず、機械検証可能な形式を維持するため。 |
| `ENV-MST-DEC-002` | URLとCredentialの実値を保持せずReference Keyだけを保持する。 | Secret漏えいとEnvironment差分の重複を防止するため。 |
| `ENV-MST-DEC-003` | Timeout、Retry、並列数およびScheduleを正式列にしない。 | Runtime／運用責務との二重管理を防止するため。 |
| `ENV-MST-DEC-004` | Business／UseCase／Scenario別の実行許可表をEnvironment Masterに持たない。 | 巨大な双方向関係と複数正本を防止するため。 |
| `ENV-MST-DEC-005` | 本番環境は`environmentType=PRODUCTION`で識別し、Production-like Environmentおよび`productionLike`属性を使用しない。 | 環境区分と安全判断を二重管理しないため。 |

## 21. 未決事項

| Issue ID | 内容 | 現在の扱い | Release影響 |
|---|---|---|---|
| `ENV-MST-ISSUE-001` | `ENV-PROD`の環境区分 | `PRODUCTION`（本番）として解決済み。実行可否は別Issueとして`enabled=false`を維持する。 | 区分Blockerなし |
| `ENV-MST-ISSUE-002` | 各Environmentの外部Configuration／Authentication Keyの実在性 | Runtime設定完成時に解決確認する。 | 未解決時`BLOCKED` |
