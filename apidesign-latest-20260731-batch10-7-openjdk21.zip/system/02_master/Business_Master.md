---
title: Business Master
document_id: MST-E6-BUS-001
version: 3.0.0-draft.1
status: DRAFT
data_status: EMPTY_PENDING_BUSINESS_ANALYSIS
document_type: Master
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# Business Master

## 1. 文書目的

本書は、E6 API Verification Platformが検証対象とするBusinessの固定Identity、業務目的、業務境界および現行業務分析書Referenceを一元管理する正本である。

正式項目、粒度、EnumおよびValidation規則は`system/02_master/design/Business_Master設計書.md`に従う。

## 2. 現在の登録状態

現時点では、7業務Flowの現行業務分析とBusiness Owner Reviewが未完了であるため、正式Businessを登録しない。

| 区分 | 件数 | 状態 |
|---|---:|---|
| 正式Business | 0 | `EMPTY_PENDING_BUSINESS_ANALYSIS` |
| 有効Business | 0 | 実行対象なし |
| 分析予定業務Flow | 7 | 名称、境界および根拠資料の確定待ち |

会話中の設計検討で作成した`BUS-E6-001`「会員情報更新業務」はE6の確認済み事実ではないため、正式一覧から除外した。履歴は`recovery/synthetic_001_member_model/`に隔離し、正式成果物またはRuntimeから参照しない。

## 3. 正式Business一覧

| businessId | businessName | systemId | businessCategory | businessPurpose | businessScope | businessAnalysisRef | businessOwner | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|

空表は「Businessが存在しない」ことを意味せず、正式な根拠資料に基づく登録がまだ完了していないことを意味する。

## 4. 登録Gate

Businessは次の条件をすべて満たした場合だけ登録する。

1. `business/flows/{businessCode}/現行業務分析書.md`が存在する。
2. 業務開始点、終了点、Actor、分岐および対象範囲が説明できる。
3. `businessId`、正式名称、`businessCategory`およびOwnerが確定している。
4. Business OwnerまたはBA LeadのReview Evidenceがある。
5. Example、会話上の仮定または件数合わせを根拠にしていない。

条件未達の候補を`enabled=false`の正式レコードとして先行登録してはならない。

## 5. Business分類

| businessCategory | 説明 |
|---|---|
| `INQUIRY` | 照会・取得を主目的とする。 |
| `REGISTRATION` | 新規登録を主目的とする。 |
| `UPDATE` | 既存状態の更新を主目的とする。 |
| `CANCELLATION` | 取消、無効化または削除を主目的とする。 |
| `FILE` | File入出力を主目的とする。 |
| `COMMON` | 複数業務に共通する業務境界。 |
| `OTHER` | 上記以外。理由を`description`へ記載する。 |

## 6. 参照整合性

| Validation ID | 確認内容 | 現在の判定 |
|---|---|---|
| `BUS-MST-V001` | 正式表が設計書の固定10列と一致する。 | PASS |
| `BUS-MST-V002` | 正式レコードが業務分析書で根拠付けられている。 | NOT_APPLICABLE（0件） |
| `BUS-MST-V003` | UseCaseの`businessIds`が本書で解決できる。 | NOT_APPLICABLE（UseCase 0件） |
| `BUS-MST-V004` | ExampleまたはRecoveryを正式Referenceにしていない。 | PASS |
| `BUS-MST-R001` | 7業務FlowのBusiness登録と承認が完了している。 | BLOCKED |

## 7. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| 業務背景、Actor、詳細Flow、分岐 | `business/flows/` |
| UseCase目的と詳細Flow | UseCase Master／UseCase設計書 |
| Scenario経路とAPI呼出 | Scenario Master／Scenario詳細設計書／Java |
| Request／Response項目 | API詳細設計書／DTO |
| Input、Expected、Check、Diff | Scenario Input／Expected／Java／検証設計 |
| Context、Run状態、Baseline | Framework／Runtime |

## 8. 要確認事項

| Issue ID | 確認事項 | 影響 | 状態 |
|---|---|---|---|
| `BUS-MST-ISSUE-001` | 7業務Flowの正式名称、境界および業務分析書Path | Business登録 | Open |
| `BUS-MST-ISSUE-002` | 各Business Owner／BA Lead | 承認責任 | Open |
| `BUS-MST-ISSUE-003` | Business ID採番順序 | 初回登録 | Open |

## 9. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `3.0.0-draft.1` | 2026-07-27 | 架空の会員情報更新Businessを正式一覧から除外。正式Businessを0件とし、業務分析完了後に登録するGateを明文化。 |
