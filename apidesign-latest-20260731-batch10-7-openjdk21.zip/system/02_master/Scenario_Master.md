---
title: Scenario Master
document_id: MST-E6-SC-001
version: 3.0.0-draft.6
status: DRAFT
data_status: EMPTY_PENDING_USECASE_DESIGN
document_type: Master
system_name: E6 API Verification Platform
updated: 2026-07-29
---

# Scenario Master

## 1. 文書目的

本書は、UseCase内の開始条件、実行経路または期待終了状態が異なるScenarioの固定Identity、種別、Java実行Class、Input、Expectedおよび詳細設計Referenceを一元管理する正本である。

正式項目とValidation規則は`system/02_master/design/Scenario_Master設計書.md`に従う。

## 2. 現在の登録状態

正式UseCaseが0件である。Java Source Root、Moduleおよび明示Registry Scaffoldは承認・作成済みだが、正式Scenario設計／Class／Input／Expectedが存在しないため、Scenarioを登録しない。

| 区分 | 件数 | 状態 |
|---|---:|---|
| 正式Scenario | 0 | `EMPTY_PENDING_USECASE_DESIGN` |
| 有効Scenario | 0 | 実行対象なし |
| Java／Registry解決可能Scenario | 0 | 正式Scenario設計／Class登録待ち |

架空の`SC-E6-001～003`、InputおよびExpectedは正式一覧から除外し、Recoveryへ隔離した。

## 3. 正式Scenario一覧

| scenarioId | useCaseId | scenarioName | scenarioType | executionClass | inputRef | expectedRef | scenarioDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|

## 4. 登録Gate

Scenarioは次の条件をすべて満たした場合だけ登録する。

1. 所属する正式UseCaseが存在する。
2. 開始条件、経路または期待終了状態の差異を説明できる。
3. Scenario詳細設計、InputおよびExpectedの作成計画が確定している。
4. 参照APIをAPI Masterで解決できる。
5. `executionClass`を正式Java Source Rootで解決でき、`scenarioId`で一意に解決したScenario Registry Descriptorの`implementationType`と完全一致するか、実装計画と有効化Gateが承認されている。

存在しないJava Classや架空Input／Expectedを参照するScenarioを`enabled=true`にしてはならない。

## 5. Scenario種別

| scenarioType | 説明 |
|---|---|
| `NORMAL` | 主正常経路。 |
| `ALTERNATIVE` | 正常に成立し得る分岐経路。 |
| `EXCEPTION` | 業務Errorまたは技術Error経路。 |
| `BOUNDARY` | 境界値・上限・下限を確認する経路。 |
| `TIMEOUT` | Timeout、停止、SkipおよびRecovery引渡しを確認する経路。 |

## 6. 参照整合性

| Validation ID | 確認内容 | 現在の判定 |
|---|---|---|
| `SC-MST-V001` | 正式表が固定10列と一致する。 | PASS |
| `SC-MST-V002` | 所属UseCaseと双方向Referenceが一致する。 | NOT_APPLICABLE（0件） |
| `SC-MST-V003` | Input、Expectedおよび詳細設計を解決できる。 | NOT_APPLICABLE（0件） |
| `SC-MST-V004` | `executionClass`をBuild対象で解決でき、`scenarioId`単位のScenario Registry Descriptorと完全一致する。 | NOT_APPLICABLE（0件） |
| `SC-MST-V005` | 有効Scenarioが無効APIを参照しない。 | NOT_APPLICABLE（0件） |
| `SC-MST-V006` | ExampleまたはRecoveryを正式Referenceにしていない。 | PASS |
| `SC-MST-R001` | 正式UseCaseのScenario Coverageが承認済みである。 | BLOCKED |

## 7. 要確認事項

| Issue ID | 確認事項 | 影響 | 状態 |
|---|---|---|---|
| `SC-MST-ISSUE-001` | 正式UseCaseとScenario Coverage | Scenario登録 | Open |
| `SC-MST-ISSUE-002` | Base Packageは`jp.co.mufg.e6.verifier`へ確定済み。Java Source RootおよびRegistry Descriptor抽出実装 | `executionClass`／Build Trace | Waiting |
| `SC-MST-ISSUE-003` | Input／Expected SchemaとBuild Validation | 実行前Gate | Open |

## 8. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `3.0.0-draft.1` | 2026-07-27 | 架空のSC-E6-001～003を正式一覧から除外。正式UseCaseとJava設計完了後に登録するGateを明文化。 |
| `3.0.0-draft.2` | 2026-07-28 | 第9バッチのScenario Registry Bindingに合わせ、`executionClass`のBuild解決、Descriptor完全一致および反射実行禁止Gateを同期。 |
| `3.0.0-draft.3` | 2026-07-29 | 第10バッチのSource Root／Module／Registry物理契約候補を反映し、正式Scenario登録GateをTop Level承認・Java Scaffold待ちへ更新。 |
| `3.0.0-draft.4` | 2026-07-29 | Java Base Packageを`jp.co.mufg.e6.verifier`へ確定し、正式Scenario登録の残存GateをSource Root承認・Java Scaffold・Build Traceへ限定。 |
| `3.0.0-draft.5` | 2026-07-29 | `REP-CR-010`承認と明示Registry Scaffoldを反映し、正式Scenario登録Gateを正式設計／ClassおよびJava 21 Build Traceへ更新。 |
| `3.0.0-draft.6` | 2026-07-29 | `REP-CR-011`によるJava 17互換基線を反映し、Java Scaffold未作成という旧状態を是正して、正式Scenario登録Gateを正式設計／ClassおよびJDK 17 Build Traceへ更新。 |
| `3.0.0-draft.7` | 2026-07-31 | `REP-CR-014`により現行Scenario登録のBuild Trace基線をOpenJDK 21へ訂正。Master列と正式Scenario件数は変更なし。 |
