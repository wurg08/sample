---
title: Master ID・Reference記述ガイド
document_id: GUIDE-E6-MST-002
version: 2.0.0-draft.2
status: DRAFT
document_type: Guide
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Master ID・Reference記述ガイド

## 1. 目的

本書は、E6 API Verification PlatformのMaster、Scenario詳細設計およびTraceability Viewで使用するID、ID Reference、File Reference、List Referenceの記述規則を定義する。

目的は、名称変更、File移動、実行順序変更および世代交代が発生しても、過去から現在まで同一対象を安定して追跡できる状態を保証することである。

## 2. 適用範囲

- Business、Environment、API、UseCase、Scenarioの各Master
- API・UseCase・Scenario対応表
- Scenario詳細設計書
- Scenario Input／Expected
- API詳細設計書
- Java Scenario Classおよび実行結果
- Guide、ChecklistおよびExample内の参照例

## 3. 基本原則

| Rule ID | 原則 | 規則 |
|---|---|---|
| `ID-REF-P001` | 一意性 | IDは定義されたScope内で一意とする。 |
| `ID-REF-P002` | 不変性 | 初回採番後、同一対象のIDを変更しない。 |
| `ID-REF-P003` | 非再利用 | 無効化または廃止したIDを別対象へ再利用しない。 |
| `ID-REF-P004` | 欠番許容 | 連番の欠番を許容し、番号詰めを行わない。 |
| `ID-REF-P005` | ID参照 | 名称、Path、Class名または表示順で論理参照しない。 |
| `ID-REF-P006` | Scope明示 | 全体IDとScenario内Local IDを区別する。 |
| `ID-REF-P007` | 相対Path | File ReferenceはRepository Root基準とする。 |
| `ID-REF-P008` | 解決可能性 | 有効レコードの必須ReferenceはBuild時に解決可能とする。 |
| `ID-REF-P009` | 正本優先 | ViewまたはExampleをID定義の正本としない。 |
| `ID-REF-P010` | 原子的変更 | IDまたはPathに関わる全参照を同一Change Setで更新する。 |

## 4. ID体系

| 識別子 | Pattern | Scope | 正本 | 例 |
|---|---|---|---|---|
| `businessId` | `BUS-E6-NNN` | Repository全体 | Business Master | `BUS-E6-001` |
| `environmentId` | `ENV-NAME` | Repository全体 | Environment Master | `ENV-STAGING` |
| `apiId` | `API-NNN` | Repository全体 | API Master | `API-002` |
| `useCaseId` | `UC-E6-NNN` | Repository全体 | UseCase Master | `UC-E6-001` |
| `scenarioId` | `SC-E6-NNN` | Repository全体 | Scenario Master | `SC-E6-003` |
| `apiCallCode` | `CALL-NNN` | 一つのScenario内 | Scenario詳細設計書 | `CALL-020` |
| `resultKey` | Stable Key | Scenario設計・Expected・実行結果の対応範囲 | Scenario設計／Expected／Java | `API.CALL-020.RESPONSE` |

`NNN`は3桁以上の数字とする。番号は表示順または重要度を意味しない。

## 5. IDごとの記述規則

### 5.1 `businessId`

- 一つの安定した業務分類または業務境界に一つ採番する。
- 部署名、担当者名、年度またはEnvironment名を含めない。
- 業務名称変更ではIDを維持する。
- 業務境界が別物になる分割・統合では、新ID採番と旧ID無効化を検討する。

```text
OK: BUS-E6-001
NG: BUS-会員更新
NG: BUS-E6-2026-001
```

### 5.2 `environmentId`

- 論理的な実行環境単位で採番する。
- 許可された大文字英数字とHyphenを使用する。
- Host名、IP Address、Credential、個人名を含めない。
- Host変更だけではIDを変更しない。

```text
OK: ENV-LOCAL
OK: ENV-STAGING
OK: ENV-PROD
NG: ENV-10.0.0.15
NG: ENV-wu-PC
```

### 5.3 `apiId`

- 一つのAPI契約に一つ採番する。
- 同一APIを複数Scenarioまたは同一Scenario内で複数回呼び出しても、API Masterへ重複登録しない。
- MethodまたはEndpoint PathをIDに含めない。
- API契約上の同一性が失われる非互換置換では、新IDを採番する。

```text
OK: API-001
NG: POST-/api/v1/members/search
NG: API-001-CALL2
```

### 5.4 `useCaseId`

- 一つの独立して説明可能な業務検証目的に一つ採番する。
- 正常／異常、入力Pattern、TimeoutまたはSkipの差だけで別UseCaseを採番しない。
- 業務目的と範囲の同一性を維持する変更ではIDを維持する。

```text
OK: UC-E6-001
NG: UC-E6-001-NORMAL
NG: UC-API-001
```

### 5.5 `scenarioId`

- 一つの確定した業務実行経路かつ一回の同期Java Batch実行単位に一つ採番する。
- 開始条件、主要経路または期待終了状態の差をScenario分割の判断材料とする。
- 単一フィールドCheckの差だけで別IDを採番しない。

```text
OK: SC-E6-001
NG: SC-E6-001-CHECK-01
NG: SC-API-001-ERROR
```

### 5.6 `apiCallCode`

- Scopeは一つのScenario内とする。
- 同一Scenario内で一意とする。
- 同じAPIを二回呼び出す場合も、呼出実体ごとに異なるCodeを使用する。
- API変更後も同じ業務上の呼出役割を維持する場合は、原則としてCodeを維持する。
- `callSequence`変更だけでCodeを変更しない。

```text
SC-E6-001 / CALL-001 → API-001
SC-E6-001 / CALL-002 → API-002
SC-E6-001 / CALL-003 → API-001
```

別Scenarioでは`CALL-001`を再利用できる。

### 5.7 `resultKey`

- Check結果、Expectedおよび実行Evidence間で同一結果を追跡できるStable Keyとする。
- Array Index、表示順または実行時に変動する値だけをKeyにしない。
- `sequence`は表示順であり、`resultKey`の代替ではない。
- API呼出結果を表す場合は、可能な限り`apiCallCode`を含め、同一APIの複数回呼出を区別する。
- `resultKey`一覧の正本はScenario設計・Expected・Javaであり、Masterへ列として追加しない。

```text
OK: API.CALL-002.STATUS
OK: BUSINESS.MEMBER_STATUS_TRANSITION
NG: RESULT-1
NG: API-001-RESPONSE
```

## 6. 採番

### 6.1 採番手順

1. 対象のIdentityとScopeを確定する。
2. 対応する正本で既存IDを全件検索する。
3. 同一対象が未登録であることを確認する。
4. 使用済み・廃止済みを含む最大番号と予約番号を確認する。
5. 未使用番号を採番する。
6. 採番記録、Change IDおよびOwnerを残す。
7. 正本へ登録し、Reference Validationを実行する。

同時作業時は、Master Ownerまたは採番管理機構が番号競合を防止する。

### 6.2 900番台

`900`番台はExampleの架空データ用とする。

| 用途 | 例 |
|---|---|
| API Example | `API-901` |
| UseCase Example | `UC-E6-901` |
| Scenario Example | `SC-E6-901` |

正式Masterへ900番台Example IDを登録してはならない。将来正式番号域が900番台へ到達する場合は、Example用番号域を先に変更し、混在を防ぐ。

### 6.3 禁止

- 欠番を詰めるための再採番
- 廃止IDの再利用
- Branchごとの独立採番
- 名称またはPathからの自動ID再生成
- 仮番号を`enabled=true`の正式レコードとしてRelease

## 7. ID継続と新IDの判断

| 変更 | 原則 |
|---|---|
| 名称・説明変更 | ID継続 |
| File名・Class名変更 | ID継続、Reference更新 |
| API Pathの訂正 | 契約上同一ならID継続 |
| API非互換置換 | 新API ID |
| UseCase目的の全面変更 | 新UseCase ID |
| Scenario内の軽微な順序変更 | Scenario IDと`apiCallCode`を原則継続 |
| Scenario経路・終了状態が別物へ変更 | 新Scenario IDを検討 |
| Environment Host変更 | Environment ID継続 |
| 論理Environmentの分割 | 新Environment ID |

新ID採番時は、旧IDを物理削除せず`enabled=false`として追跡性を保持する。

## 8. ID Reference

### 8.1 参照関係

```mermaid
flowchart TD
    B["businessId"] --> U["useCaseId"]
    U --> S["scenarioId"]
    S --> C["apiCallCode"]
    C --> A["apiId"]
    C --> R["resultKey"]
```

| 参照元 | 参照先 | 記述場所 |
|---|---|---|
| UseCase Master | `businessId` | `businessIds` |
| UseCase Master | `environmentId` | `applicableEnvironmentIds` |
| UseCase Master | `scenarioId` | `scenarioIds` |
| Scenario Master | `useCaseId` | `useCaseId` |
| Scenario詳細設計 | `apiId` | API呼出明細 |
| 対応表 | 全ID | 正本からの派生表示 |

### 8.2 解決規則

1. 参照値は参照先の正本に存在する。
2. 文字列の大文字・小文字を完全一致させる。
3. 名称を併記しても、結合Keyには使用しない。
4. 有効レコードから無効レコードへの新規参照を禁止する。
5. 参照先不在を`enabled=false`または`INACTIVE`で吸収しない。
6. 循環参照を導入しない。

### 8.3 双方向関係

UseCaseとScenarioは次を満たす。

```text
UseCase_Master.scenarioIds
    =
Scenario_Masterで同一useCaseIdを持つ全scenarioIdの集合
```

集合には有効・無効Scenarioを含める。Listの表示順はIdentityまたは実行順序を意味しない。

## 9. File Reference

### 9.1 記述形式

Repository Root基準の相対Pathを使用する。

```text
OK: system/03_api_design/examples/API-901設計書_Example.md
OK: system/04_usecase_design/examples/input/SC-E6-901-input_Example.json
NG: ./system/03_api_design/examples/API-901設計書_Example.md
NG: ../03_api_design/API-001設計書.md
NG: C:\work\repo\system\03_api_design\API-001設計書.md
NG: /home/user/repo/system/03_api_design/examples/API-901設計書_Example.md
```

### 9.2 規則

- `/`を区切り文字として使用する。
- 先頭に`/`、`./`または`../`を付けない。
- 実ファイルと大文字・小文字を一致させる。
- URL、共有Drive URL、個人PC Pathを設定しない。
- 参照先ファイル名へ対象IDを含める。
- Spaceを含むFile名を新規採用しない。
- File移動・改名時は全参照元を同一Change Setで更新する。
- 有効レコードの必須参照先はBuild時に存在確認する。

### 9.3 Referenceと正本

File Referenceは対象ファイルの場所を示す。参照元Masterへ参照先の詳細内容を複写しない。

| Reference | 参照先の正本内容 |
|---|---|
| `apiDesignRef` | Request／Response項目、契約詳細 |
| `useCaseDesignRef` | Actor、Trigger、業務Flow |
| `scenarioDesignRef` | API呼出、分岐、Check |
| `inputRef` | Scenario初期入力 |
| `expectedRef` | Expectedおよび`resultKey` |

## 10. List Reference

Markdown Tableの一セルに複数IDを記述する場合は`<br>`で区切る。

```markdown
BUS-E6-001<br>BUS-E6-002
```

規則：

1. 重複を含めない。
2. 特別な意味がなければID昇順とする。
3. 前後に空白を付けない。
4. `,`、`、`、`/`を区切り文字として混在させない。
5. 並び順だけで実行順序、優先度または主従を表現しない。
6. 空Listを`-`で表現して必須性を回避しない。

## 11. Java Class Reference

`executionClass`はJava完全修飾Class名を使用する。

```text
OK: com.example.e6.scenario.MemberUpdateScenario
NG: MemberUpdateScenario
NG: src/main/java/com/example/e6/scenario/MemberUpdateScenario.java
```

Class名は変更可能な実装参照であり、`scenarioId`の代替Keyではない。Class改名時もScenarioの同一性が維持される限り`scenarioId`を変更しない。

`executionClass`はBuild Trace用の宣言Referenceであり、Runtimeの反射実行命令ではない。Scenario Registryは`scenarioId`で一件だけ解決し、Descriptorの`implementationType`が`executionClass`と完全一致しなければならない。Registry Key、Class存在、Interface、Build IdentityまたはBinding Scopeのいずれかが不一致の場合、Referenceを`BLOCKED`または`BROKEN`とする。

## 12. 対応表での記述

| 項目 | Identity上の扱い |
|---|---|
| `scenarioId + apiCallCode` | 一行の複合Key |
| `apiId` | API正本への参照 |
| `useCaseId` | 親UseCaseへの参照 |
| `callSequence` | 表示・実行順序。Identityではない |
| 名称 | 正本から導出する表示値 |
| `relationStatus` | 各正本の`enabled`から導出 |

対応表でIDを新規採番しない。対応表の値を正本へ逆反映しない。

## 13. Exampleの扱い

- ExampleはFile名の`_Example`と`document_type`で識別し、本文で架空値と明示する。`Example`をLifecycle Statusとして使用しない。
- Example IDは正式MasterのReferenceとして使用しない。
- ExampleのPathは記述形式を示すもので、実ファイル存在を保証しない。
- Exampleから正式成果物を作成する場合は、全ID、名称、Path、Classおよび業務値を正式根拠で置換する。

## 14. Validation

| Rule ID | 確認内容 | Level |
|---|---|---|
| `ID-REF-V001` | IDが定義Patternに一致する。 | ERROR |
| `ID-REF-V002` | IDがScope内で一意である。 | ERROR |
| `ID-REF-V003` | 廃止IDが再利用されていない。 | ERROR |
| `ID-REF-V004` | 全ID Referenceが正本で解決できる。 | ERROR |
| `ID-REF-V005` | UseCaseとScenarioの双方向関係が一致する。 | ERROR |
| `ID-REF-V006` | 有効レコードが無効参照先を新規参照しない。 | ERROR |
| `ID-REF-V007` | 必須File Referenceが相対Path形式である。 | ERROR |
| `ID-REF-V008` | 有効レコードの必須Fileが存在する。 | ERROR |
| `ID-REF-V009` | List Referenceに重複がない。 | ERROR |
| `ID-REF-V010` | `apiCallCode`がScenario内で一意である。 | ERROR |
| `ID-REF-V011` | 対応表の`scenarioId + apiCallCode`が一意である。 | ERROR |
| `ID-REF-V012` | `callSequence`がIdentityとして使用されていない。 | ERROR |
| `ID-REF-V013` | 900番台Example IDが正式Masterに混入していない。 | ERROR |
| `ID-REF-V014` | 名称、PathまたはClass名が論理結合Keyに使われていない。 | ERROR |
| `ID-REF-V015` | File名変更時に全参照元が更新されている。 | WARNING |

## 15. Review Checklist

- [ ] 対象のIdentityとID Scopeが正しい。
- [ ] 既存の同一対象がない。
- [ ] ID Patternと桁数が正しい。
- [ ] IDが一意で、廃止番号を再利用していない。
- [ ] 名称、Path、Class名または順序をKeyにしていない。
- [ ] 全ID Referenceが正本で解決できる。
- [ ] 有効参照元と参照先の状態が矛盾していない。
- [ ] File ReferenceがRepository Root基準である。
- [ ] 必須FileおよびJava Classが解決できる。
- [ ] List Referenceに重複がなく、区切りが統一されている。
- [ ] UseCaseとScenarioの双方向集合が一致する。
- [ ] `apiId`と`apiCallCode`を混同していない。
- [ ] `sequence`と`resultKey`を混同していない。
- [ ] Example IDが正式Masterに混入していない。
- [ ] 変更後も過去RunのID追跡性を維持できる。

## 16. 禁止事項

1. IDを意味のある連番として並べ替える。
2. 名称変更に合わせてIDを変更する。
3. APIの呼出回数分だけAPI IDを複製する。
4. `callSequence`を`apiCallCode`として使用する。
5. Check表示順を`resultKey`として使用する。
6. 絶対Pathまたは個人環境PathをReferenceへ記載する。
7. File Reference先の内容をMasterへ重複転記する。
8. Orphan Referenceを`enabled=false`で隠す。
9. ViewまたはExampleでIDを正式定義する。
10. 参照元を確認せずIDを無効化または物理削除する。

## 17. 完了条件

IDまたはReferenceの追加・変更は、次を満たした時点で完了とする。

1. IDのIdentity、Scope、正本および採番根拠が明確である。
2. 全Referenceが定義された正本またはFileへ解決できる。
3. 双方向関係と対応表が一致する。
4. ID・Reference Validationの`ERROR`が0件である。
5. 変更前後の追跡性と過去Runの解決性が保持される。
6. Reviewと承認Evidenceが記録されている。

## 18. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 5 Master、Scenario詳細設計およびTraceability ViewのID／Reference記述規則を全面再作成 | DRAFT |
| `2.0.0-draft.2` | 2026-07-28 | 第9バッチとして`executionClass`のBuild Trace宣言、Scenario Registry Bindingおよび反射実行禁止を追加 | DRAFT |
