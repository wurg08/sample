---
title: Environment Master
document_id: MST-E6-ENV-001
version: 2.0.0-draft.2
status: DRAFT
document_type: Master
system_name: E6 API Verification Platform
updated: 2026-07-29
---

# Environment Master

## 1. 文書目的

本書は、E6 API Verification Platformが実行対象として参照する論理Environmentと、その外部接続設定Referenceを一元管理する正本である。

正式項目、Environment粒度、Security規則およびValidationは`system/02_master/design/Environment_Master設計書.md`に従う。

## 2. 管理原則

1. 一つの論理実行環境を一つのEnvironmentとする。
2. Host、URLまたはCredential変更だけでEnvironment IDを変更しない。
3. URL、IP Address、Credential、Secretまたは個人情報を記載しない。
4. Base URLとAuthenticationは外部設定Reference Keyだけを保持する。
5. Timeout、Retry、並列数、Schedule、Run状態およびBaselineを記載しない。
6. 本番Environmentは`environmentType=PRODUCTION`で明示し、実行承認が未確認の間は有効化しない。

## 3. 正式Environment一覧

| environmentId | environmentName | environmentType | purpose | systemId | baseUrlRef | authProfileRef | environmentOwner | enabled |
|---|---|---|---|---|---|---|---|:---:|
| ENV-LOCAL | Local検証環境 | LOCAL | 開発者またはCIで隔離されたE6 API検証を行う。 | E6 | CONFIG:E6:LOCAL:BASE_URL | AUTH:E6:LOCAL | Verification Platform Operations | true |
| ENV-STAGING | Staging検証環境 | STAGING | 結合検証および日次回帰検証を行う。 | E6 | CONFIG:E6:STAGING:BASE_URL | AUTH:E6:STAGING | Verification Platform Operations | true |
| ENV-PROD | 本番環境 | PRODUCTION | E6本番APIを対象とする環境。実行には本番安全Gateと個別承認を必須とする。 | E6 | CONFIG:E6:PROD:BASE_URL | AUTH:E6:PROD | E6 Operations Owner | false |

`ENV-PROD`は本番環境である。本Toolからの本番実行可否は未確認であるため、明示承認が完了するまで`enabled=false`を維持する。

## 4. Environment Type

| environmentType | 説明 |
|---|---|
| `LOCAL` | 開発者またはCI上の隔離されたLocal検証環境 |
| `DEVELOPMENT` | 共同開発環境 |
| `INTEGRATION` | System間結合環境 |
| `STAGING` | Release前の正式検証環境 |
| `PRODUCTION` | 本番環境 |
| `SANDBOX` | 外部影響を隔離した実験環境 |
| `OTHER` | 上記以外。用途と理由の説明が必要 |

## 5. UseCase参照

UseCaseからEnvironmentへの正式Referenceは`UseCase_Master.md`の`applicableEnvironmentIds`とする。

| useCaseId | environmentId | Environment状態 | 現在の判定 |
|---|---|---|---|

正式UseCaseは0件であるため、現時点でEnvironmentへのUseCase Referenceは存在しない。

## 6. 参照整合性

| Validation ID | 確認内容 | 現在の判定 |
|---|---|---|
| `ENV-MST-V001` | 正式表が設計書の固定9列と一致する。 | PASS |
| `ENV-MST-V002` | `environmentId`がPatternに一致し一意である。 | PASS |
| `ENV-MST-V003` | `environmentType`に廃止値`PRODUCTION_LIKE`が存在しない。 | PASS |
| `ENV-MST-V004` | URL、IP、Credential、Secretまたは個人情報を含まない。 | PASS |
| `ENV-MST-X001` | UseCaseのEnvironment IDが本書で解決できる。 | NOT_APPLICABLE（UseCase 0件） |
| `ENV-MST-X002` | 有効UseCaseが無効Environmentを参照しない。 | NOT_APPLICABLE（UseCase 0件） |
| `ENV-MST-R001` | 有効Environmentの外部Configuration Keyが解決できる。 | BLOCKED |
| `ENV-MST-R002` | 有効EnvironmentのAuthentication Profileが解決できる。 | BLOCKED |

## 7. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| URL、Host、IP Addressの実値 | 外部Configuration |
| Password、Token、API Key、秘密鍵 | Secret Provider |
| Proxy、TLS、Trust Store実値 | Runtime／Infrastructure設定 |
| Timeout、Retry、並列数 | Runtime設定 |
| API Path、Method、DTO | API Master／API詳細設計書 |
| Scenario別実行条件 | Scenario詳細設計書／Java |
| Input、Expected、Context | Scenario Input／Expected／RunContext |
| Run ID、前回Run、Baseline | Execution State・Baseline管理 |
| Schedule、Maintenance Window | 運用設計 |

## 8. 変更管理

- Environment名称、PurposeまたはHost変更では`environmentId`を維持する。
- Base URL変更は外部Configurationで行う。
- Credential RotationはSecret Providerで行う。
- 本番区分への変更時はSecurity、運用、UseCaseおよびScenarioへの影響をReviewする。
- 利用停止時は`enabled=false`とし、新しい実行計画からの参照を禁止する。
- Environmentの安全境界または用途を分割する場合は新IDを採番する。

## 9. 要確認事項

| Issue ID | 確認事項 | 影響 | 状態 |
|---|---|---|---|
| `ENV-MST-ISSUE-001` | `ENV-PROD`の環境区分 | `PRODUCTION`（本番）として確定。Production-like区分は廃止。 | Resolved |
| `ENV-MST-ISSUE-002` | `ENV-PROD`を本Toolから実行可能とするか | `enabled`／運用承認 | Open |
| `ENV-MST-ISSUE-003` | 各Configuration／Authentication Reference Keyの実在性 | Runtime起動 | Open |

## 10. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | 固定10項目へ全面再構成し、URL／Secret実値、Runtime設定、実行状態および廃止Master参照を削除。Lifecycle StatusをCanonical値へ統一。 |
| `2.0.0-draft.2` | 2026-07-29 | `ENV-PROD`を本番環境として確定し、Production-like環境区分、`PRODUCTION_LIKE` Enumおよび`productionLike`列を廃止。正式列を9項目へ更新し、本番実行は`enabled=false`と安全Gateで継続保護。 |
