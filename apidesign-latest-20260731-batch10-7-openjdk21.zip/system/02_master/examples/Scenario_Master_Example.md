---
title: Scenario Master記入例
document_id: EX-MST-E6-SC-001
version: 1.0.0-draft.4
status: DRAFT
document_type: Master Example
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Scenario Master記入例

## 1. 目的

本書は、`Scenario_Master.md`の正式10項目を記入する際のScenario粒度、実行資産参照、有効状態およびUseCaseとの関係を示す例である。

本書中の`SC-E6-901～903`、Class、Pathおよび業務内容は説明用の架空値であり、実システムのMasterへコピーしてはならない。`900`番台は本例内でのみ使用する。

## 2. 記入例

| scenarioId | useCaseId | scenarioName | scenarioType | executionClass | inputRef | expectedRef | scenarioDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|
| SC-E6-901 | UC-E6-901 | 注文状態変更正常経路 | NORMAL | com.example.e6.scenario.OrderStatusChangeScenario | system/04_usecase_design/examples/input/SC-E6-901-input_Example.json | system/04_usecase_design/examples/expected/SC-E6-901-expected_Example.json | system/04_usecase_design/examples/scenario/SC-E6-901設計書_Example.md | true | 注文情報を取得し、状態変更後に再照会して変更結果を確認する。 |
| SC-E6-902 | UC-E6-901 | 変更対象注文不存在経路 | ALTERNATIVE | com.example.e6.scenario.OrderNotFoundScenario | system/04_usecase_design/examples/input/SC-E6-902-input_Example.json | system/04_usecase_design/examples/expected/SC-E6-902-expected_Example.json | system/04_usecase_design/examples/scenario/SC-E6-902設計書_Example.md | false | 対象注文が存在しない場合に変更APIを呼び出さず、想定した業務結果で終了する。 |
| SC-E6-903 | UC-E6-901 | 注文状態変更Timeout経路 | TIMEOUT | com.example.e6.scenario.OrderStatusChangeTimeoutScenario | system/04_usecase_design/examples/input/SC-E6-903-input_Example.json | system/04_usecase_design/examples/expected/SC-E6-903-expected_Example.json | system/04_usecase_design/examples/scenario/SC-E6-903設計書_Example.md | false | 状態変更APIのTimeout時に後続呼出を停止し、未実行StepとScenario結果を記録する。 |

## 3. 項目別の読み方

| 項目 | SC-E6-901の例 | 説明 |
|---|---|---|
| `scenarioId` | `SC-E6-901` | 一つの確定した業務経路を識別する不変ID。 |
| `useCaseId` | `UC-E6-901` | Scenarioが所属する唯一のUseCase。 |
| `scenarioName` | 注文状態変更正常経路 | 入力条件、経路または期待終了状態を識別できる名称。 |
| `scenarioType` | `NORMAL` | 設計書で定義された標準Enum。 |
| `executionClass` | `com.example...OrderStatusChangeScenario` | Build Trace用のJava完全修飾名。`scenarioId`で解決したRegistry Descriptorの`implementationType`と一致させ、直接反射実行しない。 |
| `inputRef` | `.../SC-E6-901-input_Example.json` | Scenario開始時のInputを定義する参照。 |
| `expectedRef` | `.../SC-E6-901-expected_Example.json` | `resultKey`ごとの期待結果を定義する参照。 |
| `scenarioDesignRef` | `.../SC-E6-901設計書_Example.md` | API呼出、分岐、値引継ぎおよびCheckの正本。 |
| `enabled` | `true` | 実行候補として参照可能な状態。実行資産の存在確認は別途必要。 |
| `description` | 注文情報を取得し… | 開始条件、主要経路および期待終了状態を一文で要約する。 |

## 4. Scenarioの分け方

次の三つは同一UseCaseに所属するが、経路または期待終了状態が異なるため別Scenarioとする。

| scenarioId | 経路 | 分割理由 |
|---|---|---|
| SC-E6-901 | 取得、変更、再照会を正常完了する。 | 主正常経路。 |
| SC-E6-902 | 初回取得で対象不存在を確認し、変更Callを計画せず終了する。 | 分岐経路、正規Call集合および期待終了状態が異なる。 |
| SC-E6-903 | 変更APIがTimeoutとなり、後続を実行しない。 | 障害経路、停止条件および期待結果が異なる。 |

次の差異だけではScenarioを分けない。

- Responseの一項目にCheckを追加する。
- 同一経路でTest Dataの実値だけを変更する。
- 実行日、Run IDまたはEnvironmentだけを変更する。
- Reportの表示順または表示文言だけを変更する。

## 5. API呼出概要

次の表は説明用の要約であり、Scenario Masterの正式10項目には含めない。呼出定義の正本はScenario詳細設計書である。

| scenarioId | callSequence | apiCallCode | apiId | 呼出目的 | 実行条件 |
|---|---:|---|---|---|---|
| SC-E6-901 | 10 | CALL-001 | API-901 | 変更前注文情報取得 | ALWAYS |
| SC-E6-901 | 20 | CALL-002 | API-902 | 注文状態変更 | CALL-001が業務正常 |
| SC-E6-901 | 30 | CALL-003 | API-901 | 変更後注文情報再取得 | CALL-002が更新成功 |
| SC-E6-902 | 10 | CALL-001 | API-901 | 変更対象注文の不存在確認 | ALWAYS |
| SC-E6-903 | 10 | CALL-001 | API-901 | 更新前注文情報取得 | ALWAYS |
| SC-E6-903 | 20 | CALL-002 | API-902 | Timeout対象の注文状態変更 | CALL-001が業務正常かつTimeout Harness成立 |
| SC-E6-903 | 30 | CALL-003 | API-901 | 更新後注文情報再取得 | CALL-002が更新成功かつ結果既知 |

`API-901`を2回呼び出してもAPI Masterのレコードは1件とし、呼出実体は`CALL-001`と`CALL-003`で区別する。

SC-E6-902では`CALL-002／003`を宣言しない。未計画Callを`SKIPPED`として追加せず、正規Call集合を`CALL-001`だけとする。

SC-E6-903では`CALL-003`を宣言するが、期待経路ではCALL-002がTimeoutとなるため`SKIPPED`として記録する。宣言外の未計画Callと、停止条件により実行されない宣言済みCallを混同してはならない。

## 6. 有効・無効の使い分け

| 状況 | `enabled` | 取扱い |
|---|:---:|---|
| 詳細設計、Java Class、Input、Expectedおよび参照APIが利用可能 | `true` | Build Validation通過後に実行候補とする。 |
| 経路候補だけが決まり、実行資産が未完成 | `false` | 履歴・計画として保持し、実行対象から除外する。 |
| 参照APIが未確認または無効 | `false` | API仕様またはScenario経路の確定まで有効化しない。 |
| 廃止済みScenario | `false` | 原則として物理削除せず、過去Runの追跡性を保持する。 |

`enabled=true`だけで実行可能とは判定しない。Java Classおよび全参照資産の存在、参照先IDの有効性、Environment適用可否をBuild Validationで確認する。

## 7. 誤記例

| 誤記 | 問題 | 正しい対応 |
|---|---|---|
| `SC-E6-901-FIELD-CHECK` | 単一フィールドCheckをScenario化している。 | 同一Scenario内のJava Checkとして実装する。 |
| `executionClass=OrderScenario` | Classを一意に解決できない可能性がある。 | 完全修飾Class名を設定する。 |
| `inputRef`へRequest値を直接記載する | Masterと実行データの責務が混在する。 | Repository Root基準のInput参照だけを設定する。 |
| `description`へ全API順序を記載する | 概要と実行仕様が重複する。 | 呼出順序はScenario詳細設計書で管理する。 |
| `apiCallCode`列を追加する | Scenario概要と呼出実体の責務が混在する。 | Scenario詳細設計書で管理する。 |
| `IGNORE_FIELD`を記載する | Diff実装規則がMasterへ混入する。 | APIまたはScenario専用Java比較定義で管理する。 |

## 8. 記入時Validation

| Rule | 確認内容 |
|---|---|
| SC-EX-V001 | 全10項目が設定されている。 |
| SC-EX-V002 | `scenarioId`が`^SC-E6-[0-9]{3}$`に一致し、Master内で一意である。 |
| SC-EX-V003 | `useCaseId`がUseCase Masterで解決でき、`scenarioIds`の逆参照と一致する。 |
| SC-EX-V004 | `scenarioType`が標準Enumに含まれる。 |
| SC-EX-V005 | `executionClass`が完全修飾名であり、Build時に解決できる。 |
| SC-EX-V006 | Input、ExpectedおよびScenario設計書参照が存在する。 |
| SC-EX-V007 | Scenario詳細設計の全`apiId`がAPI Masterで解決できる。 |
| SC-EX-V008 | 有効Scenarioが無効APIを参照していない。 |
| SC-EX-V009 | API呼出、Context、Expected値、CheckおよびDiff規則が正式列へ混入していない。 |
| SC-EX-V010 | Scenario Registryが`scenarioId`で一件解決し、Descriptorの`implementationType`が`executionClass`と完全一致する。 |

## 9. 正式Master反映前Checklist

- [ ] 一つの開始条件、経路および期待終了状態として説明できる。
- [ ] 所属UseCaseが一つに決まっている。
- [ ] UseCase Masterの`scenarioIds`と双方向に一致する。
- [ ] Scenario種別が標準Enumに含まれている。
- [ ] Java Class、Scenario Registry Binding、Input、Expectedおよび詳細設計を解決できる。
- [ ] Scenario詳細設計のAPI呼出がAPI Masterで解決できる。
- [ ] 単一Checkまたは単なるデータ差異をScenario化していない。
- [ ] Runtime値、Expected値またはDiff規則をMasterへ記載していない。
- [ ] 未完成または廃止状態を`enabled=false`で表している。

## 10. 参照先

- 正式Master：`system/02_master/Scenario_Master.md`
- 設計規則：`system/02_master/design/Scenario_Master設計書.md`
- 対応表記入例：`system/02_master/examples/API_UseCase_Scenario対応表_Example.md`

## 11. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.3` | 2026-07-27 | 900番台ExampleのScenario粒度、固定10項目、Input／Expected／設計Referenceおよび有効化Gateを現行化 | DRAFT |
| `1.0.0-draft.4` | 2026-07-28 | 第9バッチとしてScenario Registry Binding、Class完全一致および反射実行禁止の記入例とValidationを追加 | DRAFT |
