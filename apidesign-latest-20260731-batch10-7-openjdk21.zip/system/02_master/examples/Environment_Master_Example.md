---
title: Environment Master記入例
document_id: EX-MST-E6-ENV-001
version: 2.0.0-draft.2
status: DRAFT
document_type: Master Example
system_name: E6 API Verification Platform
updated: 2026-07-29
---

# Environment Master記入例

## 1. 目的

本書は、`Environment_Master.md`の固定9項目を記入する際の論理Environment粒度、外部設定Reference、本番区分、Secret非保持およびValidationを示す。

本書中の`ENV-EXAMPLE-*`は架空値であり、正式Masterへコピーしてはならない。

## 2. 記入例

| environmentId | environmentName | environmentType | purpose | systemId | baseUrlRef | authProfileRef | environmentOwner | enabled |
|---|---|---|---|---|---|---|---|:---:|
| ENV-EXAMPLE-LOCAL | 注文API Local検証環境 | LOCAL | Mockを使用した開発者単体検証を行う。 | E6 | CONFIG:E6:EXAMPLE_LOCAL:BASE_URL | AUTH:E6:EXAMPLE_LOCAL | Example Platform Operations | true |
| ENV-EXAMPLE-STAGING | 注文API Staging検証環境 | STAGING | 結合および日次回帰検証を行う。 | E6 | CONFIG:E6:EXAMPLE_STAGING:BASE_URL | AUTH:E6:EXAMPLE_STAGING | Example Platform Operations | true |
| ENV-EXAMPLE-PROD | 注文API本番環境 | PRODUCTION | 本番APIへの接続候補。明示承認までは実行しない。 | E6 | CONFIG:E6:EXAMPLE_PROD:BASE_URL | AUTH:E6:EXAMPLE_PROD | Example Operations Owner | false |

Reference Keyは架空値である。URL、CredentialまたはSecret実値ではない。

## 3. 項目別の読み方

| 項目 | 記入例 | 説明 |
|---|---|---|
| `environmentId` | `ENV-EXAMPLE-STAGING` | 一つの論理Environmentを識別する不変ID。 |
| `environmentName` | 注文API Staging検証環境 | 組織内で識別できる論理名称。 |
| `environmentType` | `STAGING` | 許可Enumによる環境分類。 |
| `purpose` | 結合および日次回帰検証… | 主用途。Schedule時刻は含めない。 |
| `systemId` | `E6` | 接続対象Systemの固定ID。 |
| `baseUrlRef` | `CONFIG:E6:...:BASE_URL` | URL実値を解決する外部Configuration Key。 |
| `authProfileRef` | `AUTH:E6:...` | Authentication Profileを解決するKey。 |
| `environmentOwner` | Example Platform Operations | 接続・運用責任を持つRole。 |
| `enabled` | `true` | 新しいUseCaseおよび実行計画から参照可能。 |

## 4. 論理Environment粒度

次の変更では同じEnvironment IDを維持する。

| 変更 | IDの扱い | 正式な変更先 |
|---|---|---|
| Host交換 | 維持 | External Configuration |
| Base URL変更 | 維持 | External Configuration |
| Credential Rotation | 維持 | Secret Provider |
| Timeout変更 | 維持 | Runtime設定 |
| Retry回数変更 | 維持 | Runtime設定 |
| Container再配置 | 維持 | Infrastructure／Deployment |

次の場合は新Environment IDを検討する。

- 用途が別物になる。
- 本番と非本番の安全境界が分離される。
- 運用Ownerが異なる独立実行先となる。
- データまたは外部影響の境界が独立する。

## 5. External Configuration Reference

正しい例：

```text
CONFIG:E6:EXAMPLE_STAGING:BASE_URL
AUTH:E6:EXAMPLE_STAGING
```

誤った例：

```text
https://staging.example.invalid
10.0.0.15
user:password
Bearer actual-token
```

MasterはReference Keyだけを保持する。Runtimeが外部設定とSecret Providerから実値を解決する。

## 6. 本番区分

本番Environmentは`environmentType=PRODUCTION`で明示する。Production-likeを独立TypeまたはBoolean属性として登録しない。

| environmentType | 判定 |
|---|---|
| `LOCAL` | Local検証環境 |
| `STAGING` | Release前の検証環境 |
| `PRODUCTION` | 本番環境。追加の安全Gateと承認が必要 |
| `PRODUCTION_LIKE` | NG。廃止済みEnum |

## 7. UseCase Reference例

UseCaseはEnvironment IDだけを参照し、URLまたはCredentialを保持しない。

| useCaseId | applicableEnvironmentIds | 説明 |
|---|---|---|
| UC-E6-901 | ENV-EXAMPLE-LOCAL<br>ENV-EXAMPLE-STAGING | LocalとStagingで実行可能な架空UseCase。 |

`ENV-EXAMPLE-PROD(enabled=false)`を有効UseCaseから参照するとCross-Master `ERROR`になる。

## 8. 正しい記入と誤記

| 記入内容 | 判定 | 理由 |
|---|:---:|---|
| `baseUrlRef=CONFIG:E6:EXAMPLE_STAGING:BASE_URL` | OK | 外部設定Keyである。 |
| `authProfileRef=AUTH:E6:EXAMPLE_STAGING` | OK | 認証ProfileのReferenceである。 |
| `environmentType=PRODUCTION` | OK | 本番区分を明示している。 |
| `environmentType=PRODUCTION_LIKE` | NG | 廃止済みの環境区分である。 |
| `baseUrlRef=https://...` | NG | URL実値をMasterへ保存している。 |
| `authProfileRef=actual-token` | NG | Secret実値を保存している。 |
| `purpose=毎日03:00実行` | NG | Scheduleは運用設計の責務である。 |
| `description=previousRunId=...` | NG | Run状態はExecution Stateの責務である。 |

## 9. Masterへ含めない情報

- URL、Host、IP Address、Portの実値
- Username、Password、Token、API Key
- 秘密鍵、証明書秘密情報
- Proxy、TLS、Trust Store実値
- Timeout、Retry、Backoff、並列数
- Schedule、Maintenance Window
- Run ID、前回Run、Baseline
- Request、Response、Context、Expected
- Snapshot、Diff、Report実体
- Business／Scenarioごとの巨大なAllow／Deny一覧

## 10. 無効化例

外部設定、安全Gateまたは運用承認が未確定の場合は、有効化しない。

| environmentId | environmentName | environmentType | purpose | systemId | baseUrlRef | authProfileRef | environmentOwner | enabled |
|---|---|---|---|---|---|---|---|:---:|
| ENV-EXAMPLE-PROD | 注文API本番環境 | PRODUCTION | 本番接続の安全性と利用可否を確認する。 | E6 | CONFIG:E6:EXAMPLE_PROD:BASE_URL | AUTH:E6:EXAMPLE_PROD | Example Operations Owner | false |

`enabled=false`はSecretをMasterに記載してよいという意味ではない。無効レコードでもSecret非保持規則を適用する。

## 11. 記入時Validation

| Rule ID | 確認内容 |
|---|---|
| `ENV-EX-V001` | 固定9項目が設定され、列順が設計書と一致する。 |
| `ENV-EX-V002` | `environmentId`がPatternに一致し一意である。 |
| `ENV-EX-V003` | Environment Typeが許可Enumである。 |
| `ENV-EX-V004` | 本番は`PRODUCTION`であり、廃止値`PRODUCTION_LIKE`を使用していない。 |
| `ENV-EX-V005` | Base URLとAuthenticationがReference Keyである。 |
| `ENV-EX-V006` | URL、IP、Credential、Secretまたは個人情報がない。 |
| `ENV-EX-V007` | UseCaseのEnvironment IDが解決可能か確認できる。 |
| `ENV-EX-V008` | Runtime設定、Run状態または廃止Master参照が混入していない。 |

## 12. 正式Master反映前Checklist

- [ ] 一つの論理Environmentとして説明できる。
- [ ] Host変更だけで別Environmentを登録していない。
- [ ] Environment名称、TypeおよびPurposeが一致し、本番は`PRODUCTION`である。
- [ ] System IDを確認した。
- [ ] Base URLとAuthenticationの外部設定Keyを確認した。
- [ ] URL、Credential、Secretまたは個人情報を記載していない。
- [ ] Environment Ownerを確認した。
- [ ] UseCaseの適用Environmentとの整合性を確認した。
- [ ] Runtime設定またはRun状態を記載していない。
- [ ] Example値を正式値としてコピーしていない。

## 13. 参照先

- 正式Master：`system/02_master/Environment_Master.md`
- 設計規則：`system/02_master/design/Environment_Master設計書.md`
- 共通規則：`system/02_master/design/Master共通設計書.md`
- ID規則：`system/02_master/guide/Master_ID・Reference記述ガイド.md`

## 14. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `2.0.0-draft.1` | 2026-07-27 | Environment Master固定10項目、Production-like属性、ReferenceおよびValidationの記入例を作成。 |
| `2.0.0-draft.2` | 2026-07-29 | `ENV-PROD`を本番として明示し、Production-like Example、Enumおよび`productionLike`列を廃止。固定9項目と本番安全Gateの例へ更新。 |
