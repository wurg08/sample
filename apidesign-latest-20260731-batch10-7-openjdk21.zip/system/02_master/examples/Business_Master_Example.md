---
title: Business Master記入例
document_id: EX-MST-E6-BUS-001
version: 2.0.0-draft.1
status: DRAFT
document_type: Master Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# Business Master記入例

## 1. 目的

本書は、`Business_Master.md`の固定10項目を記入する際のBusiness粒度、業務分析Reference、Owner、禁止事項およびValidationを示す。

本書中の`BUS-E6-901`は架空値であり、正式Masterへコピーしてはならない。900番台はExample専用である。

## 2. 記入例

| businessId | businessName | systemId | businessCategory | businessPurpose | businessScope | businessAnalysisRef | businessOwner | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|
| BUS-E6-901 | 注文状態管理業務 | E6 | UPDATE | 注文状態を業務上許可された状態へ変更し、変更結果を確認可能にする。 | 注文情報の確認開始から状態変更結果の業務確認完了まで。 | business/examples/注文状態管理_現行業務分析書_Example.md | Order Business Owner | true | 注文取消や返金を含まない注文状態変更の業務境界。 |

`businessAnalysisRef`は記入形式を示す架空Pathであり、正式Masterへ反映する際は実在する正式業務分析書を参照する。

## 3. 項目別の読み方

| 項目 | 記入例 | 説明 |
|---|---|---|
| `businessId` | `BUS-E6-901` | 一つの安定した業務分類・境界を識別する不変ID。 |
| `businessName` | 注文状態管理業務 | ScenarioやAPIではなく業務を表す正式名称。 |
| `systemId` | `E6` | 主対象Systemの固定ID。 |
| `businessCategory` | `UPDATE` | 業務の主分類。 |
| `businessPurpose` | 注文状態を… | 技術手段ではなく業務目的を一文で示す。 |
| `businessScope` | 注文情報の確認開始から… | 開始点と終了境界を要約し、API Stepは記載しない。 |
| `businessAnalysisRef` | `business/examples/...` | 業務目的・Scopeの根拠となるRepository相対Path。 |
| `businessOwner` | Order Business Owner | 業務境界の判断責任を持つRole。 |
| `enabled` | `true` | 新しいUseCaseから参照可能。 |
| `description` | 注文取消や返金を含まない… | 他Businessとの境界を補足する。 |

## 4. Business粒度

次は同じBusiness配下のUseCaseまたはScenarioとして扱う。

| 差異 | 正しい取扱い | 理由 |
|---|---|---|
| 注文状態を正常に変更する。 | Scenario | 主正常経路。 |
| 対象注文が存在しない。 | Scenario | 開始条件と終了状態の差。 |
| 更新APIがTimeoutとなる。 | Scenario | 技術経路の差。 |
| 注文状態変更結果を確認する。 | 同一UseCase内のCheck | 同じ業務目的の検証。 |

次はBusiness境界が異なる可能性があるため、独立Businessを検討する。

| 候補 | 判断観点 |
|---|---|
| 注文返金業務 | 金額、会計、承認および完了条件が状態変更と異なる。 |
| 注文請求業務 | 責任Ownerと業務目的が異なる。 |
| 注文配送業務 | 業務開始点、Actorおよび外部影響が異なる。 |

## 5. Reverse Reference

Business Masterへ`useCaseIds`列を追加せず、UseCase Masterを逆引きする。

```text
UseCase_Master.businessIds contains BUS-E6-901
```

説明用の関係：

| useCaseId | businessIds | 説明 |
|---|---|---|
| UC-E6-901 | BUS-E6-901 | 注文状態変更を検証する架空UseCase。 |

## 6. 正しい記入と誤記

| 記入内容 | 判定 | 理由 |
|---|:---:|---|
| `businessPurpose=注文状態を許可状態へ変更する。` | OK | 業務目的を表す。 |
| `businessScope=注文確認開始から変更結果確認まで。` | OK | 業務境界を要約する。 |
| `businessPurpose=API-902を呼び出す。` | NG | 技術手段であり業務目的ではない。 |
| `businessScope=CALL-001→CALL-002` | NG | Scenario実行順序である。 |
| `businessAnalysisRef=https://...` | NG | Repository相対Pathではない。 |
| `businessOwner=user@example.com` | NG | 個人連絡先をMasterへ記載している。 |

## 7. Masterへ含めない情報

- API ID一覧
- UseCase ID一覧
- Scenario ID一覧
- API呼出順序
- `apiCallCode`
- Request／Response実値
- Input、Expected、`resultKey`
- Context、ApiExchange
- Ignore Field、Diff
- Baseline、Run ID、実行結果
- Credential、Secret

## 8. 無効化例

Businessが新規利用停止となった場合、IDを削除または再利用しない。

| businessId | businessName | systemId | businessCategory | businessPurpose | businessScope | businessAnalysisRef | businessOwner | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|
| BUS-E6-902 | 旧注文状態管理業務 | E6 | UPDATE | 旧方式で注文状態を変更する。 | 旧方式の注文確認から変更完了まで。 | business/examples/旧注文状態管理_現行業務分析書_Example.md | Order Business Owner | false | 後継Businessへ移行済み。新規参照禁止。 |

## 9. 記入時Validation

| Rule ID | 確認内容 |
|---|---|
| `BUS-EX-V001` | 固定10項目が設定され、列順が設計書と一致する。 |
| `BUS-EX-V002` | `businessId`がPatternに一致し一意である。 |
| `BUS-EX-V003` | Categoryが許可Enumである。 |
| `BUS-EX-V004` | Business目的とScopeが業務用語で記述されている。 |
| `BUS-EX-V005` | 業務分析ReferenceがRepository相対Pathである。 |
| `BUS-EX-V006` | Ownerが明確である。 |
| `BUS-EX-V007` | API、Scenario、Expected、DiffまたはRuntime情報が混入していない。 |
| `BUS-EX-V008` | Exampleの900番台IDが正式Masterへ混入していない。 |

## 10. 正式Master反映前Checklist

- [ ] 一つの安定した業務分類・境界として説明できる。
- [ ] 他Businessと目的またはScopeが重複していない。
- [ ] 正式な現行業務分析成果物を確認した。
- [ ] Business OwnerまたはBA Leadが境界を確認した。
- [ ] IDを既存Businessまたは廃止Businessと重複させていない。
- [ ] Category、PurposeおよびScopeが一致している。
- [ ] UseCaseから参照可能なBusiness IDである。
- [ ] API一覧、Scenario経路またはJava Checkを記載していない。
- [ ] Example値を正式値としてコピーしていない。

## 11. 参照先

- 正式Master：`system/02_master/Business_Master.md`
- 設計規則：`system/02_master/design/Business_Master設計書.md`
- 共通規則：`system/02_master/design/Master共通設計書.md`
- ID規則：`system/02_master/guide/Master_ID・Reference記述ガイド.md`
