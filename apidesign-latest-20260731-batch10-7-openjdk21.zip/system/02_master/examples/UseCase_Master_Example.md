---
title: UseCase Master記入例
document_id: EX-MST-E6-UC-001
version: 1.0.0-draft.2
status: DRAFT
document_type: Master Example
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# UseCase Master記入例

## 1. 目的

本書は、`UseCase_Master.md`の正式10項目を記入する際のUseCase粒度、参照関係および禁止事項を示す例である。

本書中の`UC-E6-901`、Business、EnvironmentおよびScenarioは説明用の架空値であり、実システムのMasterへコピーしてはならない。`900`番台は本例内でのみ使用する。

## 2. 記入例

| useCaseId | useCaseName | businessIds | businessPurpose | businessScope | preconditionSummary | applicableEnvironmentIds | scenarioIds | useCaseDesignRef | enabled |
|---|---|---|---|---|---|---|---|---|:---:|
| UC-E6-901 | 注文状態変更検証 | BUS-E6-901 | 注文状態の変更前後を確認し、注文業務で許可された状態遷移が成立することを検証する。 | 注文情報の確認開始から状態変更、再照会および業務結果確認完了まで。 | 検証対象となる注文および利用者権限が準備済みであること。 | ENV-EXAMPLE-LOCAL<br>ENV-EXAMPLE-STAGING | SC-E6-901<br>SC-E6-902<br>SC-E6-903 | system/04_usecase_design/examples/UC-E6-901設計書_Example.md | true |

## 3. 項目別の読み方

| 項目 | 記入例 | 説明 |
|---|---|---|
| `useCaseId` | `UC-E6-901` | 一つの業務検証目的を識別する不変ID。 |
| `useCaseName` | 注文状態変更検証 | 業務対象と検証目的が分かる名称。正常／異常等の経路差異を含めない。 |
| `businessIds` | `BUS-E6-901` | Business Masterで解決可能なID。 |
| `businessPurpose` | 注文状態の変更前後を確認し… | 「何を確認するか」を業務の言葉で一文にする。 |
| `businessScope` | 注文情報の確認開始から… | 業務上の開始点と完了範囲を示す。API Step一覧は記載しない。 |
| `preconditionSummary` | 検証対象となる注文および… | 全Scenarioに共通する前提だけを要約する。 |
| `applicableEnvironmentIds` | `ENV-EXAMPLE-LOCAL`、`ENV-EXAMPLE-STAGING` | Environment Master Exampleで解決可能な適用対象ID。HostやCredentialは記載しない。 |
| `scenarioIds` | `SC-E6-901～903` | 所属Scenarioの完全性確認用一覧。実行順序は表さない。 |
| `useCaseDesignRef` | `system/04_usecase_design/examples/UC-E6-901設計書_Example.md` | Repository Root基準の詳細設計参照。 |
| `enabled` | `true` | 新規Scenarioおよび実行計画から参照可能。 |

## 4. UseCaseとScenarioの分け方

次の経路は業務目的が同じため、一つのUseCase配下の別Scenarioとして管理する。

| scenarioId | 経路差異 | Scenarioとする理由 |
|---|---|---|
| SC-E6-901 | 注文状態を正常に変更する。 | 主正常経路。 |
| SC-E6-902 | 対象注文が存在せず変更を実行しない。 | 開始条件および期待終了状態が異なる。 |
| SC-E6-903 | 状態変更APIがTimeoutとなる。 | 実行経路、停止条件および期待終了状態が異なる。 |

次の差異だけでは新しいUseCaseを作成しない。

- 正常／異常／Timeout／Skipの違い
- 入力データの違い
- API呼出順序または分岐の違い
- 必須、型、桁数、固定値等のCheck項目の違い
- 実行Environmentの違い

業務目的そのものが「注文取消」から「注文返金」へ変わる場合は、独立UseCaseとするかをBusiness境界とともに再検討する。

## 5. `scenarioIds`の整合性

UseCase Master側:

```text
UC-E6-901.scenarioIds
    = SC-E6-901
    + SC-E6-902
    + SC-E6-903
```

Scenario Master側:

| scenarioId | useCaseId | 一致 |
|---|---|:---:|
| SC-E6-901 | UC-E6-901 | Yes |
| SC-E6-902 | UC-E6-901 | Yes |
| SC-E6-903 | UC-E6-901 | Yes |

両方向の関係が一致しない場合は自動補正せず、Master整合性Errorとする。

## 6. 前提条件の記入例

| 記入内容 | 判定 | 理由 |
|---|:---:|---|
| 検証対象注文と利用者権限が準備済みであること。 | OK | 全Scenarioに共通する業務前提。 |
| `orderId=O0001`であること。 | NG | Scenario Inputに属する具体値。 |
| `https://stg.example.com`へ接続すること。 | NG | Environment設定に属するHost。 |
| CALL-001成功時にCALL-002を実行すること。 | NG | Scenario詳細設計に属する実行条件。 |
| Expectedの`status=DONE`であること。 | NG | Expectedに属する具体的な判定値。 |

共通前提が存在しない場合は空欄にせず`NONE`とする。

## 7. 誤記例

| 誤記 | 問題 | 正しい対応 |
|---|---|---|
| `UC-E6-901-NORMAL`、`UC-E6-902-TIMEOUT` | 経路差異ごとにUseCaseを分割している。 | 同じ業務目的の配下Scenarioとして管理する。 |
| `businessPurpose=API-902を呼び出す` | API実行自体を業務目的としている。 | 業務上確認したい状態・成立条件を記述する。 |
| `scenarioIds=SC-E6-901→SC-E6-902` | Scenario一覧を実行順序として使用している。 | ID一覧だけを記載し、順序はScenario／実行計画で管理する。 |
| `applicableEnvironmentIds=https://...` | Environment IDではなく接続値を記載している。 | Environment MasterのIDだけを参照する。 |
| `apiCallCode`列を追加する | UseCaseとScenario実行仕様の責務が混在する。 | Scenario詳細設計書で管理する。 |
| ExpectedやDiff規則を記載する | UseCaseの業務目的と検証実装が混在する。 | Expected、Java CheckまたはComparatorで管理する。 |

## 8. 記入時Validation

| Rule | 確認内容 |
|---|---|
| UC-EX-V001 | 全10項目が設定されている。 |
| UC-EX-V002 | `useCaseId`がプロジェクトのID規則に一致し、Master内で一意である。 |
| UC-EX-V003 | `businessIds`がBusiness Masterで解決できる。 |
| UC-EX-V004 | `applicableEnvironmentIds`がEnvironment Masterで解決できる。 |
| UC-EX-V005 | `scenarioIds`がScenario Masterで解決でき、逆参照が一致する。 |
| UC-EX-V006 | 有効UseCaseに1件以上の有効Scenarioが存在する。 |
| UC-EX-V007 | `useCaseDesignRef`の参照先とUseCase IDが一致する。 |
| UC-EX-V008 | API呼出、Input、Expected、Context、VerificationおよびDiff規則が混入していない。 |

## 9. 正式Master反映前Checklist

- [ ] 一つの独立した業務検証目的として説明できる。
- [ ] Business MasterのIDと業務境界を確認した。
- [ ] 開始点、対象処理および完了範囲を業務の言葉で記載した。
- [ ] 前提条件を全Scenario共通の内容だけに限定した。
- [ ] Environment Masterの有効IDだけを設定した。
- [ ] Scenario Masterとの双方向関係を確認した。
- [ ] UseCase詳細設計書の参照先を確認した。
- [ ] 経路差異を別UseCaseとして重複登録していない。
- [ ] API呼出、Expected、Business CheckまたはDiff規則を追加していない。

## 10. 参照先

- 正式Master：`system/02_master/UseCase_Master.md`
- 設計規則：`system/02_master/design/UseCase_Master設計書.md`
