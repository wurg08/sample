---
title: Report設計書
document_id: E6-API-VAL-REPORT-DESIGN
version: 1.0.0-draft.8
status: DRAFT
document_type: Verification Report Design
system_name: E6 API Verification Platform
updated: 2026-07-28
---

# Report設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Report設計書 |
| 文書ID | `E6-API-VAL-REPORT-DESIGN` |
| 対象 | Scenario／Batch Summary、Diff Report、Evidence Index |
| 配置 | `system/07_report/` |
| 文書種別 | Report共通設計書 |
| 版数 | `1.0.0-draft.8` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-28 |
| 作成責任 | Report / Operation Team |
| レビュー責任 | System Architect / Test Lead / Operation Lead / Approver |

## 2. 目的

本書は、E6 API Verification PlatformのScenarioおよびBatch実行結果を、承認者、Leader、開発者および運用担当が同じ事実に基づいて確認できるReportへ変換する方式を定義する。

Reportは判定ロジックの正本ではない。`verification-result.json`、`response-field-diff.json`およびEvidenceを表示・集約し、元成果物へ追跡可能にする。

## 3. Report利用者

| 利用者 | 主な確認内容 | 主Report |
|---|---|---|
| 承認者 | 四結果軸、主要変化、Recovery要否、前回からの状況 | Daily Summary |
| Project Leader | Scenario別失敗、Effective Diff、影響範囲 | Scenario Summary／Diff Report |
| API／Java開発者 | Check明細、Field Diff、Request／Response | Diff Report／Evidence Index |
| 運用担当 | Execution Error、未実行、成果物欠落、再実行対象 | Daily Summary／Evidence Index |
| 監査・レビュー担当 | Input、Expected、Build、Baseline、結果の追跡 | Evidence Index |

## 4. 適用範囲

### 4.1 対象

- Scenario単位Summary
- Batch／日次Summary
- API Response Diff Report
- Ignored Diff表示
- Evidence Index
- Execution、Verification、Change、Recoveryの四結果軸表示・集約
- 初回、未比較、Effective Changeの表示
- MarkdownおよびJSON Report

### 4.2 対象外

| 対象外 | 正式な管理先 |
|---|---|
| CheckロジックおよびExpected | `検証結果・Expected設計書.md`、Java Check |
| Field DiffロジックおよびIgnore | `APIレスポンスDiff設計書.md`、Java比較定義 |
| Baseline更新可否 | `ExecutionState・Baseline管理設計書.md` |
| Request／Response生成 | Scenario詳細設計、API詳細設計、Java |
| Run中Context | `ScenarioContext設計書.md` |
| Master属性 | `system/02_master/` |

Report Generatorが入力結果を再判定、修正または補完してはならない。

## 5. 基本原則

| 原則ID | 原則 | 内容 |
|---|---|---|
| `RPT-P001` | Single Source | 判定はVerification Result、変化はDiff、証跡はEvidenceを正本とする。 |
| `RPT-P002` | 四軸分離 | Execution、Verification、Change、Recoveryを別列で表示する。 |
| `RPT-P003` | Problem First表示 | `UNKNOWN_OUTCOME`、`INCOMPLETE`、`REJECTED`、Recovery `REQUIRED`およびVerification `FAIL`をSummary上部へ明示する。 |
| `RPT-P004` | Ignore可視化 | Ignored Diffを隠さず件数と明細参照を表示する。 |
| `RPT-P005` | 推測禁止 | 欠落結果をPASS、変化なしまたは前日同一と推測しない。 |
| `RPT-P006` | 追跡可能性 | Reportの全行からRun、Scenario、Check、DiffおよびEvidenceへ到達できるようにする。 |
| `RPT-P007` | Secret保護 | ReportへSecret、Token、Credentialまたは未Mask個人情報を表示しない。 |
| `RPT-P008` | 決定性 | 同じ入力成果物から同じ内容・順序のReportを生成する。 |
| `RPT-P009` | 原子的公開 | Report一式を一時領域で完成させ、整合性確認後に公開する。 |
| `RPT-P010` | Baseline非変更 | Report生成はExecution StateまたはBaselineを変更しない。 |

## 6. 入力成果物

### 6.1 必須入力

| 入力 | Path | 用途 |
|---|---|---|
| Run Meta | `runs/{runId}/run-meta.json` | Identity、時刻、Build、参照版 |
| Verification Result | `runs/{runId}/verification-result.json` | Scenario判定、Check Summary |
| Field Diff | `runs/{runId}/api-calls/{apiCallCode}/response-field-diff.json` | 変化明細 |
| API Call Meta | `runs/{runId}/api-calls/{apiCallCode}/api-meta.json` | API呼出状態、時間、HTTP Status |
| Artifact Manifest | `runs/{runId}/artifact-manifest.json` | 成果物完全性、Hash、Path |

### 6.2 条件付き入力

| 入力 | 条件 |
|---|---|
| Request／Response JSON | Evidence Link生成時 |
| API Call Meta／安全なLog | Execution FailureまたはRecovery `REQUIRED`時 |
| Definition Snapshot Reference | Input／Expectedを含むDefinition Bundleの版、HashおよびSource Revision表示時 |
| Batch Verification Result | Batch／Daily Summary生成時 |

### 6.3 入力欠落

必須入力欠落時、Report Generatorは次を行う。

1. 欠落を`REPORT_INPUT_MISSING`として記録する。
2. Report Statusを`INCOMPLETE`とし、Source Runの四結果軸とは別に表示する。
3. 既存Verification Resultを上書きしない。
4. 不完全ReportであることをHeaderへ明示する。

## 7. 判定表示

### 7.1 Execution Status

| 表示 | 意味 |
|---|---|
| `NOT_STARTED` | 実体作成済み、未開始 |
| `RUNNING` | 処理中 |
| `COMPLETED` | 実行および成果物生成完了 |
| `INCOMPLETE` | 必須処理または成果物が成立しない |
| `REJECTED` | Preflight不成立でAPI呼出前に拒否 |
| `UNKNOWN_OUTCOME` | 更新API等の外部結果を断定不能 |

### 7.2 Verification Result

| 表示 | 意味 | 表示優先度 |
|---|---|---:|
| `FAIL` | 評価可能だが期待不成立 | 1 |
| `NOT_EVALUATED` | 前提不成立、対象外またはExecution Errorで未評価 | 2 |
| `PASS` | 期待成立 | 3 |

### 7.3 Change Status

| 表示 | 意味 |
|---|---|
| `CHANGED` | 有効差異あり |
| `UNCHANGED` | 有効差異なし。Ignored Diffの有無は別表示 |
| `NOT_COMPARED` | 初回または比較不能 |

### 7.4 Recovery Status

| 表示 | 意味 |
|---|---|
| `NOT_REQUIRED` | 運用介入不要 |
| `REQUIRED` | 状態確認、補償または手動判断が必要 |
| `IN_PROGRESS` | Recovery作業中 |
| `RESOLVED` | Recovery記録確定。元Runの他軸は不変 |

### 7.5 表示禁止例

| 実際 | 禁止表示 | 正しい表示 |
|---|---|---|
| 初回でBaselineなし | 変化なし | `NOT_COMPARED (INITIAL_EXECUTION)` |
| Ignored Diff 2件 | 完全一致 | `UNCHANGED (IGNORED_ONLY=2)` |
| Responseなし | 全項目削除 | `NOT_COMPARED (CURRENT_RESPONSE_UNAVAILABLE)` |
| Report Input欠落 | Source Runの四結果軸を書換え | `Report Status=INCOMPLETE (REPORT_INPUT_MISSING)` |

## 8. Report体系

```text
Batch／Daily Summary
├── Scenario Summary
├── Diff Report
└── Evidence Index
```

| Report | 粒度 | 主目的 |
|---|---|---|
| Daily Summary | Batch | 承認者向け全体判断 |
| Scenario Summary | Run／Scenario | CheckとAPI呼出の概要 |
| Diff Report | Run／API Call | Effective／Ignored Diffの確認 |
| Evidence Index | Run／Artifact | 調査・再現・監査 |

## 9. 物理配置

### 9.1 Scenario Report

```text
runs/{runId}/
└── reports/
    ├── scenario-summary.json
    ├── ScenarioSummary.md
    ├── diff-report.json
    ├── DiffReport.md
    ├── evidence-index.json
    └── EvidenceIndex.md
```

### 9.2 Batch／Daily Report

```text
batches/{batchId}/
└── reports/
    ├── daily-summary.json
    └── DailySummary.md
```

Report内LinkはReport RootまたはRun Rootからの相対Pathとする。OS依存絶対Pathを記載しない。

## 10. Daily Summary設計

### 10.1 Header

| 項目 | 内容 |
|---|---|
| `batchId` | Batch Identity |
| `environmentId` | 実行Environment |
| `startedAt`／`finishedAt` | Batch期間 |
| 四結果軸 | BatchのExecution、Verification、Change、Recovery集約結果 |
| `reportStatus` | `COMPLETE`／`INCOMPLETE` |
| `generatedAt` | Report生成時刻 |
| `generatorVersion` | Report Generator版 |

### 10.2 KPI

| KPI | 定義 |
|---|---|
| Scenario総数 | Batch対象Scenario数 |
| PASS／FAIL／NOT_EVALUATED | Scenario Verification Status別件数 |
| Completed／Incomplete／Rejected／Unknown Outcome | Execution Status別件数 |
| Effective Change Scenario数 | 有効差異を含むScenario数 |
| Ignored Only Scenario数 | Ignored Diffだけを含むScenario数 |
| Not Compared Scenario数 | 一つ以上の必須API比較が未実施 |
| Compare Error Scenario数 | 比較Errorを含むScenario数 |
| Recovery Required Scenario数 | 未解決Recoveryを含むScenario数 |

### 10.3 Scenario一覧

| 列 | 内容 |
|---|---|
| Business | `businessId`／名称 |
| UseCase | `useCaseId`／名称 |
| Scenario | `scenarioId`／名称 |
| Input Set | `inputSetId` |
| Run | `runId` |
| Execution | Execution Status |
| Verification | PASS／FAIL／NOT_EVALUATED |
| Change | Change Status |
| Recovery | Recovery Status |
| Effective | Effective Diff件数 |
| Ignored | Ignored Diff件数 |
| Detail | Scenario Summary Link |

### 10.4 Markdown例

```markdown
# Daily Summary

| 項目 | 内容 |
|---|---|
| Batch | BATCH-20260727-DAILY |
| Environment | ENV-STAGING |
| Execution | INCOMPLETE |
| Verification | FAIL |
| Change | CHANGED |
| Recovery | REQUIRED |
| Report Status | COMPLETE |

## Result Summary

| PASS | FAIL | NOT_EVALUATED | Effective Change | Ignored Only | Recovery Required |
|---:|---:|---:|---:|---:|---:|
| 5 | 1 | 1 | 2 | 1 | 1 |

## Scenario

| Scenario | Execution | Verification | Change | Recovery | Effective | Ignored | Detail |
|---|---|---|---|---|---:|---:|---|
| SC-E6-001 | COMPLETED | FAIL | CHANGED | NOT_REQUIRED | 1 | 2 | ScenarioSummary |
```

## 11. Scenario Summary設計

### 11.1 Header

- Run／Batch Identity
- Business／UseCase／Scenario／Input Set
- Environment
- Input、Expected、Java BuildおよびBaseline Version
- 開始・終了時刻
- Execution Status
- Verification Result
- Change Status
- Recovery Status

### 11.2 API呼出一覧

| 列 | 内容 |
|---|---|
| Sequence | Scenario詳細設計上の呼出順 |
| `apiCallCode` | 呼出実体ID |
| `apiId` | API定義ID |
| Call Status | SUCCEEDED、BUSINESS_ERROR_RESPONSE、TRANSPORT_ERROR等 |
| HTTP | HTTP Status |
| Duration | 所要時間 |
| Check Result | API所属Checkの集約 |
| Change | API Call単位Change Status |
| Diff | Field Diff Link |
| Evidence | Request／Response Link |

### 11.3 Check一覧

| 列 | 内容 |
|---|---|
| `resultKey` | Check Identity |
| Type | `resultType` |
| API Call | `apiCallCode`またはScenario |
| Expected | Mask済期待表示 |
| Actual | Mask済実績表示 |
| Result | PASS／FAIL／NOT_EVALUATED |
| Message | 人向け説明 |
| Evidence | Evidence Link |

PASS明細も保存するが、Markdownでは下位Sectionへ配置できる。FAILおよびNOT_EVALUATEDを先に表示し、後者はReason CodeとExecution／Recovery状態を併記する。

## 12. Diff Report設計

### 12.1 Summary

API呼出単位に次を表示する。

| 項目 | 内容 |
|---|---|
| `apiCallCode`／`apiId` | 呼出実体とAPI定義 |
| Baseline Run | 比較元Run |
| Comparison Status | COMPLETED／NOT_COMPARED／ERROR |
| Change Status | `CHANGED／UNCHANGED／NOT_COMPARED` |
| Display Category | Effective／Ignored Only／No Change／Compare Error |
| Checked | 比較Item数 |
| Effective | 有効差異数 |
| Ignored | Ignored Diff数 |
| Error | 比較Error数 |

### 12.2 明細

| 列 | 内容 |
|---|---|
| Path | Concrete JSON Path |
| Change | Change Type |
| Previous | Mask済前回値 |
| Current | Mask済今回値 |
| Handling | `COMPARED`／`IGNORED` |
| Ignore Mode | `IGNORE_FIELD`／`IGNORE_VALUE` |
| Effective | true／false |
| Reason | IgnoreまたはError理由 |

### 12.3 表示順

1. Compare Error
2. Effective Diff
3. Ignored Diff
4. Unchanged

同一区分内は`apiCallCode`、JSON Pathの昇順とする。出力順が実行環境により変わらないようにする。

### 12.4 Ignored Diff表示

Ignored Diffは主Failure表へ混入させないが、専用Sectionで必ず確認可能にする。

```markdown
## Ignored Diff

| API Call | Path | Change | Previous | Current | Mode | Reason |
|---|---|---|---|---|---|---|
| CALL-001 | $.updatedAt | VALUE_CHANGED | 2026-07-26... | 2026-07-27... | IGNORE_FIELD | 実行日時 |
```

## 13. Evidence Index設計

### 13.1 目的

Evidence Indexは、Reportから実行証跡へ安全に到達するための索引である。Evidence自体をReportへ複製しない。

### 13.2 索引対象

| Artifact | 例 |
|---|---|
| Run Meta | `run-meta.json` |
| Definition Snapshot | `run-meta.json`内のBundle／Input／Expected Version、Hash、Source Revision |
| Verification Result | `verification-result.json` |
| Request | `api-calls/CALL-001/request.json` |
| Response | `api-calls/CALL-001/response.json` |
| Field Diff | `api-calls/CALL-001/response-field-diff.json` |
| API Call Meta | `api-calls/CALL-001/api-meta.json`内の安全なFailure Metadata |
| Log | Log／Recovery設計で通常Evidence公開が許可された安全なLog Reference |
| Artifact Manifest | `artifact-manifest.json` |

### 13.3 Evidence項目

| 項目 | 内容 |
|---|---|
| `artifactType` | Artifact種別 |
| `relativePath` | Run Rootからの相対Path |
| `contentHash` | 完整性Hash |
| `sizeBytes` | File Size |
| `masked` | Mask済か |
| `available` | 存在するか |
| `unavailableReason` | 欠落理由 |

## 14. JSON Report契約

### 14.1 `scenario-summary.json`

```json
{
  "schemaVersion": "1.0",
  "generationId": "RPTGEN-RUN-20260727-150000-550e8400-001",
  "generatorVersion": "1.0.0",
  "reportStatus": "COMPLETE",
  "generatedAt": "2026-07-27T15:05:00+09:00",
  "runId": "RUN-20260727-150000-550e8400",
  "resultId": "RESULT-RUN-20260727-150000-550e8400",
  "batchId": "BATCH-20260727-DAILY",
  "environmentId": "ENV-STAGING",
  "businessId": "BUS-E6-001",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "inputSetId": "INPUT-DEFAULT",
  "executionStatus": "COMPLETED",
  "verificationStatus": "FAIL",
  "changeStatus": "CHANGED",
  "recoveryStatus": "NOT_REQUIRED",
  "summary": {
    "checkCount": 6,
    "passCount": 5,
    "failCount": 1,
    "notEvaluatedCount": 0,
    "effectiveChangedCount": 1,
    "ignoredDiffCount": 2
  },
  "checks": [
    {
      "resultKey": "HTTP_STATUS",
      "resultType": "STATUS_CODE",
      "apiCallCode": "CALL-001",
      "verificationStatus": "PASS",
      "severity": "ERROR",
      "sourceLocator": {
        "sourceType": "VERIFICATION_RESULT",
        "sourceId": "RESULT-RUN-20260727-150000-550e8400:HTTP_STATUS",
        "sourceRef": "../verification-result.json"
      }
    }
  ],
  "apiCalls": [
    {
      "callSequence": 10,
      "apiCallCode": "CALL-001",
      "apiId": "API-001",
      "callStatus": "SUCCEEDED",
      "httpStatus": 200,
      "durationMillis": 320,
      "verificationStatus": "PASS",
      "changeStatus": "UNCHANGED",
      "diffDisplayCategory": "IGNORED_ONLY",
      "fieldDiffRef": "../api-calls/CALL-001/response-field-diff.json",
      "sourceLocators": [
        {
          "sourceType": "API_CALL_META",
          "sourceId": "RUN-20260727-150000-550e8400:CALL-001",
          "sourceRef": "../api-calls/CALL-001/api-meta.json"
        },
        {
          "sourceType": "RESPONSE_FIELD_DIFF",
          "sourceId": "RUN-20260727-150000-550e8400:CALL-001",
          "sourceRef": "../api-calls/CALL-001/response-field-diff.json"
        }
      ]
    }
  ],
  "verificationResultRef": "../verification-result.json",
  "diffReportRef": "diff-report.json",
  "evidenceIndexRef": "evidence-index.json",
  "sourceLocator": {
    "sourceType": "VERIFICATION_RESULT",
    "sourceId": "RESULT-RUN-20260727-150000-550e8400",
    "sourceRef": "../verification-result.json"
  },
  "manifestLocator": {
    "sourceType": "ARTIFACT_MANIFEST",
    "sourceId": "MANIFEST-RUN-20260727-150000-550e8400",
    "sourceRef": "../artifact-manifest.json"
  }
}
```

### 14.2 `daily-summary.json`

```json
{
  "schemaVersion": "1.0",
  "generationId": "RPTGEN-BATCH-20260727-DAILY-001",
  "generatorVersion": "1.0.0",
  "batchResultId": "BRESULT-BATCH-20260727-DAILY",
  "batchId": "BATCH-20260727-DAILY",
  "environmentId": "ENV-STAGING",
  "reportStatus": "COMPLETE",
  "executionStatus": "INCOMPLETE",
  "verificationStatus": "FAIL",
  "changeStatus": "CHANGED",
  "recoveryStatus": "REQUIRED",
  "summary": {
    "scenarioCount": 7,
    "passCount": 5,
    "failCount": 1,
    "notEvaluatedCount": 1,
    "effectiveChangeScenarioCount": 2,
    "ignoredOnlyScenarioCount": 1,
    "notComparedScenarioCount": 0
  },
  "scenarios": [
    {
      "runId": "RUN-20260727-150000-550e8400",
      "resultId": "RESULT-RUN-20260727-150000-550e8400",
      "useCaseId": "UC-E6-001",
      "scenarioId": "SC-E6-001",
      "inputSetId": "INPUT-DEFAULT",
      "executionStatus": "COMPLETED",
      "verificationStatus": "FAIL",
      "changeStatus": "CHANGED",
      "recoveryStatus": "NOT_REQUIRED",
      "effectiveChangedCount": 1,
      "ignoredDiffCount": 2,
      "scenarioSummaryRef": "../../../runs/RUN-20260727-150000-550e8400/reports/scenario-summary.json",
      "sourceLocators": [
        {
          "sourceType": "SCENARIO_SUMMARY",
          "sourceId": "RUN-20260727-150000-550e8400",
          "sourceRef": "../../../runs/RUN-20260727-150000-550e8400/reports/scenario-summary.json"
        },
        {
          "sourceType": "VERIFICATION_RESULT",
          "sourceId": "RESULT-RUN-20260727-150000-550e8400",
          "sourceRef": "../../../runs/RUN-20260727-150000-550e8400/verification-result.json"
        }
      ]
    }
  ],
  "batchResultLocator": {
    "sourceType": "BATCH_VERIFICATION_RESULT",
    "sourceId": "BRESULT-BATCH-20260727-DAILY",
    "sourceRef": "../batch-verification-result.json"
  },
  "generatedAt": "2026-07-27T16:00:00+09:00"
}
```

### 14.3 `diff-report.json`

`diff-report.schema.json`はRun単位の表示Projectionとして、`generationId`、Execution Identity、Change Status、集計、API Call別比較状態、Effective／Ignored件数、Diff表示行およびSource Locatorを保持する。

| 項目 | 契約 |
|---|---|
| `comparisonStatus` | `COMPLETED / NOT_COMPARED / ERROR` |
| `changeStatus` | `NOT_COMPARED / UNCHANGED / CHANGED`だけを使用 |
| `displayCategory` | `EFFECTIVE_CHANGE / IGNORED_ONLY / NO_CHANGE / NOT_COMPARED / COMPARE_ERROR` |
| 表示値 | Mask後の有限長文字列。元JSONをReportへ再複製しない |
| Source | `api-meta.json`と`response-field-diff.json`の両方へ逆引き |

Diff Reportは表示用集計であり、`effectiveChanged`、IgnoreまたはChange Statusを再判定しない。

### 14.4 `evidence-index.json`

`evidence-index.schema.json`はManifest RequirementとCore Artifact Entryの索引Projectionであり、Core Artifactそのものを複製しない。

| 状態 | 必須 | 禁止 |
|---|---|---|
| `available=true` | `artifactId`、`relativePath`、`contentHash`、`sizeBytes`、`masked`、Source Locator | `unavailableReason` |
| `available=false` | `unavailableReason` | 存在しないArtifactのID、Path、HashまたはSource Locator |

Report Set自身をCore Manifest Entryとして循環参照させない。Evidence Indexの`manifestId + manifestHash`は読込元Manifestと一致させる。

### 14.5 Source Locator契約

Reportの表示行は表示値だけでSourceへ結合してはならない。Report Setは`generationId`で識別し、各表示単位は次のSource Locatorを保持する。

| 表示単位 | 必須Source Key | 必須Reference |
|---|---|---|
| Scenario Header／四結果軸 | `runId + resultId` | `verificationResultRef` |
| Check明細 | `resultId + resultKey` | Verification Result内Check |
| API Call明細 | `runId + apiCallCode` | `apiMetaRef` |
| Diff Summary／明細 | `runId + apiCallCode + path + changeType` | `fieldDiffRef` |
| Evidence行 | `artifactId` | Manifest Entryの`relativePath`＋`contentHash` |
| Daily Scenario行 | `batchId + runId` | `scenarioSummaryRef`＋Source Run |

Source Locatorは最低限、`sourceType`、`sourceId`、`sourceRef`を概念項目として持ち、Hashを持つArtifactでは`sourceContentHash`も一致させる。`sourceId`は上表のStable Keyを構造化した値とし、表示名、表行番号、Array IndexまたはLink文字列だけを使用しない。

4 Report JSON Schemaが構造を検証し、Report Generator内部ModelとCross-Artifact ValidatorがSource ID、Reference先、Hashおよび親子Identityの意味一致を検証する。SchemaでPatternに合うだけのSource Locatorを`COMPLETE`の根拠にしない。

### 14.6 Reverse Trace Gate

Report確定前に次を順に検証する。

1. `generationId`がReport Set内で一意である。
2. Scenario Headerの`runId`と`resultId`が同一Verification Resultを指す。
3. Check明細の`resultKey`がSource Result内に一件だけ存在する。
4. API Call／Diff明細の`apiCallCode`がSource RunのSealed PlanとArtifactに存在する。
5. Evidence行の`artifactId`、`relativePath`および`contentHash`がManifest Entryと一致する。
6. Report Linkが同一Run／Batchの許可Root内で解決し、Path Traversalを含まない。
7. Core ManifestがReport SetをEntryとして参照していない。

Sourceが不存在、複数解決、Hash不一致またはSchema未対象区間のため検証不能な場合、Source Runの結果を補完または変更せず、Report Statusを`INCOMPLETE`にするか公開を拒否する。

## 15. 集約規則

### 15.1 四結果軸

Batchおよび表示Groupは`共通Identity・Resultモデル設計書.md`の軸別優先順位をそのまま使用する。

```text
Execution: UNKNOWN_OUTCOME > INCOMPLETE > REJECTED > RUNNING > NOT_STARTED > COMPLETED
Verification: FAIL > NOT_EVALUATED > PASS
Change: CHANGED > NOT_COMPARED > UNCHANGED
Recovery: REQUIRED > IN_PROGRESS > RESOLVED > NOT_REQUIRED
```

Report GeneratorはScenarioの既存Resultをこの順に集約するだけで、Check明細からScenario Resultを再計算しない。

### 15.2 Change Status

| 条件 | Group Change Status |
|---|---|
| Effective Changeが1件以上 | `CHANGED` |
| 全比較完了かつEffective 0 | `UNCHANGED` |
| 比較未実施が1件以上かつ上記なし | `NOT_COMPARED` |

Compare ErrorはChange軸を`NOT_COMPARED`とし、Execution軸およびReason Codeへ原因を保持する。`IGNORED_ONLY`は`UNCHANGED`から導出する表示Categoryであり、原結果Enumへ追加しない。

### 15.3 VerificationとChangeの組合せ

| Verification | Change | Report上の意味 |
|---|---|---|
| PASS | UNCHANGED | 期待成立、有効変化なし。Ignored件数は別表示 |
| PASS | CHANGED | 期待成立だが前回から有効変化あり。確認対象 |
| FAIL | UNCHANGED | 前回と同様でも業務期待不成立 |
| FAIL | CHANGED | 業務期待不成立かつ有効変化あり |
| NOT_EVALUATED | NOT_COMPARED | 前提不成立または実行異常により評価・比較不能 |

この二軸を一つの「成功／失敗」列へ潰さない。

## 16. 初回実行

初回またはBaselineなしの場合は次を表示する。

| 項目 | 表示 |
|---|---|
| Change Status | `NOT_COMPARED` |
| Reason | `INITIAL_EXECUTION` |
| Baseline Run | `-` |
| Effective | 0 |
| Ignored | 0 |
| 注意 | 初回結果をBaseline候補として扱うかはBaseline管理に従う。 |

初回をPASSまたは差異なしと表現しない。Verification ResultはExpectedに対するCheckが実行可能なら独立してPASS／FAILを表示できる。

## 17. Execution Problem／未評価Report

### 17.1 Error表示

Error Sectionには次を表示する。

- Error Code
- 発生Phase
- `runId`、`scenarioId`、`apiCallCode`
- 安全なError Message
- 発生時刻
- 再実行可能性
- Error Evidence Link

### 17.2 未評価表示

未評価Sectionには次を表示する。

- `NOT_EVALUATED`のCheckまたはScenario
- 未成立前提
- 依存`resultKey`
- Reason Code
- 必要な対応
- Evidenceまたは設計参照

`NOT_EVALUATED`をFAILへ置換しない。Runtime／Definition異常はExecution StatusとReason Code、運用介入はRecovery Statusで表現する。

## 18. LinkおよびPath規則

1. Report内Pathは相対Pathを使用する。
2. `..`で許可されたRun／Batch Root外へ遷移しない。
3. Link先存在をReport確定前に検証する。
4. Link先欠落時はLinkを生成せず`UNAVAILABLE`と理由を表示する。
5. URL、Host、IPまたはEnvironment SecretをReportへ組み立てない。
6. `apiCallCode`をDirectory名として使用する前に許可形式を検証する。

## 19. SecurityおよびMask

### 19.1 表示禁止

- Authorization Header
- Access Token、Refresh Token、API Key
- Password、Secret
- 未Maskの個人情報
- Internal Host、IP、Credential Profile実値
- Stacktrace内のSecret

### 19.2 Mask責務

| Layer | 責務 |
|---|---|
| Evidence Writer | 通常Evidenceは保存前Mask。例外Raw Evidenceは専用承認済み領域へ隔離 |
| Verification Result Writer | Expected／Actual表示のMask |
| Diff Writer | Previous／Current ValueのMask |
| Report Generator | 入力済Maskを保持し、追加表示規則を適用 |

Report GeneratorがMask済値から原値を復元してはならない。

## 20. 生成処理

```mermaid
flowchart TD
    A["ManifestとResult読込"] --> B["Schema・Identity検証"]
    B --> C["Scenario Summary生成"]
    C --> D["Diff Report生成"]
    D --> E["Evidence Index生成"]
    E --> F["Batch／Daily集約"]
    F --> G["Link・件数・Mask検証"]
    G --> H["Report一式を原子的公開"]
```

### 20.1 詳細手順

1. Run／Batch Rootを確定する。
2. Artifact Manifestを読込む。
3. 必須成果物の存在、HashおよびSchemaを検証する。
4. Identityが全成果物で一致することを確認する。
5. Scenario Summary JSON／Markdownを生成する。
6. Diff Report JSON／Markdownを生成する。
7. Evidence Index JSON／Markdownを生成する。
8. Batch Verification ResultからDaily Summaryを生成する。
9. Summary件数と入力明細を照合する。
10. Link、Path Traversal、MaskおよびSecretを検証する。
11. 一時DirectoryからReport Directoryへ原子的に公開する。

## 21. 原子的公開

```text
Report Temporary Generation
    → 全Report生成
    → Schema検証
    → Link検証
    → Hash生成
    → Immutable Report Generation公開
    → Expected Pointer VersionでCurrent ReportをCAS切替
    → Logical reports/ ViewからRead-back
```

Temporary／Versioned／Pointerの物理PathはFile I/O Adapter内部Namespaceとし、凍結Runtime TreeまたはReport Linkへ保存しない。生成途中のReportを承認者へ公開しない。既存ReportのPointer切替に失敗した場合は旧ReportをCurrentとして保持し、新ReportのReport Statusを`FAILED`とする。

Report成功後もBaselineまたは`previousRunId`を更新しない。

`reports/`はCore Run Artifact Manifestの対象外とする。Core Manifestを読んで生成するReportを同じManifestへ後付けすると循環依存になるため、Report Setは`generationId`を持つ独立した原子的公開単位として扱う。

既存の非空`reports/` DirectoryをPortableな一回のAtomic Renameで直接上書きできると仮定しない。Consumerが使用する`reports/`はCurrent Report GenerationのLogical Viewであり、再生成では必ず新しい`generationId`を発行する。

## 22. Java Component

```java
public interface ReportGenerator {

    ScenarioReportSet generateScenarioReports(
            RunArtifactSet artifacts);

    DailyReportSet generateDailyReport(
            BatchResult batchResult);
}
```

主要Component：

```text
ReportInputValidator
ScenarioSummaryBuilder
DiffReportBuilder
EvidenceIndexBuilder
DailySummaryBuilder
MarkdownRenderer
ReportSchemaValidator
ReportLinkValidator
ReportPublisher
```

Markdown Templateへ判定ロジックを埋め込まない。

## 23. Report Status

| Report Status | 条件 |
|---|---|
| `COMPLETE` | 全必須Reportが生成・検証・公開済み |
| `INCOMPLETE` | 一部入力またはLink欠落があるが、Error説明付きReportを生成できた |
| `FAILED` | Report一式を安全に生成・公開できなかった |

Report StatusはVerification Resultとは別軸である。

例：

```text
Verification Result = FAIL
Report Status = COMPLETE
```

は正常な組合せである。

## 24. Error Code

| Error Code | 内容 | 処理 |
|---|---|---|
| `REPORT_INPUT_MISSING` | 必須入力成果物なし | `INCOMPLETE`または`FAILED` |
| `REPORT_SCHEMA_ERROR` | 入力Schema不一致 | `FAILED` |
| `REPORT_IDENTITY_MISMATCH` | 成果物間Identity不一致 | `FAILED` |
| `REPORT_SUMMARY_MISMATCH` | Summary件数不一致 | `FAILED` |
| `REPORT_DIFF_REF_MISSING` | Diff参照先なし | `INCOMPLETE` |
| `REPORT_EVIDENCE_REF_MISSING` | Evidence参照先なし | `INCOMPLETE` |
| `REPORT_UNSAFE_PATH` | Root外Path／Path Traversal | `FAILED` |
| `REPORT_SECRET_DETECTED` | Secret実値検出 | 公開中止、`FAILED` |
| `REPORT_RENDER_ERROR` | Markdown／JSON生成失敗 | `FAILED` |
| `REPORT_PUBLISH_ERROR` | 原子的公開失敗 | 旧版保持、`FAILED` |

## 25. Validation

| Validation ID | 確認内容 | Severity |
|---|---|---|
| `RPT-V001` | Run／Batch Identityが全入力で一致する。 | ERROR |
| `RPT-V002` | Verification Resultを再判定していない。 | ERROR |
| `RPT-V003` | Execution、Verification、Change、Recoveryを分離表示する。 | ERROR |
| `RPT-V004` | Summary件数が入力明細と一致する。 | ERROR |
| `RPT-V005` | Ignored DiffをEffectiveまたはFAILへ加算しない。 | ERROR |
| `RPT-V006` | 初回を`NOT_COMPARED`として表示する。 | ERROR |
| `RPT-V007` | FAIL／NOT_EVALUATEDおよびExecution ProblemからCheck明細とReasonへ追跡できる。 | ERROR |
| `RPT-V008` | Effective／Ignored DiffからDiff Fileへ追跡できる。 | ERROR |
| `RPT-V009` | Evidence Linkが同一Run／Batch Root内で解決できる。 | ERROR |
| `RPT-V010` | Secretおよび未Mask個人情報を含まない。 | ERROR |
| `RPT-V011` | JSONとMarkdownの数値・判定が一致する。 | ERROR |
| `RPT-V012` | Report一式が原子的に公開される。 | ERROR |
| `RPT-V013` | Report生成がBaseline／Execution Stateを変更しない。 | ERROR |
| `RPT-V014` | 不完全Reportが`INCOMPLETE`を明示する。 | ERROR |
| `RPT-V015` | Report Setが一意な`generationId`を持つ。 | ERROR |
| `RPT-V016` | Scenario／Check行が`resultId`＋`resultKey`でSource Resultへ逆引きできる。 | ERROR |
| `RPT-V017` | API Call／Diff行が`runId`＋`apiCallCode`＋Diff IdentityでSourceへ逆引きできる。 | ERROR |
| `RPT-V018` | Evidence行の`artifactId`、PathおよびHashがManifest Entryと一致する。 | ERROR |
| `RPT-V019` | Schema未対象または逆引き不能なReportを`COMPLETE`にしない。 | ERROR |

## 26. Test観点

- [ ] PASS／FAIL／NOT_EVALUATEDを正しい優先順位で表示できる。
- [ ] Execution、Verification、Change、Recoveryを別列で表示できる。
- [ ] Effective ChangeとIgnored Onlyを区別できる。
- [ ] PASS＋Effective Changeを表現できる。
- [ ] FAIL＋No Effective Changeを表現できる。
- [ ] 初回を`NOT_COMPARED`として表示できる。
- [ ] Ignored Diffの件数と明細へ到達できる。
- [ ] Report Input欠落をPASSへ補完しない。
- [ ] JSON ReportとMarkdown Reportの集計値が一致する。
- [ ] Scenario SummaryからVerification Result、DiffおよびEvidenceへ到達できる。
- [ ] Link先欠落時に`UNAVAILABLE`を表示できる。
- [ ] Mask対象値がReportへ平文出力されない。
- [ ] 一時Directoryから原子的に公開できる。
- [ ] Report生成失敗時に既存Reportを保持できる。
- [ ] 同一入力から同じ表示順を再現できる。

## 27. 運用および保持

1. Daily SummaryはBatch完了後に生成する。
2. Scenario Reportは各Run成果物確定後に生成する。
3. Report保持期間はEvidence保持期間と整合させる。
4. Reportだけを残し元Evidenceを削除する場合は、保持Policyと監査要件を確認する。
5. 再生成時は同じ入力Versionを使用し、`generatorVersion`と`generatedAt`を更新する。
6. Report再生成をBaseline更新Triggerにしない。

## 28. 未確定事項

| Issue ID | 未確定事項 | 暫定方針 | 確定先 |
|---|---|---|---|
| `RPT-ISSUE-001` | Batch ID採番規則 | 日次JobがUUIDを含む一意IDを発行する。 | 共通Framework／運用設計 |
| `RPT-ISSUE-002` | Optional Checkの表示Severity | 非PASSを専用Sectionへ表示しScenario Resultは変更しない。 | Scenario詳細設計／運用 |
| `RPT-ISSUE-003` | Report／Evidence保持期間 | Environmentごとに運用設定で定義する。 | 運用設計 |
| `RPT-ISSUE-004` | Approver向けHTML出力 | 初版はJSON＋Markdownとする。 | UI／運用要件 |
| `RPT-ISSUE-005` | Report JSON Schema | 4 Report種別を独立Schema化し、共通四軸とSource Locator意味規則を同期済み。正式Role Review、Generator DTO／Writerおよび公開Contract Testを待つ。 | `FW-OI-019`／Report Schema Review |

## 29. 現行Release阻断

| 阻断ID | 内容 | 影響 |
|---|---|---|
| `RPT-BLOCK-001` | `verification-result.json` Writer未実装 | Scenario Reportを生成できない。 |
| `RPT-BLOCK-002` | `response-field-diff.json` Writer未実装 | Diff Reportを生成できない。 |
| `RPT-BLOCK-003` | Batch Resultと4 Report JSON Schemaは正文・機械Validation済みだが、Generator DTO／Writer、Cross-Artifact Reverse Traceおよび公開Contract Testが未実装 | Report出力の構造は検証できるが、端到端生成・公開を正式保証できない。 |
| `RPT-BLOCK-004` | 正式ScenarioおよびRuntime Resultが0件 | 正式E6 Reportの入力契約を実データで検証できない。 |

## 30. 改訂履歴

| Version | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | Verification／Change／Execution分離、Daily／Scenario／Diff／Evidence階層およびIgnored Diff可視化に基づく初版作成 | DRAFT |
| `1.0.0-draft.2` | 2026-07-27 | 横断Reviewにより四結果軸、Canonical Status、Reason表示およびReport Statusとの責務分離へ統一 | DRAFT |
| `1.0.0-draft.3` | 2026-07-28 | Snapshot／Evidence設計に合わせ、Input／Expectedの別Copyと未定義`error.json`を廃止し、Definition Snapshot Reference、API Call MetaおよびCore ManifestとReport Setの非循環境界へ統一 | DRAFT |
| `1.0.0-draft.4` | 2026-07-28 | File I/O設計に合わせ、物理`reports.tmp`前提を廃止し、Immutable Report Generation、Expected Version付きCAS Pointer、Logical `reports/` ViewおよびRead-backへ統一 | DRAFT |
| `1.0.0-draft.5` | 2026-07-28 | 第8バッチCoverage Reviewにより初期7 SchemaとReport JSONを分離し、Artifact ManifestおよびReport Schema Blockerを現行化 | DRAFT |
| `1.0.0-draft.6` | 2026-07-28 | 初期7 Schema正文・機械Validation完了を反映し、Artifact Manifest入力契約完成とReport JSON Schema Coverage未完成を分離 | DRAFT |
| `1.0.0-draft.7` | 2026-07-28 | 第9バッチとしてReport Set Identity、Source Locator、Result／Diff／Manifestへの逆引きGateおよびSchema未対象時のFail Closedを定義 | DRAFT |
| `1.0.0-draft.8` | 2026-07-28 | 第9バッチ第2段階としてBatch Result、Scenario Summary、Diff Report、Evidence Index、Daily Summaryの独立Schema、Report Status／Generator情報およびSource Locator構造契約を同期 | DRAFT |
