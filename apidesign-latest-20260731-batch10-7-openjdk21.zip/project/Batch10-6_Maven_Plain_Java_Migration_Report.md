# 第10バッチ第6段階 Maven＋Plain Java移行検証報告

## 1. 実施結果

| 項目 | 結果 |
|---|---|
| Repository Version | `4.0.5` |
| Change ID | `REP-CR-013` |
| 実施日 | 2026-07-31 |
| 最終基線 | Java 17＋Maven Wrapper 3.9.16＋Plain Java CLI |
| Spring Boot | 非採用／Current Dependency 0件 |
| Spring Framework | 非採用／Current Dependency 0件 |
| Maven | Build、依存管理、Test、Packageに継続使用 |
| 本番Maven Install | 不要 |
| 総合判定 | 静的移行`PASSED`、Build／Test／JAR Smokeは`BLOCKED_BY_ENVIRONMENT` |

## 2. 実装変更

### 2.1 Maven

- Spring Boot Parentを削除した。
- `spring-boot-starter`を削除した。
- `spring-boot-maven-plugin`を削除した。
- Java 17、JUnitおよびMaven Plugin Versionを親POMで明示管理した。
- Maven EnforcerへSpring Boot／Spring Frameworkの直接・推移依存禁止Ruleを追加した。
- `verifier-app`をMaven Shadeによる単一の実行可能JARへ変更した。
- Application JARから`META-INF/maven/**`と署名断片を除外する。
- 全Module JARでMaven Descriptorを生成しない。

### 2.2 Plain Java CLI

- `VerifierApplication`を普通の`main(String[] args)`へ変更した。
- `VerifierComposition`をAnnotationなしの明示Factoryへ変更した。
- `VerifierCommandRunner`を普通の`run(String[])`へ変更した。
- SLF4Jの暗黙依存を廃止し、JDK標準`java.util.logging`へ変更した。
- 終了Codeを次のとおり固定した。

| Code | 意味 |
|---:|---|
| `0` | 正常終了 |
| `2` | 未対応Command／使用方法Error |
| `3` | 予期しない内部Error |

- `VerifierApplicationContractTest`を追加し、正常Commandと未対応Commandの終了Codeを検証する。

### 2.3 Config／Release

- `application-staging.yml`を削除した。
- `verifier-staging.properties`を追加した。
- `build-release.sh`へMaven Verify、JAR内容検査、CLI Smoke、白名单CopyおよびSHA-256生成を実装した。
- 本番Release UnitへPOM、Maven Wrapper、Source、TestおよびLocal Repositoryを含めない。

## 3. 変更範囲

本報告を含むChange Setは23 Pathである。

| 種別 | 件数 | 主な対象 |
|---|---:|---|
| 変更 | 18 | POM、Java 3 Class、Build／Runtime／Staging、Repository／Master／Framework設計 |
| 追加 | 4 | 移行計画、Contract Test、Properties Template、本報告 |
| 削除 | 1 | Spring専用`application-staging.yml` |

Top Level、7 Module、Base Package、5 Master、1 Traceability View、正式Master列、Environment IDおよび正式業務Data件数は変更していない。

## 4. 静的検証

| 検証 | 結果 |
|---|---:|
| 現行正本Markdown | 68份、`PASSED` |
| 一意な`document_id` | 68个、`PASSED` |
| Markdown内JSON | 47个、`PASSED` |
| 製品JSON | 22份、`PASSED` |
| Draft 2020-12 Schema | 16份、Strict Compile `PASSED` |
| POM XML | 8份、Parse `PASSED` |
| Java Source | 26份、静的Gate `PASSED` |
| 本批設計文書Table | 220个、構造`PASSED` |
| Shell | Maven Wrapper／Release Script構文`PASSED` |
| Spring Parent／Dependency | 0件 |
| JavaのSpring／SLF4J Import | 0件 |
| Spring Annotation／Context API | 0件 |
| 旧Staging Config | 0件 |
| Plain Java Config Template | 1件 |
| Java 18以降専用`getFirst()` | 0件 |

Springという文字列は、禁止Rule、非採用要件、今回の移行説明および過去改訂履歴には残る。Current DependencyまたはCurrent Framework採用を意味しない。

## 5. Maven Build実行結果

### 5.1 実行Command

```bash
runtime/mvnw \
  -f runtime/pom.xml \
  --batch-mode \
  --no-transfer-progress \
  clean verify
```

### 5.2 環境事実

| 確認 | 結果 |
|---|---|
| Java Runtime | OpenJDK 17.0.19は存在 |
| Java Launcher | 既定環境では`libjli.so`検索Path不足 |
| `javac` | 存在しない |
| Maven Wrapper | Java Library Path追補後に起動 |
| Reactor | Parent＋7 Moduleの8 Projectを認識 |
| Maven Central | DNS／Network制約で解決不可 |
| 最初の停止点 | `maven-enforcer-plugin:3.6.3`解決 |

### 5.3 判定

Build、JUnit Contract Test、Shade実行可能JAR生成、JAR内容検査およびCLI Smokeは
`BLOCKED_BY_ENVIRONMENT`である。Source Compile Error、Test FailureまたはPackage Failureを
観測したものではないため、`FAILED`または`PASSED`へ置き換えない。

解除条件は次のとおりである。

1. `javac`を含む承認済みJDK 17を配置する。
2. Java共有Library PathをBuild環境で正常化する。
3. 承認済みMaven Repositoryまたは事前取得済み依存Cacheへ接続する。
4. `build/scripts/build-release.sh`を実行する。
5. Maven Verify、JUnit、Shade JAR、JAR内容、CLI SmokeおよびChecksum Evidenceを保存する。

## 6. Release／Security判定

| Gate | 状態 |
|---|---|
| Spring禁止の設計・POM実装 | `PASSED` |
| Release File白名单Script | `PASSED_STATIC` |
| `META-INF/maven/**`除外設定 | `PASSED_STATIC` |
| Secret／Credential追加 | 0件 |
| Master／Environment Security境界 | 変更なし |
| `ENV-PROD enabled=false` | 維持 |
| 実Release JAR内容検査 | `BLOCKED_BY_ENVIRONMENT` |
| SBOM／License／Vulnerability Scan | 後続Build環境で実行 |

## 7. 結論

`REP-CR-013`の設計・Source・POM・Config・Build／Smoke定義への移行は完了した。
現行基線はMavenを使用するPlain Java 17 CLI Batchであり、Spring Bootおよび
Spring Frameworkを使用しない。

Repositoryの内容Versionは`4.0.5`とする。正式Release可否は、承認済みJDK 17と
Maven Repository接続環境でBuild／Test／JAR Smoke Evidenceを取得するまで
`BLOCKED_BY_ENVIRONMENT`を維持する。
