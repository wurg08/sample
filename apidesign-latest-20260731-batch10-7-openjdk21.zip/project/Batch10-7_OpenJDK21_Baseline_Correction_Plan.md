---
title: 第10バッチ第7段階 OpenJDK 21基線訂正計画
document_id: E6-API-VP-BATCH10-7-OPENJDK21-PLAN
version: 1.0.0
status: EXECUTED
document_type: Change Plan
change_id: REP-CR-014
repository_version_from: 4.0.5
repository_version_to: 4.0.6
created: 2026-07-31
updated: 2026-07-31
---

# 第10バッチ第7段階 OpenJDK 21基線訂正計画

## 1. 目的

Repository `4.0.5`の現行Java基線をJava 17からOpenJDK 21へ訂正し、Maven、
Plain Java CLI、7 ModuleおよびSpring非採用の確定済み境界を維持したまま、
Build、Runtime、Smoke、Traceおよび設計Consumerを同一Change Setで同期する。

## 2. 確定基線

| 項目 | 訂正後契約 |
|---|---|
| Java Distribution | 銀行承認済みOpenJDK Distribution |
| Java Major Version | 21 |
| Maven Compiler | `release=21` |
| Maven Enforcer | Java Version `[21,22)` |
| Build／CI | OpenJDK 21 |
| Runtime最低Version | OpenJDK 21 |
| Build Tool | Maven Wrapper 3.9.16 |
| Application Framework | なし。Plain Java CLI |
| 非採用 | Spring Boot、Spring Framework、Spring Batch、Tomcat |
| Base Package | `jp.co.mufg.e6.verifier` |

## 3. 変更対象

| 区分 | 対象 | 変更 |
|---|---|---|
| Build Descriptor | `runtime/pom.xml` | Java Property、Compiler Release、Enforcer範囲を21へ訂正 |
| Build Script | `build/scripts/build-release.sh` | Java仕様Version 21とOpenJDK Runtime名のFail-Closed Gateを追加 |
| Runtime説明 | `runtime/README.md` | OpenJDK 21 Build／Runtime契約へ同期 |
| Build／Smoke | `build/README.md`、`staging/smoke/README.md` | Release BuildおよびSmoke条件へ同期 |
| Repository正本 | `system/01_repository/` | `REP-CR-014`、Repository `4.0.6`、Trace／Review／Blockerへ同期 |
| Master Consumer | `system/02_master/` | Build TraceおよびMaster共通Runtime境界へ同期 |
| Framework正本 | `system/05_framework/` | Decision、System、Framework、Environment、Traceへ同期 |
| Verification Consumer | `system/06_verification_assets/APIレスポンスDiff設計書.md` | Compare Definition Build基線へ同期 |

## 4. 非変更対象

- Maven Wrapper 3.9.16
- Maven Multi-Module 7 Module
- Plain Java CLI Entry Pointおよび明示Composition
- Spring Boot／Spring Framework依存禁止
- Maven Shade実行可能JARとRelease Maven情報除外
- Base Package `jp.co.mufg.e6.verifier`
- 5 Master＋1 Traceability View
- Master列、正式Data件数および`02_master` Directory構造
- `ENV-PROD=PRODUCTION`、`enabled=false`
- Production-like Environment廃止
- Run ID、Output隔離およびRuntime Artifact契約

## 5. 歴史証跡の取扱い

`REP-CR-011`、Repository `4.0.1`および旧Validation Reportに記録されたJDK 17は、
当時の決定と実行環境を示す履歴として保持する。これらを現行基線として参照しては
ならない。現行Build／Runtime契約は`REP-CR-014`を優先する。

## 6. 実施順序

1. Java 17参照を現行規則と履歴へ分類する。
2. POM、Build Script、Runtime／Build／Smoke説明をOpenJDK 21へ変更する。
3. Repository、Trace、Review、Master、FrameworkおよびDiff Consumerを同期する。
4. POM XML、Shell、Java Source、JSON、Schema、Markdown表、Document IDを静的検証する。
5. OpenJDK 21未配置環境でRelease Build GateがFail Closedとなることを確認する。
6. Maven Build、JUnitおよびJAR Smokeの実行可否を環境条件と分離して記録する。
7. Repository `4.0.6`完全PackageとSHA-256を生成する。

## 7. 完了条件

- `java.version=21`および`maven.compiler.release=21`である。
- Maven EnforcerがJDK主Version 21だけを許可する。
- Release BuildがOpenJDK以外またはJava 21以外を拒否する。
- 現行正文のBuild／Runtime／Trace GateがOpenJDK 21で一致する。
- Java 17表現は履歴または旧Evidenceに限定される。
- Spring Source ImportおよびSpring POM依存が0件である。
- Directory、Master列、EnvironmentおよびBase Packageに変更がない。
- 静的Validationが成功し、実Build未実行時は`BLOCKED_BY_ENVIRONMENT`と記録する。
