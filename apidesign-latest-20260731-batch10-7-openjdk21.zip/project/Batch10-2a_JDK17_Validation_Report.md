# 第10バッチ第2段階追補 JDK 17 Validation Report

## 1. 対象

- Repository Change: `REP-CR-011`
- Repository Version: `4.0.1`
- Java Base Package: `jp.co.mufg.e6.verifier`
- Spring Boot: `4.1.0`
- Java compile release: `17`
- Minimum Runtime Version: `17`
- Maven Wrapper Distribution: `3.9.16`
- Application Type: 非Web Batch
- Spring Batch: 第1段階は非採用

本追補は`Batch10-2_Validation_Report.md`を上書きしない。旧ReportはJava 21基線だった時点の実行証跡として保持し、本書でJava 17への承認済み変更と再検証結果を記録する。

## 2. 承認済み変更

| 項目 | 変更前 | 変更後 |
|---|---|---|
| Java compile release | `21` | `17` |
| Maven Compiler release | `21` | `17` |
| Maven Enforcer最低Version | `[21,)` | `[17,)` |
| Build／CI最低JDK | `21` | `17` |
| Runtime最低JDK | `21` | `17` |
| 上位JDK | 21以上 | JDK 17以上を許可 |
| Repository Version | `4.0.0` | `4.0.1` |

変更しない項目：

- Spring Boot 4.1.0
- Maven Wrapper 3.9.16
- 7 Module構成
- Base Package `jp.co.mufg.e6.verifier`
- `WebApplicationType.NONE`
- Tomcat／Web Starter非採用
- 第1段階Spring Batch非採用
- `verifier-app`だけをExecutable JARとするPackaging契約

## 3. Source互換性是正

`VerifierCommandRunner`にJava 21で追加された`List.getFirst()`が存在し、POMだけを17へ変更するとCompile Errorになる状態を検出した。

```text
commands.getFirst()
→ commands.get(0)
```

空Listの場合は既存の条件分岐で`validate-registry`を使用するため、動作契約は変更しない。

全25 Java Sourceを対象にJava 18以降専用APIのLiteral Scanを行い、追加Hitは0件だった。現在使用中のRecord、`Stream.toList()`および`HexFormat`はJava 17で利用可能である。

## 4. Validation結果

| Validation | 結果 |
|---|---|
| Root POMの`java.version=17` | `PASSED` |
| Root POMの`maven.compiler.release=17` | `PASSED` |
| Maven EnforcerのJava最低Version=`[17,)` | `PASSED` |
| 8 POM XML Parse | `PASSED` |
| 7 Module一意性／Dependency Cycle | `PASSED` |
| 25 Java Source Package Ownership | `PASSED` |
| Java 18以降専用API Literal Scan | `PASSED / 0 HIT` |
| Web／Tomcat／Spring Batch禁止依存 | `PASSED / 0 HIT` |
| Maven Wrapper 3.9.16起動 | `PASSED` |
| OpenJDK Runtime 17起動 | `PASSED / 17.0.19` |
| 16 JSON Schema Draft 2020-12 Strict Compile | `PASSED` |
| 現行68 Markdown／68一意`document_id` | `PASSED` |
| 現行22 JSON File Parse | `PASSED` |
| 現行47 Markdown内JSON Example Parse | `PASSED` |
| 変更14文書のFront Matter／本文版数／改訂履歴一致 | `PASSED` |
| Java 17 Maven `clean verify` | `BLOCKED_BY_ENVIRONMENT` |
| JUnit Contract Test実行 | `NOT_REACHED / BLOCKED_BY_ENVIRONMENT` |
| Executable JAR生成／Smoke | `NOT_REACHED / BLOCKED_BY_ENVIRONMENT` |

## 5. Build Gate未完了理由

現作業環境のJava RuntimeはOpenJDK 17.0.19であり、Maven Wrapper 3.9.16を起動できた。ただし次の2条件が満たされていない。

1. Java配置に`javac`がなく、完全なJDK 17ではなくRuntimeだけが存在する。
2. Maven Centralの名前解決が許可されず、Spring Boot Parent `4.1.0`を取得できない。

`clean verify`はPOM Model構築時のParent解決で停止し、Compile、JUnit、PackageおよびSmokeへ到達していない。したがって、Source／POMのBuild成功または失敗を示す結果ではない。

## 6. 再実行条件

依存Repositoryへ接続可能な完全JDK 17環境で次を実行する。

```bash
cd runtime
java -version
javac -version
./mvnw --batch-mode --no-transfer-progress clean verify
java -jar modules/verifier-app/target/e6-api-verifier.jar validate-registry
```

完了条件：

1. `java -version`と`javac -version`が17以上である。
2. Maven Wrapperが3.9.16を使用する。
3. Maven EnforcerのJava／Maven／Dependency Convergence Ruleが成功する。
4. 7 ModuleがCompile／Test／Packageに成功する。
5. Registry Contract Testが成功する。
6. `verifier-app`だけがSpring Boot Executable JARを生成する。
7. Executable JARの`validate-registry`が非Webで終了Code 0を返す。

## 7. 最終判定

| 判定軸 | 状態 |
|---|---|
| JDK 17設計契約 | `APPROVED` |
| POM／Source／Smoke／設計への反映 | `IMPLEMENTED` |
| 静的互換性Validation | `PASSED` |
| Java 17 Maven Build／Test | `BLOCKED_BY_ENVIRONMENT` |
| 正式DTO／Scenario Class Trace | `BLOCKED / FORMAL DATA 0` |

JDK 17環境対応は設計・設定・Source是正まで完了したが、完全JDK 17および依存Repository接続環境でのBuild／Test成功を確認するまで`TRACE-BUILD`全体を`PASS`にしてはならない。
