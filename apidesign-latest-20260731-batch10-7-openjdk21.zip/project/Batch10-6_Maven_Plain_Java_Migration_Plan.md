# 第10バッチ第6段階 Maven＋Plain Java移行計画

## 1. 目的

Repository `4.0.4`を基線とし、API検証ToolのApplication FrameworkをSpring BootからPlain Java 17 CLIへ変更する。MavenはBuild、依存管理、TestおよびPackageの正規Toolとして継続使用する。

## 2. 承認済み技術基線

| 項目 | 決定 |
|---|---|
| Change ID | `REP-CR-013` |
| Java | Java 17 compile release／最低Runtime |
| Build | Maven Wrapper 3.9.16 |
| Application Framework | なし。Plain Java |
| 実行形態 | CLI／非Web Batch |
| Packaging | Mavenによる単一の実行可能JAR |
| Entry Point | `jp.co.mufg.e6.verifier.app.VerifierApplication` |
| DI／Composition | ConstructorとComposition Rootによる明示組立 |
| Logging | JDK標準`java.util.logging` |
| Test | JUnit Contract Test |
| 非採用 | Spring Boot、Spring Framework、Spring Batch、Tomcat／Servlet Container |

## 3. 非変更範囲

- Repository Top Levelおよび`system/`直下Directory
- Business、Environment、API、UseCase、Scenarioの5 Master
- `API_UseCase_Scenario対応表.md`
- Masterの正式列、ID、Referenceおよび0件の正式業務Data状態
- `ENV-PROD = PRODUCTION`、`enabled=false`
- Production-like Environment廃止
- Java Base Package `jp.co.mufg.e6.verifier`
- 6 Production Module＋1 Contract Test Module
- 明示Scenario Registry
- Processごとの`run_id`、出力Directory分離、共有更新Lock

## 4. 変更対象

| 区分 | 対象 | 変更 |
|---|---|---|
| Build | `runtime/pom.xml` | Spring Boot Parentを削除し、Java／JUnit／Maven Plugin Versionを明示管理 |
| Package | `runtime/modules/verifier-app/pom.xml` | Spring Starter／Boot Pluginを削除し、Plain Java実行可能JARを生成 |
| Java | `VerifierApplication.java` | Spring Application Contextを廃止し、普通の`main`から明示Compositionを実行 |
| Java | `VerifierComposition.java` | `@Configuration`／`@Bean`を廃止し、普通のFactoryへ変更 |
| Java | `VerifierCommandRunner.java` | Spring Runner／ExitCode接口を廃止し、`run(String[])`で終了Codeを返却 |
| Config | `staging/config-template/` | Spring専用YAMLをTool固有Properties Templateへ置換 |
| Build／Run | `build/`、`runtime/README.md`、`staging/smoke/` | Build、実行、Smoke ContractをPlain Javaへ同期 |
| Governance | `Repository_Structure.md` | `REP-CR-013`、Repository `4.0.5`、凍結基線を同期 |
| Master | `Master共通設計書.md` | Consumer境界をMaven＋Plain Javaへ同期 |
| Framework | 現行Framework設計4文書 | Framework、Packaging、Entry Point、Build Gateを同期 |
| Review | Review／GlossaryのCurrent State | Spring Boot現行採用表現を履歴へ限定 |

## 5. 実行順序

1. POMとJava Entry Pointを変更する。
2. Config、Build、RunおよびSmoke定義を変更する。
3. Repository Governance、Master共通設計、Framework設計と決定事項を同期する。
4. Spring Boot／Spring FrameworkのCurrent Dependencyが0件であることを確認する。
5. POM XML、Java 17 Source、JUnit Contract、Executable JAR、JSON、Schema、Document IDおよびReferenceを検証する。
6. Validation Report、完全PackageおよびSHA-256を生成する。

## 6. 完了条件

- `runtime/pom.xml`と全Module Dependency TreeにSpringが存在しない。
- Production Java Sourceに`org.springframework.*`、Spring AnnotationおよびSLF4Jの暗黙依存が存在しない。
- Entry PointがSpring Contextなしで終了Code `0／2／3`を決定できる。
- `validate-registry`がE6 APIへ接続せず完了する。
- Maven `clean verify`と実行可能JAR Smoke TestがJDK 17 Build環境で成功する。
- Build環境不足時は静的ValidationをPASSとし、Build Gateを事実どおり`BLOCKED_BY_ENVIRONMENT`に維持する。
- 既存Master、Schema、JSON、Referenceおよび凍結Directory構造を破壊しない。
