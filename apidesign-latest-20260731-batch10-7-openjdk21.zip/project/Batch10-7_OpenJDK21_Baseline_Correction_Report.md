---
title: 第10バッチ第7段階 OpenJDK 21基線訂正検証報告
document_id: E6-API-VP-BATCH10-7-OPENJDK21-REPORT
version: 1.0.0
status: VALIDATED_WITH_ENVIRONMENT_BLOCKER
document_type: Validation Report
change_id: REP-CR-014
repository_version: 4.0.6
created: 2026-07-31
updated: 2026-07-31
---

# 第10バッチ第7段階 OpenJDK 21基線訂正検証報告

## 1. 結論

現行Java基線をOpenJDK 21へ訂正し、Repository `4.0.6`へ反映した。
POM、Release Build Gate、Runtime／Build／Smoke、Repository、Trace、Master、
FrameworkおよびVerification Consumerの静的整合性は成立している。

現作業環境にはOpenJDK 21 Compilerと承認済み依存Repository接続がないため、
Maven `clean verify`、JUnitおよび実行可能JAR Smokeは
`BLOCKED_BY_ENVIRONMENT`とする。静的検証の成功を実Buildの`PASS`へ変換しない。

## 2. 最終技術基線

| 項目 | 現行値 |
|---|---|
| Java | 銀行承認済みOpenJDK 21 |
| Java Major | 21だけ |
| Maven Compiler | `release=21` |
| Maven Enforcer | `[21,22)` |
| Maven | Maven Wrapper 3.9.16 |
| Application | Plain Java CLI非Web Batch |
| Module | 7 Module |
| Framework | Spring Boot／Spring Framework／Spring Batch非採用 |
| Web／Container | Tomcat／Servlet Container非採用 |
| Base Package | `jp.co.mufg.e6.verifier` |
| Repository Version | `4.0.6` |
| Change ID | `REP-CR-014` |

## 3. 実施変更

| 区分 | 実施内容 |
|---|---|
| POM | `java.version=21`、`maven.compiler.release=21`、Enforcer `[21,22)` |
| Release Build | Java仕様Version 21とOpenJDK Runtime名の事前Gateを追加 |
| Runtime／Smoke | OpenJDK 21でのBuild、実行およびRelease一致条件へ同期 |
| Repository | `REP-CR-014`とVersion `4.0.6`を追加 |
| Trace／Review | OpenJDK 21 Build Traceと`REV-JAVA-013`を追加 |
| Master | Master共通、API、Scenario ConsumerのBuild Gateを同期 |
| Framework | Decision、System、Framework、Environment、Trace、Blockerを同期 |
| Diff | Compare DefinitionのBuild／Runtime比較基線を同期 |

Maven、Plain Java CLI、7 Module、Spring禁止、Base Package、Master列、Environment、
Run IDおよびRuntime Artifact契約は変更していない。

## 4. 静的検証結果

| 検証 | 結果 | 件数／Evidence |
|---|---|---:|
| Product JSON Parse | PASS | 22 |
| Markdown内JSON Parse | PASS | 47 |
| Draft 2020-12 Schema Strict Compile | PASS | 16 |
| POM XML Parse | PASS | 8 |
| POM OpenJDK 21契約 | PASS | `21 / 21 / [21,22)` |
| Java Source Spring Import | PASS | 26 Source、0 Hit |
| Spring Production Dependency | PASS | 0件 |
| 変更Markdown表構造 | PASS | 373 Table／3,464 Row |
| Shell Syntax | PASS | `build-release.sh` |
| `document_id`一意性 | PASS | 70件、重複0件 |
| Current Java 17残留分類 | PASS | 過去Change／改訂履歴／旧Evidenceだけ |

## 5. Build Gate検証

現作業環境の実態は次のとおりである。

| 項目 | 実態 |
|---|---|
| Java Runtime | OpenJDK 17.0.19 |
| Java Launcher | 通常起動は`libjli.so`不足。Library Path指定時のみ起動 |
| Java Compiler | `javac`なし |
| OpenJDK 21 | 未配置 |
| Maven Wrapper | 3.9.16起動可能 |
| Maven Reactor | 親＋7 Module、合計8 Projectを認識 |
| Maven Plugin Repository | Maven Enforcer Plugin解決不可 |

### 5.1 Fail-Closed確認

OpenJDK 17 Runtimeで`build/scripts/build-release.sh`を実行し、Maven開始前に
次の理由で終了することを確認した。

```text
Release Build requires Java specification version 21.
```

結果は`PASS`である。Java 17による誤Buildを継続しない。

### 5.2 Maven Build状態

Maven WrapperのReactor認識は成功したが、依存Repositoryへ接続できず
`maven-enforcer-plugin:3.6.3`を解決できなかった。またOpenJDK 21 Compilerが
存在しないため、次は未実施である。

- Maven `clean verify`
- Maven Enforcer実行完了
- Java 21 Compile
- JUnit Contract Test
- Maven Shade実行可能JAR生成
- JAR Contents確認
- `validate-registry` CLI Smoke

判定は`BLOCKED_BY_ENVIRONMENT`であり、Source／Test Failureではない。

## 6. 歴史証跡

次の成果物は当時のJDK 17決定または実行環境を示す履歴として原文保持した。

- `Batch10-2a_JDK17_Validation_Report.md`
- `Batch10-6_Maven_Plain_Java_Migration_Plan.md`
- `Batch10-6_Maven_Plain_Java_Migration_Report.md`
- `REP-CR-011`およびRepository `4.0.1`の改訂履歴

これらは現行Build／Runtime基線ではない。現行契約は`REP-CR-014`と
Repository `4.0.6`を正とする。

## 7. 残存Gate

1. 銀行承認済みOpenJDK 21 Distribution／VendorとPatch Versionを固定する。
2. OpenJDK 21 Compilerを持つBuild／CI環境を準備する。
3. 銀行承認済みMaven Repository Mirrorへ接続する。
4. `build/scripts/build-release.sh`を実行する。
5. Maven Verify、JUnit、Shade JAR、Contents、CLI SmokeおよびChecksum Evidenceを保存する。

上記が完了するまで`TRACE-BUILD`全体を正式`PASS`にしてはならない。
