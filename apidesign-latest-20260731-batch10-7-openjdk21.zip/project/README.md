# Project Management

本Directoryは、E6 API Verification Platformの要件、WBS、Schedule、QA、IssueおよびRiskを管理するProject管理領域である。

実行可能なJava Source、Build生成物、環境CredentialおよびRuntime結果は配置しない。

