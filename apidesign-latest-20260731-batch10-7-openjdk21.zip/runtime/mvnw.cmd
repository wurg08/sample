@echo off
setlocal
set "PROJECT_DIR=%~dp0"
set "PROPERTIES=%PROJECT_DIR%.mvn\wrapper\maven-wrapper.properties"
for /f "tokens=1,* delims==" %%A in (%PROPERTIES%) do (
  if "%%A"=="distributionUrl" set "DISTRIBUTION_URL=%%B"
  if "%%A"=="distributionSha512Sum" set "EXPECTED_SHA512=%%B"
)
set "MAVEN_VERSION=3.9.16"
if defined MAVEN_USER_HOME (
  set "WRAPPER_ROOT=%MAVEN_USER_HOME%\wrapper\dists"
) else (
  set "WRAPPER_ROOT=%USERPROFILE%\.m2\wrapper\dists"
)
set "WRAPPER_HOME=%WRAPPER_ROOT%\apache-maven-%MAVEN_VERSION%"
set "ARCHIVE=%WRAPPER_HOME%\apache-maven-%MAVEN_VERSION%-bin.zip"
set "MAVEN_HOME=%WRAPPER_HOME%\apache-maven-%MAVEN_VERSION%"

if not exist "%MAVEN_HOME%\bin\mvn.cmd" (
  if not exist "%WRAPPER_HOME%" mkdir "%WRAPPER_HOME%"
  powershell -NoProfile -NonInteractive -Command ^
    "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing '%DISTRIBUTION_URL%' -OutFile '%ARCHIVE%'; $actual=(Get-FileHash -Algorithm SHA512 '%ARCHIVE%').Hash.ToLowerInvariant(); if ($actual -ne '%EXPECTED_SHA512%') { throw 'Maven distribution checksum mismatch.' }; Expand-Archive -Force '%ARCHIVE%' '%WRAPPER_HOME%'"
  if errorlevel 1 exit /b 1
)

call "%MAVEN_HOME%\bin\mvn.cmd" %*
exit /b %ERRORLEVEL%

