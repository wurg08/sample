# E6 API Verifier Runtime

OpenJDK 21上で動作するPlain Java CLIおよびMaven Multi-Moduleで構成する非Web Batch Applicationである。
Spring Boot、Spring Framework、Spring Batch、TomcatおよびServlet Containerは使用しない。

Java互換性契約は次のとおりとする。

- Build JDK、CI基準および最低Runtime VersionはOpenJDK 21とする。
- Maven Compilerの`release`は21へ固定する。
- BuildはOpenJDKのJDK主Version 21だけを承認対象とし、別Major Versionは再検証なしに使用しない。
- Java 22以降だけで利用可能なAPIまたは言語仕様をSourceへ導入しない。
- Maven EnforcerでSpring Boot／Spring Frameworkの直接・推移依存を禁止する。
- Application組立はAnnotationやDI Containerを使用せず、Composition Rootで明示する。
- MavenはBuild Toolであり、本番RuntimeへのInstallを要求しない。

## Build

```bash
./mvnw clean verify
```

BuildにはOpenJDK 21の完全なJDKが必要である。JREだけの環境または別Major VersionではBuildできない。

## Run

```bash
java -jar modules/verifier-app/target/e6-api-verifier.jar validate-registry
```

本Scaffoldでは正式E6 Scenarioを登録していない。正式Master／設計／Input／Expectedが承認された後、`verifier-scenarios-e6`の明示Catalogへ登録する。

## Module

| Module | 責務 |
|---|---|
| `verifier-core` | Identity、Command／Result、Port、Scenario実行契約 |
| `verifier-definition` | Descriptor、明示Registry、Snapshot |
| `verifier-verification` | Checkと検証結果 |
| `verifier-adapters` | HTTP等の外部Adapter |
| `verifier-scenarios-e6` | E6固有Scenarioと明示Catalog |
| `verifier-app` | Plain Java CLI Entry Pointと明示Composition Root |
| `verifier-contract-tests` | Module、Registryおよび横断Contract Test |

## Exit Code

| Code | 意味 |
|---:|---|
| `0` | Command正常終了 |
| `2` | 未対応Commandまたは使用方法Error |
| `3` | Application内部Error |

## Release境界

本番Release UnitへMaven Wrapper、POM、SourceおよびTestを含めない。Maven Shadeで
生成する実行可能JARでは`META-INF/maven/**`を除外する。第三者Libraryを追加する場合は
SBOM、License、Version、Checksumおよび脆弱性Reviewを別途満たす。
