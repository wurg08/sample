package jp.co.mufg.e6.verifier.definition;

import java.util.List;
import java.util.Objects;

public record RegistrySnapshot(
        String sha256,
        List<ScenarioDescriptor> descriptors) {

    public RegistrySnapshot {
        Objects.requireNonNull(sha256, "sha256");
        descriptors = List.copyOf(descriptors);
    }
}

