package jp.co.mufg.e6.verifier.definition;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;
import jp.co.mufg.e6.verifier.core.Scenario;
import jp.co.mufg.e6.verifier.core.model.ScenarioId;

public final class ImmutableScenarioRegistry implements ScenarioRegistry {

    private final Map<ScenarioId, ScenarioRegistration> registrations;
    private final RegistrySnapshot snapshot;

    private ImmutableScenarioRegistry(
            Map<ScenarioId, ScenarioRegistration> registrations) {
        this.registrations = Map.copyOf(registrations);
        List<ScenarioDescriptor> descriptors = registrations.values().stream()
                .map(ScenarioRegistration::descriptor)
                .sorted(java.util.Comparator.comparing(ScenarioDescriptor::scenarioId))
                .toList();
        this.snapshot = new RegistrySnapshot(hash(descriptors), descriptors);
    }

    public static ImmutableScenarioRegistry seal(
            Collection<ScenarioRegistration> registrations) {
        Map<ScenarioId, ScenarioRegistration> unique = new LinkedHashMap<>();
        for (ScenarioRegistration registration : registrations) {
            ScenarioId key = registration.descriptor().scenarioId();
            if (unique.putIfAbsent(key, registration) != null) {
                throw new IllegalArgumentException(
                        "Duplicate scenario registration: " + key);
            }
        }
        return new ImmutableScenarioRegistry(unique);
    }

    @Override
    public Optional<Scenario> find(ScenarioId scenarioId) {
        return Optional.ofNullable(registrations.get(scenarioId))
                .map(ScenarioRegistration::instance);
    }

    @Override
    public Scenario require(ScenarioId scenarioId) {
        return find(scenarioId).orElseThrow(
                () -> new NoSuchElementException(
                        "Scenario is not registered: " + scenarioId));
    }

    @Override
    public RegistrySnapshot snapshot() {
        return snapshot;
    }

    private static String hash(List<ScenarioDescriptor> descriptors) {
        String canonical = descriptors.stream()
                .map(descriptor -> descriptor.scenarioId()
                        + "|" + descriptor.implementationType()
                        + "|" + descriptor.version()
                        + "|" + descriptor.capabilities().stream()
                                .sorted()
                                .collect(Collectors.joining(",")))
                .collect(Collectors.joining("\n"));
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(
                    digest.digest(canonical.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is required by Java", exception);
        }
    }
}

