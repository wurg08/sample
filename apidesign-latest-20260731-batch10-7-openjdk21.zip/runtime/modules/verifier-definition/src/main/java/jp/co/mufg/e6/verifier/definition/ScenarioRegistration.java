package jp.co.mufg.e6.verifier.definition;

import java.util.Objects;
import jp.co.mufg.e6.verifier.core.Scenario;

public record ScenarioRegistration(
        ScenarioDescriptor descriptor,
        Scenario instance) {

    public ScenarioRegistration {
        Objects.requireNonNull(descriptor, "descriptor");
        Objects.requireNonNull(instance, "instance");
        if (!descriptor.scenarioId().equals(instance.id())) {
            throw new IllegalArgumentException(
                    "Descriptor and instance scenarioId must match");
        }
        if (!descriptor.implementationType().equals(instance.getClass().getName())) {
            throw new IllegalArgumentException(
                    "Descriptor implementationType must match the instance type");
        }
    }

    public static ScenarioRegistration of(
            Scenario instance,
            String version,
            java.util.Set<String> capabilities) {
        return new ScenarioRegistration(
                new ScenarioDescriptor(
                        instance.id(),
                        instance.getClass().getName(),
                        version,
                        capabilities),
                instance);
    }
}

