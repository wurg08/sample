package jp.co.mufg.e6.verifier.definition;

import java.util.Objects;
import java.util.Set;
import jp.co.mufg.e6.verifier.core.model.ScenarioId;

public record ScenarioDescriptor(
        ScenarioId scenarioId,
        String implementationType,
        String version,
        Set<String> capabilities) {

    public ScenarioDescriptor {
        Objects.requireNonNull(scenarioId, "scenarioId");
        Objects.requireNonNull(implementationType, "implementationType");
        Objects.requireNonNull(version, "version");
        capabilities = Set.copyOf(capabilities);
        if (implementationType.isBlank() || version.isBlank()) {
            throw new IllegalArgumentException(
                    "implementationType and version must not be blank");
        }
    }
}

