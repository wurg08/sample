package jp.co.mufg.e6.verifier.definition;

import java.util.Optional;
import jp.co.mufg.e6.verifier.core.Scenario;
import jp.co.mufg.e6.verifier.core.model.ScenarioId;

public interface ScenarioRegistry {

    Optional<Scenario> find(ScenarioId scenarioId);

    Scenario require(ScenarioId scenarioId);

    RegistrySnapshot snapshot();
}

