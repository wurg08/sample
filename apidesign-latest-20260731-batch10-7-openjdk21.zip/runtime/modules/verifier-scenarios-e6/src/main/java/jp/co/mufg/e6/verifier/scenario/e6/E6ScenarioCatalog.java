package jp.co.mufg.e6.verifier.scenario.e6;

import java.util.List;
import jp.co.mufg.e6.verifier.definition.ScenarioRegistration;

public final class E6ScenarioCatalog {

    private final List<ScenarioRegistration> registrations;

    private E6ScenarioCatalog(List<ScenarioRegistration> registrations) {
        this.registrations = List.copyOf(registrations);
    }

    public static E6ScenarioCatalog empty() {
        return new E6ScenarioCatalog(List.of());
    }

    public static E6ScenarioCatalog of(
            List<ScenarioRegistration> registrations) {
        return new E6ScenarioCatalog(registrations);
    }

    public List<ScenarioRegistration> registrations() {
        return registrations;
    }
}

