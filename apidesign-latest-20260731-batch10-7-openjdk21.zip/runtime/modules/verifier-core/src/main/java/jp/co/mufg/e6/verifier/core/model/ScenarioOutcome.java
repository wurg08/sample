package jp.co.mufg.e6.verifier.core.model;

public enum ScenarioOutcome {
    COMPLETED,
    REJECTED,
    INCOMPLETE,
    UNKNOWN_OUTCOME
}

