package jp.co.mufg.e6.verifier.core;

import jp.co.mufg.e6.verifier.core.model.ScenarioContext;
import jp.co.mufg.e6.verifier.core.model.ScenarioExecutionResult;
import jp.co.mufg.e6.verifier.core.model.ScenarioId;

public interface Scenario {

    ScenarioId id();

    ScenarioExecutionResult execute(ScenarioContext context);
}

