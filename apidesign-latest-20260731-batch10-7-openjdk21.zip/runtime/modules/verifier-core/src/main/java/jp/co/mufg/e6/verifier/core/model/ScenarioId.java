package jp.co.mufg.e6.verifier.core.model;

import java.util.Objects;
import java.util.regex.Pattern;

public record ScenarioId(String value) implements Comparable<ScenarioId> {

    private static final Pattern FORMAT = Pattern.compile("SC-[A-Z0-9]+-[0-9]{3}");

    public ScenarioId {
        Objects.requireNonNull(value, "value");
        if (!FORMAT.matcher(value).matches()) {
            throw new IllegalArgumentException("Invalid scenarioId: " + value);
        }
    }

    @Override
    public int compareTo(ScenarioId other) {
        return value.compareTo(other.value);
    }

    @Override
    public String toString() {
        return value;
    }
}

