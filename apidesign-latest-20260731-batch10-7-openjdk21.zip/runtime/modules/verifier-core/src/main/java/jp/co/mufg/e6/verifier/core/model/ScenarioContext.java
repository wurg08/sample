package jp.co.mufg.e6.verifier.core.model;

import java.util.Map;

public record ScenarioContext(Map<String, Object> inputs) {

    public ScenarioContext {
        inputs = Map.copyOf(inputs);
    }
}

