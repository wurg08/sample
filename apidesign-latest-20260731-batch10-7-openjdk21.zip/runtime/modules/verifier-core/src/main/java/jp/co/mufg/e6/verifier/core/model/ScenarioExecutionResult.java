package jp.co.mufg.e6.verifier.core.model;

import java.util.Objects;

public record ScenarioExecutionResult(
        ScenarioId scenarioId,
        ScenarioOutcome outcome,
        String reasonCode) {

    public ScenarioExecutionResult {
        Objects.requireNonNull(scenarioId, "scenarioId");
        Objects.requireNonNull(outcome, "outcome");
        Objects.requireNonNull(reasonCode, "reasonCode");
        if (reasonCode.isBlank()) {
            throw new IllegalArgumentException("reasonCode must not be blank");
        }
    }
}

