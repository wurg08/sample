package jp.co.mufg.e6.verifier.app;

import jp.co.mufg.e6.verifier.definition.ImmutableScenarioRegistry;
import jp.co.mufg.e6.verifier.definition.ScenarioRegistry;
import jp.co.mufg.e6.verifier.scenario.e6.E6ScenarioCatalog;

final class VerifierComposition {

    private VerifierComposition() {
    }

    static VerifierCommandRunner createCommandRunner() {
        E6ScenarioCatalog catalog = E6ScenarioCatalog.empty();
        ScenarioRegistry registry = scenarioRegistry(catalog);
        return new VerifierCommandRunner(registry);
    }

    private static ScenarioRegistry scenarioRegistry(E6ScenarioCatalog catalog) {
        return ImmutableScenarioRegistry.seal(catalog.registrations());
    }
}
