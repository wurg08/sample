package jp.co.mufg.e6.verifier.app;

import java.util.logging.Logger;
import jp.co.mufg.e6.verifier.definition.RegistrySnapshot;
import jp.co.mufg.e6.verifier.definition.ScenarioRegistry;

final class VerifierCommandRunner {

    private static final Logger LOGGER =
            Logger.getLogger(VerifierCommandRunner.class.getName());

    private final ScenarioRegistry registry;

    VerifierCommandRunner(ScenarioRegistry registry) {
        this.registry = registry;
    }

    int run(String[] arguments) {
        String command = arguments.length == 0 ? "validate-registry" : arguments[0];

        if (!"validate-registry".equals(command)) {
            LOGGER.warning(() -> "Unsupported command: " + command);
            return 2;
        }

        RegistrySnapshot snapshot = registry.snapshot();
        LOGGER.info(() -> "Scenario Registry validated: count="
                + snapshot.descriptors().size()
                + ", sha256="
                + snapshot.sha256());
        return 0;
    }
}
