package jp.co.mufg.e6.verifier.app;

import java.util.logging.Level;
import java.util.logging.Logger;

public final class VerifierApplication {

    private static final Logger LOGGER =
            Logger.getLogger(VerifierApplication.class.getName());

    private VerifierApplication() {
    }

    public static void main(String[] args) {
        System.exit(run(args));
    }

    public static int run(String[] args) {
        try {
            return VerifierComposition.createCommandRunner().run(args);
        } catch (RuntimeException exception) {
            LOGGER.log(Level.SEVERE, "Verifier terminated unexpectedly.", exception);
            return 3;
        }
    }
}
