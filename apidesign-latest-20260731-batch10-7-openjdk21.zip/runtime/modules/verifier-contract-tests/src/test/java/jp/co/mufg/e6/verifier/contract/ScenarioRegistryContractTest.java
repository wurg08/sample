package jp.co.mufg.e6.verifier.contract;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;
import java.util.Map;
import java.util.Set;
import jp.co.mufg.e6.verifier.core.Scenario;
import jp.co.mufg.e6.verifier.core.model.ScenarioContext;
import jp.co.mufg.e6.verifier.core.model.ScenarioExecutionResult;
import jp.co.mufg.e6.verifier.core.model.ScenarioId;
import jp.co.mufg.e6.verifier.core.model.ScenarioOutcome;
import jp.co.mufg.e6.verifier.definition.ImmutableScenarioRegistry;
import jp.co.mufg.e6.verifier.definition.ScenarioDescriptor;
import jp.co.mufg.e6.verifier.definition.ScenarioRegistration;
import org.junit.jupiter.api.Test;

class ScenarioRegistryContractTest {

    @Test
    void sealsExplicitRegistrationAndCreatesStableSnapshot() {
        FixtureScenario scenario = new FixtureScenario("SC-E6-901");
        ScenarioRegistration registration =
                ScenarioRegistration.of(scenario, "1.0.0", Set.of("READ_ONLY"));

        var first = ImmutableScenarioRegistry.seal(List.of(registration));
        var second = ImmutableScenarioRegistry.seal(List.of(registration));

        assertEquals(scenario, first.require(scenario.id()));
        assertEquals(first.snapshot().sha256(), second.snapshot().sha256());
        assertEquals(1, first.snapshot().descriptors().size());
    }

    @Test
    void rejectsDuplicateScenarioIdInsteadOfLastWins() {
        FixtureScenario scenario = new FixtureScenario("SC-E6-901");
        ScenarioRegistration registration =
                ScenarioRegistration.of(scenario, "1.0.0", Set.of());

        assertThrows(
                IllegalArgumentException.class,
                () -> ImmutableScenarioRegistry.seal(
                        List.of(registration, registration)));
    }

    @Test
    void rejectsDescriptorWhoseImplementationTypeDoesNotMatchInstance() {
        FixtureScenario scenario = new FixtureScenario("SC-E6-901");
        ScenarioDescriptor invalid = new ScenarioDescriptor(
                scenario.id(),
                "jp.co.mufg.e6.verifier.InvalidScenario",
                "1.0.0",
                Set.of());

        assertThrows(
                IllegalArgumentException.class,
                () -> new ScenarioRegistration(invalid, scenario));
    }

    @Test
    void snapshotChangesWhenTheRegisteredVersionChanges() {
        FixtureScenario scenario = new FixtureScenario("SC-E6-901");
        var first = ImmutableScenarioRegistry.seal(List.of(
                ScenarioRegistration.of(scenario, "1.0.0", Set.of())));
        var second = ImmutableScenarioRegistry.seal(List.of(
                ScenarioRegistration.of(scenario, "1.0.1", Set.of())));

        assertNotEquals(first.snapshot().sha256(), second.snapshot().sha256());
    }

    private static final class FixtureScenario implements Scenario {

        private final ScenarioId id;

        private FixtureScenario(String id) {
            this.id = new ScenarioId(id);
        }

        @Override
        public ScenarioId id() {
            return id;
        }

        @Override
        public ScenarioExecutionResult execute(ScenarioContext context) {
            return new ScenarioExecutionResult(
                    id,
                    ScenarioOutcome.COMPLETED,
                    context.inputs().equals(Map.of())
                            ? "FIXTURE_COMPLETED"
                            : "FIXTURE_INPUT_ACCEPTED");
        }
    }
}

