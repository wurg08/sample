package jp.co.mufg.e6.verifier.contract;

import static org.junit.jupiter.api.Assertions.assertEquals;

import jp.co.mufg.e6.verifier.app.VerifierApplication;
import org.junit.jupiter.api.Test;

class VerifierApplicationContractTest {

    @Test
    void validatesEmptyFormalRegistryWithoutExternalApiCall() {
        assertEquals(0, VerifierApplication.run(new String[]{"validate-registry"}));
    }

    @Test
    void returnsUsageExitCodeForUnsupportedCommand() {
        assertEquals(2, VerifierApplication.run(new String[]{"unsupported"}));
    }
}
