package jp.co.mufg.e6.verifier.contract;

import static org.junit.jupiter.api.Assertions.assertTrue;

import jp.co.mufg.e6.verifier.scenario.e6.E6ScenarioCatalog;
import org.junit.jupiter.api.Test;

class E6ScenarioCatalogContractTest {

    @Test
    void productionCatalogIsEmptyUntilFormalScenariosAreApproved() {
        assertTrue(E6ScenarioCatalog.empty().registrations().isEmpty());
    }
}

