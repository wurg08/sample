package jp.co.mufg.e6.verifier.verification;

public enum CheckOutcome {
    PASS,
    FAIL,
    NOT_EVALUATED
}

