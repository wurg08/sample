package jp.co.mufg.e6.verifier.verification;

@FunctionalInterface
public interface VerificationCheck<T> {

    CheckResult evaluate(T actual);
}

