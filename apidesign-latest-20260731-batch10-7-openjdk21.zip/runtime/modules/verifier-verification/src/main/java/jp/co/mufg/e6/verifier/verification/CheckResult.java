package jp.co.mufg.e6.verifier.verification;

import java.util.Objects;

public record CheckResult(
        String checkId,
        CheckOutcome outcome,
        String reasonCode) {

    public CheckResult {
        Objects.requireNonNull(checkId, "checkId");
        Objects.requireNonNull(outcome, "outcome");
        Objects.requireNonNull(reasonCode, "reasonCode");
        if (checkId.isBlank() || reasonCode.isBlank()) {
            throw new IllegalArgumentException(
                    "checkId and reasonCode must not be blank");
        }
    }
}

