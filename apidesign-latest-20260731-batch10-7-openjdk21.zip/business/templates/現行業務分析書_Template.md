---
title: 現行業務分析書 Template
document_id: E6-API-VAL-CURRENT-BUSINESS-ANALYSIS-TEMPLATE
version: 1.0.0-draft.1
status: DRAFT
document_type: Current Business Analysis Template
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# 現行業務分析書 Template

> 本Templateを`business/flows/{businessCode}/現行業務分析書.md`へ複製して使用する。  
> `<...>`はReview依頼前に事実、`TBD`または`NOT_APPLICABLE`へ置換する。架空例で補完してはならない。

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | `<業務正式名称> 現行業務分析書` |
| 文書ID | `<BA-E6-NNN>` |
| 分析作業ID | `<BA-WORK-01>` |
| Business ID候補 | `<BUS-E6-NNN / TBD>` |
| 対象システム | `<E6 / 関連System>` |
| 対象業務 | `<業務正式名称 / TBD>` |
| 対象版・基準日 | `<Version / YYYY-MM-DD>` |
| 版数 | `<1.0.0-draft.1>` |
| 文書状態 | `<DRAFT / REVIEW / APPROVED / FROZEN>` |
| 作成責任 | `<BA担当>` |
| レビュー責任 | `<BA Lead / API Owner>` |
| 承認責任 | `<Business Owner>` |
| 最終更新日 | `<YYYY-MM-DD>` |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 作成者 | Review状態 |
|---|---|---|---|---|
| `<1.0.0-draft.1>` | `<YYYY-MM-DD>` | `<初版作成>` | `<担当>` | `<DRAFT>` |

## 3. 分析目的・範囲

### 3.1 分析目的

`<本業務を分析する目的、検証Platformで確認したい業務結果、および後続成果物への利用目的を記載する。>`

### 3.2 対象範囲

| 分類 | 対象 | 開始点 | 終了点 | 確認状態 | 根拠Source ID |
|---|---|---|---|---|---|
| 業務 | `<対象業務>` | `<開始Event>` | `<終了状態>` | `<CONFIRMED等>` | `<SRC-001>` |
| System | `<対象System>` | `<境界>` | `<境界>` | `<CONFIRMED等>` | `<SRC-001>` |
| Data | `<対象Data>` | `<入力>` | `<出力／更新>` | `<CONFIRMED等>` | `<SRC-002>` |

### 3.3 対象外

| No. | 対象外 | 理由 | 正式な分析先 | 確認状態 |
|---:|---|---|---|---|
| 1 | `<対象外処理>` | `<理由>` | `<文書／Team / NONE>` | `<CONFIRMED等>` |

## 4. 根拠資料・調査記録

### 4.1 根拠資料

| Source ID | 資料名 | 種別 | 版数／基準日 | Reference | 対象範囲 | 確認状態 |
|---|---|---|---|---|---|---|
| `SRC-001` | `<資料名>` | `<要件／設計／Source／OpenAPI／Log>` | `<版数／日付>` | `<相対Path等>` | `<章・Class等>` | `<CONFIRMED等>` |

### 4.2 ヒアリング・観測

| Record ID | 日時 | 区分 | 確認先／Environment | 確認内容 | Evidence Ref | 確認状態 |
|---|---|---|---|---|---|---|
| `OBS-001` | `<YYYY-MM-DD>` | `<ヒアリング／実行観測／Source確認>` | `<役割／環境>` | `<内容>` | `<Mask済みEvidence>` | `<OBSERVED等>` |

### 4.3 根拠間Conflict

| Conflict ID | 対象 | Source A | Source B | 差異 | 暫定扱い | 解消先 | 状態 |
|---|---|---|---|---|---|---|---|
| `CONFLICT-001` | `<項目>` | `<SRC-001>` | `<SRC-002>` | `<差異>` | `<採用禁止等>` | `<Owner>` | `<Open / Closed>` |

## 5. 業務定義

### 5.1 業務概要

`<開始条件、主な処理、業務結果を300～800字程度で記載する。To-Be設計やJava実装は記載しない。>`

### 5.2 業務属性

| 項目 | 内容 | 確認状態 | 根拠Source ID |
|---|---|---|---|
| 業務正式名称 | `<名称>` | `<CONFIRMED等>` | `<SRC-001>` |
| 業務目的 | `<目的>` | `<CONFIRMED等>` | `<SRC-001>` |
| 業務分類候補 | `<INQUIRY / REGISTRATION / UPDATE / CANCELLATION / FILE / COMMON / OTHER>` | `<状態>` | `<SRC-001>` |
| 実行契機 | `<画面操作／Batch／Event／手動等>` | `<状態>` | `<SRC-001>` |
| 実行頻度 | `<随時／日次等>` | `<状態>` | `<SRC-001>` |
| 業務Owner | `<Role / TBD>` | `<状態>` | `<SRC-001>` |
| データ影響 | `<READ_ONLY / CREATE / UPDATE / DELETE / MIXED / UNKNOWN>` | `<状態>` | `<SRC-002>` |
| 再実行性 | `<SAFE / CONDITIONAL / UNSAFE / UNKNOWN>` | `<状態>` | `<SRC-002>` |

### 5.3 Actor

| Actor ID | Actor | 種別 | 責務 | 入力 | 受領結果 | 確認状態 |
|---|---|---|---|---|---|---|
| `ACT-001` | `<Actor名>` | `<USER / SYSTEM / BATCH / EXTERNAL>` | `<責務>` | `<入力>` | `<結果>` | `<CONFIRMED等>` |

### 5.4 業務前提

| Precondition ID | 前提条件 | 不成立時の扱い | 確認状態 | 根拠Source ID |
|---|---|---|---|---|
| `PRE-001` | `<開始前提>` | `<開始不可／別Flow等>` | `<CONFIRMED等>` | `<SRC-001>` |

### 5.5 業務終了状態

| End State ID | 終了状態 | 分類 | 業務結果 | データ状態 | 後続処理 | 確認状態 |
|---|---|---|---|---|---|---|
| `END-001` | `<正常終了>` | `NORMAL` | `<結果>` | `<更新後状態／変更なし>` | `<後続 / NONE>` | `<CONFIRMED等>` |
| `END-002` | `<代替終了>` | `ALTERNATIVE` | `<結果>` | `<状態>` | `<後続 / NONE>` | `<CONFIRMED等>` |
| `END-003` | `<異常終了>` | `EXCEPTION` | `<結果>` | `<結果不明を含む>` | `<Recovery等>` | `<CONFIRMED等>` |

## 6. 現行業務Flow

### 6.1 Flow図

```mermaid
flowchart TD
    S["START"]
    BF001["BF-001: 開始処理"]
    D001{"BR-001: 判定"}
    BF002["BF-002: 正常処理"]
    BF003["BF-003: 代替処理"]
    E1["END-001"]
    E2["END-002"]

    S --> BF001
    BF001 --> D001
    D001 -->|条件成立| BF002
    D001 -->|条件不成立| BF003
    BF002 --> E1
    BF003 --> E2
```

MermaidのNode ID、Step一覧の`Flow Step ID`および分岐一覧の`Branch ID`を一致させる。

### 6.2 Flow Step一覧

| 順序 | Flow Step ID | 処理名 | Actor | 処理概要 | 入力 | 出力 | 利用API | データ影響 | 次Step | 確認状態 | 根拠 |
|---:|---|---|---|---|---|---|---|---|---|---|---|
| 1 | `BF-001` | `<処理名>` | `<ACT-001>` | `<概要>` | `<入力>` | `<出力>` | `<API-NNN / NONE / TBD>` | `<READ等>` | `<BF-002 / BR-001 / END-001>` | `<状態>` | `<SRC-001>` |

### 6.3 分岐一覧

| Branch ID | 判定Step | 判定元 | 判定項目 | 条件 | 成立時 | 不成立時 | 未取得時 | 確認状態 | 根拠 |
|---|---|---|---|---|---|---|---|---|---|
| `BR-001` | `<BF-001>` | `<API Response／入力／状態>` | `<JSON Path／Flg等>` | `<条件>` | `<BF-002>` | `<BF-003>` | `<Error／UNKNOWN>` | `<状態>` | `<SRC-001>` |

### 6.4 Alternative／Exception Flow

| Flow ID | 分類 | 発生条件 | 開始Step | 実行Step | 終了状態 | 後続API Skip | 結果不明可能性 | 確認状態 |
|---|---|---|---|---|---|---|---|---|
| `AF-001` | `ALTERNATIVE` | `<条件>` | `<BF-...>` | `<BF-...>` | `<END-002>` | `<API-NNN / NONE>` | `<Yes / No>` | `<状態>` |
| `EF-001` | `EXCEPTION` | `<Timeout／Error等>` | `<BF-...>` | `<処理>` | `<END-003>` | `<API-NNN / NONE>` | `<Yes / No>` | `<状態>` |

### 6.5 処理Flg・状態遷移

| Rule ID | Flg／状態 | 変更前 | 条件 | 変更後 | 使用Step | 業務意味 | 確認状態 |
|---|---|---|---|---|---|---|---|
| `STATE-001` | `<処理Flg>` | `<Before>` | `<条件>` | `<After>` | `<BF-...>` | `<意味>` | `<状態>` |

## 7. 利用API分析

### 7.1 利用API一覧

| 順序 | API ID候補 | API名称 | 利用Step | 利用目的 | 呼出条件 | Request概要 | Response利用 | Data影響 | API分析書Ref | 確認状態 |
|---:|---|---|---|---|---|---|---|---|---|---|
| 1 | `<API-NNN / TBD>` | `<名称>` | `<BF-001>` | `<目的>` | `<条件>` | `<主要入力>` | `<主要出力／分岐>` | `<READ等>` | `<business/API分析書/... / TBD>` | `<状態>` |

### 7.2 API呼出Sequence

```mermaid
sequenceDiagram
    participant A as "Actor"
    participant V as "現行呼出元"
    participant P1 as "API候補1"
    participant P2 as "API候補2"

    A->>V: 業務開始
    V->>P1: Request
    P1-->>V: Response
    alt 分岐条件成立
        V->>P2: Request
        P2-->>V: Response
    else 分岐条件不成立
        V-->>A: 代替終了
    end
```

### 7.3 API呼出依存

| Dependency ID | 前段Step／API | 後段API | 受渡Data | 後段実行条件 | 前段失敗時 | 確認状態 |
|---|---|---|---|---|---|---|
| `DEP-001` | `<BF-001 / API-NNN>` | `<API-NNN>` | `<論理Data／JSON Path>` | `<条件>` | `<Skip／終了／Recovery>` | `<状態>` |

## 8. Data Flow

### 8.1 業務Data一覧

| Data ID | 論理名 | 業務Key | 生成元 | 利用先 | 更新有無 | Sensitive | 保存／保持 | 確認状態 |
|---|---|:---:|---|---|---|:---:|---|---|
| `DATA-001` | `<Data名>` | `<Yes / No>` | `<Actor／Step／API>` | `<Step／API>` | `<CREATE／UPDATE／NONE>` | `<Yes / No>` | `<現行仕様>` | `<状態>` |

### 8.2 Step間Data連携

| Mapping候補ID | 送信元Step／API | 送信元項目 | 送信先Step／API | 送信先項目 | 変換 | 必須 | 欠落時 | 確認状態 |
|---|---|---|---|---|---|:---:|---|---|
| `MAP-CAND-001` | `<Source>` | `<JSON Path／項目>` | `<Target>` | `<Parameter／JSON Path>` | `<NONE／内容>` | `<Yes / No>` | `<処理>` | `<状態>` |

本表はAs-Isの受渡事実を記録する。To-BeのJava Class、MethodまたはMapping式を確定しない。

## 9. 業務Rule・判定

### 9.1 業務Rule一覧

| Business Rule ID | Rule名 | 条件 | 処理／結果 | 対象Step | 優先度 | 確認状態 | 根拠 |
|---|---|---|---|---|---|---|---|
| `BRULE-001` | `<Rule名>` | `<条件>` | `<結果>` | `<BF-...>` | `<High等>` | `<状態>` | `<SRC-001>` |

### 9.2 Decision Table

| 条件／Action | Rule 1 | Rule 2 | Rule 3 |
|---|:---:|:---:|:---:|
| `<条件A>` | Y | Y | N |
| `<条件B>` | Y | N | `-` |
| `<Action A>` | X |  |  |
| `<Action B>` |  | X | X |
| 終了状態 | `<END-001>` | `<END-002>` | `<END-003>` |

`-`は判定不要を示す。空欄と意味を混同しない。

## 10. 検証観点候補

### 10.1 業務結果候補

| Candidate ID | 対象Flow／End State | 検証目的 | 観測対象 | 期待候補 | 重要度 | 後続反映先 | 確認状態 |
|---|---|---|---|---|---|---|---|
| `VER-CAND-001` | `<END-001>` | `<目的>` | `<API Response／状態等>` | `<業務期待>` | `<Critical等>` | `<UseCase／Verification>` | `<状態>` |

### 10.2 Request視点のScenario候補

| Candidate ID | 入口Request条件 | 業務経路 | 分岐 | 終了状態 | 必要Test Data | 備考 |
|---|---|---|---|---|---|---|
| `REQ-SC-CAND-001` | `<必須／境界／属性／値Pattern>` | `<PATH候補>` | `<BR-...>` | `<END-...>` | `<Data条件>` | `<正常／異常等>` |

Request項目の単純な全組合せを作成しない。業務経路、分岐または期待結果を変える同値Classと境界だけをScenario候補にする。

### 10.3 Error／Recovery観点

| Candidate ID | 発生点 | Error／Timeout | 更新有無 | 再実行可否 | 結果不明時の扱い | 後続反映先 | 確認状態 |
|---|---|---|---|---|---|---|---|
| `ERR-CAND-001` | `<BF/API>` | `<条件>` | `<Yes/No/Unknown>` | `<Safe/Conditional/Unsafe>` | `<Recovery／手動確認>` | `<Scenario／Framework>` | `<状態>` |

## 11. 非機能・運用上の現行制約

| Constraint ID | 分類 | 現行制約 | 影響 | 根拠 | 確認状態 |
|---|---|---|---|---|---|
| `CONS-001` | `<性能／時間帯／権限／データ／運用>` | `<制約>` | `<実行／検証への影響>` | `<SRC-001>` | `<状態>` |

## 12. 後続成果物への反映

| Handoff ID | 分析結果 | 反映先 | 反映内容 | 状態 | Reference／Issue |
|---|---|---|---|---|---|
| `HO-001` | `<業務Identity>` | Business Master | `<候補値>` | `<PENDING / REFLECTED>` | `<Ref>` |
| `HO-002` | `<API棚卸し>` | API Master／API分析 | `<候補>` | `<状態>` | `<Ref>` |
| `HO-003` | `<Flow／経路>` | BA×Scenario一覧／UseCase設計 | `<候補>` | `<状態>` | `<Ref>` |
| `HO-004` | `<検証観点>` | Verification設計 | `<候補>` | `<状態>` | `<Ref>` |

## 13. Traceability

| Trace ID | Source | Flow Step | API候補 | Rule | End State | Scenario候補 | 後続成果物 | 状態 |
|---|---|---|---|---|---|---|---|---|
| `TRACE-001` | `<SRC-001>` | `<BF-001>` | `<API-NNN>` | `<BRULE-001>` | `<END-001>` | `<SC-CAND-...>` | `<TBD>` | `<状態>` |

## 14. Open Issues

| Issue ID | 分類 | 確認事項 | 選択肢／Conflict | 影響 | 確認先 | 期限 | 状態 |
|---|---|---|---|---|---|---|---|
| `BA-ISSUE-001` | `<業務／API／Data等>` | `<確認事項>` | `<選択肢>` | `<影響>` | `<Owner>` | `<YYYY-MM-DD / TBD>` | `<Open / Closed>` |

## 15. Review Gate

| Gate ID | 確認内容 | 判定 | Evidence／Issue |
|---|---|---|---|
| `BA-GATE-001` | 開始点、終了点および対象外が明確 | `<PASS / BLOCKED / ERROR>` | `<Ref>` |
| `BA-GATE-002` | 全Step、分岐、Alternative／Exceptionが追跡可能 | `<判定>` | `<Ref>` |
| `BA-GATE-003` | API利用、Data Flow、更新影響が明確 | `<判定>` | `<Ref>` |
| `BA-GATE-004` | 事実、観測、推定、Conflict、Unknownを分離 | `<判定>` | `<Ref>` |
| `BA-GATE-005` | Scenario／Verification候補を後続へ引渡可能 | `<判定>` | `<Ref>` |
| `BA-GATE-006` | Secretおよび未Mask個人情報がない | `<判定>` | `<Ref>` |
| `BA-GATE-007` | Business Owner承認済み | `<判定>` | `<Ref>` |

## 16. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | As-Is業務、Flow、API利用、Data、Rule、Request視点Scenario候補およびTraceabilityを統合した初版Template。 |
