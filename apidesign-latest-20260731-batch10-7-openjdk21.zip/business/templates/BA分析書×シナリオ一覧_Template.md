---
title: BA分析書×シナリオ一覧 Template
document_id: E6-API-VAL-BA-SCENARIO-CANDIDATE-TEMPLATE
version: 1.0.0-draft.1
status: DRAFT
document_type: Business Flow Scenario Candidate Template
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# BA分析書×シナリオ一覧 Template

> 本Templateを`business/flows/{businessCode}/BA分析書×シナリオ一覧.md`へ複製して使用する。  
> 本書のScenarioはAs-Is分析から抽出する候補であり、正式`SC-E6-*`ではない。正式IDはUseCase／Scenario設計とMaster登録時に決定する。

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | `<業務正式名称> BA分析書×シナリオ一覧` |
| 文書ID | `<BA-SC-E6-NNN>` |
| 対象現行業務分析書 | `business/flows/<businessCode>/現行業務分析書.md` |
| 対象BA文書ID | `<BA-E6-NNN>` |
| Business ID候補 | `<BUS-E6-NNN / TBD>` |
| 対象版・基準日 | `<Version / YYYY-MM-DD>` |
| 版数 | `<1.0.0-draft.1>` |
| 文書状態 | `<DRAFT / REVIEW / APPROVED / FROZEN>` |
| 作成責任 | `<BA担当>` |
| レビュー責任 | `<BA Lead / API Owner / UseCase Designer>` |
| 承認責任 | `<Business Owner>` |
| 最終更新日 | `<YYYY-MM-DD>` |

## 2. 目的・責務

本書は、現行業務分析書で確認した業務Flowを、開始条件、分岐、処理Flg、API実行／Skip、終了状態および期待業務結果が同一となる経路へ整理し、UseCase／Scenario設計の入力となるScenario候補を定義する。

本書では次を確定しない。

| 確定しない情報 | 正式な確定先 |
|---|---|
| 正式Scenario ID、名称、`enabled` | Scenario Master |
| Java `executionClass`、API呼出実装 | Scenario詳細設計、Java |
| Scenario Input JSON | `system/04_usecase_design/input/` |
| Scenario Expected JSON | `system/04_usecase_design/expected/` |
| Check、Compare、Result集約 | Verification設計、Java |
| Runtime Retry、Recovery実装 | Framework設計、Java |

## 3. Input整合

| 確認項目 | 値 | 判定 | Evidence／Issue |
|---|---|---|---|
| 対象BA文書が存在 | `<Ref>` | `<PASS / ERROR>` | `<Ref>` |
| BA文書がReview可能状態 | `<Status>` | `<PASS / BLOCKED>` | `<Ref>` |
| Flow Step IDが一意 | `<件数>` | `<PASS / ERROR>` | `<Ref>` |
| 分岐と終了状態が識別可能 | `<件数>` | `<PASS / BLOCKED>` | `<Ref>` |
| 利用API候補が棚卸し済み | `<件数>` | `<PASS / BLOCKED>` | `<Ref>` |

## 4. Flow要約

### 4.1 Flow Step一覧

| Flow Step ID | 処理名 | API候補 | 分岐有無 | 処理Flg／状態 | 次Step | 到達可能なEnd State | 確認状態 |
|---|---|---|:---:|---|---|---|---|
| `<BF-001>` | `<処理名>` | `<API-NNN / NONE>` | `<Yes / No>` | `<Flg／状態>` | `<BF-002 / END-001>` | `<END-001等>` | `<CONFIRMED等>` |

### 4.2 分岐一覧

| Branch ID | 判定Step | 判定項目 | 条件Class | 条件 | 成立先 | 不成立先 | Unknown／Error先 | 確認状態 |
|---|---|---|---|---|---|---|---|---|
| `<BR-001>` | `<BF-001>` | `<JSON Path／Flg>` | `<BUSINESS / REQUEST / RESPONSE / ERROR / TIMEOUT>` | `<条件>` | `<BF/END>` | `<BF/END>` | `<BF/END>` | `<状態>` |

### 4.3 終了状態一覧

| End State ID | 分類 | 業務結果 | 最終API候補 | データ状態 | Result候補 | 確認状態 |
|---|---|---|---|---|---|---|
| `<END-001>` | `<NORMAL / ALTERNATIVE / EXCEPTION / UNKNOWN>` | `<結果>` | `<API-NNN / NONE>` | `<状態>` | `<PASS / WARN / FAIL / INCONCLUSIVE候補>` | `<状態>` |

`Result候補`は業務上の期待候補であり、Runtimeの最終Result規則ではない。

## 5. 経路抽出

### 5.1 経路一覧

| Path ID | 経路名 | 分類 | 開始条件 | 通過Step | 分岐条件 | Run API | Skip API | 終了状態 | データ影響 | 確認状態 |
|---|---|---|---|---|---|---|---|---|---|---|
| `PATH-001` | `<主正常経路>` | `NORMAL` | `<条件>` | `<BF-001 → BF-002>` | `<BR-001=...>` | `<API-...>` | `<NONE>` | `<END-001>` | `<READ等>` | `<状態>` |

### 5.2 到達不能・未確定経路

| Path ID | 起点 | 想定条件 | 到達不能／未確定理由 | 根拠 | 処置 | 状態 |
|---|---|---|---|---|---|---|
| `PATH-OPEN-001` | `<BF/BR>` | `<条件>` | `<理由>` | `<Source>` | `<Owner確認／除外>` | `<Open / Closed>` |

### 5.3 経路重複判定

| Candidate A | Candidate B | 開始条件差 | API経路差 | 終了状態差 | Expected差 | 判定 | 理由 |
|---|---|---|---|---|---|---|---|
| `<PATH-001>` | `<PATH-002>` | `<有無>` | `<有無>` | `<有無>` | `<有無>` | `<MERGE / KEEP_SEPARATE>` | `<理由>` |

開始値が異なるだけで経路、Checkおよび期待結果が同じ場合は、原則として1 Scenario候補内のInput Setとして扱う。境界値、Error再現またはデータ影響が異なる場合は分離理由を記載する。

## 6. Scenario候補

### 6.1 Scenario候補一覧

| Scenario候補ID | 候補名 | 種別候補 | 対象Path | 業務目的 | 開始条件 | Entry Request条件 | 終了状態 | API Call数 | Test Data条件 | 優先度 | 確認状態 |
|---|---|---|---|---|---|---|---|---:|---|---|---|
| `SC-CAND-001` | `<名称>` | `<NORMAL / ALTERNATIVE / EXCEPTION / BOUNDARY / TIMEOUT>` | `<PATH-001>` | `<何を確認するか>` | `<前提>` | `<Request同値Class／境界>` | `<END-001>` | `<N>` | `<条件>` | `<Critical等>` | `<状態>` |

### 6.2 Scenario分離基準

別Scenario候補とするのは、少なくとも次の一つが異なる場合とする。

1. 到達する業務終了状態。
2. APIの実行／Skip経路。
3. 業務上意味のある分岐条件または処理Flg。
4. 更新、取消、重複登録または再実行のデータ影響。
5. 期待する業務Errorまたは技術Error。
6. Timeout後の結果確定性またはRecovery要求。
7. Request境界により期待するContract／業務結果が変わる。

単なる表示順、毎回変動する値または同一経路内の任意Sample差だけでScenarioを増やさない。

## 7. Scenario候補別API実行

| Scenario候補ID | Call順 | Flow Step | API候補 | 実行条件 | Skip条件 | Request入力元 | Response利用先 | Error時 | 確認状態 |
|---|---:|---|---|---|---|---|---|---|---|
| `SC-CAND-001` | 1 | `<BF-001>` | `<API-NNN>` | `<条件>` | `<NONE／条件>` | `<Entry／前段API>` | `<分岐／後段API／期待結果>` | `<END／Recovery>` | `<状態>` |

### 7.1 API実行Matrix

| API／Step | `SC-CAND-001` | `SC-CAND-002` | `SC-CAND-003` |
|---|:---:|:---:|:---:|
| `<API-NNN / BF-001>` | `RUN` | `RUN` | `SKIP` |
| `<API-NNN / BF-002>` | `RUN` | `SKIP` | `NOT_REACHED` |
| 終了状態 | `<END-001>` | `<END-002>` | `<END-003>` |

`SKIP`は経路上に存在するが条件により実行しないこと、`NOT_REACHED`は前段終了によりStepへ到達しないことを示す。

## 8. 分岐・Skip Rule候補

| Rule候補ID | 対象Scenario候補 | 発生点 | 判定元 | 条件 | Action | 対象API／Step | 終了状態 | 確認状態 |
|---|---|---|---|---|---|---|---|---|
| `SKIP-CAND-001` | `<SC-CAND-...>` | `<BF/API>` | `<Response／Flg>` | `<条件>` | `<SKIP / STOP / CONTINUE>` | `<API/BF>` | `<END-...>` | `<状態>` |

本表はAs-Isの経路候補であり、Javaの条件式または外部実行Policyではない。

## 9. Request視点のInput候補

### 9.1 Entry Input候補

| Input候補ID | Scenario候補ID | 論理項目 | 入力位置 | 同値Class／境界 | 必須 | Null | 空文字 | 期待経路 | Test Data Source | 確認状態 |
|---|---|---|---|---|:---:|:---:|:---:|---|---|---|
| `INPUT-CAND-001` | `<SC-CAND-001>` | `<項目>` | `<Header／Path／Query／Body JSON Path>` | `<Valid／Min／Max／Invalid等>` | `<Yes/No>` | `<可否>` | `<可否>` | `<PATH-001>` | `<Source/TBD>` | `<状態>` |

### 9.2 入力組合せ制約

| Constraint ID | 対象項目 | 条件 | 許可／禁止 | 期待経路 | 確認状態 |
|---|---|---|---|---|---|
| `INPUT-CONS-001` | `<項目A, B>` | `<組合せ条件>` | `<ALLOW / REJECT>` | `<PATH/END>` | `<状態>` |

## 10. Expected候補

### 10.1 業務Expected候補

| Expected候補ID | Scenario候補ID | Result Key候補 | 対象 | 期待内容 | Severity候補 | 根拠 | 確認状態 |
|---|---|---|---|---|---|---|---|
| `EXP-CAND-001` | `<SC-CAND-001>` | `<業務結果Key>` | `<End State／Data状態>` | `<期待>` | `<CRITICAL等>` | `<Source>` | `<状態>` |

### 10.2 API／Field Check候補

| Check候補ID | Scenario候補ID | API候補 | 対象Path | 観点候補 | 期待候補 | 値無視時の構造Check | 根拠 | 確認状態 |
|---|---|---|---|---|---|---|---|---|
| `CHK-CAND-001` | `<SC-CAND-001>` | `<API-NNN>` | `<$.field>` | `<PRESENCE / TYPE / NOT_NULL / FIXED_VALUE / ENUM / REQUEST_MATCH / IGNORE_VALUE等>` | `<値／条件>` | `<存在:Yes, 型:Yes, Null:No等>` | `<Source>` | `<状態>` |

`IGNORE_VALUE`は項目全体を無条件で無視する意味ではない。存在、型、Null、空文字、Object／Array構造および子項目のCheck要否を個別に示す。

### 10.3 Error／Timeout Expected候補

| Expected候補ID | Scenario候補ID | 発生点 | HTTP／Error候補 | 業務結果 | 後続API | データ状態 | Recovery要否 | 確認状態 |
|---|---|---|---|---|---|---|---|---|
| `ERR-EXP-CAND-001` | `<SC-CAND-...>` | `<API/BF>` | `<Status/Code>` | `<期待>` | `<Skip/Stop>` | `<変更なし／結果不明>` | `<Yes/No/TBD>` | `<状態>` |

## 11. Coverage

### 11.1 Branch Coverage

| Branch ID | 条件区分 | 対応Path | 対応Scenario候補 | Coverage | Gap／理由 |
|---|---|---|---|---|---|
| `<BR-001>` | `<成立>` | `<PATH-001>` | `<SC-CAND-001>` | `<COVERED / GAP / EXCLUDED>` | `<理由>` |
| `<BR-001>` | `<不成立>` | `<PATH-002>` | `<SC-CAND-002>` | `<状態>` | `<理由>` |
| `<BR-001>` | `<Unknown／Error>` | `<PATH-003>` | `<SC-CAND-003>` | `<状態>` | `<理由>` |

### 11.2 End State Coverage

| End State ID | 対応Path | 対応Scenario候補 | Coverage | 承認除外理由 |
|---|---|---|---|---|
| `<END-001>` | `<PATH-001>` | `<SC-CAND-001>` | `<COVERED等>` | `<NONE／理由>` |

### 11.3 API Coverage

| API候補 | 利用Flow | 対応Scenario候補 | 正常 | 業務Error | 技術Error | Timeout | Gap |
|---|---|---|:---:|:---:|:---:|:---:|---|
| `<API-NNN>` | `<BF-...>` | `<SC-CAND-...>` | `<Yes/No>` | `<Yes/No>` | `<Yes/No>` | `<Yes/No>` | `<内容>` |

## 12. 正式設計へのHandoff

| Handoff ID | Scenario候補ID | UseCase候補 | 正式Scenario ID | Input作成 | Expected作成 | Java実装 | 状態 | Issue |
|---|---|---|---|---|---|---|---|---|
| `SC-HO-001` | `<SC-CAND-001>` | `<UC候補/TBD>` | `TBD` | `<Required>` | `<Required>` | `<Required>` | `<PENDING / ACCEPTED / REJECTED>` | `<Issue>` |

正式Scenario IDを採番した場合、候補IDを削除せずHandoff Traceとして保持する。

## 13. Traceability

| Trace ID | BA Source | Flow Step | Branch | Path | Scenario候補 | API候補 | Input候補 | Expected候補 | 正式設計 |
|---|---|---|---|---|---|---|---|---|---|
| `SC-TRACE-001` | `<BA文書ID>` | `<BF-001>` | `<BR-001>` | `<PATH-001>` | `<SC-CAND-001>` | `<API-NNN>` | `<INPUT-CAND-001>` | `<EXP-CAND-001>` | `<TBD>` |

## 14. Open Issues

| Issue ID | 分類 | 確認事項 | 影響Scenario候補 | 影響 | 確認先 | 状態 |
|---|---|---|---|---|---|---|
| `BA-SC-ISSUE-001` | `<分岐／Result／Data等>` | `<確認事項>` | `<SC-CAND-...>` | `<影響>` | `<Owner>` | `<Open / Closed>` |

## 15. Review Gate

| Gate ID | 確認内容 | 判定 | Evidence／Issue |
|---|---|---|---|
| `BA-SC-GATE-001` | 全到達可能PathとEnd Stateを識別 | `<PASS / BLOCKED / ERROR>` | `<Ref>` |
| `BA-SC-GATE-002` | Branch成立／不成立／ErrorのCoverageを確認 | `<判定>` | `<Ref>` |
| `BA-SC-GATE-003` | Scenario重複と過剰分割を排除 | `<判定>` | `<Ref>` |
| `BA-SC-GATE-004` | API Run／Skip／Not Reachedが一意 | `<判定>` | `<Ref>` |
| `BA-SC-GATE-005` | Request視点InputとExpected候補を引渡可能 | `<判定>` | `<Ref>` |
| `BA-SC-GATE-006` | 正式Scenario IDを先行採番していない | `<判定>` | `<Ref>` |
| `BA-SC-GATE-007` | Business OwnerとUseCase DesignerがReview済み | `<判定>` | `<Ref>` |

## 16. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | Flow経路、Scenario候補、Request視点Input、Expected候補およびCoverageを統合した初版Template。 |
