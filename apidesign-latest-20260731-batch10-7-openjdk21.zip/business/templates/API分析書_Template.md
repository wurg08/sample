---
title: API分析書 Template
document_id: E6-API-VAL-API-ANALYSIS-TEMPLATE
version: 1.0.0-draft.1
status: DRAFT
document_type: Current API Analysis Template
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# API分析書 Template

> 本Templateを`business/API分析書/API-{NNN}分析書.md`へ複製して使用する。  
> 本書は現行APIのAs-Is分析であり、`system/03_api_design/API-{NNN}設計書.md`の代替ではない。`<...>`を事実、`TBD`または`NOT_APPLICABLE`へ置換する。

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | `<API正式名称> API分析書` |
| 文書ID | `<API-ANL-E6-NNN>` |
| API ID候補 | `<API-NNN / TBD>` |
| 対象System | `<E6／Provider System>` |
| 対象版・基準日 | `<Version / YYYY-MM-DD>` |
| 関連Business候補 | `<BUS-E6-NNN / BA文書ID / TBD>` |
| 版数 | `<1.0.0-draft.1>` |
| 文書状態 | `<DRAFT / REVIEW / APPROVED / FROZEN>` |
| 作成責任 | `<API分析担当>` |
| レビュー責任 | `<API Owner / BA Lead / Runtime Lead>` |
| 承認責任 | `<API Owner / System Owner>` |
| 最終更新日 | `<YYYY-MM-DD>` |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 作成者 | Review状態 |
|---|---|---|---|---|
| `<1.0.0-draft.1>` | `<YYYY-MM-DD>` | `<初版作成>` | `<担当>` | `<DRAFT>` |

## 3. 分析目的・状態

### 3.1 分析目的

`<本APIの現行Interface、業務利用、Request／Response、Error、依存、データ影響および検証候補を明らかにする目的を記載する。>`

### 3.2 分析状態

| 分析項目 | 状態 | 根拠／Issue |
|---|---|---|
| 業務利用位置 | `<NOT_STARTED / IN_PROGRESS / CONFIRMED / BLOCKED>` | `<Ref>` |
| Method／Endpoint | `<状態>` | `<Ref>` |
| 認証／Header | `<状態>` | `<Ref>` |
| Request | `<状態>` | `<Ref>` |
| Response | `<状態>` | `<Ref>` |
| Error／HTTP Status | `<状態>` | `<Ref>` |
| 実API観測 | `<状態>` | `<Ref>` |
| 後続設計反映 | `<PENDING / IN_PROGRESS / REFLECTED>` | `<Ref>` |

## 4. 根拠資料・観測

### 4.1 根拠資料

| Source ID | 資料名 | 種別 | 版数／Commit／日付 | Reference | 対象範囲 | 確認状態 |
|---|---|---|---|---|---|---|
| `SRC-001` | `<資料名>` | `<OpenAPI／Postman／設計／Source／Log>` | `<識別子>` | `<Ref>` | `<対象>` | `<CONFIRMED等>` |

### 4.2 実API観測

| Observation ID | 日時 | Environment | 入力条件 | HTTP Status | 結果概要 | Evidence Ref | Mask確認 | 確認状態 |
|---|---|---|---|---:|---|---|---|---|
| `API-OBS-001` | `<YYYY-MM-DDThh:mm:ss+09:00>` | `<Environment ID>` | `<Mask済み条件>` | `<200>` | `<概要>` | `<Ref>` | `<PASS>` | `<OBSERVED>` |

実API観測のRequest／ResponseにはSecret、Tokenまたは未Maskの個人・業務データを保存しない。

### 4.3 根拠Conflict

| Conflict ID | 対象 | Source A | Source B | 差異 | 採用可否 | 解消先 | 状態 |
|---|---|---|---|---|---|---|---|
| `API-CONFLICT-001` | `<Method／Field等>` | `<SRC-001>` | `<SRC-002>` | `<差異>` | `<採用禁止／暫定>` | `<Owner>` | `<Open / Closed>` |

## 5. API概要

| 項目 | 現行確認結果 | 確認状態 | 根拠 |
|---|---|---|---|
| API名称 | `<正式名称>` | `<CONFIRMED等>` | `<SRC-001>` |
| Provider | `<System／Component>` | `<状態>` | `<Source>` |
| Consumer | `<System／業務>` | `<状態>` | `<Source>` |
| 業務目的 | `<取得／登録／更新等>` | `<状態>` | `<Source>` |
| API分類 | `<INQUIRY / CREATE / UPDATE / DELETE / FILE / OTHER>` | `<状態>` | `<Source>` |
| 同期方式 | `<SYNCHRONOUS / ASYNCHRONOUS / UNKNOWN>` | `<状態>` | `<Source>` |
| 冪等性 | `<IDEMPOTENT / NON_IDEMPOTENT / CONDITIONAL / UNKNOWN>` | `<状態>` | `<Source>` |
| データ影響 | `<READ_ONLY / CREATE / UPDATE / DELETE / MIXED / UNKNOWN>` | `<状態>` | `<Source>` |
| 日次検証候補 | `<Yes / No / TBD>` | `<状態>` | `<Source>` |
| 重要度候補 | `<Critical / High / Medium / Low / TBD>` | `<状態>` | `<Source>` |

## 6. 業務利用位置

| 利用ID | BA文書 | Flow Step | 利用目的 | 前提API | 後続API | 分岐利用 | 終了API候補 | 確認状態 |
|---|---|---|---|---|---|---|---|---|
| `API-USE-001` | `<BA文書ID／Ref>` | `<BF-001>` | `<目的>` | `<API-NNN / NONE>` | `<API-NNN / NONE>` | `<BR-001 / NONE>` | `<Yes / No>` | `<状態>` |

## 7. Endpoint・Protocol

| 項目 | 現行確認結果 | 確認状態 | 根拠 | 備考 |
|---|---|---|---|---|
| Scheme | `<HTTPS / HTTP / UNKNOWN>` | `<状態>` | `<Source>` | `<備考>` |
| HTTP Method | `<GET / POST / PUT / PATCH / DELETE / UNKNOWN>` | `<状態>` | `<Source>` | `<備考>` |
| Endpoint Path | `</api/... / TBD>` | `<状態>` | `<Source>` | Hostを含めない |
| Content-Type | `<application/json等>` | `<状態>` | `<Source>` | `<備考>` |
| Accept | `<application/json等>` | `<状態>` | `<Source>` | `<備考>` |
| Character Set | `<UTF-8等>` | `<状態>` | `<Source>` | `<備考>` |
| Timeout観測値 | `<duration / UNKNOWN>` | `<状態>` | `<Source>` | To-Be値ではない |
| Payload上限 | `<値 / UNKNOWN>` | `<状態>` | `<Source>` | `<備考>` |

Environment別Base URLはEnvironment Master候補または設定へ引き渡し、本書へCredential実値を記載しない。

## 8. Header・認証・認可

### 8.1 Header

| No. | Header名 | 必須 | 形式 | 設定元 | Sensitive | 値保存 | 確認状態 | 根拠 |
|---:|---|:---:|---|---|:---:|---|---|---|
| 1 | `<Header>` | `<Yes / No / Unknown>` | `<形式>` | `<Caller／Auth等>` | `<Yes/No>` | `<禁止／Mask／可>` | `<状態>` | `<Source>` |

### 8.2 認証・認可

| 項目 | 現行確認結果 | 確認状態 | 根拠 |
|---|---|---|---|
| 認証方式 | `<Bearer／API Key／mTLS／NONE／UNKNOWN>` | `<状態>` | `<Source>` |
| Token取得 | `<論理方式。実値禁止>` | `<状態>` | `<Source>` |
| 必要権限 | `<Scope／Role／UNKNOWN>` | `<状態>` | `<Source>` |
| 認証失敗Status | `<401／403等>` | `<状態>` | `<Source>` |
| Credential管理 | `<Secret Store等／UNKNOWN>` | `<状態>` | `<Source>` |

## 9. Request概要

| 項目 | 現行確認結果 | 確認状態 | 根拠 |
|---|---|---|---|
| 形式 | `<JSON / QUERY / PATH / FORM / MULTIPART / NONE>` | `<状態>` | `<Source>` |
| Root型 | `<OBJECT / ARRAY / NONE / UNKNOWN>` | `<状態>` | `<Source>` |
| 必須項目数 | `<N / UNKNOWN>` | `<状態>` | `<Source>` |
| 任意項目数 | `<N / UNKNOWN>` | `<状態>` | `<Source>` |
| Unknown Field | `<REJECT / IGNORE / UNKNOWN>` | `<状態>` | `<Source>` |
| 空Body | `<ALLOW / REJECT / NOT_APPLICABLE / UNKNOWN>` | `<状態>` | `<Source>` |

## 10. Request項目分析

| No. | Location | JSON Path／Parameter | 論理名 | JSON型 | Format | 必須 | 存在 | Null | 空文字 | 長さ／桁 | Pattern | Enum／固定値 | Default | Sensitive | 確認状態 | 根拠 |
|---:|---|---|---|---|---|:---:|---|---|---|---|---|---|---|:---:|---|---|
| 1 | `<HEADER/PATH/QUERY/BODY>` | `<$.field>` | `<論理名>` | `<STRING等>` | `<date等/NONE>` | `<Yes/No/Unknown>` | `<条件>` | `<Allow/Reject/Unknown>` | `<Allow/Reject/NA>` | `<min..max>` | `<regex/NONE>` | `<値/NONE>` | `<値/NONE>` | `<Yes/No>` | `<状態>` | `<Source>` |

### 10.1 Request項目の分析規則

1. `必須`、JSON上の`存在`、`Null`およびStringの`空文字`を別々に確認する。
2. JSON型、Format、長さ、数値桁、Scale、Pattern、Enumおよび固定値を混同しない。
3. Object／ArrayはContainerと子項目を別行で追跡できるようにする。
4. 条件付き必須は条件を明示し、単純な`Yes`へ丸めない。
5. 未確認値を一般的なAPI慣習で補完しない。

### 10.2 Request Sample

```json
{
  "exampleField": "MASKED-EXAMPLE"
}
```

Sampleは架空またはMask済みとし、正式仕様は10章の項目表で判断する。

### 10.3 Request組合せ・相関

| Rule候補ID | 対象項目 | 条件 | 許可／拒否 | 現行動作 | 検証候補 | 確認状態 |
|---|---|---|---|---|---|---|
| `REQ-RULE-CAND-001` | `<fieldA, fieldB>` | `<条件>` | `<ALLOW / REJECT>` | `<動作>` | `<Test候補>` | `<状態>` |

## 11. Response概要

| 項目 | 現行確認結果 | 確認状態 | 根拠 |
|---|---|---|---|
| 形式 | `<JSON / XML / FILE / BINARY / NONE>` | `<状態>` | `<Source>` |
| Root型 | `<OBJECT / ARRAY / NONE / UNKNOWN>` | `<状態>` | `<Source>` |
| 正常HTTP Status | `<200等>` | `<状態>` | `<Source>` |
| 空Body | `<ALLOW / REJECT / NOT_APPLICABLE / UNKNOWN>` | `<状態>` | `<Source>` |
| Dynamic項目 | `<Yes / No / Unknown>` | `<状態>` | `<Source>` |
| 項目追加互換性 | `<許容／拒否／Unknown>` | `<状態>` | `<Source>` |

## 12. Response項目分析

| No. | JSON Path | 論理名 | JSON型 | Format | 必須 | 存在条件 | Null | 空文字 | 長さ／桁 | Enum／固定値 | Request一致 | Dynamic | Collection Key | Sensitive | 業務利用 | 確認状態 | 根拠 |
|---:|---|---|---|---|:---:|---|---|---|---|---|---|:---:|---|:---:|---|---|---|
| 1 | `<$.field>` | `<論理名>` | `<STRING等>` | `<date等/NONE>` | `<Yes/No/Unknown>` | `<常時／条件>` | `<Allow/Reject>` | `<Allow/Reject/NA>` | `<min..max>` | `<値/NONE>` | `<Request Path/NONE>` | `<Yes/No>` | `<Key/NONE>` | `<Yes/No>` | `<分岐／表示／後続等>` | `<状態>` | `<Source>` |

### 12.1 Response項目増減

| 変更観点 | 現行Consumer動作 | Verification候補 | 互換性候補 | 確認状態 | 根拠 |
|---|---|---|---|---|---|
| 未知項目追加 | `<Ignore／Error／Unknown>` | `<Detect／Allow／Report Only>` | `<Compatible等>` | `<状態>` | `<Source>` |
| 任意項目欠落 | `<動作>` | `<Presence条件>` | `<候補>` | `<状態>` | `<Source>` |
| 必須項目欠落 | `<動作>` | `<ERROR候補>` | `<Incompatible候補>` | `<状態>` | `<Source>` |
| Null化 | `<動作>` | `<Null Check候補>` | `<候補>` | `<状態>` | `<Source>` |
| 型変更 | `<動作>` | `<Type Check候補>` | `<Incompatible候補>` | `<状態>` | `<Source>` |

### 12.2 Dynamic項目

| Candidate ID | JSON Path | 変動理由 | 値比較候補 | 存在Check | 型Check | Null／空文字Check | Format／範囲Check | 確認状態 |
|---|---|---|---|:---:|:---:|---|---|---|
| `DYN-CAND-001` | `<$.traceId>` | `<実行毎採番等>` | `<IGNORE_VALUE / PATTERN / EXISTS等>` | `<Yes/No>` | `<Yes/No>` | `<内容>` | `<内容>` | `<状態>` |

`IGNORE_VALUE`を選んでも、項目の存在、型、Null、空文字、Formatおよび子構造まで自動的に無視しない。必要なCheckを各列で明示する。

### 12.3 Collection

| Candidate ID | JSON Path | Element型 | 最小／最大件数 | 順序意味 | Match Key候補 | 重複許可 | Null Element | 比較候補 | 確認状態 |
|---|---|---|---|---|---|---|---|---|---|
| `COL-CAND-001` | `<$.items>` | `<OBJECT等>` | `<0..N>` | `<有／無／Unknown>` | `<$.id / NONE>` | `<Yes/No/Unknown>` | `<Allow/Reject>` | `<ORDERED / UNORDERED_KEYED / SIZE_ONLY等>` | `<状態>` |

### 12.4 Response Sample

```json
{
  "exampleField": "MASKED-EXAMPLE",
  "traceId": "00000000-0000-0000-0000-000000000000"
}
```

## 13. HTTP Status・Error分析

### 13.1 Status一覧

| No. | HTTP Status | 業務／技術分類 | 発生条件 | Body形式 | Error Code | 再実行候補 | 後続API | 確認状態 | 根拠 |
|---:|---:|---|---|---|---|---|---|---|---|
| 1 | `<200>` | `<SUCCESS>` | `<条件>` | `<形式>` | `<NONE>` | `<NA>` | `<Continue>` | `<状態>` | `<Source>` |
| 2 | `<400>` | `<CONTRACT／BUSINESS>` | `<条件>` | `<形式>` | `<Code>` | `<No>` | `<Stop／Skip>` | `<状態>` | `<Source>` |

### 13.2 Error項目

| JSON Path | 論理名 | JSON型 | 必須 | Null | Dynamic | Sensitive | 業務利用 | 確認状態 | 根拠 |
|---|---|---|:---:|---|:---:|:---:|---|---|---|
| `<$.error.code>` | `<Error Code>` | `<STRING>` | `<Yes>` | `<Reject>` | `<No>` | `<No>` | `<分岐／Report>` | `<状態>` | `<Source>` |

### 13.3 Timeout・通信異常

| 異常 | 現行動作 | Provider処理継続可能性 | データ結果確定性 | 自動再送安全性 | Recovery候補 | 確認状態 |
|---|---|---|---|---|---|---|
| `<Timeout>` | `<動作>` | `<Yes/No/Unknown>` | `<確定／不明>` | `<Safe/Unsafe/Unknown>` | `<手動確認等>` | `<状態>` |

Timeoutを一律にRetry可能と判断しない。更新APIで結果が不明な場合は、重複更新を防ぐRecovery観点を後続設計へ引き渡す。

## 14. API依存・Sequence

### 14.1 前提・後続API

| Dependency ID | 関係 | API候補 | 受渡Data | 条件 | 本API失敗時 | 確認状態 | 根拠 |
|---|---|---|---|---|---|---|---|
| `API-DEP-001` | `<PREDECESSOR / SUCCESSOR>` | `<API-NNN>` | `<Data／JSON Path>` | `<条件>` | `<Skip／Stop等>` | `<状態>` | `<Source>` |

### 14.2 Data Mapping候補

| Mapping候補ID | Source API／Input | Source Path | Target API | Target Path | 変換 | 必須 | 欠落時 | 確認状態 |
|---|---|---|---|---|---|:---:|---|---|
| `API-MAP-CAND-001` | `<Entry/API-NNN>` | `<$.field>` | `<API-NNN>` | `<$.field>` | `<NONE／内容>` | `<Yes/No>` | `<処理>` | `<状態>` |

本表は現行連携事実の候補を示す。To-Be Java MappingはScenario詳細設計とJavaで確定する。

## 15. データ影響・再実行

| 観点 | 現行確認結果 | 確認状態 | 根拠 |
|---|---|---|---|
| 更新対象 | `<Entity／NONE／UNKNOWN>` | `<状態>` | `<Source>` |
| Commit契機 | `<同期完了前後／UNKNOWN>` | `<状態>` | `<Source>` |
| 冪等Key | `<論理項目／NONE／UNKNOWN>` | `<状態>` | `<Source>` |
| 同一Request再送 | `<同一結果／重複／Error／UNKNOWN>` | `<状態>` | `<Source>` |
| Cleanup／Rollback | `<方式／NONE／UNKNOWN>` | `<状態>` | `<Source>` |
| 日次実行Data影響 | `<許容／条件付き／禁止／UNKNOWN>` | `<状態>` | `<Source>` |

## 16. Verification候補

### 16.1 Request Check候補

| Check候補ID | 対象 | 観点 | 条件／期待 | Severity候補 | 後続反映 | 確認状態 |
|---|---|---|---|---|---|---|
| `REQ-CHK-CAND-001` | `<Path>` | `<PRESENCE / TYPE / NOT_NULL / NOT_BLANK / LENGTH / FORMAT / ENUM / FIXED_VALUE / RANGE / CORRELATION>` | `<内容>` | `<Critical等>` | `<API設計／Verification>` | `<状態>` |

### 16.2 Response Check候補

| Check候補ID | 対象Path | 観点 | 値期待候補 | 値比較 | 存在 | 型 | Null／空 | 構造／子項目 | Severity候補 | 確認状態 |
|---|---|---|---|---|---|---|---|---|---|---|
| `RES-CHK-CAND-001` | `<$.field>` | `<業務目的>` | `<値／条件／NONE>` | `<EXACT / ENUM / REQUEST_MATCH / FORMAT / RANGE / IGNORE_VALUE / CUSTOM候補>` | `<必須／条件付き／不要>` | `<型>` | `<条件>` | `<Check内容>` | `<Critical等>` | `<状態>` |

### 16.3 Diff候補

| Diff候補ID | 対象Path | Current内Check | Previous比較候補 | Baseline比較候補 | 項目追加 | 項目欠落 | Collection | 理由 | 確認状態 |
|---|---|---|---|---|---|---|---|---|---|
| `DIFF-CAND-001` | `<$.field>` | `<Presence/Type等>` | `<EXACT / IGNORE_VALUE / NONE等>` | `<候補>` | `<ALLOW/DETECT>` | `<ALLOW/ERROR>` | `<方式>` | `<理由>` | `<状態>` |

### 16.4 比較候補の責務

本章は分析結果から検証候補を提示するだけであり、外部Compare PolicyまたはRuntime実行規則ではない。最終的なCheck、Compare Definition、SeverityおよびResult集約は次で確定する。

- API詳細設計
- Scenario詳細設計
- Scenario Expected
- Verification仕様
- API Response Diff設計
- Java Check／Comparator

## 17. 非機能・Security観点

| Candidate ID | 分類 | 現行観測／要求 | 測定条件 | 後続反映先 | 確認状態 |
|---|---|---|---|---|---|
| `NFR-CAND-001` | `<性能／Availability／Rate Limit／Security／Mask>` | `<内容>` | `<条件>` | `<API設計／Framework>` | `<状態>` |

## 18. 後続成果物への反映

| Handoff ID | 分析項目 | 反映先 | 反映内容 | 状態 | Reference／Issue |
|---|---|---|---|---|---|
| `API-HO-001` | `<固定Identity／Method／Path>` | API Master | `<候補値>` | `<PENDING / REFLECTED>` | `<Ref>` |
| `API-HO-002` | `<Request／Response>` | API詳細設計 | `<内容>` | `<状態>` | `<Ref>` |
| `API-HO-003` | `<依存／Mapping>` | Scenario設計／Java | `<内容>` | `<状態>` | `<Ref>` |
| `API-HO-004` | `<Check／Diff候補>` | Verification設計／Java | `<内容>` | `<状態>` | `<Ref>` |
| `API-HO-005` | `<環境／認証Profile>` | Environment Master／設定 | `<論理参照>` | `<状態>` | `<Ref>` |

## 19. Traceability

| Trace ID | Source | BA／Flow | API候補 | Request／Response | Error／Rule | Verification候補 | 後続成果物 | 状態 |
|---|---|---|---|---|---|---|---|---|
| `API-TRACE-001` | `<SRC-001>` | `<BA/BF>` | `<API-NNN>` | `<Path>` | `<Status/Rule>` | `<Candidate ID>` | `<TBD>` | `<状態>` |

## 20. Open Issues

| Issue ID | 分類 | 確認事項 | Conflict／選択肢 | 影響 | 確認先 | 優先度 | 状態 |
|---|---|---|---|---|---|---|---|
| `API-ANL-ISSUE-001` | `<Request／Response／Error等>` | `<確認事項>` | `<内容>` | `<影響>` | `<API Owner>` | `<High等>` | `<Open / Closed>` |

## 21. Review Gate

| Gate ID | 確認内容 | 判定 | Evidence／Issue |
|---|---|---|---|
| `API-ANL-GATE-001` | 業務利用位置とAPI Identity候補が明確 | `<PASS / BLOCKED / ERROR>` | `<Ref>` |
| `API-ANL-GATE-002` | Method、Path、Header、認証が根拠付き | `<判定>` | `<Ref>` |
| `API-ANL-GATE-003` | Request／Responseの存在・型・Null・値制約を分離 | `<判定>` | `<Ref>` |
| `API-ANL-GATE-004` | Error、Timeout、データ影響、再実行性を確認 | `<判定>` | `<Ref>` |
| `API-ANL-GATE-005` | Dynamic、Collection、項目増減、値無視時Checkを定義 | `<判定>` | `<Ref>` |
| `API-ANL-GATE-006` | 根拠ConflictとUnknownを未解消のまま確定していない | `<判定>` | `<Ref>` |
| `API-ANL-GATE-007` | Secret／未Maskデータがない | `<判定>` | `<Ref>` |
| `API-ANL-GATE-008` | API Owner承認済み | `<判定>` | `<Ref>` |

## 22. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | As-Is API、Request／Response、項目増減、Dynamic、Collection、Error、依存、再実行およびVerification候補を統合した初版Template。 |
