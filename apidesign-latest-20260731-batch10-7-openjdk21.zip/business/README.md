---
title: Business Analysis Domain
document_id: E6-API-VAL-BUSINESS-README
version: 1.0.0-draft.1
status: DRAFT
document_type: Business Analysis Governance
system_name: E6 API Verification Platform
updated: 2026-07-27
---

# Business Analysis Domain

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Business Analysis Domain README |
| 文書ID | `E6-API-VAL-BUSINESS-README` |
| 対象範囲 | `business/` |
| 文書種別 | 現行業務・現行API分析の運用規約 |
| 版数 | `1.0.0-draft.1` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-27 |
| 作成責任 | Business Analysis Team |
| レビュー責任 | BA Lead / API Owner / System Architect |
| 承認責任 | Business Owner / System Owner |

## 2. 目的

`business/`は、E6 API Verification Platformが対象とする現行業務Flowおよび現行APIの調査結果を、根拠資料と確認状態を伴って管理するAs-Is分析の正本領域である。

本領域は次を目的とする。

1. 7業務Flowの開始点、終了点、Actor、業務Step、分岐および例外を確定する。
2. 各Flowで利用する約24 APIの目的、順序、前提、Request、ResponseおよびErrorを確認する。
3. 業務Flowから検証対象となる経路とScenario候補を抽出する。
4. Business、API、UseCaseおよびScenario Masterへ登録する事実根拠を形成する。
5. API詳細設計、UseCase／Scenario設計およびVerification設計へ追跡可能な入力を提供する。
6. 確認済み事実、分析上の推定および未確認事項を混在させない。

`business/`の文書はRuntime入力ではない。RuntimeまたはJavaが本領域のMarkdownを直接読み込んで実行してはならない。

## 3. 責務境界

| 情報 | 本領域での扱い | 正式な後続正本 |
|---|---|---|
| 現行業務の目的、境界、Actor、Flow | 調査・確定する | 現行業務分析書 |
| 現行のAPI呼出位置、分岐、処理Flg | 調査・経路候補化する | BA分析書×シナリオ一覧 |
| 現行APIのInterface、項目、Error | 調査・根拠付けする | API分析書 |
| Business／APIの固定Identity | 登録候補を提示する | Business／API Master |
| To-Be UseCase／Scenario | 候補と根拠を提示する | UseCase／Scenario Master・詳細設計 |
| API呼出順序、Mapping、Checkの実装 | 実装要求候補を提示する | Java Scenario／Check実装 |
| Scenario Input／Expected | 必要データと期待候補を提示する | `system/04_usecase_design/input/`、`expected/` |
| Compare／Diff実行規則 | 比較観点候補を提示する | Verification設計、API Response Diff設計、Java |
| Environment別URL、Credential | 論理参照だけ記録する | Environment Master／設定／Secret Store |
| Runtime結果、Evidence | 分析Evidenceとは分離する | Runtime Data Root |

## 4. 正式Directory構成

```text
business/
├── README.md
├── templates/
│   ├── 現行業務分析書_Template.md
│   ├── BA分析書×シナリオ一覧_Template.md
│   └── API分析書_Template.md
├── flows/
│   └── {businessCode}/
│       ├── 現行業務分析書.md
│       └── BA分析書×シナリオ一覧.md
├── API分析書/
│   ├── API一覧.md
│   ├── API依存関係一覧.md
│   ├── API呼出シーケンス一覧.md
│   ├── API共通仕様一覧.md
│   ├── APIエラーコード一覧.md
│   ├── API認証方式一覧.md
│   ├── APIレスポンスコード一覧.md
│   └── API-{NNN}分析書.md
└── examples/
    └── （900番台の架空またはMask済みExample）
```

`{businessCode}`および`{NNN}`はPlaceholderであり、実Directory名またはFile名へ波括弧を残してはならない。

## 5. 成果物一覧

| 成果物 | 単位 | 目的 | 主なConsumer |
|---|---|---|---|
| 現行業務分析書 | 1業務Flowにつき1件 | As-Is業務、Step、分岐、利用API、業務結果の確定 | Business Master、UseCase設計 |
| BA分析書×シナリオ一覧 | 現行業務分析書につき1件 | Flow経路とScenario候補の抽出 | UseCase／Scenario設計、対応表 |
| API分析書 | 1 APIにつき1件 | 現行Interface、Request／Response、Error、依存の確定 | API Master、API詳細設計、Verification設計 |
| API横断一覧 | 全API横断 | 共通仕様、依存、Sequence、認証、Code体系の一元化 | API設計、Framework、Review |
| Example | 架空ケース | 記入方法の説明 | 作成者、Reviewer |

## 6. 分析対象の現在状態

現時点では、7業務Flowの正式名称、境界および根拠資料が未確定であり、正式Business／APIはMasterへ登録されていない。

| 作業管理ID | 対象 | 正式ID | 名称 | 状態 | 登録条件 |
|---|---|---|---|---|---|
| `BA-WORK-01` | 業務Flow 1 | `TBD` | `TBD` | `NOT_STARTED` | 根拠資料とOwner確認 |
| `BA-WORK-02` | 業務Flow 2 | `TBD` | `TBD` | `NOT_STARTED` | 根拠資料とOwner確認 |
| `BA-WORK-03` | 業務Flow 3 | `TBD` | `TBD` | `NOT_STARTED` | 根拠資料とOwner確認 |
| `BA-WORK-04` | 業務Flow 4 | `TBD` | `TBD` | `NOT_STARTED` | 根拠資料とOwner確認 |
| `BA-WORK-05` | 業務Flow 5 | `TBD` | `TBD` | `NOT_STARTED` | 根拠資料とOwner確認 |
| `BA-WORK-06` | 業務Flow 6 | `TBD` | `TBD` | `NOT_STARTED` | 根拠資料とOwner確認 |
| `BA-WORK-07` | 業務Flow 7 | `TBD` | `TBD` | `NOT_STARTED` | 根拠資料とOwner確認 |

`BA-WORK-*`は分析作業の仮管理IDであり、Business Masterの`businessId`ではない。約24 APIという件数は計画値であり、重複排除と現行調査が完了するまで正式件数として扱わない。

## 7. 作成順序

```mermaid
flowchart TD
    A["根拠資料・担当者の特定"]
    B["7業務Flowの現行分析"]
    C["Flow別経路・Scenario候補抽出"]
    D["API棚卸し・重複排除"]
    E["API単位・横断分析"]
    F["業務／API Owner Review"]
    G["5 Master登録"]
    H["API／UseCase／Scenario詳細設計"]

    A --> B
    B --> C
    B --> D
    C --> E
    D --> E
    E --> F
    F --> G
    G --> H
```

### 7.1 1業務Flowの標準作業

1. 根拠資料、説明担当者、対象Versionおよび調査Environmentを特定する。
2. `現行業務分析書_Template.md`を複製し、As-Is Flowを作成する。
3. 各Step、API、分岐、終了状態およびデータ影響を確認する。
4. `BA分析書×シナリオ一覧_Template.md`を複製し、経路とScenario候補を抽出する。
5. 関連APIの既存分析書を更新し、未作成APIはAPI棚卸しへ追加する。
6. Open Issueを業務担当またはAPI担当へ確認する。
7. BA LeadとBusiness OwnerのReview後、Master登録Change Setを作成する。

## 8. 事実・推定・未確認の管理

分析値には必ず次の確認状態を付与する。

| 確認状態 | 意味 | 使用条件 |
|---|---|---|
| `CONFIRMED` | 複数根拠またはOwner確認により確定 | 正式設計入力に利用可 |
| `OBSERVED` | 実API、Logまたは現行動作で観測 | 観測条件とEvidence必須 |
| `INFERRED` | Source、LogまたはFlowから推定 | 根拠と確認先を明記 |
| `CONFLICTED` | 根拠間で矛盾 | 正式値へ採用禁止 |
| `UNKNOWN` | 確認できていない | 推測値で置換禁止 |
| `NOT_APPLICABLE` | 対象外 | 対象外理由を明記 |

確度が必要な場合は`HIGH / MEDIUM / LOW`を補助的に使用できるが、確認状態の代替にしてはならない。

## 9. 根拠資料とEvidence

| Source種別 | 例 | 注意 |
|---|---|---|
| 現行設計書 | 要件、基本設計、API仕様、Flow図 | 版数と対象範囲を記録する。 |
| OpenAPI／Postman | Interface定義、Sample | 実装との乖離を確認する。 |
| Source Code | Controller、DTO、Client、業務分岐 | Build／Branch／Commit等を識別する。 |
| 実API観測 | Mask済みRequest／Response | Environment、日時、入力条件を記録する。 |
| Log | 呼出順序、Error、処理Flg | 個人情報、Token、Secretを除去する。 |
| 担当者説明 | 業務Rule、例外、運用 | 説明者の役割、確認日、確認結果を記録する。 |

根拠資料がない説明を`CONFIRMED`にしてはならない。実行Evidenceには実Credential、Token、個人情報または未Maskの業務データを保存してはならない。

## 10. IDとReference

1. 正式Business IDはBusiness Master登録時に確定する。
2. 正式API IDはAPI棚卸し、重複排除およびAPI Owner Review後に確定する。
3. BA段階の経路は文書内固定ID`PATH-*`で管理する。
4. BA段階のScenarioは`SC-CAND-*`として管理し、正式`SC-E6-*`を先行採番しない。
5. Flow Step IDは対象文書内で一意な`BF-*`を使用する。
6. Repository内ReferenceはRepository Root基準の相対Pathとする。
7. `examples/`または`recovery/`を正式Referenceに使用しない。

## 11. Status

| Status | 意味 | 後続利用 |
|---|---|---|
| `DRAFT` | 作成中 | 正式Master登録不可 |
| `REVIEW` | Review中 | 暫定参照のみ |
| `APPROVED` | Owner承認済み | 正式設計入力に利用可 |
| `FROZEN` | 対象Versionの分析基準として凍結 | 変更管理必須 |
| `DEPRECATED` | 後継あり | 新規設計入力不可 |
| `ARCHIVED` | 参照終了 | Runtime／正式設計参照不可 |

## 12. Review Gate

### 12.1 現行業務分析書

- [ ] 業務開始点と終了点が一意である。
- [ ] Main、Alternative、Exceptionの各経路が識別できる。
- [ ] 全Flow StepにID、入力、出力、次Stepがある。
- [ ] 利用APIと非API処理を区別している。
- [ ] データ更新、取消、再実行およびCleanup影響が明確である。
- [ ] 推定と未確認が確定事項から分離されている。

### 12.2 BA分析書×シナリオ一覧

- [ ] 全到達可能な終了経路が`PATH-*`で表現されている。
- [ ] 分岐条件と処理Flgが根拠付きである。
- [ ] Run／Skip対象APIが経路ごとに明確である。
- [ ] Scenario候補が正式Scenario IDを先行使用していない。
- [ ] 同一目的・同一経路の重複候補がない。

### 12.3 API分析書

- [ ] Method、Path、Header、Request、ResponseおよびErrorが確認されている。
- [ ] 必須、存在、Null、空文字、型、長さおよび値制約を混同していない。
- [ ] 値比較を無視する項目でも、存在・型・構造Check要否を明示している。
- [ ] Dynamic Field、Collection、項目増減および互換性観点がある。
- [ ] Secretまたは未Maskデータがない。
- [ ] 後続API、UseCase、Verificationへの反映候補が記録されている。

## 13. 完了条件

Business分析域の初期構築完了は、次をすべて満たした状態とする。

1. 7業務Flowすべてに2文書が存在し、Owner Review済みである。
2. API棚卸しと重複排除が完了し、正式API件数が確定している。
3. 全正式APIにAPI分析書がある。
4. API横断7一覧が作成され、個別分析と矛盾しない。
5. Business／API Master登録候補が承認されている。
6. Open Issueが解消済み、または後続設計を妨げないと承認されている。
7. Example、Recoveryおよび正式成果物が相互参照されていない。

## 14. 禁止事項

- 架空のBusiness、API、処理FlgまたはResponseを正式成果物へ記載する。
- 7件または約24件という計画件数に合わせるため、根拠のないレコードを作る。
- `enabled=false`を未確認データの保管場所として使用する。
- 会話、ExampleまたはRecoveryだけを根拠に正式IDを採番する。
- API分析書へEnvironment別Credential実値を記載する。
- BA文書へJavaの最終Class名、Packageまたは未承認Source Rootを固定する。
- Compare候補を外部Policy Masterまたは実行可能Scriptとして定義する。
- 現行分析書からRuntimeを直接駆動する。

## 15. 関連文書

- `system/01_repository/Repository_Structure.md`
- `system/01_repository/文書作成規約.md`
- `system/01_repository/命名規約.md`
- `system/01_repository/トレーサビリティ規約.md`
- `system/02_master/README.md`
- `system/03_api_design/API設計書_Template.md`
- `system/04_usecase_design/UseCase設計書_Template.md`
- `system/06_verification_assets/Verification仕様書_Template.md`

## 16. Open Issues

| Issue ID | 確認事項 | 影響 | Owner | 状態 |
|---|---|---|---|---|
| `BUS-README-ISSUE-001` | 7業務Flowの正式名称、対象資料および説明担当 | Flow分析開始 | Business Owner | Open |
| `BUS-README-ISSUE-002` | 約24 APIの棚卸し元一覧と重複判定基準 | API正式件数 | API Owner | Open |
| `BUS-README-ISSUE-003` | 業務分析Evidenceの保管先とRetention | 分析証跡 | Repository Owner | Open |

## 17. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| `1.0.0-draft.1` | 2026-07-27 | `business/`の責務、作成順序、7 Flow管理、確認状態、Review Gateおよび完了条件を初版定義。 |
