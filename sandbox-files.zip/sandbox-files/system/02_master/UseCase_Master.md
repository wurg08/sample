---
title: UseCase Master
document_id: MST-E6-UC-001
version: 2.0.0
status: Draft
document_type: Master
system_name: E6 API Verification Platform
updated: 2026-07-25
---

# UseCase Master

## 1. 文書目的

本書は、E6 API Verification Platformで検証する業務目的、業務範囲、共通前提条件および所属ScenarioをUseCase単位で一元管理する正本である。

本書の設計規則は、`system/02_master/design/UseCase_Master設計書.md`に従う。

## 2. 管理原則

1. 1 UseCaseは、独立して説明可能な1つの業務検証目的を表す。
2. 入力条件、分岐、正常／異常、TimeoutまたはSkipの違いはScenarioとして管理する。
3. API呼出順序、`apiCallCode`、Context、ExpectedおよびBusiness Checkは本書に記載しない。
4. `scenarioIds`はUseCaseに所属するScenarioの完全性確認用一覧であり、実行順序を表さない。
5. UseCaseを細分化する目的で単一APIまたは単一フィールドCheckをUseCase化しない。

## 3. 正式UseCase一覧

| useCaseId | useCaseName | businessIds | businessPurpose | businessScope | preconditionSummary | applicableEnvironmentIds | scenarioIds | useCaseDesignRef | enabled |
|---|---|---|---|---|---|---|---|---|:---:|
| UC-E6-001 | 会員状態更新検証 | BUS-E6-001 | 会員状態の更新前後を確認し、想定した状態遷移およびAPI間のデータ整合性が成立することを検証する。 | 更新前会員情報の取得から会員状態更新、更新後の再照会および業務Check完了まで。 | 対象Environmentへの接続情報、認証情報およびScenario別検証データが準備済みであること。 | ENV-LOCAL<br>ENV-STAGING<br>ENV-PROD | SC-E6-001<br>SC-E6-002<br>SC-E6-003 | system/04_usecase_design/UC-E6-001設計書.md | true |

## 4. UseCaseとScenarioの関係

| useCaseId | scenarioId | Scenario概要 | 使用可否 |
|---|---|---|---|
| UC-E6-001 | SC-E6-001 | 会員情報を取得し、状態更新後に再照会して更新結果を確認する主正常経路。 | 使用可 |
| UC-E6-001 | SC-E6-002 | 更新対象会員が存在しない場合に、更新を実行せず業務上の想定結果を確認する経路。 | 詳細設計確定後 |
| UC-E6-001 | SC-E6-003 | 会員状態更新APIでTimeoutが発生した場合の停止、Skipおよび結果集約を確認する経路。 | 詳細設計確定後 |

本表は所属関係の説明であり、Scenario定義の正本は`Scenario_Master.md`とする。

## 5. Business／Environment参照

| 参照種別 | 参照ID | 本UseCaseでの意味 | 整合性確認 |
|---|---|---|---|
| Business | BUS-E6-001 | 会員情報更新業務 | `Business_Master.md`との照合が必要 |
| Environment | ENV-LOCAL | ローカル検証 | `Environment_Master.md`との照合が必要 |
| Environment | ENV-STAGING | 結合・日次検証 | `Environment_Master.md`との照合が必要 |
| Environment | ENV-PROD | 本番環境または本番相当環境 | 正式名称・実行許可範囲の確認が必要 |

## 6. 参照整合性

| Validation ID | 確認内容 | 現在の判定 |
|---|---|---|
| UC-MST-V001 | 正式10項目がすべて設定されていること。 | PASS |
| UC-MST-V002 | `useCaseId`が`UC-E6-NNN`形式で一意であること。 | PASS |
| UC-MST-V003 | `businessIds`がBusiness Masterで解決できること。 | 要照合 |
| UC-MST-V004 | `applicableEnvironmentIds`がEnvironment Masterで解決できること。 | 要照合 |
| UC-MST-V005 | `scenarioIds`がScenario Masterで解決でき、逆参照が一致すること。 | PASS |
| UC-MST-V006 | 有効UseCaseに1件以上の有効Scenarioが存在すること。 | PASS |
| UC-MST-V007 | `useCaseDesignRef`が詳細設計書を指すこと。 | PASS（参照先ファイル作成待ち） |

## 7. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| API一覧、呼出順序、分岐、Skip | Scenario詳細設計書 |
| `apiCallCode` | Scenario詳細設計書 |
| Input値 | Scenario Input JSON |
| 前序Responseから後続RequestへのMapping | Scenario Java実装 |
| Expected、`resultKey` | Scenario Expected、Java Check |
| Response Diff、Baseline | Java Comparator、Runtime設計 |
| 実行頻度、前回Run、実行状態 | Scheduler／RunContext／運用設計 |

## 8. 変更管理

- 業務目的が異なる場合は新しいUseCaseを追加する。
- 入力条件、経路または期待終了状態だけが異なる場合はScenarioを追加する。
- Scenario追加・廃止時は、同一変更単位で本書の`scenarioIds`と`Scenario_Master.md`を更新する。
- 利用停止時は原則としてレコードを削除せず、`enabled=false`とする。

## 9. 要確認事項

| Issue ID | 確認事項 | 影響 | 確認元 | 状態 |
|---|---|---|---|---|
| UC-MST-ISSUE-001 | `BUS-E6-001`の正式名称・有効状態 | Business参照 | Business Master | Open |
| UC-MST-ISSUE-002 | `ENV-PROD`が本番か本番相当環境か | 実行許可範囲 | Environment Master | Open |
| UC-MST-ISSUE-003 | SC-E6-002の業務結果区分 | Scenario／Expected | 業務担当 | Open |
| UC-MST-ISSUE-004 | SC-E6-003のRetryおよび終了条件 | Scenario詳細設計 | 共通Framework／API仕様 | Open |
| UC-MST-ISSUE-005 | 7業務Flowから抽出する残りUseCase | UseCase Coverage | BA分析書×Scenario一覧 | Open |

## 10. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| 2.0.0 | 2026-07-25 | 新UseCase Master設計の正式10項目に再構成し、API実行・Verification・Baseline関連項目を削除。 |
