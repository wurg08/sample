---
title: MasterレビューChecklist
document_id: CHECK-E6-MST-001
version: 2.0.0
status: Draft
document_type: Checklist
system_name: E6 API Verification Platform
updated: 2026-07-25
---

# MasterレビューChecklist

## 1. 目的

本Checklistは、E6 API Verification PlatformのMaster、関連設計書、Guide、ExampleおよびAPI・UseCase・Scenario対応表について、人によるReviewの観点、判定、指摘および承認Evidenceを統一する。

本ChecklistはReviewの正本であり、機械的なCross-Master整合性検証の詳細は`Master整合性Checklist.md`で管理する。

## 2. 使用方法

1. Review対象とChange IDを記入する。
2. 変更内容に該当する全Checklistを実施する。
3. 判定を`PASS`、`FAIL`、`N/A`から選択する。
4. `N/A`には適用外理由を必ず記載する。
5. `FAIL`にはIssue ID、Owner、期限およびRelease影響を設定する。
6. Validation結果、差分、設計書または実装をEvidenceとして記録する。
7. 必須Review者が承認後、最終判定を記録する。

Checkboxだけを完了し、根拠と判定を残さない運用は禁止する。

## 3. Review記録

| 項目 | 記入欄 |
|---|---|
| Change ID |  |
| 対象Release |  |
| 対象ファイル |  |
| 対象Version |  |
| 変更種別 | 追加／属性変更／関係変更／無効化／置換／削除 |
| 作成者 |  |
| Master Owner |  |
| Domain Reviewer |  |
| Architecture Reviewer |  |
| Test Reviewer |  |
| Review開始日 |  |
| Review完了日 |  |
| Validation Evidence |  |
| 最終判定 | PASS／CONDITIONAL PASS／FAIL |

## 4. 判定基準

| 判定 | 意味 | Release |
|---|---|---|
| `PASS` | 指摘なし、または全指摘が解消済み | 他Gateを満たせば可 |
| `CONDITIONAL PASS` | WARNINGに承認済み対応計画がある | Approver判断 |
| `FAIL` | ERROR、未解決重大指摘またはEvidence不足 | 不可 |
| `N/A` | 変更内容に適用しない | 理由記載必須 |

## 5. 共通文書Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-CMN-001` | YAML Front Matterが存在し、解析可能である。 |  |  |
| `REV-CMN-002` | `document_id`がRepository内で一意である。 |  |  |
| `REV-CMN-003` | Version、Status、更新日が変更内容と一致する。 |  |  |
| `REV-CMN-004` | 文書目的、適用範囲および管理対象外が明確である。 |  |  |
| `REV-CMN-005` | 改訂履歴に変更理由と影響が記録されている。 |  |  |
| `REV-CMN-006` | Markdown Tableの列数と見出しが一致する。 |  |  |
| `REV-CMN-007` | Code Fence、Mermaidおよび内部Linkが正しく閉じている。 |  |  |
| `REV-CMN-008` | 日本語の用語、表記およびID名が文書内で統一されている。 |  |  |
| `REV-CMN-009` | 未決事項にOwner、期限およびRelease影響がある。 |  |  |
| `REV-CMN-010` | Exampleまたは暫定値を正式値と誤認しない記述である。 |  |  |

## 6. 責務・正本Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-SOR-001` | 変更対象情報の正本が一つに決まっている。 |  |  |
| `REV-SOR-002` | 同じ定義を複数Masterへ重複登録していない。 |  |  |
| `REV-SOR-003` | Masterには複数成果物から参照される安定情報だけを置いている。 |  |  |
| `REV-SOR-004` | API呼出順序、分岐、Input、ExpectedおよびCheckがMasterへ混入していない。 |  |  |
| `REV-SOR-005` | Runtime、Snapshot、Baseline、DiffおよびReport実値がMasterへ混入していない。 |  |  |
| `REV-SOR-006` | `IGNORE_FIELD`、`IGNORE_VALUE`およびJava比較ロジックがMasterへ混入していない。 |  |  |
| `REV-SOR-007` | 対応表を第四のMasterまたはJava実行仕様として扱っていない。 |  |  |
| `REV-SOR-008` | Viewと正本が不一致の場合、正本確認を起点としている。 |  |  |
| `REV-SOR-009` | 廃止済みContext／Verification／Policy／Compare Policy Masterを依存先にしていない。 |  |  |
| `REV-SOR-010` | 凍結済みMaster体系へ未承認のMaster、Directoryまたは列を追加していない。 |  |  |

## 7. ID Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-ID-001` | 主IDが定義Patternに一致する。 |  |  |
| `REV-ID-002` | IDがScope内で一意である。 |  |  |
| `REV-ID-003` | 同一対象の既存IDがない。 |  |  |
| `REV-ID-004` | 廃止済みIDを再利用していない。 |  |  |
| `REV-ID-005` | 欠番を許容し、番号詰めまたは再採番をしていない。 |  |  |
| `REV-ID-006` | 名称、Path、Class名または表示順を外部参照Keyにしていない。 |  |  |
| `REV-ID-007` | `apiId`と`apiCallCode`を区別している。 |  |  |
| `REV-ID-008` | `callSequence`をIdentityとして使用していない。 |  |  |
| `REV-ID-009` | `sequence`と`resultKey`を区別している。 |  |  |
| `REV-ID-010` | 900番台Example IDが正式Masterへ混入していない。 |  |  |

## 8. Reference Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-REF-001` | 全ID Referenceの参照先正本が明確である。 |  |  |
| `REV-REF-002` | 全ID Referenceが正本に存在する。 |  |  |
| `REV-REF-003` | 有効レコードが無効参照先を新規参照していない。 |  |  |
| `REV-REF-004` | File ReferenceがRepository Root基準の相対Pathである。 |  |  |
| `REV-REF-005` | `./`、`../`、絶対Path、URLまたは個人Pathを使用していない。 |  |  |
| `REV-REF-006` | File名に対象IDが含まれ、実ファイルと大小文字が一致する。 |  |  |
| `REV-REF-007` | 有効レコードの必須File Referenceが解決できる。 |  |  |
| `REV-REF-008` | Java Class Referenceが完全修飾Class名で解決できる。 |  |  |
| `REV-REF-009` | List Referenceに重複がなく、`<br>`区切りが統一されている。 |  |  |
| `REV-REF-010` | File移動・改名時に全参照元を同一Change Setで更新している。 |  |  |

## 9. `enabled`・Lifecycle Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-STS-001` | 文書`status`とレコード`enabled`を区別している。 |  |  |
| `REV-STS-002` | `enabled=true`の正式値が根拠資料で確認済みである。 |  |  |
| `REV-STS-003` | `enabled=true`の必須設計、実装およびReferenceが解決可能である。 |  |  |
| `REV-STS-004` | `enabled=false`をID重複やOrphanの代替に使用していない。 |  |  |
| `REV-STS-005` | 無効化レコードを物理削除せず履歴追跡できる。 |  |  |
| `REV-STS-006` | Frozen文書の変更に承認済みChange Requestがある。 |  |  |
| `REV-STS-007` | Deprecated対象が新規参照されていない。 |  |  |
| `REV-STS-008` | 対応表の`relationStatus`が正本の状態から導出されている。 |  |  |

## 10. Business Master Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-BUS-001` | 1レコードが一つの安定した業務分類・境界を表す。 |  |  |
| `REV-BUS-002` | 他Businessと目的またはScopeが重複していない。 |  |  |
| `REV-BUS-003` | 一時的なTest Pattern、ScenarioまたはAPI単位をBusiness化していない。 |  |  |
| `REV-BUS-004` | UseCaseから参照できる十分な業務名称と説明がある。 |  |  |
| `REV-BUS-005` | 業務OwnerまたはBA Leadが境界を承認している。 |  |  |

## 11. Environment Master Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-ENV-001` | 1レコードが一つの論理実行環境を表す。 |  |  |
| `REV-ENV-002` | Host名変更だけで別Environmentを重複登録していない。 |  |  |
| `REV-ENV-003` | Credential、Secretまたは個人情報を記載していない。 |  |  |
| `REV-ENV-004` | Local、Staging、Prod等の名称と実際の用途が一致する。 |  |  |
| `REV-ENV-005` | 接続・実行可否・運用責任がEnvironment設計と整合する。 |  |  |

## 12. API Master Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-API-001` | 一つのAPI契約を一つのレコードとしている。 |  |  |
| `REV-API-002` | 同一APIの複数回呼出を重複API登録していない。 |  |  |
| `REV-API-003` | 正式10項目が個別設計書の定義と一致する。 |  |  |
| `REV-API-004` | MethodとEndpoint PathがAPI仕様に一致する。 |  |  |
| `REV-API-005` | Endpoint PathにHost、Query実値またはEnvironment差分を含めていない。 |  |  |
| `REV-API-006` | Request／Response DTOがJava実装と一致する。 |  |  |
| `REV-API-007` | `apiDesignRef`が対象APIの詳細設計書を指す。 |  |  |
| `REV-API-008` | Request／Responseフィールド定義を重複保持していない。 |  |  |
| `REV-API-009` | 非互換置換時のAPI ID継続可否が承認されている。 |  |  |
| `REV-API-010` | API無効化による全Scenario影響を確認している。 |  |  |

## 13. UseCase Master Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-UC-001` | 一つの独立した業務検証目的を一つのUseCaseとしている。 |  |  |
| `REV-UC-002` | 正常／異常、入力差またはTimeout差だけでUseCaseを分割していない。 |  |  |
| `REV-UC-003` | 正式10項目が個別設計書の定義と一致する。 |  |  |
| `REV-UC-004` | `businessIds`がBusiness Masterで解決できる。 |  |  |
| `REV-UC-005` | `applicableEnvironmentIds`がEnvironment Masterで解決できる。 |  |  |
| `REV-UC-006` | `scenarioIds`が所属Scenarioの完全な集合である。 |  |  |
| `REV-UC-007` | `scenarioIds`の並びを実行順序として使用していない。 |  |  |
| `REV-UC-008` | 有効UseCaseに一件以上の有効Scenarioがある。 |  |  |
| `REV-UC-009` | `useCaseDesignRef`が業務Flow詳細を指す。 |  |  |
| `REV-UC-010` | API一覧、呼出順序またはExpectedを保持していない。 |  |  |

## 14. Scenario Master Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-SC-001` | 一つの確定経路かつ一回の同期Batch実行単位である。 |  |  |
| `REV-SC-002` | 開始条件、主要経路および期待終了状態が説明できる。 |  |  |
| `REV-SC-003` | 単一フィールドCheck差だけでScenarioを分割していない。 |  |  |
| `REV-SC-004` | 正式10項目が個別設計書の定義と一致する。 |  |  |
| `REV-SC-005` | `useCaseId`がUseCase Masterで解決できる。 |  |  |
| `REV-SC-006` | `scenarioType`が許可Enumに一致する。 |  |  |
| `REV-SC-007` | `executionClass`、Input、Expected、設計書参照が整合する。 |  |  |
| `REV-SC-008` | 有効Scenarioに一件以上の正式API呼出がある。 |  |  |
| `REV-SC-009` | 有効Scenarioの全APIが有効である。 |  |  |
| `REV-SC-010` | API呼出明細、Check明細、Runtime値をMaster列に追加していない。 |  |  |

## 15. Traceability View Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-TRC-001` | 対応表がTraceability Viewであることを明記している。 |  |  |
| `REV-TRC-002` | 一行が`scenarioId + apiCallCode`の呼出実体である。 |  |  |
| `REV-TRC-003` | 正式14表示項目が設計書と一致する。 |  |  |
| `REV-TRC-004` | `apiCallCode`がScenario内で一意である。 |  |  |
| `REV-TRC-005` | `callSequence`が数値順を示し、Identityではない。 |  |  |
| `REV-TRC-006` | 同一API複数回呼出を異なる`apiCallCode`で表示する。 |  |  |
| `REV-TRC-007` | 名称、設計参照および状態が各正本と一致する。 |  |  |
| `REV-TRC-008` | Orphan、重複または親子不一致がない。 |  |  |
| `REV-TRC-009` | 有効Scenarioが無効APIを参照していない。 |  |  |
| `REV-TRC-010` | ViewだけをJava実行仕様として使用していない。 |  |  |

## 16. 変更影響Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-CHG-001` | Change ID、理由、対象Releaseおよび根拠がある。 |  |  |
| `REV-CHG-002` | 変更対象の正本とOwnerが特定されている。 |  |  |
| `REV-CHG-003` | ID継続または新ID採番の判断根拠がある。 |  |  |
| `REV-CHG-004` | 参照元、参照先、View、Java、Testおよび運用への影響を確認した。 |  |  |
| `REV-CHG-005` | 関連成果物が同一Change Setで更新されている。 |  |  |
| `REV-CHG-006` | 無効化後も過去Run、Snapshot、DiffおよびReportから追跡できる。 |  |  |
| `REV-CHG-007` | 物理削除の場合、参照0件と承認Evidenceがある。 |  |  |
| `REV-CHG-008` | Rollbackまたは切戻し方針がある。 |  |  |
| `REV-CHG-009` | 未決事項にOwner、期限およびRelease影響がある。 |  |  |
| `REV-CHG-010` | 変更後に対応表とCoverageを再生成・再確認した。 |  |  |

## 17. Validation・Release Review

| ID | 確認項目 | 判定 | Evidence／Comment |
|---|---|---|---|
| `REV-REL-001` | 構文Validationが完了している。 |  |  |
| `REV-REL-002` | 単一ファイルValidationが完了している。 |  |  |
| `REV-REL-003` | ID・Path Reference Validationが完了している。 |  |  |
| `REV-REL-004` | Cross-Master Validationが完了している。 |  |  |
| `REV-REL-005` | Scenario詳細設計・Java整合性確認が完了している。 |  |  |
| `REV-REL-006` | 対応表・Coverage Validationが完了している。 |  |  |
| `REV-REL-007` | Validation `ERROR`が0件である。 |  |  |
| `REV-REL-008` | `WARNING`が修正済みまたは承認済みである。 |  |  |
| `REV-REL-009` | 必須Reviewerの承認Evidenceがある。 |  |  |
| `REV-REL-010` | 対象文書のLifecycle状態がRelease条件を満たす。 |  |  |

## 18. 現行E6データの必須確認

現行Masterには、次のRelease阻断事項が存在する。

| Issue | 確認内容 | 期待処置 | 判定 |
|---|---|---|---|
| `TRC-V008` | `SC-E6-001(enabled=true)`の`CALL-002`が`API-002(enabled=false)`を参照している。 | API-002の正式仕様・設計・実装を確認して有効化するか、SC-E6-001を実行対象外とする。 | FAIL |

この不一致を`relationStatus=INACTIVE`の表示だけで解消済みとしてはならない。

## 19. 指摘管理

| Issue ID | Checklist ID | 指摘内容 | Level | Owner | 期限 | 状態 | Release影響 |
|---|---|---|---|---|---|---|---|
|  |  |  | ERROR／WARNING／INFO |  |  | OPEN／CLOSED |  |

`ERROR`は全件Closeする。`WARNING`を残す場合は、Master OwnerとRelease Approverの承認、期限および対応計画を記録する。

## 20. 承認

| 役割 | 氏名 | 判定 | 日付 | Evidence |
|---|---|---|---|---|
| Master Owner |  |  |  |  |
| Domain Reviewer |  |  |  |  |
| System Architect |  |  |  |  |
| Test Lead |  |  |  |  |
| Release Approver |  |  |  |  |

## 21. Review完了条件

Reviewは次をすべて満たした時点で完了とする。

1. 適用対象Checklistがすべて判定済みである。
2. `N/A`に理由が記録されている。
3. `FAIL`にIssue、Owner、期限およびRelease影響が設定されている。
4. Validation `ERROR`が0件である。
5. 未解決`WARNING`が承認済みである。
6. 正本、ID、Reference、状態およびTraceabilityの責務が一致している。
7. 変更差分とEvidenceが追跡可能である。
8. 必須ReviewerとRelease Approverが承認している。
