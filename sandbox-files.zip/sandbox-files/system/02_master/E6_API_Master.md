---
title: E6 API Master
document_id: MST-E6-API-001
version: 2.0.0
status: Draft
document_type: Master
system_name: E6 API Verification Platform
updated: 2026-07-25
---

# E6 API Master

## 1. 文書目的

本書は、E6 API Verification Platformが参照するAPIの固定識別子および安定した技術属性を一元管理する正本である。

本書の設計規則は、`system/02_master/design/API_Master設計書.md`に従う。

## 2. 管理原則

1. 1 APIを1レコードとして登録する。
2. 同一APIを複数のScenarioまたは同一Scenario内で複数回呼び出しても、レコードを重複登録しない。
3. Scenario内の呼出実体は`apiCallCode`で識別し、本書では管理しない。
4. Request／Responseのフィールド定義はAPI詳細設計書およびJava DTOを正本とする。
5. Expected、Business Check、Context、BaselineおよびResponse Diff規則は本書に記載しない。
6. 未確認情報を推測で正式レコードへ登録しない。

## 3. 正式API一覧

| apiId | apiName | systemId | method | endpointPath | requestDto | responseDto | apiDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|
| API-001 | 会員情報取得API | E6 | POST | /api/v1/members/search | MemberSearchRequest | MemberSearchResponse | system/03_api_design/API-001設計書.md | true | 会員番号等の検索条件を指定して会員情報を取得する。 |
| API-002 | 会員状態更新API | E6 | POST | /api/v1/members/status | MemberUpdateRequest | MemberUpdateResponse | system/03_api_design/API-002設計書.md | false | 指定会員の状態を更新する。Endpoint PathはAPI詳細設計確定時に最終照合する。 |

## 4. 登録状態

| 区分 | 件数 | 説明 |
|---|---:|---|
| 正式レコード | 2 | 現時点で名称、MethodおよびDTOの設計根拠を確認できるAPI。 |
| `enabled=true` | 1 | API詳細設計例とEndpoint Pathが一致しているAPI。 |
| `enabled=false` | 1 | API詳細設計または実装との最終照合が必要なAPI。 |
| 初期想定総数 | 約24 | 7業務Flowの正式分析後に確定する。 |
| 未登録 | 約22 | 正式API分析書または現行仕様の提示後に登録する。 |

件数を合わせる目的で`API-003`以降を仮登録してはならない。

## 5. API別確認状態

| apiId | 確認対象 | 現在の状態 | 完了条件 |
|---|---|---|---|
| API-001 | API名称、Method、Endpoint、DTO、設計書参照 | 確認済み | API詳細設計書との最終Review完了 |
| API-002 | API名称、Method、DTO | 確認済み | API詳細設計書との最終Review完了 |
| API-002 | Endpoint Path | 暫定 | 現行API仕様またはAPI詳細設計書で正式Pathを確認 |
| API-003以降 | 全10項目 | 未登録 | 7業務のAPI分析書から正式情報を取得 |

## 6. 参照整合性

| Validation ID | 確認内容 | 現在の判定 |
|---|---|---|
| API-MST-V001 | 各レコードに正式10項目が設定されていること。 | PASS |
| API-MST-V002 | `apiId`が`API-NNN`形式で一意であること。 | PASS |
| API-MST-V003 | `method`が許可Enumであること。 | PASS |
| API-MST-V004 | `endpointPath`が`/`から開始しHostを含まないこと。 | PASS |
| API-MST-V005 | `apiDesignRef`がAPI詳細設計書を指すこと。 | PASS（参照先ファイル作成待ち） |
| API-MST-V006 | 有効APIのDTOおよび実装が解決可能であること。 | 要Build確認 |
| API-MST-V007 | Scenario詳細設計の全`apiId`が本書で解決できること。 | 対応表作成時に確認 |

## 7. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| `apiCallCode`、呼出順序、呼出条件 | Scenario詳細設計書 |
| Request／Response項目、型、必須、桁数 | API詳細設計書、Java DTO |
| Scenario Input | Scenario Input JSON |
| Expected、`resultKey` | Scenario Expected、Java Check |
| 前後API間の値引継ぎ | Scenario Java実装 |
| `IGNORE_FIELD`、`IGNORE_VALUE` | Java比較定義 |
| Current／Previous／Baseline比較結果 | Runtime出力、API Response Diff |

## 8. 変更管理

- API追加時は、正式10項目を確定し、API詳細設計書およびDTOとの整合性を確認する。
- Method、EndpointまたはDTOの非互換変更は、影響調査後にAPI IDの継続可否を判断する。
- 利用停止時は原則としてレコードを削除せず、`enabled=false`とする。
- 本書だけを変更してScenarioの呼出先を差し替えてはならない。

## 9. 要確認事項

| Issue ID | 確認事項 | 影響 | 確認元 | 状態 |
|---|---|---|---|---|
| API-MST-ISSUE-001 | API-002の正式Endpoint Path | API-002有効化 | API詳細設計書／現行API仕様 | Open |
| API-MST-ISSUE-002 | E6の正式Java packageをDTO名に含めるか | DTO解決 | Java実装規約 | Open |
| API-MST-ISSUE-003 | 7業務Flowで使用する全API一覧 | 約24 APIの登録 | 各業務API分析書 | Open |
| API-MST-ISSUE-004 | `systemId=E6`の正式System Master有無 | System ID整合性 | システム設計 | Open |

## 10. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| 2.0.0 | 2026-07-25 | 新API Master設計の正式10項目に再構成し、旧Scenario／Verification／Compare項目を削除。 |
