---
title: API・UseCase・Scenario対応表記入例
document_id: EX-TRC-E6-API-UC-SC-001
version: 1.0.0
status: Example
document_type: Traceability View Example
system_name: E6 API Verification Platform
updated: 2026-07-25
---

# API・UseCase・Scenario対応表記入例

## 1. 目的

本書は、`API_UseCase_Scenario対応表.md`の正式14表示項目、1行の粒度、正本からの導出方法、同一API複数回呼出および不整合検出の記入例を示す。

本書中の`UC-E6-901`、`SC-E6-901`、`API-901～902`および全業務値は説明用の架空値である。本書はTraceability Viewの例であり、API、UseCase、Scenarioまたは呼出仕様の正本ではない。

## 2. 入力となる正本

| 情報 | 例 | 正本 |
|---|---|---|
| UseCase | `UC-E6-901` 注文状態変更検証 | UseCase Master |
| Scenario | `SC-E6-901` 注文状態変更正常経路 | Scenario Master |
| API | `API-901` 注文情報取得API、`API-902` 注文状態更新API | API Master |
| 呼出仕様 | `CALL-001～003`、順序、目的、条件 | Scenario詳細設計書 |

対応表で値を新規決定してはならない。

## 3. 正式14項目の記入例

| useCaseId | useCaseName | scenarioId | scenarioName | scenarioType | callSequence | apiCallCode | apiId | apiName | callPurpose | executeCondition | scenarioDesignRef | apiDesignRef | relationStatus |
|---|---|---|---|---|---:|---|---|---|---|---|---|---|---|
| UC-E6-901 | 注文状態変更検証 | SC-E6-901 | 注文状態変更正常経路 | NORMAL | 10 | CALL-001 | API-901 | 注文情報取得API | 変更前注文情報取得 | ALWAYS | system/04_usecase_design/examples/scenario/SC-E6-901設計書_Example.md | system/03_api_design/examples/API-901設計書_Example.md | ACTIVE |
| UC-E6-901 | 注文状態変更検証 | SC-E6-901 | 注文状態変更正常経路 | NORMAL | 20 | CALL-002 | API-902 | 注文状態更新API | 注文状態変更 | CALL-001が業務正常 | system/04_usecase_design/examples/scenario/SC-E6-901設計書_Example.md | system/03_api_design/examples/API-902設計書_Example.md | ACTIVE |
| UC-E6-901 | 注文状態変更検証 | SC-E6-901 | 注文状態変更正常経路 | NORMAL | 30 | CALL-003 | API-901 | 注文情報取得API | 変更後注文情報再取得 | CALL-002が更新成功 | system/04_usecase_design/examples/scenario/SC-E6-901設計書_Example.md | system/03_api_design/examples/API-901設計書_Example.md | ACTIVE |

## 4. 行Identity

一行は、次の複合Keyで識別する。

```text
scenarioId + apiCallCode
```

本例のIdentity:

```text
SC-E6-901 + CALL-001
SC-E6-901 + CALL-002
SC-E6-901 + CALL-003
```

`callSequence`は表示順であり、Identityではない。順序変更後も呼出目的が同一である場合は、原則として`apiCallCode`を維持する。

## 5. 同一API複数回呼出

`CALL-001`と`CALL-003`は同じ`API-901`を参照するが、目的と実行位置が異なる別の呼出実体である。

| apiId | apiCallCode | callSequence | callPurpose |
|---|---|---:|---|
| API-901 | CALL-001 | 10 | 変更前注文情報取得 |
| API-901 | CALL-003 | 30 | 変更後注文情報再取得 |

この場合もAPI Masterの`API-901`を複製してはならない。

## 6. 関係状態の導出

`relationStatus`は手入力で決定せず、参照する三Masterの`enabled`から導出する。

| UseCase | Scenario | API | relationStatus |
|:---:|:---:|:---:|---|
| true | true | true | `ACTIVE` |
| false | 任意 | 任意 | `INACTIVE` |
| true | false | 任意 | `INACTIVE` |
| true | true | false | `INACTIVE`。ただし有効Scenarioからの参照は整合性Error |

参照先不在、親子関係不一致または複合Key重複を`INACTIVE`で吸収してはならない。これらはValidation Errorである。

## 7. 不整合例

### 7.1 有効Scenarioが無効APIを参照

```text
UC-E6-901.enabled = true
SC-E6-901.enabled = true
API-902.enabled = false
```

この場合、`CALL-002`の表示状態は`INACTIVE`となるが、同時に「有効Scenarioが無効APIを参照」というERRORを出力し、Releaseを阻断する。

### 7.2 複合Key重複

次の二行は登録不可とする。

| scenarioId | apiCallCode | apiId |
|---|---|---|
| SC-E6-901 | CALL-001 | API-901 |
| SC-E6-901 | CALL-001 | API-902 |

呼出先変更である場合は、Scenario詳細設計書を正本として一行を更新し、変更影響をレビューする。

### 7.3 Orphan

`SC-E6-999`がScenario Masterに存在しない場合、対応表へ暫定行を残してはならない。正本を修正するか、誤った行を再生成で除外する。

## 8. 未展開Scenario

Scenario Masterに存在しても、Scenario詳細設計書に正式なAPI呼出が定義されていないScenarioについて、推測で行を生成してはならない。

| scenarioId | enabled | 取扱い |
|---|:---:|---|
| SC-E6-902 | false | API呼出仕様確定後に対応表へ展開する。 |
| SC-E6-903 | false | Timeout対象と停止条件確定後に対応表へ展開する。 |

有効Scenarioに呼出行が一件もない場合は、未展開として許容せず整合性Errorとする。

## 9. 順方向・逆方向Traceability

### 9.1 順方向

```text
UC-E6-901
└─ SC-E6-901
   ├─ CALL-001 → API-901
   ├─ CALL-002 → API-902
   └─ CALL-003 → API-901
```

### 9.2 逆方向

| apiId | UseCase | Scenario | 呼出実体 | 呼出回数 |
|---|---|---|---|---:|
| API-901 | UC-E6-901 | SC-E6-901 | CALL-001、CALL-003 | 2 |
| API-902 | UC-E6-901 | SC-E6-901 | CALL-002 | 1 |

## 10. 対応表へ含めない情報

| 含めない情報 | 管理先 |
|---|---|
| Request／Response項目、型、必須、桁数 | API詳細設計書およびDTO |
| Input実値 | Scenario Input |
| 前段Responseから後段Requestへの値引継ぎ | Scenario詳細設計書およびJava実装 |
| Expected値、`resultKey` | Scenario ExpectedおよびJava Check |
| Context実値 | Scenario Runtime |
| `IGNORE_FIELD`、`IGNORE_VALUE` | APIまたはScenario専用Java比較定義 |
| Previous／Current／Diff結果 | Run成果物 |

## 11. 誤記例

| 誤記 | 問題 | 正しい対応 |
|---|---|---|
| 1行を1 APIとして記載する | Scenario内の複数呼出を識別できない。 | 1行を1呼出実体とする。 |
| `callSequence`だけで行を識別する | 順序変更でIdentityが変わる。 | `scenarioId + apiCallCode`を使用する。 |
| 対応表でAPI名を修正しMasterへ逆反映する | Viewが正本化する。 | API Masterを承認変更し、対応表を再生成する。 |
| `relationStatus=ACTIVE`を手入力する | 正本の有効状態と乖離する。 | 三Masterの`enabled`から導出する。 |
| `resultKey`列を追加する | Traceabilityと検証結果Identityが混在する。 | Scenario設計、ExpectedおよびJavaで管理する。 |

## 12. 記入時Validation

| Rule | 確認内容 | Level |
|---|---|---|
| TRC-EX-V001 | 全行が正式14項目を持つ。 | ERROR |
| TRC-EX-V002 | `scenarioId + apiCallCode`が一意である。 | ERROR |
| TRC-EX-V003 | `callSequence`がScenario内で一意の正整数である。 | ERROR |
| TRC-EX-V004 | UseCase、ScenarioおよびAPIが各Masterで解決できる。 | ERROR |
| TRC-EX-V005 | Scenarioの`useCaseId`がUseCase Masterと一致する。 | ERROR |
| TRC-EX-V006 | 呼出情報がScenario詳細設計書と一致する。 | ERROR |
| TRC-EX-V007 | 有効Scenarioが一件以上の呼出行を持つ。 | ERROR |
| TRC-EX-V008 | 有効Scenarioが無効APIを参照しない。 | ERROR |
| TRC-EX-V009 | `relationStatus`が正本の有効状態から正しく導出される。 | ERROR |
| TRC-EX-V010 | 正本外のExpected、Context、CheckまたはDiff規則が混入していない。 | ERROR |

## 13. 正式対応表反映前Checklist

- [ ] 三MasterおよびScenario詳細設計書を入力元としている。
- [ ] 一行を一つのAPI呼出実体としている。
- [ ] 複合Keyが一意である。
- [ ] 同一API複数回呼出を別`apiCallCode`で表している。
- [ ] `callSequence`をIdentityとして扱っていない。
- [ ] `relationStatus`を正本から導出している。
- [ ] 順方向と逆方向の追跡が可能である。
- [ ] 未展開の有効Scenarioが存在しない。
- [ ] 対応表だけをJava実行仕様として使用していない。

## 14. 参照先

- 正式対応表：`system/02_master/API_UseCase_Scenario対応表.md`
- 設計規則：`system/02_master/design/API・UseCase・Scenario対応表設計書.md`
- API記入例：`system/02_master/examples/E6_API_Master_Example.md`
- UseCase記入例：`system/02_master/examples/UseCase_Master_Example.md`
- Scenario記入例：`system/02_master/examples/Scenario_Master_Example.md`

