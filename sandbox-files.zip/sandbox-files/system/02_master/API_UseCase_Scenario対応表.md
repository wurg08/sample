---
title: API・UseCase・Scenario対応表
document_id: TRC-E6-API-UC-SC-001
version: 2.0.0
status: Draft
document_type: Traceability View
system_name: E6 API Verification Platform
updated: 2026-07-25
---

# API・UseCase・Scenario対応表

## 1. 文書目的

本書は、E6 API Verification PlatformにおけるUseCase、ScenarioおよびScenario内のAPI呼出実体を、レビュー可能な形で相互追跡するためのTraceability Viewである。

本書の作成・更新規則は、`system/02_master/design/API・UseCase・Scenario対応表設計書.md`に従う。

## 2. 位置付け

1. 本書はレビュー対象となる正式成果物であるが、各項目の定義元ではない。
2. UseCase属性は`UseCase_Master.md`、Scenario属性は`Scenario_Master.md`、API属性は`E6_API_Master.md`を正本とする。
3. `callSequence`、`apiCallCode`、`callPurpose`および`executeCondition`はScenario詳細設計書を正本とする。
4. 1行は`scenarioId + apiCallCode`で識別される一つのAPI呼出実体を表す。
5. 本書だけを変更してJavaの実行順序または呼出先を変更してはならない。
6. 正本間に不一致がある場合、本書で値を補正せず、Validation Errorとして明示する。

## 3. 対応一覧

| useCaseId | useCaseName | scenarioId | scenarioName | scenarioType | callSequence | apiCallCode | apiId | apiName | callPurpose | executeCondition | scenarioDesignRef | apiDesignRef | relationStatus |
|---|---|---|---|---|---:|---|---|---|---|---|---|---|---|
| UC-E6-001 | 会員状態更新検証 | SC-E6-001 | 会員情報更新正常経路 | NORMAL | 10 | CALL-001 | API-001 | 会員情報取得API | 更新前会員情報取得 | ALWAYS | system/04_usecase_design/scenario/SC-E6-001設計書.md | system/03_api_design/API-001設計書.md | ACTIVE |
| UC-E6-001 | 会員状態更新検証 | SC-E6-001 | 会員情報更新正常経路 | NORMAL | 20 | CALL-002 | API-002 | 会員状態更新API | 会員状態更新 | CALL-001が業務正常 | system/04_usecase_design/scenario/SC-E6-001設計書.md | system/03_api_design/API-002設計書.md | INACTIVE |
| UC-E6-001 | 会員状態更新検証 | SC-E6-001 | 会員情報更新正常経路 | NORMAL | 30 | CALL-003 | API-001 | 会員情報取得API | 更新後会員情報再取得 | CALL-002が更新成功 | system/04_usecase_design/scenario/SC-E6-001設計書.md | system/03_api_design/API-001設計書.md | ACTIVE |

### 3.1 関係状態の判定根拠

| apiCallCode | UseCase | Scenario | API | relationStatus | 判定理由 |
|---|---|---|---|---|---|
| CALL-001 | enabled | enabled | enabled | ACTIVE | すべての参照元が`enabled=true`。 |
| CALL-002 | enabled | enabled | disabled | INACTIVE | `API-002`が`enabled=false`。 |
| CALL-003 | enabled | enabled | enabled | ACTIVE | すべての参照元が`enabled=true`。 |

`relationStatus`は手入力値ではなく、各正本の`enabled`から導出する。

## 4. 未展開Scenario

| scenarioId | Scenario名称 | enabled | 未展開理由 | 対応条件 |
|---|---|:---:|---|---|
| SC-E6-002 | 更新対象会員不存在経路 | false | Scenario詳細設計書が未完成であり、正式なAPI呼出実体が未定義。 | `apiCallCode`、`apiId`、順序、目的および実行条件の確定後に行を生成する。 |
| SC-E6-003 | 会員状態更新Timeout経路 | false | Scenario詳細設計書が未完成であり、正式なAPI呼出実体が未定義。 | Timeout対象呼出、Retry、停止およびSkip条件の確定後に行を生成する。 |

未展開Scenarioに対して、件数を満たす目的でAPI呼出行を推測作成してはならない。

## 5. Traceability確認

### 5.1 順方向

```text
UC-E6-001
└─ SC-E6-001
   ├─ CALL-001 → API-001
   ├─ CALL-002 → API-002
   └─ CALL-003 → API-001
```

### 5.2 逆方向

| apiId | 参照Scenario | 呼出実体 | 呼出回数 | 状態 |
|---|---|---|---:|---|
| API-001 | SC-E6-001 | CALL-001、CALL-003 | 2 | ACTIVE |
| API-002 | SC-E6-001 | CALL-002 | 1 | INACTIVE |

同一APIを複数回呼び出しても、API MasterのAPIレコードは1件のままとする。

## 6. Coverage

| 指標 | 算出値 | 判定 | 備考 |
|---|---:|---|---|
| 登録UseCase数 | 1 | 情報 | 7業務Flowの分析完了後に増補する。 |
| 登録Scenario数 | 3 | 情報 | 有効1、無効2。 |
| API呼出行を持つScenario数 | 1 | PASS | 有効Scenarioは1件。 |
| 対応表行数 | 3 | 情報 | SC-E6-001の3呼出。 |
| 参照API数 | 2 | 情報 | API-001、API-002。 |
| ACTIVE関係数 | 2 | 情報 | CALL-001、CALL-003。 |
| INACTIVE関係数 | 1 | ERROR | 有効Scenarioが無効APIを参照している。 |
| 未展開Scenario数 | 2 | PASS | いずれも`enabled=false`。 |

Coverage値は品質の充足を自動的に意味しない。対象業務、異常経路およびAPI全数が確定した後、別途Coverage基準と照合する。

## 7. 整合性Validation

| Validation ID | 確認内容 | 判定 | 処置 |
|---|---|---|---|
| TRC-V001 | 正式14表示項目が全行に存在すること。 | PASS | なし |
| TRC-V002 | `scenarioId + apiCallCode`が一意であること。 | PASS | なし |
| TRC-V003 | `callSequence`がScenario内で一意の正整数であること。 | PASS | なし |
| TRC-V004 | UseCaseおよびScenario参照が各Masterで解決できること。 | PASS | なし |
| TRC-V005 | API参照がAPI Masterで解決できること。 | PASS | なし |
| TRC-V006 | UseCase Masterの`scenarioIds`とScenario Masterの逆参照が一致すること。 | PASS | なし |
| TRC-V007 | 有効Scenarioが1件以上のAPI呼出行を持つこと。 | PASS | なし |
| TRC-V008 | 有効Scenarioが`enabled=false`のAPIを参照しないこと。 | ERROR | `API-002`の仕様・詳細設計・Endpointを確認し、有効化するか、SC-E6-001を無効化して設計を修正する。 |
| TRC-V009 | `scenarioDesignRef`および`apiDesignRef`の参照先が存在すること。 | 要確認 | 詳細設計ファイル作成後にBuild Validationを実施する。 |
| TRC-V010 | 対応表の呼出情報がScenario詳細設計書と一致すること。 | 要確認 | SC-E6-001詳細設計書の完成後に再生成・照合する。 |

`TRC-V008`が解消されるまで、本書をRelease状態へ変更してはならない。

## 8. 要確認事項

| Issue ID | 確認事項 | 影響 | 確認元 | 状態 |
|---|---|---|---|---|
| TRC-ISSUE-001 | `API-002`を有効化できる正式仕様、EndpointおよびAPI詳細設計 | SC-E6-001実行可否 | 現行API仕様／API詳細設計書 | Open |
| TRC-ISSUE-002 | SC-E6-001の正式Scenario詳細設計書 | 呼出定義の正本確認 | UseCase／Scenario設計 | Open |
| TRC-ISSUE-003 | SC-E6-002の正式API呼出経路 | Alternative経路Coverage | 業務担当／Scenario設計 | Open |
| TRC-ISSUE-004 | SC-E6-003のTimeout対象、Retry、停止およびSkip条件 | Timeout経路Coverage | API仕様／共通Framework | Open |
| TRC-ISSUE-005 | 残り6業務FlowのUseCase、ScenarioおよびAPI関係 | 全体Coverage | BA分析書×Scenario一覧 | Open |

## 9. 更新規則

1. API、UseCase、ScenarioまたはScenario詳細設計の変更後に本表を再生成する。
2. 同一`scenarioId + apiCallCode`が別の`apiId`へ変わった場合は、単純な表示差分ではなく呼出先変更としてレビューする。
3. 呼出順序だけを変更する場合、同一目的の`apiCallCode`は維持する。
4. 無効化された関係は監査・履歴要件を確認せず物理削除しない。
5. 対応表の手修正結果を正本またはJava実装へ逆反映しない。

## 10. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| 2.0.0 | 2026-07-25 | 新対応表設計の正式14表示項目で再構成。SC-E6-001の3呼出を展開し、API-002無効による不整合を明示。 |
