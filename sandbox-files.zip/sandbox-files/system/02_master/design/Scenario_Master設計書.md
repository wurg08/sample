---
documentId: E6-API-VAL-MST-SC-DESIGN
title: Scenario Master設計書
version: 1.0.0-draft.1
status: DRAFT
lastUpdated: 2026-07-25
---

# Scenario Master設計書

## 1. 文書情報

| 項目 | 内容 |
|---|---|
| 文書名 | Scenario Master設計書 |
| 文書ID | `E6-API-VAL-MST-SC-DESIGN` |
| 対象システム | E6 API Verification Platform |
| 対象Master | `system/02_master/Scenario_Master.md` |
| 文書種別 | Master詳細設計書 |
| 版数 | `1.0.0-draft.1` |
| 文書状態 | `DRAFT` |
| 最終更新日 | 2026-07-25 |
| 作成責任 | Verification Platform Team |
| レビュー責任 | System Architect / Scenario Design Lead / Runtime Lead / Test Lead |
| 承認責任 | System Owner / Business Owner |

## 2. 改訂履歴

| 版数 | 日付 | 変更内容 | 状態 |
|---|---|---|---|
| `1.0.0-draft.1` | 2026-07-25 | 同期Java Batchを実行単位とする新Scenarioモデルに基づき全面再作成 | DRAFT |

## 3. 目的

本書は、E6 API Verification Platformで使用するScenario Masterの責務、管理項目、記述形式、実行単位、整合性規則、変更管理および関連成果物との境界を定義する。

Scenario Masterは、UseCaseを実行可能な一つの確定した業務経路へ具体化し、次の問いに対する正本を提供する。

- どのScenarioが存在するか。
- どのUseCaseに所属するか。
- 正常、異常、境界等のどの経路種別か。
- どのJava ClassがScenarioを実行するか。
- 初期Inputはどこに定義されるか。
- Expectedはどこに定義されるか。
- Scenario詳細設計書はどこにあるか。
- 現在実行可能なScenarioか。

Scenario Masterは、API呼出明細、Contextの全項目、Expected値、`resultKey`一覧または実行結果を保持するものではない。

## 4. Scenarioの定義

本システムにおけるScenarioは、次の条件をすべて満たす単位とする。

1. 一つのUseCaseに所属する。
2. 一つの明確な業務経路を表す。
3. 開始条件、入力Pattern、分岐経路および期待終了状態を一意に説明できる。
4. 一回の起動で開始から終了まで同期実行される。
5. 一つのJava Scenario実行Classに対応する。
6. API呼出、Check、Snapshotおよび結果を一つのScenario実行結果として集約できる。
7. 同一Inputと同一前提状態から、同じ経路を再現できる。

ScenarioはTestCase一項目ではない。Responseの一フィールドに対する必須、型、桁数または固定値Checkだけを理由にScenarioを分割してはならない。

## 5. 適用範囲

本書は、7業務Flowおよび最大10件程度のUseCase配下で実行するすべてのScenarioに適用する。

対象となる代表的な経路は次のとおりである。

- 正常終了経路
- 代替正常経路
- 業務Error終了経路
- 入力Validation Error経路
- 0件、1件、複数件のResponse経路
- 最小値、最大値、境界超過経路
- API途中終了経路
- 条件により後続APIをSkipする経路
- Timeoutまたは通信Errorを期待する経路
- 前段APIのResponseを後段APIのRequestへ引き継ぐ経路
- 同一APIを同一Scenario内で複数回呼び出す経路

単なるEnvironment差異はScenarioを分割する理由としない。Environmentごとの差異はEnvironment Masterおよび実行設定で解決する。

## 6. 基本原則

| 原則ID | 原則 | 説明 |
|---|---|---|
| `SC-MST-P001` | 1経路1 Scenario | 分岐条件と期待終了状態が確定した一つの経路を一つのScenarioとする。 |
| `SC-MST-P002` | 1 Scenario 1同期Batch | 一回のScenario起動は一つのJava処理として同期完了する。 |
| `SC-MST-P003` | 1 Scenario 1 UseCase | Scenarioは必ず一つのUseCaseにのみ所属する。 |
| `SC-MST-P004` | Masterと実行詳細の分離 | Masterは概要と参照を管理し、API呼出明細はScenario詳細設計に置く。 |
| `SC-MST-P005` | API定義と呼出実体の分離 | `apiId`はAPI Master、`apiCallCode`はScenario詳細設計で管理する。 |
| `SC-MST-P006` | Input／Expectedの外部化 | 初期入力と期待値はScenario単位ファイルを参照し、Masterへ直接埋め込まない。 |
| `SC-MST-P007` | Stable Keyによる結果照合 | Check結果はJavaが明示する`resultKey`でPrevious／Current／Expectedを対応付ける。 |
| `SC-MST-P008` | 実行順序と結果Identityの分離 | `sequence`は表示順、`resultKey`は結果Identityとして扱う。 |
| `SC-MST-P009` | 実行結果を保持しない | Run情報、Response、DiffおよびCheck結果をMasterへ保存しない。 |
| `SC-MST-P010` | 物理削除を原則禁止する | 利用停止Scenarioは削除せず、`enabled=false`として履歴を保持する。 |

## 7. Scenario粒度

### 7.1 新しいScenarioとする差異

次のいずれかが異なる場合は、原則として別Scenarioとする。

| 判断観点 | 例 |
|---|---|
| 通過する業務分岐 | 会員あり経路／会員なし経路 |
| API呼出経路 | API-003を呼ぶ経路／Skipする経路 |
| 期待終了状態 | 正常完了／業務Error完了 |
| Input Pattern | 必須値あり／必須値なし |
| Response Pattern | 0件／1件／複数件 |
| 境界Pattern | 最大値以内／最大値超過 |
| 障害Pattern | 正常応答／Timeout |
| 副作用範囲 | 参照のみ／更新あり |

### 7.2 新しいScenarioとしない差異

| 差異 | 取扱い |
|---|---|
| Responseの一フィールドだけをCheckする | 同一Scenario内のBusiness Checkとする。 |
| 同じ経路でTest Dataの実値だけが異なる | Input／Test DataのVariationとして扱う。必要時はTestCaseを分ける。 |
| 実行日、Run IDが異なる | RunContextで扱う。 |
| Environmentが異なる | Environment MasterおよびRuntime設定で扱う。 |
| Base URL、Credentialが異なる | Environment設定で扱う。 |
| 比較除外フィールドが異なる | `apiId`既定または`apiCallCode`固有のJava比較定義で扱う。 |
| Report表示名だけが異なる | Report定義で扱う。 |

### 7.3 UseCaseとの境界

```text
UseCase
    一つの業務目的と業務範囲

Scenario
    その目的を確認する一つの具体的な実行経路

TestCase／Check
    Scenario内で確認する個別条件または判定
```

業務目的そのものが変わる場合はUseCaseを分ける。目的は同じで経路または期待終了状態が変わる場合はScenarioを分ける。

## 8. 責務

Scenario Masterは、次の情報を管理する。

1. Scenarioの固定識別子
2. 所属UseCase
3. Scenario名称
4. Scenario種別
5. Java Scenario実行Class
6. Scenario Inputファイルへの参照
7. Scenario Expectedファイルへの参照
8. Scenario詳細設計書への参照
9. Scenarioの有効・無効状態
10. 業務経路概要

Scenarioを参照する側は`scenarioId`を使用する。Scenario名称、Java Class名または表示順を外部参照キーとして使用してはならない。

## 9. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| APIの固定属性、Method、Endpoint、DTO | API MasterおよびAPI詳細設計書 |
| `apiCallCode`、`apiId`、API呼出順序 | Scenario詳細設計書および対応表 |
| Request初期値 | `inputRef`が示すScenario Input |
| 前段Responseから後段Requestへの値引継ぎ | Scenario詳細設計書およびJava実装 |
| Contextの全項目と更新処理 | Scenario詳細設計書およびJava実装 |
| Expected値 | `expectedRef`が示すExpectedファイル |
| `resultKey`一覧、Check順序 | Scenario詳細設計書およびJava実装 |
| 業務必須、非空、型、桁数、固定値、Enum、状態遷移判定 | API詳細設計、Business CheckおよびJava実装 |
| `IGNORE_FIELD`、`IGNORE_VALUE` | API専用Java比較定義およびAPIレスポンスDiff設計書 |
| Retry、共通Timeout、並列数 | 共通実行設計およびRuntime設定 |
| 実行頻度、起動時刻 | Scheduler／運用設計 |
| Run ID、実行日時、実行中Status | RunContext |
| Request／Response実値、Snapshot | 実行成果物 |
| Previous／Current／Expected比較結果 | DiffおよびVerification Result |
| Report Layout | Report設計 |

Scenario Masterへ実装上便利であることだけを理由に、API呼出明細またはCheck明細の列を追加してはならない。

## 10. 関連成果物と責務境界

```mermaid
flowchart TD
    U["UseCase Master<br/>業務目的"]
    S["Scenario Master<br/>経路概要・実装参照"]
    D["Scenario詳細設計<br/>API呼出・Input・Check"]
    J["Java Scenario Class<br/>同期実行"]
    R["実行成果物<br/>Snapshot・Diff・Result"]

    U --> S
    S --> D
    D --> J
    J --> R
```

| 成果物 | Scenario Masterとの関係 | 正本関係 |
|---|---|---|
| `Business_Master.md` | UseCaseを介して上位Businessを追跡する。 | 直接参照しない |
| `UseCase_Master.md` | 所属UseCaseおよびScenario逆引き一覧を提供する。 | `useCaseId`の参照先 |
| `E6_API_Master.md` | Scenarioで呼び出すAPIの固定定義を提供する。 | `apiId`の参照先 |
| `Environment_Master.md` | 実行Environmentの固定識別と接続設定を提供する。 | Masterレコードから直接参照しない |
| `Scenario_Master.md` | Scenario概要と実装・Input・Expected・設計書参照を登録する。 | Scenario自身の正本 |
| `API_UseCase_Scenario対応表.md` | UseCase、Scenario、APIのTraceabilityを表示する。 | 関係情報のView |
| Scenario詳細設計書 | API呼出順序、分岐、値引継ぎ、Check、出力を定義する。 | 実行仕様の正本 |
| Scenario Input | 初期入力値およびTest Data参照を定義する。 | 初期Inputの正本 |
| Scenario Expected | Batch期待結果および`resultKey`別期待結果を定義する。 | Expectedの正本 |
| Java Scenario Class | Scenario詳細設計を同期実行し、結果を明示的に出力する。 | 実行実装 |
| APIレスポンスDiff設計書 | API Responseの構造・値差分と無視判定を定義する。 | Diff仕様の正本 |

### 10.1 Scenario所属の正本規則

Scenarioの親UseCaseは`Scenario_Master.md`の`useCaseId`を正本とする。

`UseCase_Master.md`の`scenarioIds`はレビュー用の必須逆引き一覧であり、次の関係を常に満たさなければならない。

```text
UseCase_Master.scenarioIds
    =
Scenario_Masterで同一useCaseIdを持つ有効・無効ScenarioのscenarioId集合
```

不一致時は自動補正せず、Master整合性Errorとする。

## 11. Scenario定義モデル

### 11.1 正式レコード

`Scenario_Master.md`では、1行を1 Scenarioの正式レコードとする。

| No. | 表示名 | 列名 | 型 | 必須 | 設定規則 |
|---:|---|---|---|:---:|---|
| 1 | Scenario ID | `scenarioId` | String | Yes | `SC-E6-NNN`形式。一意かつ不変。 |
| 2 | UseCase ID | `useCaseId` | String | Yes | `UseCase_Master.md`に存在するID。 |
| 3 | Scenario名称 | `scenarioName` | String | Yes | 入力条件、経路または期待結果を識別できる名称。 |
| 4 | Scenario種別 | `scenarioType` | Enum | Yes | 本書11.4の標準値から選択する。 |
| 5 | 実行Class | `executionClass` | String | Yes | Java Scenario実行Classの完全修飾名。 |
| 6 | Input参照 | `inputRef` | Path | Yes | Repository Root基準のScenario Input相対Path。 |
| 7 | Expected参照 | `expectedRef` | Path | Yes | Repository Root基準のScenario Expected相対Path。 |
| 8 | Scenario設計書参照 | `scenarioDesignRef` | Path | Yes | Repository Root基準のScenario詳細設計書相対Path。 |
| 9 | 有効フラグ | `enabled` | Boolean | Yes | `true`または`false`。 |
| 10 | 業務経路概要 | `description` | String | Yes | 開始条件、主要経路、期待終了状態を一文で記述する。 |

### 11.2 記述形式

```markdown
| scenarioId | useCaseId | scenarioName | scenarioType | executionClass | inputRef | expectedRef | scenarioDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|---:|---|
| SC-E6-001 | UC-E6-001 | 会員情報更新正常経路 | NORMAL | com.example.e6.scenario.MemberUpdateScenario | system/04_usecase_design/input/SC-E6-001-input.json | system/04_usecase_design/expected/SC-E6-001-expected.json | system/04_usecase_design/scenario/SC-E6-001設計書.md | true | 会員情報を取得し、更新後に再照会して更新結果を確認する。 |
```

### 11.3 ID階層

| 識別子 | 意味 | 定義場所 | Scope |
|---|---|---|---|
| `useCaseId` | 業務検証目的 | UseCase Master | 全システム |
| `scenarioId` | 確定した業務実行経路 | Scenario Master | 全システム |
| `apiId` | API固定定義 | API Master | 全システム |
| `apiCallCode` | Scenario内のAPI呼出実体 | Scenario詳細設計 | Scenario内 |
| `resultKey` | Check結果の安定Identity | Scenario Java／Expected | Scenario内 |
| `runId` | 一回の実行 | RunContext | Runtime |

`useCaseId`から`apiCallCode`または`resultKey`を直接解決してはならない。必ず`scenarioId`を介して解決する。

### 11.4 Scenario種別

標準値は次のとおりとする。

| 値 | 説明 |
|---|---|
| `NORMAL` | 主正常経路 |
| `ALTERNATIVE` | 業務目的を満たす代替正常経路 |
| `ABNORMAL` | 業務Error、Validation Error、通信Error等を期待する経路 |
| `BOUNDARY` | 最大、最小、直前、直後等の境界経路 |
| `EMPTY` | 0件、空配列、空文字等の経路 |
| `MULTIPLE` | 複数件、複数要素等の経路 |
| `CONDITIONAL` | 分岐またはSkipを主目的とする経路 |
| `TIMEOUT` | Timeoutを期待する経路 |
| `RECOVERY` | 再実行または復旧確認経路 |

必要な区分がない場合は、Master共通設計の変更手続を経て標準値を追加する。自由記述値を使用してはならない。

## 12. 項目別設計規則

### 12.1 Scenario ID

- 形式は`SC-E6-NNN`とする。
- 初回登録後は変更しない。
- 欠番を許容し、無効化または廃止した番号を再利用しない。
- UseCase変更時もIDを流用せず、業務経路の同一性が失われる場合は新規採番する。
- Environment名、Version、日付を含めない。

Pattern:

```regex
^SC-E6-[0-9]{3}$
```

### 12.2 UseCase ID

- `UseCase_Master.md`に存在する`useCaseId`を設定する。
- 一つのScenarioに複数の`useCaseId`を設定しない。
- 親UseCaseが`enabled=false`の場合、Scenarioを新規実行対象にしてはならない。
- 親UseCase変更は単純な表示変更ではなく、業務目的と経路の再レビューを必要とする。

### 12.3 Scenario名称

- 条件、経路または期待結果が判別できる日本語名称とする。
- 「正常系1」「異常系A」「Pattern 2」のような識別不能名称を使用しない。
- Environment名、実行日、担当者名を含めない。
- 名称は変更可能だが、参照キーとして使用しない。

### 12.4 実行Class

- `ScenarioExecutor`等の共通実行Interfaceを実装するConcrete Classを設定する。
- 完全修飾Class名を使用する。
- Classは`scenarioId`に対する同期実行入口を一つ提供する。
- 同一Classによる複数Scenarioの実装は許容するが、入力、Expectedおよび経路差異を明示的に分離できること。
- Class名をResult照合Keyとして使用しない。
- Master Load時または起動前ValidationでClassの存在とInterface実装を検証する。

### 12.5 Input参照

- Scenario開始時に必要な初期値だけを定義するファイルを参照する。
- 前段API Responseから取得できる値を初期Inputへ重複定義しない。
- Credential、TokenまたはSecret実値を含めない。
- Environment依存値はEnvironment設定から解決する。
- `scenarioId`とInput内のScenario識別が一致しなければならない。

### 12.6 Expected参照

- Scenario全体の期待終了結果と、`resultKey`別期待結果を定義するファイルを参照する。
- ExpectedはJava変数名、配列位置または実行順序でCheck結果を参照してはならない。
- Expected内部の各KeyはJavaが出力する`resultKey`と一致しなければならない。
- Input値、比較除外フィールド定義またはRuntime実績値をExpectedへ混在させない。

Expectedの最小概念例:

```json
{
  "scenarioId": "SC-E6-001",
  "batchExpectedResult": "PASS",
  "expectedResults": {
    "API1_RESPONSE": "PASS",
    "API1_MEMBER_STATUS": "PASS",
    "API2_UPDATE_RESULT": "PASS",
    "API1_API2_CONSISTENCY": "PASS"
  }
}
```

### 12.7 Scenario設計書参照

- API呼出、値引継ぎ、分岐、Checkおよび出力の実行仕様を一意に追跡できるPathを設定する。
- 存在しないPathまたはフォルダだけを設定してはならない。
- Scenario設計書の`scenarioId`はMasterと一致しなければならない。

### 12.8 有効フラグ

- `enabled=true`は、設計、Input、Expected、Java Classおよび利用APIが実行可能な状態であることを表す。
- 一時的な実行選択除外を理由に`enabled=false`へ変更しない。実行対象選択はExecution Specで扱う。
- 廃止時は物理削除せず`enabled=false`とする。

### 12.9 業務経路概要

- 「開始条件 → 主要処理 → 期待終了状態」が理解できる一文とする。
- APIの全StepまたはCheck項目を列挙しない。
- 実行実績、日付または一時的な障害情報を記載しない。

## 13. Scenario実行設計

### 13.1 同期Batch境界

一回のScenario実行は、次の処理を一つの同期Batch境界として完了する。

```mermaid
flowchart TD
    L["Master・Input・Expected読込"]
    A["API呼出とContext更新"]
    C["Check・Diff実行"]
    O["結果・Snapshot出力"]
    E["Scenario終了Status返却"]

    L --> A
    A --> C
    C --> O
    O --> E
```

- 起動元は`scenarioId`を一つ指定する。
- Java実行Classは完了、業務上の期待Error、Skipまたは実行Errorまで同期して返却する。
- APIの非同期受付を利用する場合も、Scenario設計で定めた状態照会または終了条件までを同一Scenario実行内で扱う。
- 後続の別Scenarioを暗黙に起動しない。
- 一回のRunで複数Scenarioを実行する場合も、各Scenario結果は独立して識別・保存する。

### 13.2 API呼出定義

API呼出明細はScenario Masterではなく、Scenario詳細設計書に次の最小項目を定義する。

| 項目 | 説明 |
|---|---|
| `apiCallCode` | Scenario内で一意かつ安定したAPI呼出Identity |
| `callSequence` | 標準経路における呼出表示順 |
| `apiId` | API Masterへの参照 |
| `callPurpose` | 呼出目的 |
| `executeCondition` | 呼出条件 |
| `inputSource` | InputまたはContextからの値取得元 |
| `outputTarget` | ResponseのContext格納先 |
| `onError` | 停止、継続または期待Error処理 |

例:

```markdown
| apiCallCode | callSequence | apiId | callPurpose | executeCondition |
|---|---:|---|---|---|
| CALL-001 | 10 | API-001 | 更新前会員情報取得 | ALWAYS |
| CALL-002 | 20 | API-002 | 会員情報更新 | CALL-001が業務正常 |
| CALL-003 | 30 | API-001 | 更新後会員情報再取得 | CALL-002が更新成功 |
```

同一`apiId`を複数回呼び出す場合も、`apiCallCode`は呼出実体ごとに分ける。

### 13.3 分岐とSkip

- `callSequence`は標準表示順であり、分岐条件そのものではない。
- 実行可否は`executeCondition`とJava実装で判定する。
- 実行しなかったAPI呼出は、理由とともに`SKIPPED`として記録する。
- 想定外に実行されなかった呼出と、設計上のSkipを区別する。
- 分岐により期待終了状態が異なる場合は、原則としてScenarioを分ける。

### 13.4 InputとContext

```text
Scenario Input
    実行開始前に与える初期値

Scenario Context
    実行中にJavaが保持・更新する値

API Request
    InputまたはContextから組み立てる呼出単位の値
```

- Inputは開始値、Contextは実行中の受渡し値として分離する。
- 前段Responseから後段Requestへの値引継ぎはJavaが明示的に実装する。
- ContextはScenario実行Scopeを越えて暗黙共有しない。
- 別Scenarioへ値を渡す必要がある場合は、正式な外部データまたは実行成果物を介する。

### 13.5 Check結果と`resultKey`

JavaはCheck結果を生成する時点で、安定した`resultKey`を必ず明示する。

```text
useCaseId + scenarioId + resultKey
```

が結果の完全Identityとなる。

`resultKey`は次の照合に使用する。

```text
Previous Result
        ↕
Current Result  ← resultKey →  Expected Result
```

次の値を照合Keyとして使用してはならない。

- 配列位置
- Java Method名
- Java Class名
- Report表示名
- `sequence`

### 13.6 Check順序

| 項目 | 役割 |
|---|---|
| `sequence` | 当該RunでJavaが結果を出力した順序。Report表示用。 |
| `resultKey` | Previous／Current／Expectedを対応させる安定Identity。 |
| `resultName` | 利用者向け表示名称。変更可能。 |
| `relatedApiCallCodes` | Checkが参照したAPI呼出。所属を表すものではない。 |

CheckはJavaの実際の実行位置で順に出力する。API単位へ強制的に再分類してはならない。

複数APIにまたがるCheckは、いずれか一つのAPIへ所属させず、独立した`resultKey`を付与する。

例:

```json
{
  "sequence": 5,
  "resultKey": "API1_API2_CONSISTENCY",
  "resultName": "API間データ整合性チェック",
  "relatedApiCallCodes": ["CALL-001", "CALL-002"],
  "currentResult": "PASS"
}
```

### 13.7 Scenario終了結果

Scenario終了結果は少なくとも次を区別する。

| 結果 | 意味 |
|---|---|
| `PASS` | Expectedどおりに完了した。期待するError経路を含む。 |
| `FAIL` | 実行は完了したが、ExpectedまたはBusiness Checkと不一致。 |
| `ERROR` | 実行基盤、通信、予期しない例外等で判定不能。 |
| `SKIPPED` | 前提未成立または実行選択により実行しなかった。 |

異常Responseを期待するScenarioでは、期待するError CodeおよびExpectedを満たした場合に`PASS`となる。

## 14. Scenario出力範囲

### 14.1 出力単位

一回のScenario実行では、少なくとも次を追跡可能にする。

```text
runId
└── useCaseId
    └── scenarioId
        ├── apiCallCode
        └── resultKey
```

### 14.2 論理出力構造

```text
outputs/runs/{runId}/{useCaseId}/{scenarioId}/
├── scenario-execution.json
├── verification-result.json
├── api-calls/
│   └── {apiCallCode}/
│       ├── request.json
│       ├── response.json
│       └── response-field-diff.json
└── logs/
    └── scenario.log
```

物理配置の正本はファイル入出力設計書で確定する。本書では、`scenarioId`、`apiCallCode`および`resultKey`により相互追跡できることを必須とする。

### 14.3 `verification-result.json`

結果はJavaの実行順に保持し、各Entryが安定した`resultKey`を持つ。

```json
{
  "runId": "RUN-20260725-001",
  "useCaseId": "UC-E6-001",
  "scenarioId": "SC-E6-001",
  "scenarioResult": "PASS",
  "results": [
    {
      "sequence": 1,
      "resultKey": "API1_RESPONSE",
      "currentResult": "PASS",
      "expectedResult": "PASS",
      "verificationResult": "PASS"
    }
  ]
}
```

### 14.4 API Response Diff

- API ResponseのPrevious／Current比較は`apiCallCode`単位で出力する。
- API既定の比較定義は`apiId`単位でJavaに保持する。
- Scenario固有の上書きは`apiCallCode`単位で行う。
- `IGNORE_FIELD`は対象Field全体を比較対象外とする。
- `IGNORE_VALUE`は存在性、型等を確認できるが、値変化を有効差異に数えない。
- 実際の変化は消去せず、`comparisonStatus=IGNORED`として記録する。
- 無視された変化は`effectiveChanged=false`とする。

```json
{
  "detectedChangeType": "VALUE_CHANGED",
  "comparisonStatus": "IGNORED",
  "effectiveChanged": false
}
```

これらの比較定義をScenario MasterまたはExpectedへ埋め込んではならない。

## 15. Validation・整合性規則

### 15.1 レコードValidation

| Rule ID | 規則 | Level |
|---|---|---|
| `SC-MST-V001` | 必須10項目がすべて設定されていること。 | ERROR |
| `SC-MST-V002` | `scenarioId`がPatternに一致すること。 | ERROR |
| `SC-MST-V003` | `scenarioId`が全Scenarioで一意であること。 | ERROR |
| `SC-MST-V004` | `scenarioType`が標準Enumに含まれること。 | ERROR |
| `SC-MST-V005` | `enabled`がBooleanであること。 | ERROR |
| `SC-MST-V006` | Path参照がRepository Root基準の相対Pathであること。 | ERROR |
| `SC-MST-V007` | 名称と概要が空文字でないこと。 | ERROR |

### 15.2 参照整合性

| Rule ID | 規則 | Level |
|---|---|---|
| `SC-MST-V101` | `useCaseId`がUseCase Masterに存在すること。 | ERROR |
| `SC-MST-V102` | UseCase Masterの`scenarioIds`と所属関係が双方向に一致すること。 | ERROR |
| `SC-MST-V103` | `executionClass`が存在し、共通Scenario実行Interfaceを実装すること。 | ERROR |
| `SC-MST-V104` | `inputRef`が存在し、Input内`scenarioId`が一致すること。 | ERROR |
| `SC-MST-V105` | `expectedRef`が存在し、Expected内`scenarioId`が一致すること。 | ERROR |
| `SC-MST-V106` | `scenarioDesignRef`が存在し、設計書内`scenarioId`が一致すること。 | ERROR |
| `SC-MST-V107` | Scenario詳細設計の全`apiId`がAPI Masterに存在すること。 | ERROR |
| `SC-MST-V108` | Scenario内の`apiCallCode`が一意であること。 | ERROR |
| `SC-MST-V109` | Expectedの全`resultKey`がJava出力可能Keyとして定義されること。 | ERROR |
| `SC-MST-V110` | Java出力対象の必須`resultKey`がExpectedから欠落しないこと。 | ERROR |

### 15.3 実行可否Validation

`enabled=true`のScenarioは、次をすべて満たさなければならない。

1. 親UseCaseが`enabled=true`である。
2. Input、ExpectedおよびScenario詳細設計書が存在する。
3. Java実行Classを解決できる。
4. 利用する全APIが`enabled=true`である。
5. API呼出経路にEntryと終了条件が存在する。
6. `apiCallCode`が重複していない。
7. 必須`resultKey`とExpectedが一致する。
8. Secret実値がInputまたはExpectedに含まれていない。

一つでも満たさない場合は、Runtimeで推測補完せず起動前Errorとする。

## 16. Runtime読込・実行フロー

Runtimeは次の順序でScenarioを解決する。

1. 起動要求から`scenarioId`を取得する。
2. Scenario Masterからレコードを一意に取得する。
3. `enabled=true`を確認する。
4. `useCaseId`をUseCase Masterで解決する。
5. `scenarioDesignRef`から実行経路を読み込む。
6. Scenario詳細設計の`apiId`をAPI Masterで解決する。
7. `inputRef`から初期Inputを読み込む。
8. `expectedRef`からExpectedを読み込む。
9. `executionClass`を生成し、同期実行する。
10. API呼出ごとに`apiCallCode`を付与してSnapshotとDiffを出力する。
11. Checkごとに`resultKey`と`sequence`を付与する。
12. ExpectedおよびPreviousと照合する。
13. Scenario終了結果と成果物を確定する。

```text
scenarioId
├── useCaseId
├── executionClass
├── inputRef
├── expectedRef
└── scenarioDesignRef
    ├── apiCallCode → apiId
    ├── callSequence
    ├── branch／skip
    └── resultKey
```

## 17. 変更管理

### 17.1 変更影響分類

| 変更 | 取扱い | 主な影響先 |
|---|---|---|
| 名称・概要修正 | 同一Scenarioの軽微変更 | Master、Report表示 |
| `scenarioType`変更 | 分類変更としてレビュー | Master、Scenario一覧 |
| Input値変更 | 経路不変なら同一Scenario | Input、Test Data |
| Expected変更 | 業務期待変更としてレビュー | Expected、Check、Report |
| API呼出順序変更 | 実行仕様変更 | Scenario設計、Java、対応表 |
| API追加・削除 | 経路変更 | Scenario設計、Java、対応表、Output |
| 分岐・期待終了状態変更 | Scenario同一性を再判定 | Master、新Scenario採番候補 |
| `executionClass`変更 | 実装差替え | Java、回帰試験 |
| `resultKey`変更 | 互換性影響あり | Expected、Previous、Diff、Report |
| `apiCallCode`変更 | Snapshot／Diff追跡影響あり | Scenario設計、Java、成果物 |
| 利用停止 | `enabled=false` | Execution Spec、運用 |

### 17.2 新規Scenario追加

1. 親UseCaseと業務目的を確認する。
2. 既存Scenarioとの差異が経路差異か、Check差異だけかを判定する。
3. `scenarioId`を新規採番する。
4. Scenario Masterレコードを作成する。
5. Input、ExpectedおよびScenario詳細設計書を作成する。
6. `apiCallCode`、呼出順序、分岐およびCheckを設計する。
7. Java Scenario Classを実装する。
8. UseCase Masterの`scenarioIds`を更新する。
9. API・UseCase・Scenario対応表を更新する。
10. Master整合性試験とScenario回帰試験を実施する。

### 17.3 廃止

- Scenarioを物理削除しない。
- `enabled=false`へ変更する。
- UseCase Masterの逆引き一覧には履歴追跡のため残す。
- 新規Execution Specから選択できないようにする。
- 既存Run、Snapshot、DiffおよびReportからの参照を維持する。

## 18. 禁止事項

次を禁止する。

1. 一つのScenarioに相互排他的な複数経路を詰め込む。
2. 一つのCheck項目だけを理由にScenarioを作る。
3. Scenario MasterへAPI Step明細を埋め込む。
4. `apiId`と`apiCallCode`を同一Identityとして扱う。
5. API呼出を配列位置だけで識別する。
6. Expectedを実行順序またはJava Method名で参照する。
7. `sequence`をPrevious／Expected照合Keyとして使用する。
8. 複数APIにまたがるCheckを一つのAPIへ強制所属させる。
9. InputへSecret、CredentialまたはEnvironment固有URLを記載する。
10. Expectedへ比較除外定義を混在させる。
11. Scenario MasterへRun実績またはDiff結果を保存する。
12. 廃止ScenarioのIDを再利用する。
13. Runtimeで不正なMaster参照を暗黙補完する。
14. 廃止済みのContext／Verification／Verification Policy／Compare Policy Masterを参照する。

## 19. Review Checklist

### 19.1 Scenario粒度

- [ ] 一つの業務経路として開始から終了まで説明できる。
- [ ] 親UseCaseの業務目的を具体化している。
- [ ] 相互排他的な分岐を一つに混在させていない。
- [ ] 単一フィールドCheckだけをScenario化していない。
- [ ] Input、経路および期待終了状態が明確である。

### 19.2 Master項目

- [ ] 正式10項目がすべて設定されている。
- [ ] `scenarioId`が一意かつ規則に一致する。
- [ ] `useCaseId`が存在し、逆引き一覧と一致する。
- [ ] `executionClass`、`inputRef`、`expectedRef`、`scenarioDesignRef`を解決できる。
- [ ] `enabled`の状態が関連成果物の準備状態と一致する。

### 19.3 実行・結果

- [ ] 一回の起動が一つの同期Scenario Batchとして完了する。
- [ ] 各API呼出に安定した`apiCallCode`がある。
- [ ] 同一APIの複数回呼出を別`apiCallCode`で識別している。
- [ ] 呼出順序、分岐、Skipおよび停止条件がScenario詳細設計にある。
- [ ] 各Checkに安定した`resultKey`がある。
- [ ] `sequence`と`resultKey`の責務を混同していない。
- [ ] 複数APIにまたがるCheckが独立した結果として出力される。
- [ ] Outputから`runId`、`useCaseId`、`scenarioId`、`apiCallCode`、`resultKey`を追跡できる。

### 19.4 責務境界

- [ ] API固定属性を重複定義していない。
- [ ] Context項目、Expected値、Check一覧をMasterへ埋め込んでいない。
- [ ] Baseline、Diff、Ignore RuleをMasterへ埋め込んでいない。
- [ ] 廃止済みのMasterを参照していない。
- [ ] 対応表を実行仕様の唯一の正本として誤用していない。

## 20. 完了条件

本書は次をすべて満たした時点で`APPROVED`とする。

1. Scenarioの粒度と同期Batch境界が承認されている。
2. 正式10項目が承認されている。
3. API MasterおよびUseCase Masterとの責務境界が一致している。
4. `scenarioId`、`apiCallCode`、`resultKey`のScopeが確定している。
5. Input、Context、Expectedの責務分離が確定している。
6. API呼出順序、分岐およびSkipの管理先が確定している。
7. Check順序と結果Identityの規則が確定している。
8. Scenario Outputの論理構造がファイル入出力設計へ引継ぎ可能である。
9. 全Validationおよび整合性規則が実装可能である。
10. 7業務FlowからScenarioを抽出できる。
11. Critical Open Issueがない。
12. Scenario Design Lead、Runtime LeadおよびBusiness Ownerがレビュー済みである。

## 21. Open Issues

| Issue ID | 論点 | 本書の暫定方針 | 確定先 |
|---|---|---|---|
| `SC-MST-ISSUE-001` | Scenario Input／Expectedの正式物理配置 | `04_usecase_design`配下のScenario単位ファイルを参照する。 | Repository Structure／ファイル入出力設計 |
| `SC-MST-ISSUE-002` | `executionClass`を1 Scenario 1 Classに限定するか | Class共有を許容するが、Scenarioごとの経路分離を必須とする。 | 共通Framework設計 |
| `SC-MST-ISSUE-003` | Output物理Pathとファイル名 | 本書14章を論理構造とし、物理構造は後続設計で確定する。 | ファイル入出力設計 |
| `SC-MST-ISSUE-004` | 対応表に`callSequence`を保持するか | Traceability Viewとして保持可能だが、実行仕様の正本はScenario詳細設計とする。 | API・UseCase・Scenario対応表設計書 |

## 22. 次工程

本書の次に次を実施する。

1. `API・UseCase・Scenario対応表設計書.md`を新しいTraceabilityモデルに基づき全面再作成する。
2. `Scenario_Master.md`を本書の正式10項目に従って再作成する。
3. `Scenario_Master_Example.md`を再作成する。
4. Master共通設計書、作成・更新GuideおよびChecklistへ本書の責務境界を反映する。
5. Input／Expected／Outputの物理配置をRepository Structureおよびファイル入出力設計で確定する。
