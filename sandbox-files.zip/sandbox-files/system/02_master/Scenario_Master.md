---
title: Scenario Master
document_id: MST-E6-SC-001
version: 2.0.0
status: Draft
document_type: Master
system_name: E6 API Verification Platform
updated: 2026-07-25
---

# Scenario Master

## 1. 文書目的

本書は、E6 API Verification Platformで実行する確定した業務経路をScenario単位で識別し、所属UseCase、Scenario種別、Java実行Classおよび実行資産参照を一元管理する正本である。

本書の設計規則は、`system/02_master/design/Scenario_Master設計書.md`に従う。

## 2. 管理原則

1. 1 Scenarioは、開始条件、API呼出経路および期待終了状態が確定した1つの業務実行経路を表す。
2. 1 Scenarioは、1回の同期Java Batch実行単位とする。
3. API呼出明細、`apiCallCode`、呼出順序、分岐およびSkipはScenario詳細設計書とJava実装で管理する。
4. 単一フィールドの必須、型、桁数または固定値Checkだけを理由にScenarioを分割しない。
5. 実装・Input・Expected・詳細設計が未確定のScenarioは`enabled=false`とし、実行対象に含めない。

## 3. 正式Scenario一覧

| scenarioId | useCaseId | scenarioName | scenarioType | executionClass | inputRef | expectedRef | scenarioDesignRef | enabled | description |
|---|---|---|---|---|---|---|---|:---:|---|
| SC-E6-001 | UC-E6-001 | 会員情報更新正常経路 | NORMAL | com.example.e6.scenario.MemberUpdateScenario | system/04_usecase_design/input/SC-E6-001-input.json | system/04_usecase_design/expected/SC-E6-001-expected.json | system/04_usecase_design/scenario/SC-E6-001設計書.md | true | 会員情報を取得し、状態更新後に再照会して更新結果およびAPI間整合性を確認する。 |
| SC-E6-002 | UC-E6-001 | 更新対象会員不存在経路 | ALTERNATIVE | com.example.e6.scenario.MemberUpdateTargetNotFoundScenario | system/04_usecase_design/input/SC-E6-002-input.json | system/04_usecase_design/expected/SC-E6-002-expected.json | system/04_usecase_design/scenario/SC-E6-002設計書.md | false | 更新対象会員が存在しない場合に更新APIを実行せず、想定した業務結果で終了する。 |
| SC-E6-003 | UC-E6-001 | 会員状態更新Timeout経路 | TIMEOUT | com.example.e6.scenario.MemberUpdateTimeoutScenario | system/04_usecase_design/input/SC-E6-003-input.json | system/04_usecase_design/expected/SC-E6-003-expected.json | system/04_usecase_design/scenario/SC-E6-003設計書.md | false | 会員状態更新APIのTimeout時に後続処理を停止し、未実行StepとScenario結果を正しく記録する。 |

## 4. 実行可否

| scenarioId | Java Class | Input | Expected | 詳細設計 | enabled | 判定 |
|---|---|---|---|---|:---:|---|
| SC-E6-001 | 設計上確定 | 参照先作成待ち | 参照先作成待ち | 参照先作成待ち | true | 実装・資産作成後にBuild Validationを実施 |
| SC-E6-002 | Class名候補 | 未作成 | 未作成 | 未作成 | false | 実行不可 |
| SC-E6-003 | Class名候補 | 未作成 | 未作成 | 未作成 | false | 実行不可 |

`enabled=true`は業務上の対象状態を表す。実際の実行開始前には、Java Classと全参照資産の存在をBuild Validationで確認する。

## 5. SC-E6-001呼出概要

本節は追跡確認用の要約であり、呼出定義の正本ではない。正本はScenario詳細設計書とする。

| callSequence | apiCallCode | apiId | 呼出目的 | 実行条件 |
|---:|---|---|---|---|
| 10 | CALL-001 | API-001 | 更新前会員情報取得 | ALWAYS |
| 20 | CALL-002 | API-002 | 会員状態更新 | CALL-001が業務正常 |
| 30 | CALL-003 | API-001 | 更新後会員情報再取得 | CALL-002が更新成功 |

同一APIである`API-001`を2回呼び出すが、API Masterには1レコードだけを登録する。

## 6. 参照整合性

| Validation ID | 確認内容 | 現在の判定 |
|---|---|---|
| SC-MST-V001 | 正式10項目がすべて設定されていること。 | PASS |
| SC-MST-V002 | `scenarioId`が`SC-E6-NNN`形式で一意であること。 | PASS |
| SC-MST-V003 | `useCaseId`がUseCase Masterで解決できること。 | PASS |
| SC-MST-V004 | UseCase Masterの`scenarioIds`と逆参照が一致すること。 | PASS |
| SC-MST-V005 | `scenarioType`が標準Enumであること。 | PASS |
| SC-MST-V006 | `executionClass`が完全修飾名であること。 | PASS（Class存在はBuild確認待ち） |
| SC-MST-V007 | 有効ScenarioのInput／Expected／設計書参照が解決できること。 | 参照先作成待ち |
| SC-MST-V008 | Scenario詳細設計の全`apiId`がAPI Masterで解決できること。 | SC-E6-001はPASS |

## 7. Scenario種別使用状況

| scenarioType | 件数 | 対象 |
|---|---:|---|
| NORMAL | 1 | SC-E6-001 |
| ALTERNATIVE | 1 | SC-E6-002 |
| TIMEOUT | 1 | SC-E6-003 |

未使用の標準種別は、必要な業務経路が正式化された時点で追加する。

## 8. 管理対象外

| 管理対象外情報 | 正式な定義・実装先 |
|---|---|
| API呼出順序、`apiCallCode`、呼出条件、Skip条件 | Scenario詳細設計書 |
| Request生成、前後APIの値引継ぎ | Scenario Java実装 |
| API Request／Response項目定義 | API詳細設計書、Java DTO |
| Expected値、`resultKey` | Scenario Expected、Java Check |
| Business Check、Cross-API Check | Scenario Java実装 |
| `IGNORE_FIELD`、`IGNORE_VALUE` | Java比較定義 |
| Previous／Current／Baseline実体 | Runtime出力 |

## 9. 変更管理

- 開始条件、API経路または期待終了状態が異なる場合は、新しいScenarioを追加する。
- フィールドCheckの追加だけではScenarioを追加しない。
- Scenario追加・廃止時は、同一変更単位でUseCase Masterの`scenarioIds`を更新する。
- 実行Class、Input、Expectedまたは詳細設計が未完成の場合は`enabled=false`とする。
- 廃止したScenarioは原則として物理削除しない。

## 10. 要確認事項

| Issue ID | 確認事項 | 影響 | 確認元 | 状態 |
|---|---|---|---|---|
| SC-MST-ISSUE-001 | SC-E6-001のJava packageおよびClass実体 | 実行可否 | Java実装 | Open |
| SC-MST-ISSUE-002 | Input／Expected／Scenario詳細設計の正式配置 | 参照解決 | Repository Structure | Open |
| SC-MST-ISSUE-003 | SC-E6-002を業務正常終了、WARNまたはFAILのどれにするか | Expected／Report | 業務担当 | Open |
| SC-MST-ISSUE-004 | SC-E6-003のTimeout、Retryおよび停止条件 | 実行制御 | API仕様／共通Framework | Open |
| SC-MST-ISSUE-005 | 残り6業務FlowのScenario抽出 | Scenario Coverage | BA分析書×Scenario一覧 | Open |

## 11. 改訂履歴

| 版数 | 日付 | 変更内容 |
|---|---|---|
| 2.0.0 | 2026-07-25 | 新Scenario Master設計の正式10項目に再構成し、Java First実行単位と参照境界を反映。 |
