# Sandbox ??????

- ????: 18/18

1. API_Master設計書.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/design/API_Master設計書.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\design\API_Master設計書.md`
   - bytes: `21134`
2. UseCase_Master設計書.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/design/UseCase_Master設計書.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\design\UseCase_Master設計書.md`
   - bytes: `27431`
3. Scenario_Master設計書.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/design/Scenario_Master設計書.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\design\Scenario_Master設計書.md`
   - bytes: `35290`
4. API・UseCase・Scenario対応表設計書.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/design/API・UseCase・Scenario対応表設計書.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\design\API・UseCase・Scenario対応表設計書.md`
   - bytes: `32140`
5. E6_API_Master.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/E6_API_Master.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\E6_API_Master.md`
   - bytes: `5361`
6. UseCase_Master.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/UseCase_Master.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\UseCase_Master.md`
   - bytes: `5661`
7. Scenario_Master.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/Scenario_Master.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\Scenario_Master.md`
   - bytes: `6897`
8. API_UseCase_Scenario対応表.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/API_UseCase_Scenario対応表.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\API_UseCase_Scenario対応表.md`
   - bytes: `7973`
9. E6_API_Master_Example.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/examples/E6_API_Master_Example.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\examples\E6_API_Master_Example.md`
   - bytes: `5886`
10. UseCase_Master_Example.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/examples/UseCase_Master_Example.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\examples\UseCase_Master_Example.md`
   - bytes: `7245`
11. Scenario_Master_Example.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/examples/Scenario_Master_Example.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\examples\Scenario_Master_Example.md`
   - bytes: `8465`
12. API_UseCase_Scenario対応表_Example.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/examples/API_UseCase_Scenario対応表_Example.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\examples\API_UseCase_Scenario対応表_Example.md`
   - bytes: `8839`
13. Master共通設計書.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/design/Master共通設計書.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\design\Master共通設計書.md`
   - bytes: `29779`
14. Master作成・更新ガイド.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/guide/Master作成・更新ガイド.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\guide\Master作成・更新ガイド.md`
   - bytes: `17395`
15. Master_ID・Reference記述ガイド.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/guide/Master_ID・Reference記述ガイド.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\guide\Master_ID・Reference記述ガイド.md`
   - bytes: `15418`
16. MasterレビューChecklist.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/checklist/MasterレビューChecklist.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\checklist\MasterレビューChecklist.md`
   - bytes: `15688`
17. Master整合性Checklist.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/checklist/Master整合性Checklist.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\checklist\Master整合性Checklist.md`
   - bytes: `23709`
18. README.md - downloaded
   - sandbox: `/workspace/scratch/3c2ff987d456/system/02_master/README.md`
   - local: `C:\Users\sakae\Documents\chatpgt2md\chatgpt-md-export\文件分析与总结__6a6469d2-cd90-83ee-b55d-a0dbdb234acd\sandbox-files\system\02_master\README.md`
   - bytes: `11055`
